# Workouts 1.2.1 — focused food search

- Default searches show common foods before packaged variants and collapse food families into representative choices. Show all matches retains preparations and brands; brand-specific searches and barcode lookup remain available.
- Single-letter searches match the start of the friendly food name, with an editorial familiarity order (B begins with Burger, Banana, Bread). This is curated ordering, not measured global popularity.
- Display aliases preserve original USDA identifiers, source descriptions and nutrients. Food Details shows the original source entry whenever an alias is used.
- Category-only substring matches no longer pollute results. Specific word-prefix queries still find preparations, ingredients and brands.
- Existing foods, favorites, recipes and diary history are preserved.
