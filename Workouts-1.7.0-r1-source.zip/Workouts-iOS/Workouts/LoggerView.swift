import SwiftUI

struct LoggerView: View {
    @EnvironmentObject var store: TrainingStore
    @Environment(\.dismiss) var dismiss
    @State private var picker = false
    @State private var finish = false
    @State private var discard = false
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading,spacing: 18) {
                    if let active = store.state?.active {
                        HStack { Label("Cycle \(active.cycle)",systemImage: "calendar"); Spacer(); TimelineView(.periodic(from: .now,by: 1)) { timeline in Text(parseDate(active.started),style: .relative).monospacedDigit() } }.font(.subheadline).foregroundStyle(.secondary)
                        if active.deload { Label("Lighter workout",systemImage: "leaf").font(.subheadline).foregroundStyle(.green) }
                        ForEach(Array(active.items.enumerated()),id: \.offset) { index, item in
                            ExerciseLogCard(item: item,index: index)
                        }
                        Button { Haptics.tick(); picker = true } label: { Label("Add Exercise",systemImage: "plus").frame(maxWidth: .infinity).padding(18).card() }.buttonStyle(.plain)
                        if !active.items.isEmpty { PrimaryButton(label: "Finish Workout") { Haptics.tick(); finish = true } }
                    }
                }.padding(16)
            }.background(Palette.background).navigationTitle(store.state?.active?.name ?? "Workout").navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) { Button { Haptics.tick(); dismiss() } label: { Image(systemName: "chevron.down").frame(width: 36,height: 36) }.accessibilityLabel("Minimize workout") }
                    ToolbarItem(placement: .primaryAction) { Button("Discard",role: .destructive) { Haptics.tick(); discard = true } }
                    ToolbarItemGroup(placement: .keyboard) { Spacer(); Button("Done") { Haptics.tick(); UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil,from: nil,for: nil) } }
                }
                .safeAreaInset(edge: .bottom) {
                    if let end = store.restEnd {
                        TimelineView(.periodic(from: .now,by: 1)) { time in
                            HStack { Image(systemName: "timer"); Text(time.date < end ? "Rest · \(max(0,Int(ceil(end.timeIntervalSince(time.date)))))s" : "Rest complete").monospacedDigit(); Spacer(); Button("Skip") { Haptics.tick(); store.cancelRest() } }.font(.headline).padding(16).background(Palette.surface).overlay(alignment: .top) { Divider() }
                        }
                    }
                }
                .sheet(isPresented: $picker) { ExerciseLibraryView(onSelect: { e in if store.send("addExercise",["id": e.id],haptic: true) { picker = false } }) }
                .confirmationDialog("Finish this workout? Only completed sets are saved.",isPresented: $finish,titleVisibility: .visible) { Button("Finish Workout") { if store.send("finish",haptic: true) { store.cancelRest(); dismiss() } } }
                .confirmationDialog("Discard this unfinished workout?",isPresented: $discard,titleVisibility: .visible) { Button("Discard Workout",role: .destructive) { if store.send("discard",haptic: true) { store.cancelRest(); dismiss() } } }
                .alert("Workouts",isPresented: Binding(get: { store.error != nil },set: { if !$0 { store.error = nil } })) { Button("OK",role: .cancel) { Haptics.tick(); store.error = nil } } message: { Text(store.error ?? "") }
        }
    }
}
struct ExerciseLogCard: View {
    @EnvironmentObject var store: TrainingStore
    let item: SessionExercise
    let index: Int
    @State private var showInstructions = false
    @State private var remove = false
    @State private var note = ""
    @State private var guidanceExpanded = false
    private var exercise: Exercise? { store.exercise(item.target.id) }
    var body: some View {
        VStack(alignment: .leading,spacing: 14) {
            HStack(alignment: .top) {
                Button { Haptics.tick(); showInstructions = true } label: { VStack(alignment: .leading,spacing: 5) { Text(exercise?.name ?? item.target.id).font(.headline).multilineTextAlignment(.leading); Text("\(item.target.min)–\(item.target.max) reps · \(item.target.rir) RIR · \(item.target.rest)s rest").font(.caption).foregroundStyle(.secondary) } }.buttonStyle(.plain)
                Spacer(minLength: 0)
                Menu { Button("Remove Exercise",role: .destructive) { Haptics.tick(); remove = true } } label: { Image(systemName: "ellipsis").frame(width: 36,height: 36) }.simultaneousGesture(TapGesture().onEnded { Haptics.tick() })
            }
            HStack(spacing: 6) { Text("Set").frame(width: 30); Text("lb").frame(maxWidth: .infinity); Text(exercise?.metric == "time" ? "Seconds" : "Reps").frame(maxWidth: .infinity); Text("RIR").frame(width: 45); Image(systemName: "checkmark").frame(width: 42) }.font(.caption).foregroundStyle(.secondary)
            ForEach(Array(item.sets.enumerated()),id: \.offset) { position, set in
                SetRow(itemIndex: index,setIndex: position,set: set,timed: exercise?.metric == "time")
            }
            if let recs = store.analysis?.recommendations, recs.indices.contains(index), let rec = recs[index].first {
                DisclosureGroup(isExpanded: Binding(get: { guidanceExpanded }, set: { guidanceExpanded = $0; Haptics.tick() })) {
                    VStack(alignment: .leading,spacing: 6) { Text(rec.reason); ForEach(rec.details,id: \.self) { Text($0) }; if let warning = rec.warning { Text(warning).foregroundStyle(.orange) } }.font(.caption).foregroundStyle(.secondary).padding(.top,6)
                } label: { Label("\(rec.confidence) · Set guidance",systemImage: "sparkles").font(.caption) }
            }
            Button { _ = store.send("addSet",["item": index],haptic: true) } label: { Label("Add Set",systemImage: "plus").frame(maxWidth: .infinity).padding(.vertical,8) }.buttonStyle(.plain)
            TextField("Exercise note",text: $note,axis: .vertical).font(.subheadline).lineLimit(1...4).onChange(of: note) { _, value in if value != item.note { _ = store.send("note",["item": index,"note": String(value.prefix(2000))]) } }.onAppear { note = item.note }
        }.padding(16).card().sheet(isPresented: $showInstructions) { if let exercise { ExerciseDetailView(exercise: exercise) } }
            .confirmationDialog("Remove this exercise and its sets?",isPresented: $remove,titleVisibility: .visible) { Button("Remove",role: .destructive) { _ = store.send("removeExercise",["item": index],haptic: true) } }
    }
}
struct SetRow: View {
    @EnvironmentObject var store: TrainingStore
    let itemIndex: Int; let setIndex: Int; let set: LoggedSet; let timed: Bool
    @State private var remove = false
    var body: some View {
        HStack(spacing: 6) {
            Menu {
                ForEach(["Work","Warm-up","Drop","Failure","Myo","Partial"],id: \.self) { kind in Button(kind) { update(["kind": kind],haptic: true) } }
                Button("Delete Set",role: .destructive) { Haptics.tick(); remove = true }
            } label: { Text(set.kind == "Work" ? "\(setIndex+1)" : String(set.kind.prefix(1))).font(.subheadline.weight(.semibold)).frame(width: 30,height: 44) }.simultaneousGesture(TapGesture().onEnded { Haptics.tick() }).accessibilityLabel("Set \(setIndex+1), \(set.kind). Change type")
            NumberEntry(value: set.weight, label: "Weight in pounds", maximum: 3000) { update(["weight": $0]) }.disabled(set.done)
            NumberEntry(value: timed ? set.seconds ?? 0 : Double(set.reps),label: timed ? "Seconds" : "Repetitions",maximum: timed ? 86400 : 200,integer: !timed) { update(timed ? ["seconds": $0] : ["reps": Int($0)]) }.disabled(set.done)
            Menu { ForEach(0...6,id: \.self) { rir in Button("\(rir) RIR") { update(["rir": rir,"kind": set.kind == "Failure" && rir > 0 ? "Work" : set.kind],haptic: true) } } } label: { Text("\(set.rir)").font(.subheadline).frame(width: 45,height: 44).background(Palette.control,in: RoundedRectangle(cornerRadius: 7)) }.disabled(set.done).simultaneousGesture(TapGesture().onEnded { Haptics.tick() })
            Button { UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder),to: nil,from: nil,for: nil); store.complete(item: itemIndex,set: setIndex) } label: { Image(systemName: set.done ? "checkmark.circle.fill" : "circle").font(.system(size: 26)).foregroundStyle(set.done ? Palette.blue : Color.secondary).frame(width: 42,height: 44) }.buttonStyle(.plain).accessibilityLabel(set.done ? "Uncheck set \(setIndex+1)" : "Complete set \(setIndex+1)")
        }.opacity(set.done ? 0.75 : 1)
            .confirmationDialog("Delete this set?",isPresented: $remove,titleVisibility: .visible) { Button("Delete Set",role: .destructive) { _ = store.send("removeSet",["item": itemIndex,"set": setIndex],haptic: true) } }
    }
    private func update(_ values: [String: Any],haptic: Bool = false) { _ = store.send("set",["item": itemIndex,"set": setIndex,"values": values],haptic: haptic) }
}
struct NumberEntry: View {
    let value: Double; let label: String; var maximum: Double; var integer = false
    let change: (Double) -> Void
    @State private var text = ""
    @FocusState private var focused: Bool
    var body: some View {
        TextField("0",text: $text).keyboardType(integer ? .numberPad : .decimalPad).multilineTextAlignment(.center).font(.subheadline.monospacedDigit()).frame(maxWidth: .infinity).frame(height: 44).background(Palette.control,in: RoundedRectangle(cornerRadius: 7)).focused($focused).accessibilityLabel(label)
            .onAppear { text = display(value) }
            .onChange(of: value) { _, new in if !focused { text = display(new) } }
            .onChange(of: text) { _, raw in
                if raw.isEmpty { if value != 0 { change(0) }; return }
                if let number = Double(raw.replacingOccurrences(of: ",",with: ".")), number.isFinite {
                    let bounded = min(maximum,max(0,integer ? number.rounded() : number))
                    if bounded != value { change(bounded) }
                    if bounded != number { text = display(bounded) }
                }
            }
            .onChange(of: focused) { _, isFocused in if isFocused { Haptics.tick() } else { text = display(value) } }
    }
    private func display(_ number: Double) -> String { number.formatted(.number.grouping(.never).precision(.fractionLength(0...2))) }
}
