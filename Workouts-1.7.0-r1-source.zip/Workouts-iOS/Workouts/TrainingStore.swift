import Foundation
import JavaScriptCore
import SwiftUI
import UniformTypeIdentifiers
import UserNotifications

@MainActor
final class TrainingStore: ObservableObject {
    @Published private(set) var state: TrainingState?
    @Published private(set) var analysis: Analysis?
    @Published var error: String?
    @Published var tab = 0
    @Published var showLogger = false
    @Published var overview: WorkoutRoute?
    var pendingOverviewStart: Int?
    @Published var restEnd: Date?
    @Published var days = 7 { didSet { refreshAnalysis() } }
    @Published var startupBlocked = false
    private(set) var exercises: [Exercise] = []
    private var stateJSON = ""
    private var context: JSContext?
    private var scriptError: String?
    private var directory: URL {
        #if DEBUG
        if let test = ProcessInfo.processInfo.environment["WORKOUTS_WORKOUT_TEST"] { return FileManager.default.temporaryDirectory.appendingPathComponent("WorkoutUITest-" + test,isDirectory: true) }
        #endif
        return FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("Workouts", isDirectory: true)
    }
    private var stateURL: URL { directory.appendingPathComponent("training-v1.json") }
    private var previousURL: URL { directory.appendingPathComponent("training-v1.previous.json") }
    var catalog: [Exercise] { exercises + (state?.custom ?? []) }

    init() {
        do {
            guard let context = JSContext() else { throw AppError("Could not start the workout engine.") }
            self.context = context
            context.exceptionHandler = { [weak self] _, value in self?.scriptError = value?.toString() ?? "Workout engine error." }
            let uuid: @convention(block) () -> String = { UUID().uuidString.lowercased() }
            context.setObject(uuid, forKeyedSubscript: "nativeUUID" as NSString)
            context.evaluateScript("var crypto = {randomUUID: function(){return nativeUUID();}};")
            guard let url = Bundle.main.url(forResource: "engine", withExtension: "js") else { throw AppError("Workout engine is missing from this build.") }
            context.evaluateScript(try String(contentsOf: url, encoding: .utf8))
            if let scriptError { throw AppError(scriptError) }
            let bootstrap = try invoke("bootstrap", arguments: [])
            let boot = try JSONDecoder().decode(Bootstrap.self, from: Data(bootstrap.utf8))
            exercises = boot.exercises
            let object = try JSONSerialization.jsonObject(with: Data(bootstrap.utf8)) as! [String: Any]
            stateJSON = String(decoding: try JSONSerialization.data(withJSONObject: object["state"]!), as: UTF8.self)
            if FileManager.default.fileExists(atPath: stateURL.path) {
                let disk = try JSONDecoder().decode(DiskState.self, from: Data(contentsOf: stateURL))
                guard disk.schemaVersion == 1 else { throw AppError("This data was saved by a newer app. Install the latest version; your data has not been changed.") }
                stateJSON = try validated(disk.stateJSON)
            }
            state = try JSONDecoder().decode(TrainingState.self, from: Data(stateJSON.utf8))
            if let end = UserDefaults.standard.object(forKey: "restEnd") as? Date, end > Date() { restEnd = end }
            refreshAnalysis()
        } catch {
            startupBlocked = true
            self.error = "Your saved file has been left untouched. \(error.localizedDescription)"
        }
    }
    func exercise(_ id: String) -> Exercise? { catalog.first { $0.id == id } }
    private func invoke(_ method: String, arguments: [Any]) throws -> String {
        scriptError = nil
        guard let result = context?.objectForKeyedSubscript("TrainingEngine")?.invokeMethod(method, withArguments: arguments),
              !result.isUndefined, !result.isNull, let text = result.toString() else {
            throw AppError(scriptError ?? "Workout engine did not respond.")
        }
        if let scriptError { throw AppError(scriptError) }
        return text
    }
    private func request(_ action: String, args: [String: Any], json: String? = nil) throws -> String {
        let value = try JSONSerialization.jsonObject(with: Data((json ?? stateJSON).utf8))
        let data = try JSONSerialization.data(withJSONObject: ["state": value, "action": action, "args": args])
        return try invoke("run", arguments: [String(decoding: data, as: UTF8.self)])
    }
    private func validated(_ json: String) throws -> String { try request("validate", args: [:], json: json) }
    @discardableResult
    func send(_ action: String, _ args: [String: Any] = [:], haptic: Bool = false) -> Bool {
        guard !startupBlocked else { return false }
        if haptic { Haptics.tick() }
        do {
            let result = try request(action, args: args)
            let decoded = try JSONDecoder().decode(TrainingState.self, from: Data(result.utf8))
            // Persist before publishing success. A failed disk write leaves the visible workout intact.
            try persist(result)
            stateJSON = result; state = decoded; refreshAnalysis()
            return true
        } catch { self.error = error.localizedDescription; return false }
    }
    private func persist(_ json: String) throws {
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        if FileManager.default.fileExists(atPath: stateURL.path) {
            let previous = try Data(contentsOf: stateURL)
            try previous.write(to: previousURL, options: .atomic)
        }
        try JSONEncoder().encode(DiskState(stateJSON: json)).write(to: stateURL, options: [.atomic, .completeFileProtectionUnlessOpen])
    }
    func refreshAnalysis() {
        guard !stateJSON.isEmpty, !startupBlocked else { return }
        do {
            let value = try JSONSerialization.jsonObject(with: Data(stateJSON.utf8))
            let input = try JSONSerialization.data(withJSONObject: ["state": value, "days": days])
            let result = try invoke("analyze", arguments: [String(decoding: input, as: UTF8.self)])
            analysis = try JSONDecoder().decode(Analysis.self, from: Data(result.utf8))
        } catch { self.error = error.localizedDescription }
    }
    func workoutPreview(_ day: Int) -> Session? {
        do {
            let value = try JSONSerialization.jsonObject(with: Data(stateJSON.utf8))
            let data = try JSONSerialization.data(withJSONObject: ["state": value, "day": day])
            let result = try invoke("preview", arguments: [String(decoding: data, as: UTF8.self)])
            return try JSONDecoder().decode(Session.self, from: Data(result.utf8))
        } catch { self.error = error.localizedDescription; return nil }
    }
    func openWorkout(_ day: Int, haptic: Bool = true) {
        if haptic { Haptics.tick() }
        overview = WorkoutRoute(id: day)
    }
    func start(_ day: Int, lighter: Bool = false, haptic: Bool = true) {
        if haptic { Haptics.tick() }
        if state?.active != nil { showLogger = true; return }
        if send("start", ["day": day, "lighter": lighter]) { showLogger = true }
    }
    func startEmpty(haptic: Bool = true) { if haptic { Haptics.tick() }; if send("empty") { showLogger = true } }
    func complete(item: Int, set: Int) {
        let wasDone = state?.active?.items[item].sets[set].done ?? false
        let rest = state?.active?.items[item].target.rest ?? 0
        if send("toggle", ["item": item,"set": set], haptic: true), !wasDone, rest > 0 { startRest(seconds: rest) }
    }
    func startRest(seconds: Int) {
        cancelRest()
        let end = Date().addingTimeInterval(Double(seconds))
        restEnd = end; UserDefaults.standard.set(end, forKey: "restEnd")
        guard UserDefaults.standard.bool(forKey: "restNotifications") else { return }
        let content = UNMutableNotificationContent(); content.title = "Rest complete"; content.body = "Ready for your next set."; content.sound = .default
        let request = UNNotificationRequest(identifier: "workouts-rest", content: content, trigger: UNTimeIntervalNotificationTrigger(timeInterval: Double(seconds), repeats: false))
        UNUserNotificationCenter.current().add(request) { [weak self] error in
            if let error { Task { @MainActor in self?.error = "Could not schedule the rest alert: \(error.localizedDescription)" } }
        }
    }
    func cancelRest() {
        restEnd = nil; UserDefaults.standard.removeObject(forKey: "restEnd")
        UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: ["workouts-rest"])
        UNUserNotificationCenter.current().removeDeliveredNotifications(withIdentifiers: ["workouts-rest"])
    }
    func setNotifications(_ enabled: Bool) async {
        Haptics.tick()
        if !enabled { UserDefaults.standard.set(false, forKey: "restNotifications"); UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: ["workouts-rest"]); objectWillChange.send(); return }
        do {
            let allowed = try await UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound])
            UserDefaults.standard.set(allowed, forKey: "restNotifications"); objectWillChange.send()
            if !allowed { error = "Rest alerts are disabled. You can enable notifications for Workouts in iPhone Settings." }
        } catch { self.error = error.localizedDescription }
    }
    func exportData() throws -> URL {
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("Workouts-backup-\(Date().formatted(.iso8601.year().month().day()))-\(UUID().uuidString.prefix(6)).json")
        // Plain state matches the existing web app's import/export format.
        try Data(stateJSON.utf8).write(to: url, options: .atomic)
        return url
    }
    func importData(_ url: URL) {
        let access = url.startAccessingSecurityScopedResource(); defer { if access { url.stopAccessingSecurityScopedResource() } }
        do {
            let size = try url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0
            guard size <= 25_000_000 else { throw AppError("Backup is too large (maximum 25 MB).") }
            let data = try Data(contentsOf: url)
            let object = try JSONSerialization.jsonObject(with: data)
            // Engine validates every nested field and merges IDs without duplicating history.
            _ = send("import", ["state": object], haptic: true)
        } catch { self.error = error.localizedDescription }
    }
}
struct AppError: LocalizedError { let message: String; init(_ message: String) { self.message = message }; var errorDescription: String? { message } }
@MainActor
enum Haptics {
    private static let selection = UISelectionFeedbackGenerator()
    static func prepare() { selection.prepare() }
    static func tick() {
        selection.selectionChanged()
        selection.prepare()
    }
}
struct ShareSheet: UIViewControllerRepresentable {
    let url: URL
    func makeUIViewController(context: Context) -> UIActivityViewController { UIActivityViewController(activityItems: [url], applicationActivities: nil) }
    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}
