import Foundation

actor InternationalFoodService {
    static let shared = InternationalFoodService()
    private var lastSearch = Date.distantPast
    func search(_ query: String) async throws -> [FoodItem] {
        let value = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard value.count >= 2,value.count <= 150 else { throw FoodScanError.message("Enter a food name, brand or barcode.") }
        guard Date().timeIntervalSince(lastSearch) >= 6 else { throw FoodScanError.message("Wait a few seconds before searching again.") }
        lastSearch = Date()
        let barcode = value.allSatisfy(\.isNumber) && (8...14).contains(value.count)
        var components = URLComponents(string: barcode ? "https://world.openfoodfacts.org/api/v2/product/\(value).json" : "https://search.openfoodfacts.org/search")!
        let fields = "code,product_name,product_name_en,brands,categories,nutriments,serving_quantity,serving_quantity_unit,serving_size,nutrition_data_per"
        components.queryItems = barcode ? [URLQueryItem(name: "fields",value: fields)] : [URLQueryItem(name: "q",value: value),URLQueryItem(name: "page_size",value: "25"),URLQueryItem(name: "fields",value: fields)]
        var request = URLRequest(url: components.url!); request.timeoutInterval = 20
        request.setValue("Workouts-iOS/1.2.0 (https://github.com/nonfiction2199/workouts-ios)",forHTTPHeaderField: "User-Agent")
        let (data,response) = try await URLSession.shared.data(for: request)
        try Task.checkCancellation()
        guard let http = response as? HTTPURLResponse,http.statusCode == 200,data.count <= 2_000_000 else { throw FoodScanError.message("International lookup is unavailable. Your offline food library still works.") }
        let object = try JSONSerialization.jsonObject(with: data) as? [String:Any] ?? [:]
        let products = barcode ? [object["product"] as? [String:Any]].compactMap { $0 } : object["hits"] as? [[String:Any]] ?? []
        return products.compactMap(Self.food)
    }
    static func food(_ product: [String:Any]) -> FoodItem? {
        guard product["nutrition_data_per"] as? String != "100ml" else { return nil }
        guard let code = product["code"] as? String,!code.isEmpty,code.count <= 30,let nutrients = product["nutriments"] as? [String:Any] else { return nil }
        func number(_ key: String) -> Double? {
            let n = (nutrients[key] as? NSNumber)?.doubleValue ?? (nutrients[key] as? String).flatMap(Double.init)
            return n.flatMap { $0.isFinite && $0 >= 0 && $0 <= 100000 ? $0 : nil }
        }
        guard let calories = number("energy-kcal_100g") ?? number("energy_100g").flatMap({ nutrients["energy_unit"] as? String == "kJ" ? $0 / 4.184 : nil }),let protein = number("proteins_100g"),let carbs = number("carbohydrates_100g"),let fat = number("fat_100g") else { return nil }
        let name = (product["product_name"] as? String).flatMap { $0.isEmpty ? nil : $0 } ?? product["product_name_en"] as? String ?? ""
        let fiber = number("fiber_100g")
        var food = FoodItem(id: "off-" + code,name: name,category: String((product["categories"] as? String ?? "Packaged food").prefix(200)),source: "Open Food Facts · community label data",referenceGrams: 100,macros: FoodMacros(calories: calories,protein: protein,carbs: carbs,fat: fat,fiber: fiber ?? 0),portions: [])
        let brand = product["brands"] as? String ?? (product["brands"] as? [String])?.joined(separator: ", ") ?? ""
        food.brand = String(brand.prefix(200)); food.barcode = code; food.fiberMissing = fiber == nil
        // A milliliter label serving must never be treated as a gram serving.
        if product["serving_quantity_unit"] as? String == "g",let grams = (product["serving_quantity"] as? NSNumber)?.doubleValue,grams > 0,grams <= 100000 {
            food.portions = [FoodPortion(name: String((product["serving_size"] as? String ?? "1 label serving").prefix(100)),grams: grams)]
        }
        return food.valid && calories <= 1000 && protein <= 105 && carbs <= 105 && fat <= 105 && (fiber ?? 0) <= 105 && protein + carbs + fat <= 110 ? food : nil
    }
}
