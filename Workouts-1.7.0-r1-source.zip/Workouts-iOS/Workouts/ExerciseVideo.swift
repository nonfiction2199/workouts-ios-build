import SwiftUI
import AVFoundation
import UniformTypeIdentifiers

struct ExerciseVideo: Decodable, Identifiable {
    let key: String
    let name: String
    let file: String
    let poster: String
    let author: String
    let source: String
    let license: String
    let licenseURL: String
    let changes: String
    var id: String { key }
    var url: URL? { Bundle.main.url(forResource: file, withExtension: nil) }
    static let library: [ExerciseVideo] = {
        guard let url = Bundle.main.url(forResource: "demo-library", withExtension: "json"), let data = try? Data(contentsOf: url) else { return [] }
        return (try? JSONDecoder().decode([ExerciseVideo].self, from: data)) ?? []
    }()
    static let matches: [String: String] = {
        guard let url = Bundle.main.url(forResource: "demo-matches", withExtension: "json"), let data = try? Data(contentsOf: url) else { return [:] }
        return (try? JSONDecoder().decode([String: String].self, from: data)) ?? [:]
    }()
    static func forExercise(_ exercise: Exercise) -> ExerciseVideo? {
        guard let key = matches[exercise.name.lowercased()] else { return nil }
        return library.first { $0.key == key && $0.url != nil }
    }
    static var customDirectory: URL {
        FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("ExerciseDemos", isDirectory: true)
    }
    static func customURL(_ id: String) -> URL? {
        guard let filename = UserDefaults.standard.string(forKey: "exerciseDemo.\(id)") else { return nil }
        let url = customDirectory.appendingPathComponent(filename)
        return FileManager.default.fileExists(atPath: url.path) ? url : nil
    }
    static func importVideo(_ source: URL, exerciseID: String) async throws -> URL {
        let accessed = source.startAccessingSecurityScopedResource()
        defer { if accessed { source.stopAccessingSecurityScopedResource() } }
        let asset = AVURLAsset(url: source)
        guard try await asset.load(.isPlayable), !(try await asset.loadTracks(withMediaType: .video)).isEmpty else { throw DemoError.invalid }
        try FileManager.default.createDirectory(at: customDirectory, withIntermediateDirectories: true)
        let destination = customDirectory.appendingPathComponent(UUID().uuidString + "." + source.pathExtension)
        try FileManager.default.copyItem(at: source, to: destination)
        let previous = customURL(exerciseID)
        UserDefaults.standard.set(destination.lastPathComponent, forKey: "exerciseDemo.\(exerciseID)")
        if let previous { try? FileManager.default.removeItem(at: previous) }
        return destination
    }
    enum DemoError: LocalizedError { case invalid; var errorDescription: String? { "This file does not contain a playable video. Choose an MP4 or MOV file." } }
}

final class DemoPlayerModel: ObservableObject {
    let player = AVQueuePlayer()
    private var looper: AVPlayerLooper?
    private var observation: NSKeyValueObservation?
    private var itemObservation: NSKeyValueObservation?
    @Published var failed = false
    @Published var ready = false
    @Published var progress = 0.0
    private var timeObserver: Any?
    var playbackRate: Float = 1
    func load(_ url: URL) {
        player.pause(); looper?.disableLooping(); player.removeAllItems()
        failed = false; ready = false; progress = 0
        if let timeObserver { player.removeTimeObserver(timeObserver) }
        timeObserver = player.addPeriodicTimeObserver(forInterval: CMTime(seconds: 0.1, preferredTimescale: 600), queue: .main) { [weak self] time in
            guard let self, let duration = self.player.currentItem?.duration.seconds, duration.isFinite, duration > 0 else { return }
            self.progress = min(1, max(0, time.seconds / duration))
        }
        let item = AVPlayerItem(url: url)
        observation = player.observe(\.currentItem, options: [.initial, .new]) { [weak self] player, _ in
            self?.itemObservation = player.currentItem?.observe(\.status, options: [.initial, .new]) { [weak self] item, _ in
                DispatchQueue.main.async { self?.failed = item.status == .failed; self?.ready = item.status == .readyToPlay }
            }
        }
        player.isMuted = true
        looper = AVPlayerLooper(player: player, templateItem: item)
    }
    func stop() { player.pause() }
    deinit { if let timeObserver { player.removeTimeObserver(timeObserver) }; player.pause(); looper?.disableLooping() }
}
private final class DemoSurface: UIView {
    override class var layerClass: AnyClass { AVPlayerLayer.self }
    var playerLayer: AVPlayerLayer { layer as! AVPlayerLayer }
}
private struct NativeDemoSurface: UIViewRepresentable {
    let player: AVQueuePlayer
    func makeUIView(context: Context) -> UIView { let view = DemoSurface(); view.playerLayer.videoGravity = .resizeAspect; view.playerLayer.player = player; return view }
    func updateUIView(_ uiView: UIView, context: Context) { (uiView as? DemoSurface)?.playerLayer.player = player }
    static func dismantleUIView(_ uiView: UIView, coordinator: ()) { (uiView as? DemoSurface)?.playerLayer.player = nil }
}
struct ExerciseDemoView: View {
    let exercise: Exercise
    @Environment(\.scenePhase) private var scenePhase
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @StateObject private var model = DemoPlayerModel()
    @State private var importing = false
    @State private var customURL: URL?
    @State private var paused = false
    @State private var speed: Float = 1
    @State private var error: String?
    private var demo: ExerciseVideo? { ExerciseVideo.forExercise(exercise) }
    private var url: URL? { customURL ?? ExerciseVideo.customURL(exercise.id) ?? demo?.url }
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            ZStack {
                Color.black
                if url != nil {
                    NativeDemoSurface(player: model.player)
                    if !model.ready && !model.failed { ProgressView().tint(.white) }
                    if model.failed { Text("This demonstration could not play.").foregroundStyle(.white) }
                } else {
                    VStack(spacing: 12) {
                        BodyMap(selected: exercise.muscle, thumbnail: true).frame(width: 105, height: 120)
                        Text("No matching demonstration yet").font(.subheadline).foregroundStyle(Palette.secondary)
                        Button("Add Video") { Haptics.tick(); importing = true }.font(.subheadline)
                    }
                }
            }.frame(height: 420)
                .overlay(alignment: .bottomLeading) {
                    if url != nil {
                        VStack(alignment: .leading, spacing: 18) {
                            HStack(spacing: 8) {
                                ForEach([Float(0.2), 0.5, 1], id: \.self) { rate in
                                    Button { Haptics.tick(); speed = rate; updatePlayback() } label: {
                                        Text(rate == 1 ? "1×" : rate == 0.5 ? "0.5×" : "0.2×").font(.system(size: 16, weight: .bold)).padding(7)
                                            .foregroundStyle(speed == rate ? Color.black : Color.white).background(speed == rate ? Color.white : Color.black.opacity(0.25), in: RoundedRectangle(cornerRadius: 4))
                                    }.accessibilityLabel("Playback speed \(rate)")
                                }
                            }
                            ProgressView(value: model.progress).tint(.white).background(.black.opacity(0.4))
                        }.padding(16).padding(.trailing, 50)
                    }
                }
                .overlay(alignment: .bottomTrailing) {
                    if url != nil && !model.failed {
                        Button { Haptics.tick(); paused.toggle(); updatePlayback() } label: {
                            Image(systemName: paused ? "play.fill" : "pause.fill").frame(width: 44,height: 44).background(.black.opacity(0.6),in: Circle())
                        }.foregroundStyle(.white).padding(16).padding(.bottom, 12).accessibilityLabel(paused ? "Play demonstration" : "Pause demonstration")
                    }
                }
            if url != nil {
                HStack {
                    Text(customURL != nil || ExerciseVideo.customURL(exercise.id) != nil ? "Your demonstration" : "\(demo?.author ?? "") · \(demo?.license ?? "")").font(.caption).foregroundStyle(Palette.secondary)
                    Spacer()
                    Button { Haptics.tick(); importing = true } label: { Image(systemName: "square.and.arrow.down") }.accessibilityLabel("Replace demonstration from Files")
                }.padding(.horizontal, 16)
            }
        }
        .task(id: url) { if let url { model.load(url); paused = reduceMotion; updatePlayback() } }
        .onDisappear { model.stop() }
        .onChange(of: scenePhase) { updatePlayback() }
        .onChange(of: reduceMotion) { paused = reduceMotion; updatePlayback() }
        .fileImporter(isPresented: $importing, allowedContentTypes: [.movie, .mpeg4Movie, .quickTimeMovie]) { result in
            Task { do { customURL = try await ExerciseVideo.importVideo(try result.get(), exerciseID: exercise.id) } catch { self.error = error.localizedDescription } }
        }
        .alert("Video Import", isPresented: Binding(get: { error != nil }, set: { if !$0 { error = nil } })) { Button("OK",role: .cancel) { error = nil } } message: { Text(error ?? "") }
    }
    private func updatePlayback() { if scenePhase == .active && !paused { model.player.playImmediately(atRate: speed) } else { model.player.pause() } }
}
struct DemoCreditsView: View {
    var body: some View {
        List {
            Section { Text("Demonstrations by Goulart, distributed through wger under Creative Commons Attribution-ShareAlike 4.0. These are independent demonstrations, not Jeff Nippard or MacroFactor videos."); Link("License: CC BY-SA 4.0",destination: URL(string: "https://creativecommons.org/licenses/by-sa/4.0/")!) }
            ForEach(ExerciseVideo.library) { demo in
                Section(demo.name) { Text("\(demo.author) · \(demo.license)"); Text(demo.changes).font(.footnote); if let url = URL(string: demo.source) { Link("Original video",destination: url) } }
            }
            Section { Text("Imported demonstrations stay on this iPhone and are separate from workout JSON backups.").font(.footnote) }
        }.darkForm().navigationTitle("Demonstration Credits").navigationBarTitleDisplayMode(.inline)
    }
}
