import SwiftUI
import PhotosUI

// Device-only measurements and progress photos. These files are independent of
// training state and are never sent to a server or used for load suggestions.
enum UtilityKind: String, Identifiable { case weight, metrics, photos; var id: String { rawValue }; var title: String { switch self { case .weight: return "Weight"; case .metrics: return "Measurements"; case .photos: return "Progress Photos" } } }
struct BodyRecord: Codable, Identifiable {
    var id: String
    var weight: Double?
    var bodyFat: Double?
    var waist: Double?
    var photos: [String: String] = [:]
}
@MainActor
final class UtilityStore: ObservableObject {
    @Published private(set) var records: [BodyRecord] = []
    @Published var error: String?
    private var readable = true
    private var directory: URL { FileManager.default.urls(for: .applicationSupportDirectory,in: .userDomainMask)[0].appendingPathComponent("BodyRecords",isDirectory: true) }
    private var file: URL { directory.appendingPathComponent("records-v1.json") }
    init() { reload() }
    func reload() {
        guard FileManager.default.fileExists(atPath: file.path) else { return }
        do { records = try JSONDecoder().decode([BodyRecord].self,from: Data(contentsOf: file)) } catch { readable = false; self.error = "Saved measurements could not be read. Your file has not been changed." }
    }
    func record(_ date: Date) -> BodyRecord { let key = date.formatted(.iso8601.year().month().day().dateSeparator(.dash)); return records.first { $0.id == key } ?? BodyRecord(id: key) }
    func photo(_ filename: String) -> URL { directory.appendingPathComponent(filename) }
    func save(_ record: BodyRecord,photos: [String: Data] = [:]) -> Bool {
        guard readable else { error = "Cannot overwrite an unreadable saved file."; return false }
        do {
            try FileManager.default.createDirectory(at: directory,withIntermediateDirectories: true)
            var value = record
            for (side,data) in photos {
                let name = "\(UUID().uuidString).jpg"
                try data.write(to: photo(name),options: [.atomic,.completeFileProtectionUnlessOpen]); value.photos[side] = name
            }
            var next = records.filter { $0.id != value.id }; next.append(value); next.sort { $0.id > $1.id }
            try JSONEncoder().encode(next).write(to: file,options: [.atomic,.completeFileProtectionUnlessOpen]); records = next; return true
        } catch { self.error = error.localizedDescription; return false }
    }
    func remove(_ date: Date,kind: UtilityKind) -> Bool {
        var value = record(date)
        switch kind { case .weight: value.weight = nil; case .metrics: value.bodyFat = nil; value.waist = nil; case .photos: value.photos = [:] }
        let oldPhotos = record(date).photos
        guard save(value) else { return false }
        if kind == .photos { for filename in oldPhotos.values { try? FileManager.default.removeItem(at: photo(filename)) } }
        return true
    }
}
struct UtilityView: View {
    let kind: UtilityKind
    @Environment(\.dismiss) var dismiss
    @StateObject private var records = UtilityStore()
    @State private var date = Date()
    @State private var weight = ""
    @State private var bodyFat = ""
    @State private var waist = ""
    @State private var photos: [String: Data] = [:]
    @State private var confirmDelete = false
    private let sides = ["Front","Side","Back"]
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 24) {
                    DatePicker("Date",selection: $date,displayedComponents: .date).datePickerStyle(.compact).onChange(of: date) { Haptics.tick(); load() }
                    if kind == .photos {
                        HStack(spacing: 16) {
                            ForEach(sides,id: \.self) { side in
                                PhotoSlot(title: side,data: photos[side],existing: records.record(date).photos[side].map { records.photo($0) }) { data in photos[side] = data }
                            }
                        }
                        Text("Photos are saved privately on this iPhone. Keep the originals in Photos; workout JSON backups do not include images.").font(.footnote).foregroundStyle(.secondary)
                    } else if kind == .weight {
                        field("Weight (lb)",text: $weight)
                    } else {
                        field("Body fat (%)",text: $bodyFat); field("Waist (inches)",text: $waist)
                    }
                    PrimaryButton(label: "Save") { save() }
                    if kind != .photos {
                        VStack(alignment: .leading,spacing: 16) {
                            SectionHeading(title: "Recent Entries")
                            ForEach(records.records.filter { kind == .weight ? $0.weight != nil : ($0.bodyFat != nil || $0.waist != nil) }.prefix(12)) { record in
                                HStack { Text(record.id); Spacer(); Text(kind == .weight ? "\((record.weight ?? 0).short) lb" : "\(record.bodyFat.map { $0.short + "%" } ?? "––") · \(record.waist.map { $0.short + " in" } ?? "––")").foregroundStyle(.secondary) }; Divider()
                            }
                        }
                    }
                }.padding(20)
            }.background(Palette.surface).navigationTitle(kind.title).navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .cancellationAction) { Button { Haptics.tick(); dismiss() } label: { Image(systemName: "xmark") } }; ToolbarItem(placement: .primaryAction) { Button { Haptics.tick(); confirmDelete = true } label: { Image(systemName: "trash") }.accessibilityLabel("Delete this day's entry") }; ToolbarItemGroup(placement: .keyboard) { Spacer(); Button("Done") { Haptics.tick(); UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder),to: nil,from: nil,for: nil) } } }
                .onAppear { load() }
                .alert("Measurements",isPresented: Binding(get: { records.error != nil },set: { if !$0 { records.error = nil } })) { Button("OK",role: .cancel) { records.error = nil } } message: { Text(records.error ?? "") }
                .confirmationDialog("Delete this entry for the selected date?",isPresented: $confirmDelete,titleVisibility: .visible) { Button("Delete",role: .destructive) { Haptics.tick(); if records.remove(date,kind: kind) { load() } } }
        }.presentationDetents([.medium,.large]).presentationDragIndicator(.visible)
    }
    private func field(_ label: String,text: Binding<String>) -> some View { VStack(alignment: .leading,spacing: 10) { Text(label).font(.headline); TextField("Enter value",text: text).keyboardType(.decimalPad).font(.title).padding(16).background(Palette.control,in: RoundedRectangle(cornerRadius: 10)) } }
    private func load() { let record = records.record(date); weight = record.weight?.short ?? ""; bodyFat = record.bodyFat?.short ?? ""; waist = record.waist?.short ?? ""; photos = [:] }
    private func save() {
        Haptics.tick(); var record = records.record(date)
        func number(_ text: String,_ range: ClosedRange<Double>) -> Double? { guard let n = Double(text.replacingOccurrences(of: ",",with: ".")), n.isFinite, range.contains(n) else { return nil }; return n }
        switch kind {
        case .weight: guard let n = number(weight,1...2000) else { records.error = "Enter a valid weight in pounds."; return }; record.weight = n
        case .metrics:
            guard bodyFat.isEmpty || number(bodyFat,0...100) != nil, waist.isEmpty || number(waist,1...200) != nil else { records.error = "Enter a valid percentage or waist measurement."; return }
            record.bodyFat = number(bodyFat,0...100); record.waist = number(waist,1...200)
        case .photos: guard !photos.isEmpty else { records.error = "Choose at least one photo."; return }
        }
        if records.save(record,photos: photos) { dismiss() }
    }
}
struct PhotoSlot: View {
    let title: String; let data: Data?; let existing: URL?; let changed: (Data) -> Void
    @State private var item: PhotosPickerItem?
    @State private var error: String?
    private var image: UIImage? { if let data { return UIImage(data: data) }; if let existing { return UIImage(contentsOfFile: existing.path) }; return nil }
    var body: some View {
        VStack(spacing: 8) {
            Text(title).font(.subheadline.bold())
            PhotosPicker(selection: $item,matching: .images) {
                ZStack { RoundedRectangle(cornerRadius: 10).fill(Palette.control); if let image { Image(uiImage: image).resizable().scaledToFill() } else { Image(systemName: "figure.stand").font(.title).foregroundStyle(.secondary) } }.frame(height: 100).frame(maxWidth: .infinity).clipped().clipShape(RoundedRectangle(cornerRadius: 10)).overlay(RoundedRectangle(cornerRadius: 10).strokeBorder(Color.secondary,style: StrokeStyle(lineWidth: 2,dash: [6,4])))
            }.buttonStyle(.plain).simultaneousGesture(TapGesture().onEnded { Haptics.tick() }).accessibilityLabel("Choose \(title.lowercased()) photo")
        }.frame(maxWidth: .infinity)
            .onChange(of: item) { _, selected in
                Task { do {
                    guard let data = try await selected?.loadTransferable(type: Data.self), let image = UIImage(data: data) else { return }
                    let scale = min(1,1600/max(image.size.width,image.size.height)); let size = CGSize(width: image.size.width*scale,height: image.size.height*scale)
                    let format = UIGraphicsImageRendererFormat(); format.scale = 1
                    let resized = UIGraphicsImageRenderer(size: size,format: format).image { _ in image.draw(in: CGRect(origin: .zero,size: size)) }
                    guard let jpeg = resized.jpegData(compressionQuality: 0.82) else { return }; Haptics.tick(); changed(jpeg)
                } catch { self.error = error.localizedDescription } }
            }.alert("Photo could not be opened",isPresented: Binding(get: { error != nil },set: { if !$0 { error = nil } })) { Button("OK") { error = nil } } message: { Text(error ?? "") }
    }
}
