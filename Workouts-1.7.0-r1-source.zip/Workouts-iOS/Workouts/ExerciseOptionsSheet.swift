import SwiftUI

struct ExerciseOptionsSheet: View {
    @Environment(\.dismiss) private var dismiss
    let name: String
    let sets: Int
    let canEdit: Bool
    let canDuplicate: Bool
    let canMoveUp: Bool
    let canMoveDown: Bool
    let action: (String) -> Void
    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Button { Haptics.tick(); dismiss() } label: { Image(systemName: "xmark").frame(width: 44, height: 44) }.accessibilityLabel("Close exercise options")
                VStack(spacing: 4) { Text("Exercise Options").font(.headline); Text(name).font(.caption).foregroundStyle(Palette.secondary).lineLimit(2) }.frame(maxWidth: .infinity)
                Menu {
                    Button("Move Up") { Haptics.tick(); action("Up") }.disabled(!canMoveUp || !canEdit)
                    Button("Move Down") { Haptics.tick(); action("Down") }.disabled(!canMoveDown || !canEdit)
                } label: { Image(systemName: "arrow.up.arrow.down").frame(width: 44, height: 44) }.accessibilityLabel("Reorder exercise")
            }.padding(.horizontal, 8).padding(.vertical, 12)
            Divider().overlay(Palette.separator)
            row("Info", subtitle: "Learn about the exercise", symbol: "chart.bar.fill")
            row("Targets", subtitle: "\(sets) sets", symbol: "scope", edit: true, disabled: !canEdit)
            row("Superset", subtitle: "Manage superset settings", symbol: "arrow.triangle.2.circlepath", disabled: !canEdit)
            row("Swap", subtitle: "Replace with an alternate", symbol: "arrow.triangle.swap", disabled: !canEdit)
            row("Duplicate", title: "Duplicate Exercise", symbol: "square.on.square.fill", disabled: !canEdit || !canDuplicate)
            row("Remove", title: "Remove from workout", symbol: "minus.circle.fill", disabled: !canEdit)
        }.padding(.bottom, 10).background(Palette.surface)
            .presentationDetents([.height(480)]).presentationDragIndicator(.visible).presentationCornerRadius(18)
    }
    private func row(_ key: String, title: String? = nil, subtitle: String? = nil, symbol: String, edit: Bool = false, disabled: Bool = false) -> some View {
        Button { Haptics.tick(); action(key) } label: {
            HStack(spacing: 18) {
                Image(systemName: symbol).font(.system(size: 19, weight: .semibold)).foregroundStyle(key == "Remove" ? Color.red : Color.primary).frame(width: 28)
                VStack(alignment: .leading, spacing: 4) { Text(title ?? key).font(.system(size: 16)); if let subtitle { Text(subtitle).font(.system(size: 13)).foregroundStyle(Palette.secondary) } }
                Spacer()
                if edit { Text("Edit").font(.subheadline).padding(.horizontal, 12).padding(.vertical, 7).background(Palette.control, in: Capsule()) }
                else if subtitle != nil { Image(systemName: "chevron.right").font(.caption).foregroundStyle(.tertiary) }
            }.padding(.horizontal, 20).frame(height: 62).contentShape(Rectangle())
        }.buttonStyle(.plain).disabled(disabled).overlay(alignment: .bottom) { if key != "Remove" { Divider().overlay(Palette.separator).padding(.leading, 66) } }
    }
}
struct SupersetSheet: View {
    @Environment(\.dismiss) private var dismiss
    let linked: Bool
    let canLink: Bool
    let save: (Bool) -> Void
    var body: some View {
        VStack(spacing: 0) {
            HStack { Button { Haptics.tick(); dismiss() } label: { Image(systemName: "xmark").frame(width: 44,height: 44) }; Spacer(); Text("Exercise").font(.headline); Spacer(); Color.clear.frame(width: 44,height: 44) }.padding(8)
            Divider()
            Button { Haptics.tick(); save(!linked) } label: { Label(linked ? "Remove from superset" : "Superset with next",systemImage: "link").frame(maxWidth: .infinity,alignment: .leading).padding(22) }.disabled(!linked && !canLink)
        }.background(Palette.surface).presentationDetents([.height(155)]).presentationDragIndicator(.visible)
    }
}
