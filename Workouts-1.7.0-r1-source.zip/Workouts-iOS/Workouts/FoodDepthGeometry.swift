import Foundation

// Metric camera coordinates: x right, y down, z forward. ARKit depth is z,
// not radial distance. Never substitute relative monocular depth here.
struct DepthPoint: Equatable {
    var x: Double
    var y: Double
    var z: Double
    static func -(l: Self,r: Self) -> Self { Self(x:l.x-r.x,y:l.y-r.y,z:l.z-r.z) }
    static func +(l: Self,r: Self) -> Self { Self(x:l.x+r.x,y:l.y+r.y,z:l.z+r.z) }
    func scaled(_ k: Double) -> Self { Self(x:x*k,y:y*k,z:z*k) }
    var length: Double { sqrt(x*x+y*y+z*z) }
    func cross(_ p: Self) -> Self { Self(x:y*p.z-z*p.y,y:z*p.x-x*p.z,z:x*p.y-y*p.x) }
}
struct DepthPixel: Equatable {
    var u: Double
    var v: Double
    var valid: Bool { u.isFinite && v.isFinite && u >= 0 && u <= 1 && v >= 0 && v <= 1 }
}
struct MetricDepthFrame {
    var width: Int
    var height: Int
    var depths: [Float]
    var confidence: [UInt8]
    var fx: Double
    var fy: Double
    var cx: Double
    var cy: Double
    var valid: Bool {
        width >= 16 && height >= 16 && width <= 1024 && height <= 1024 && depths.count == width*height && confidence.count == depths.count &&
        [fx,fy,cx,cy].allSatisfy(\.isFinite) && fx > 0 && fy > 0 && cx >= 0 && cx < Double(width) && cy >= 0 && cy < Double(height)
    }
    func point(_ x: Int,_ y: Int) -> DepthPoint? {
        guard x >= 0,y >= 0,x < width,y < height else { return nil }
        let i = y*width+x,z = Double(depths[i])
        guard confidence[i] == 2,z.isFinite,z >= 0.20,z <= 1.2 else { return nil }
        return DepthPoint(x:(Double(x)-cx)*z/fx,y:(Double(y)-cy)*z/fy,z:z)
    }
    // Display uses the complete RGB image rotated 90 degrees clockwise, aspect
    // fit (never aspect fill). This inverse maps its normalized taps to sensor pixels.
    static func sensorPixel(portrait p: DepthPixel) -> DepthPixel { DepthPixel(u:p.v,v:1-p.u) }
}
struct DepthVolume {
    var milliliters: Double
    var coverage: Double
    var planeErrorMM: Double
    var meanHeightMM: Double
    var footprintCM2: Double
    var acceptedCells: Int
}
enum FoodDepthGeometry {
    static func fail(_ message: String) -> FoodScanError { .message(message) }
    // Plane z=a*x+b*y+c, fitted to high-confidence empty plate patches.
    static func plane(_ points: [DepthPoint]) throws -> (a:Double,b:Double,c:Double,error:Double) {
        guard points.count >= 12 else { throw fail("Select four clear, flat empty areas of the plate.") }
        let n = Double(points.count)
        let mx = points.reduce(0) { $0+$1.x }/n,my = points.reduce(0) { $0+$1.y }/n,mz = points.reduce(0) { $0+$1.z }/n
        var xx=0.0,yy=0.0,xy=0.0,xz=0.0,yz=0.0
        for p in points { let x=p.x-mx,y=p.y-my,z=p.z-mz; xx+=x*x; yy+=y*y; xy+=x*y; xz+=x*z; yz+=y*z }
        let det=xx*yy-xy*xy
        guard xx > 0.0001,yy > 0.0001,det > 0.08*xx*yy else { throw fail("Spread the four plate points around the food; avoid a straight line.") }
        let a=(xz*yy-yz*xy)/det,b=(yz*xx-xz*xy)/det,c=mz-a*mx-b*my,norm=sqrt(1+a*a+b*b)
        guard norm <= 1.3 else { throw fail("Hold the phone closer to directly above the plate.") }
        let rms=sqrt(points.reduce(0) { $0+pow(($1.z-a*$1.x-b*$1.y-c)/norm,2) }/n)
        guard rms <= 0.003 else { throw fail("The plate points do not form a flat surface. Avoid raised rims, bowls and food.") }
        return (a,b,c,rms)
    }
    static func contains(_ p: DepthPixel,_ polygon: [DepthPixel]) -> Bool {
        var inside=false,j=polygon.count-1
        for i in polygon.indices {
            let a=polygon[i],b=polygon[j]
            if (a.v > p.v) != (b.v > p.v),p.u < (b.u-a.u)*(p.v-a.v)/(b.v-a.v)+a.u { inside.toggle() }
            j=i
        }
        return inside
    }
    static func simple(_ polygon: [DepthPixel]) -> Bool {
        guard polygon.count >= 3,polygon.count <= 64,polygon.allSatisfy(\.valid) else { return false }
        func orient(_ a:DepthPixel,_ b:DepthPixel,_ c:DepthPixel) -> Double { (b.u-a.u)*(c.v-a.v)-(b.v-a.v)*(c.u-a.u) }
        func intersects(_ a:DepthPixel,_ b:DepthPixel,_ c:DepthPixel,_ d:DepthPixel) -> Bool {
            let x=orient(a,b,c),y=orient(a,b,d),z=orient(c,d,a),w=orient(c,d,b)
            if x*y < 0 && z*w < 0 { return true }
            func on(_ a:DepthPixel,_ b:DepthPixel,_ p:DepthPixel,_ cross:Double) -> Bool {
                abs(cross) < 1e-10 && p.u >= min(a.u,b.u) && p.u <= max(a.u,b.u) && p.v >= min(a.v,b.v) && p.v <= max(a.v,b.v)
            }
            return on(a,b,c,x) || on(a,b,d,y) || on(c,d,a,z) || on(c,d,b,w)
        }
        for i in polygon.indices {
            let ni=(i+1)%polygon.count
            guard abs(polygon[i].u-polygon[ni].u)+abs(polygon[i].v-polygon[ni].v) > 0.0001 else { return false }
            for j in polygon.indices where j > i {
                let nj=(j+1)%polygon.count
                if ni == j || nj == i { continue }
                if intersects(polygon[i],polygon[ni],polygon[j],polygon[nj]) { return false }
            }
        }
        return true
    }
    static func estimate(frame: MetricDepthFrame,outline: [DepthPixel],plate: [DepthPixel]) throws -> DepthVolume {
        guard frame.valid else { throw fail("The depth capture is incomplete. Retake the scan.") }
        guard simple(outline) else { throw fail("Outline one food with an uncrossed boundary.") }
        guard plate.count == 4,plate.allSatisfy(\.valid),plate.allSatisfy({ !contains($0,outline) }) else { throw fail("Select four empty plate areas outside the food outline.") }
        guard (plate.map(\.u).max()!-plate.map(\.u).min()!)>=0.15,(plate.map(\.v).max()!-plate.map(\.v).min()!)>=0.15 else { throw fail("The plate references are too close together.") }
        for i in plate.indices { for j in plate.indices where j>i { guard hypot(plate[i].u-plate[j].u,plate[i].v-plate[j].v)>=0.05 else { throw fail("The plate references overlap.") } } }
        var points:[DepthPoint]=[]
        for tap in plate {
            let x=Int((tap.u*Double(frame.width-1)).rounded()),y=Int((tap.v*Double(frame.height-1)).rounded())
            var patch:[DepthPoint]=[]
            for dy in -2...2 { for dx in -2...2 { if let p=frame.point(x+dx,y+dy) { patch.append(p) } } }
            guard patch.count >= 18 else { throw fail("A plate point has unreliable depth. Choose another flat area.") }
            points.append(contentsOf:patch)
        }
        let base=try plane(points),norm=sqrt(1+base.a*base.a+base.b*base.b)
        let normal=DepthPoint(x:base.a/norm,y:base.b/norm,z:-1/norm)
        var volume=0.0,area=0.0,total=0,accepted=0,negative=0
        for y in 0..<(frame.height-1) { for x in 0..<(frame.width-1) {
            let p=DepthPixel(u:(Double(x)+0.5)/Double(frame.width-1),v:(Double(y)+0.5)/Double(frame.height-1))
            guard contains(p,outline) else { continue }; total+=1
            let samples=[frame.point(x,y),frame.point(x+1,y),frame.point(x,y+1),frame.point(x+1,y+1)]
            guard samples.allSatisfy({ $0 != nil }) else { continue }
            let top=samples.map { $0! },heights=top.map { (base.a*$0.x+base.b*$0.y+base.c-$0.z)/norm }
            if heights.contains(where: { $0 < -0.004 }) { negative+=1; continue }
            guard heights.allSatisfy({ $0 <= 0.15 }),((heights.max() ?? 0)-(heights.min() ?? 0)) <= 0.025 else { continue }
            let h=heights.map { max(0,$0) },foot=zip(top,h).map { $0.0-normal.scaled($0.1) }
            let a=(foot[1]-foot[0]).cross(foot[2]-foot[0]).length*0.5,b=(foot[2]-foot[3]).cross(foot[1]-foot[3]).length*0.5
            guard a+b <= 0.0001 else { continue }
            volume+=a*(h[0]+h[1]+h[2])/3+b*(h[3]+h[2]+h[1])/3; area+=a+b; accepted+=1
        } }
        guard total >= 100,accepted >= 100 else { throw fail("This food occupies too few reliable depth pixels. Move closer and retake.") }
        guard Double(negative)/Double(total) <= 0.03 else { throw fail("Food appears below the selected plate surface. Choose flat plate points, not the rim.") }
        let coverage=Double(accepted)/Double(total)
        guard coverage >= 0.95 else { throw fail("Too much depth is missing or inconsistent. Retake in good light, closer and directly above.") }
        let height=volume/area
        guard height >= max(0.012,base.error*4) else { throw fail("This portion is too thin to resolve reliably. Use grams or a serving count.") }
        guard volume >= 0.000005,volume <= 0.005,area > 0.0005,area <= 0.2 else { throw fail("The estimated size is outside the supported range. Check the outline and plate points.") }
        // Deliberately do not fill holes or multiply by 1/coverage. Missing regions
        // can be systematically different. Report the observed surface estimate.
        return DepthVolume(milliliters:volume*1_000_000,coverage:coverage,planeErrorMM:base.error*1000,meanHeightMM:height*1000,footprintCM2:area*10_000,acceptedCells:accepted)
    }
}

struct FoodDensityReference: Identifiable {
    var title: String
    var milliliters: Double
    var grams: Double
    var source: String
    var id: String { title }
    var density: Double { grams/milliliters }
    var valid: Bool { milliliters.isFinite && milliliters > 0 && grams.isFinite && grams > 0 && density >= 0.05 && density <= 2.5 }
    // Strict volume portions only. A slice, tender, bowl or generic serving is not
    // a volume reference. Cups remain a bulk-density assumption, chosen by the user.
    static func suggestions(_ food: FoodItem?) -> [Self] {
        guard let food else { return [] }
        return food.portions.compactMap { portion in
            let name=portion.name.lowercased().trimmingCharacters(in:.whitespacesAndNewlines)
            let pattern="^([0-9]+(?:\\.[0-9]+)?)\\s*(ml|milliliters?|millilitres?|cups?|tablespoons?|tbsp|teaspoons?|tsp)(?:$|[, (])"
            guard let r=try? NSRegularExpression(pattern:pattern),let m=r.firstMatch(in:name,range:NSRange(name.startIndex...,in:name)),let amount=Range(m.range(at:1),in:name).flatMap({ Double(name[$0]) }),let unit=Range(m.range(at:2),in:name).map({ String(name[$0]) }) else { return nil }
            // Only USDA cup/spoon portions have a known US customary convention.
            // Other databases may use metric cups (250 mL) or labeling cups (240 mL).
            let multiplier:Double
            if unit.hasPrefix("ml") || unit.hasPrefix("millil") { multiplier=1 }
            else if food.id.hasPrefix("usda-") {
                multiplier=unit.hasPrefix("cup") ? 236.5882365 : (["tbsp","tablespoon","tablespoons"].contains(unit) ? 14.7867648 : 4.9289216)
            } else { return nil }
            let result=Self(title:portion.name,milliliters:amount*multiplier,grams:portion.grams,source:food.source+" · "+portion.name)
            return result.valid ? result : nil
        }
    }
}

struct FoodDepthRegion {
    var volume: DepthVolume
    // Bounds in the displayed portrait RGB image, [left, top, right, bottom].
    var bounds: [Double]
}
extension FoodDepthGeometry {
    // Robust dominant support plane inside a Vision foreground matte. Ambiguous
    // parallel planes, insufficient empty support and disconnected/hidden foods
    // fail closed: the ordinary photo estimate remains available.
    static func automatic(frame:MetricDepthFrame,foreground:[UInt8]) throws -> [FoodDepthRegion] {
        guard frame.valid,foreground.count==frame.depths.count else { throw fail("Incomplete depth") }
        let visible=foreground.indices.filter { foreground[$0] != 0 }
        guard !visible.isEmpty,Double(visible.filter { frame.confidence[$0]==2 && frame.depths[$0].isFinite }.count)/Double(visible.count)>=0.95 else { throw fail("Depth coverage is insufficient") }
        var samples:[DepthPoint]=[]
        for y in stride(from:2,to:frame.height-2,by:3) { for x in stride(from:2,to:frame.width-2,by:3) {
            if foreground[y*frame.width+x] != 0,let p=frame.point(x,y) { samples.append(p) }
        } }
        guard samples.count >= 150 else { throw fail("Insufficient foreground depth") }
        var random:UInt64=0xBADC0FFEE
        func pick()->Int { random=random &* 6364136223846793005 &+ 1;return Int((random>>32)%UInt64(samples.count)) }
        var best:[DepthPoint]=[]
        for _ in 0..<240 {
            let p=samples[pick()],q=samples[pick()],r=samples[pick()]
            let n=(q-p).cross(r-p)
            guard abs(n.z)>0.00001 else { continue }
            let a = -n.x/n.z,b = -n.y/n.z,c=p.z-a*p.x-b*p.y,normal=sqrt(1+a*a+b*b)
            guard normal <= 1.3 else { continue }
            let inliers=samples.filter { abs(($0.z-a*$0.x-b*$0.y-c)/normal)<=0.0025 }
            if inliers.count > best.count { best=inliers }
        }
        guard best.count >= 100,Double(best.count)/Double(samples.count)>=0.40 else { throw fail("No stable support plane") }
        let base=try plane(best),norm=sqrt(1+base.a*base.a+base.b*base.b)
        let normal=DepthPoint(x:base.a/norm,y:base.b/norm,z:-1/norm)
        // A second substantial flat surface behind the chosen plane may be table,
        // bowl or plate rim. Do not pretend the chosen plane is the food bottom.
        let behind=samples.filter { (base.a*$0.x+base.b*$0.y+base.c-$0.z)/norm < -0.006 }
        guard Double(behind.count)/Double(samples.count)<0.08 else { throw fail("Ambiguous supporting surfaces") }
        var above=[Bool](repeating:false,count:frame.depths.count),visited=above
        for y in 1..<frame.height-1 { for x in 1..<frame.width-1 {
            let i=y*frame.width+x
            if foreground[i] != 0,let p=frame.point(x,y) {
                let h=(base.a*p.x+base.b*p.y+base.c-p.z)/norm
                above[i]=h>=max(0.008,base.error*4) && h<=0.15
            }
        } }
        var results:[FoodDepthRegion]=[]
        for seed in above.indices where above[seed] && !visited[seed] {
            var queue=[seed],cursor=0;visited[seed]=true
            while cursor<queue.count {
                let i=queue[cursor];cursor+=1
                for j in [i-1,i+1,i-frame.width,i+frame.width] where j>=0 && j<above.count && !visited[j] && above[j] {
                    guard abs((j%frame.width)-(i%frame.width))<=1 else { continue };visited[j]=true;queue.append(j)
                }
            }
            guard queue.count>=150 else { continue }
            let xs=queue.map { $0%frame.width },ys=queue.map { $0/frame.width }
            let loX=xs.min()!,hiX=xs.max()!,loY=ys.min()!,hiY=ys.max()!
            guard loX>2,loY>2,hiX<frame.width-3,hiY<frame.height-3 else { continue }
            // Empty-plane support must surround the component in all four image
            // quadrants, not just along a background strip.
            let center=DepthPoint(x:Double(loX+hiX)/2,y:Double(loY+hiY)/2,z:0)
            var quadrants=Set<Int>()
            for p in best {
                let px=p.x*frame.fx/p.z+frame.cx,py=p.y*frame.fy/p.z+frame.cy
                quadrants.insert((px<center.x ? 0:1)+(py<center.y ? 0:2))
            }
            guard quadrants.count==4 else { continue }
            let mask=Set(queue)
            var volume=0.0,area=0.0,total=0,accepted=0
            for i in queue {
                let x=i%frame.width,y=i/frame.width
                let corners=[i,i+1,i+frame.width,i+frame.width+1]
                // Interior triangulation deliberately excludes unresolved edges.
                guard corners.allSatisfy({ mask.contains($0) }) else { continue };total+=1
                let points=[frame.point(x,y),frame.point(x+1,y),frame.point(x,y+1),frame.point(x+1,y+1)]
                guard points.allSatisfy({ $0 != nil }) else { continue }
                let top=points.map { $0! },h=top.map { (base.a*$0.x+base.b*$0.y+base.c-$0.z)/norm }
                guard (h.max()!-h.min()!)<=0.025 else { continue }
                let foot=zip(top,h).map { $0.0-normal.scaled($0.1) }
                let a=(foot[1]-foot[0]).cross(foot[2]-foot[0]).length*0.5,b=(foot[2]-foot[3]).cross(foot[1]-foot[3]).length*0.5
                guard a+b<=0.0001 else { continue }
                volume+=a*(h[0]+h[1]+h[2])/3+b*(h[3]+h[2]+h[1])/3;area+=a+b;accepted+=1
            }
            guard total>=100,area>0 else { continue }
            let coverage=Double(accepted)/Double(total),height=volume/area,ml=volume*1_000_000
            guard coverage>=0.95,height>=max(0.012,base.error*4),ml>=5,ml<=5000 else { continue }
            let v=DepthVolume(milliliters:ml,coverage:coverage,planeErrorMM:base.error*1000,meanHeightMM:height*1000,footprintCM2:area*10_000,acceptedCells:accepted)
            results.append(FoodDepthRegion(volume:v,bounds:[1-Double(hiY)/Double(frame.height-1),Double(loX)/Double(frame.width-1),1-Double(loY)/Double(frame.height-1),Double(hiX)/Double(frame.width-1)]))
        }
        return results.sorted { $0.volume.milliliters > $1.volume.milliliters }.prefix(8).map { $0 }
    }
    static func applying(_ regions:[FoodDepthRegion],to items:[FoodAIItem]) -> [FoodAIItem] {
        var used=Set<Int>()
        return items.map { item in
            guard item.quantity?.weightBasis != "user",!(item.quantity?.basis == "user" && item.quantity?.count != nil),item.nutritionBasis?.servings == nil,let food=item.matchedFood,food.id.hasPrefix("usda-"),item.nutritionBasis?.adjusted != true else { return item }
            let refs=FoodDensityReference.suggestions(food)
            guard !refs.isEmpty else { return item }
            let densities=refs.map(\.density).sorted()
            // Conflicting preparation/packing references cannot justify an update.
            guard densities.last! / densities.first! <= 1.2 else { return item }
            let ref=refs.min { abs($0.density-densities[densities.count/2]) < abs($1.density-densities[densities.count/2]) }!
            let matches=regions.enumerated().filter { index,region in
                guard !used.contains(index) else { return false }
                if let box=item.imageRegion,box.count==4 {
                    let b=region.bounds,cx=(b[0]+b[2])/2,cy=(b[1]+b[3])/2
                    let intersection=max(0,min(b[2],box[2])-max(b[0],box[0]))*max(0,min(b[3],box[3])-max(b[1],box[1]))
                    let a=(b[2]-b[0])*(b[3]-b[1])
                    return cx>=box[0] && cx<=box[2] && cy>=box[1] && cy<=box[3] && intersection/a>=0.75
                }
                return items.count==1 && regions.count==1
            }
            guard matches.count==1 else { return item }
            if items.count>1 {
                guard items.allSatisfy({ $0.imageRegion?.count==4 }) else { return item }
                let b=matches[0].element.bounds
                let center=[(b[0]+b[2])/2,(b[1]+b[3])/2]
                let owners=items.filter { other in guard let box=other.imageRegion else { return false };return center[0]>=box[0] && center[0]<=box[2] && center[1]>=box[1] && center[1]<=box[3] }
                guard owners.count==1 else { return item }
            }
            let (index,region)=matches[0],v=region.volume,grams=v.milliliters*ref.density
            // A geometric disagreement is not proof that a new density or food
            // identity is correct. Keep the photo estimate when wildly divergent.
            guard grams>0,grams<=10000,grams/item.grams>=0.25,grams/item.grams<=4 else { return item }
            var next=item,basis=item.nutritionBasis ?? FoodNutritionBasis(resolution:"library")
            let evidence=FoodDepthEvidence(method:"arkit-lidar-automatic-v2",volumeML:v.milliliters,densityGramsPerML:ref.density,densitySource:String((ref.source+" · estimated bulk density").prefix(200)),referenceVolumeML:ref.milliliters,referenceWeightGrams:ref.grams,scanGrams:grams,coverage:v.coverage,planeErrorMM:v.planeErrorMM,meanHeightMM:v.meanHeightMM,foodID:food.id,applied:true)
            guard evidence.valid else { return item }
            next.photoGrams=item.photoGrams ?? item.grams;next.photoMacros=item.photoMacros ?? item.macros
            next.grams=grams;next.macros=food.nutrition(grams:grams)
            basis.depth=evidence;basis.portionBasis="Automatic depth volume × food density; estimated weight";basis.portionReviewed=false
            next.nutritionBasis=basis
            guard next.valid else { return item };used.insert(index);return next
        }
    }
}
