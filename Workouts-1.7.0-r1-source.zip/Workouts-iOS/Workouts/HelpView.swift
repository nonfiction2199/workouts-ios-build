import SwiftUI

struct WorkoutHelpView: View {
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            List {
                Section("Start a workout") { Text("Open Workout, choose a routine, review its exercises and press Start Workout. Your current session can be resumed from the Workout tab.") }
                Section("Exercise information") { Text("Tap an exercise to switch between Instructions, Details and History. Available demonstrations play inline. Use the speed buttons to slow playback; you can also import your own video.") }
                Section("Customize a routine") { Text("Use the three-dot button beside an exercise to edit Targets, link a Superset, Swap, Duplicate, reorder or Remove it. Completed history is kept when you change your program.") }
                Section("Levels") { Text("Levels displays average weekly completed sets over 1 week, 1 month or 3 months. Primary muscles receive one set; secondary muscles receive half a set. Warm-ups are excluded.") }
                Section("Backups and updates") { Text("Export a workout backup before updating through Signulous. Keep the same signing settings and install over the existing app. Measurements, imported videos and photos are stored separately on this iPhone.") }
            }.darkForm().navigationTitle("Tutorials").navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { dismiss() } } }
        }
    }
}
