import SwiftUI

struct WorkoutOverviewView: View {
    @EnvironmentObject var store: TrainingStore
    @Environment(\.dismiss) var dismiss
    let dayIndex: Int
    @State private var preview: Session?
    @State private var detail: Exercise?
    @State private var adding = false
    @State private var programEditing = false
    @State private var replacing: Int?
    @State private var editing: WorkoutRoute?
    @State private var removing: Int?
    @State private var options: WorkoutRoute?
    @State private var superset: WorkoutRoute?
    @State private var afterOptions: (() -> Void)?
    private var day: ProgramDay? {
        guard let program = store.state?.program, program.indices.contains(dayIndex) else { return nil }
        return program[dayIndex]
    }
    private var muscleNames: [String] {
        Array(Set((preview?.items ?? []).flatMap { item in
            guard let e = store.exercise(item.target.id) else { return [String]() }
            return (e.primary ?? [e.muscle]) + (e.secondary ?? [])
        })).sorted()
    }
    private var minutes: Int {
        let seconds = (preview?.items ?? []).reduce(0) { total, item in
            total + item.sets.count * 40 + max(0, item.sets.count - 1) * item.target.rest + 90
        }
        return max(1, Int(ceil(Double(seconds) / 60)))
    }
    private var durationText: String {
        minutes >= 60 ? "\(minutes / 60) hr \(minutes % 60) min" : "\(minutes) min"
    }
    var body: some View { NavigationStack { presentationContent } }
    private var baseContent: some View {
        ScrollView {
                VStack(alignment: .leading, spacing: 40) {
                    if !muscleNames.isEmpty {
                        VStack(alignment: .leading, spacing: 16) {
                            SectionHeading(title: "Target Muscles")
                            ScrollView(.horizontal) {
                                HStack(spacing: 12) { ForEach(muscleNames, id: \.self) { muscle in muscleCard(muscle) } }
                            }.scrollIndicators(.hidden)
                        }
                    }
                    HStack {
                        VStack(alignment: .leading, spacing: 5) {
                            Text("\(preview?.items.count ?? 0) Exercises").font(.system(size: 20, weight: .semibold))
                            Text("Estimated workout time is \(durationText)").font(.subheadline).foregroundStyle(Palette.secondary)
                        }
                        Spacer()
                        CircleAction(symbol: "plus", label: "Add exercise", diameter: 48) { Haptics.tick(); adding = true }
                            .disabled(store.state?.active != nil || (day?.items.count ?? 0) >= 30)
                    }
                    if preview?.items.isEmpty != false {
                        Text("Add exercises to build this workout.").foregroundStyle(Palette.secondary).padding(.vertical, 32)
                    }
                    if let preview {
                        if preview.deload { Label("Lighter week · reduced sets and effort", systemImage: "leaf").font(.subheadline).foregroundStyle(Palette.secondary) }
                        LazyVStack(spacing: 20) {
                            ForEach(Array(preview.items.enumerated()), id: \.offset) { index, item in
                                exerciseRow(index, item)
                            }
                        }
                    }
                    Text("RIR = repetitions in reserve. Muscle totals include half a set for secondary muscles. Duration is an estimate.")
                        .font(.caption).foregroundStyle(Palette.secondary)
                }.padding(16)
            }
            .background(Palette.surface)
            .navigationTitle(day?.name ?? "Workout").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button { Haptics.tick(); dismiss() } label: { Image(systemName: "chevron.left") }.accessibilityLabel("Back")
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Menu {
                        Button("Edit Workouts", systemImage: "pencil") { Haptics.tick(); programEditing = true }
                        Button("Add Exercise", systemImage: "plus") { Haptics.tick(); adding = true }
                    } label: { Image(systemName: "ellipsis").rotationEffect(.degrees(90)) }
                        .disabled(store.state?.active != nil)
                        .simultaneousGesture(TapGesture().onEnded { Haptics.tick() })
                        .accessibilityLabel("Workout options")
                }
            }
            .safeAreaInset(edge: .bottom, spacing: 0) {
                PrimaryButton(label: store.state?.active != nil ? "Resume Current Workout" : "Start Workout") {
                    Haptics.tick(); store.pendingOverviewStart = dayIndex; dismiss()
                }.disabled((preview?.items.isEmpty ?? true) && store.state?.active == nil)
                    .padding(16).background(Palette.surface).overlay(alignment: .top) { Divider().overlay(Palette.separator) }
            }
            .onAppear {
                refresh()
                #if DEBUG
                if ["exercise", "exercise-details", "exercise-history"].contains(ProcessInfo.processInfo.environment["WORKOUTS_PREVIEW_SCREEN"] ?? "") {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { detail = store.exercise(preview?.items.first?.target.id ?? "bench") }
                }
                if ProcessInfo.processInfo.environment["WORKOUTS_PREVIEW_SCREEN"] == "exercise-options" { DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { options = WorkoutRoute(id: 0) } }
                #endif
            }
    }
    private var presentationContent: some View {
        baseContent
            .sheet(item: $detail) { exercise in ExerciseDetailView(exercise: exercise) }
            .sheet(item: $options, onDismiss: {
                let action = afterOptions; afterOptions = nil
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) { action?() }
            }) { route in
                if let day, day.items.indices.contains(route.id) {
                    ExerciseOptionsSheet(name: store.exercise(day.items[route.id].id)?.name ?? "Exercise", sets: day.items[route.id].sets, canEdit: store.state?.active == nil, canDuplicate: day.items.count < 30, canMoveUp: route.id > 0, canMoveDown: route.id + 1 < day.items.count) { action in
                        afterOptions = { handleOption(action, index: route.id) }; options = nil
                    }
                }
            }
            .sheet(item: $superset) { route in
                if let day, day.items.indices.contains(route.id) {
                    SupersetSheet(linked: !day.items[route.id].group.isEmpty, canLink: route.id + 1 < day.items.count) { linked in
                        update { value in
                            let index = route.id
                            guard value.items.indices.contains(index) else { return }
                            if linked && index + 1 < value.items.count {
                                let group = value.items[index + 1].group.isEmpty ? "SS-" + String(UUID().uuidString.prefix(8)) : value.items[index + 1].group
                                value.items[index].group = group; value.items[index + 1].group = group
                            } else {
                                let group = value.items[index].group
                                value.items[index].group = ""
                                if value.items.filter({ $0.group == group }).count == 1 {
                                    for i in value.items.indices where value.items[i].group == group { value.items[i].group = "" }
                                }
                            }
                        }
                        superset = nil
                    }
                }
            }
            .sheet(isPresented: $programEditing, onDismiss: refresh) { ProgramEditorView() }
            .sheet(isPresented: $adding) {
                ExerciseLibraryView(onSelect: { exercise in
                    Haptics.tick()
                    update { $0.items.append(Target(id: exercise.id, sets: 3, min: 8, max: 12, rir: 2, rest: 90, increment: exercise.increment, group: "")) }
                    adding = false
                })
            }
            .sheet(isPresented: Binding(get: { replacing != nil }, set: { if !$0 { replacing = nil } })) {
                ExerciseLibraryView(onSelect: { exercise in
                    guard let index = replacing else { return }; Haptics.tick()
                    update { day in
                        guard day.items.indices.contains(index) else { return }
                        // A replacement retains rep/set goals, but never inherits another machine's load constraints.
                        let old = day.items[index]
                        day.items[index] = Target(id: exercise.id, sets: old.sets, min: old.min, max: old.max, rir: old.rir, rest: old.rest, increment: exercise.increment, group: old.group, cycles: old.cycles)
                    }
                    replacing = nil
                })
            }
            .sheet(item: $editing) { route in
                if let day, day.items.indices.contains(route.id) {
                    WorkoutTargetEditor(target: day.items[route.id]) { target in
                        update { $0.items[route.id] = target }; editing = nil
                    }
                }
            }
            .confirmationDialog("Remove this exercise from the program? Previous workout history stays saved.", isPresented: Binding(get: { removing != nil }, set: { if !$0 { removing = nil } }), titleVisibility: .visible) {
                Button("Remove Exercise", role: .destructive) {
                    if let index = removing { Haptics.tick(); update { $0.items.remove(at: index) } }; removing = nil
                }
            }
            .alert("Workouts", isPresented: Binding(get: { store.error != nil }, set: { if !$0 { store.error = nil } })) {
                Button("OK", role: .cancel) { store.error = nil }
            } message: { Text(store.error ?? "") }
    }
    private func handleOption(_ action: String, index: Int) {
        guard let day, day.items.indices.contains(index) else { return }
        switch action {
        case "Info": detail = store.exercise(day.items[index].id)
        case "Targets": editing = WorkoutRoute(id: index)
        case "Superset": superset = WorkoutRoute(id: index)
        case "Swap": replacing = index
        case "Duplicate": update { value in if value.items.count < 30 { var copy = value.items[index]; copy.group = ""; value.items.insert(copy, at: index + 1) } }
        case "Up": update { $0.items.swapAt(index, index - 1) }
        case "Down": update { $0.items.swapAt(index, index + 1) }
        case "Remove": removing = index
        default: break
        }
    }
    private func refresh() { preview = store.workoutPreview(dayIndex) }
    private func update(_ change: (inout ProgramDay) -> Void) {
        guard var program = store.state?.program, program.indices.contains(dayIndex) else { return }
        change(&program[dayIndex])
        do { if store.send("program", ["program": try jsonObject(program)]) { refresh() } }
        catch { store.error = error.localizedDescription }
    }
    private func muscleCard(_ muscle: String) -> some View {
        let items = (preview?.items ?? []).filter { item in
            guard let e = store.exercise(item.target.id) else { return false }
            return ((e.primary ?? [e.muscle]) + (e.secondary ?? [])).contains(muscle)
        }
        let sets = items.reduce(0.0) { total, item in
            let primary = store.exercise(item.target.id)?.primary ?? []
            return total + Double(item.sets.count) * (primary.contains(muscle) ? 1 : 0.5)
        }
        return HStack(spacing: 12) {
            BodyMap(levels: [:], back: rearMuscles.contains(muscle), selected: muscle, thumbnail: true).frame(width: 82, height: 78).clipped()
            VStack(alignment: .leading, spacing: 6) {
                Text(muscle).font(.system(size: 17)).foregroundStyle(.primary)
                Text("\(items.count) exercises")
                Text("\(sets.short) sets")
            }.font(.subheadline).foregroundStyle(Palette.secondary)
        }.padding(.horizontal, 4).padding(.vertical, 2).frame(width: 188, alignment: .leading)
            .overlay(RoundedRectangle(cornerRadius: 12).stroke(Palette.separator, lineWidth: 2))
    }
    private func exerciseRow(_ index: Int, _ item: SessionExercise) -> some View {
        let exercise = store.exercise(item.target.id)
        return HStack(alignment: .center, spacing: 16) {
            Button { Haptics.tick(); detail = exercise } label: {
                ZStack {
                    RoundedRectangle(cornerRadius: 6).fill(Palette.control)
                    if let exercise, let demo = ExerciseVideo.forExercise(exercise), let path = Bundle.main.path(forResource: demo.poster, ofType: nil), let image = UIImage(contentsOfFile: path) {
                        Image(uiImage: image).resizable().scaledToFill().frame(width: 56, height: 76).clipped()
                    } else if let exercise { BodyMap(levels: [:], back: rearMuscles.contains(exercise.muscle), selected: exercise.muscle, thumbnail: true).padding(4) }
                }.frame(width: 56, height: 76).clipShape(RoundedRectangle(cornerRadius: 4))
            }.buttonStyle(.plain).accessibilityLabel("Instructions for \(exercise?.name ?? "exercise")")
            VStack(alignment: .leading, spacing: 8) {
                Button { Haptics.tick(); detail = exercise } label: {
                    Text(exercise?.name ?? item.target.id).font(.system(size: 17)).multilineTextAlignment(.leading).frame(maxWidth: .infinity, alignment: .leading)
                }.buttonStyle(.plain)
                HStack(alignment: .center, spacing: 8) {
                    VStack(spacing: 4) {
                        ForEach(Array(item.sets.enumerated()), id: \.offset) { offset, set in
                            HStack(spacing: 8) {
                                Text("\(offset + 1)").frame(width: 22, height: 22).background(Palette.control, in: Circle())
                                Text(exercise?.metric == "time" ? "\(Int(set.seconds ?? 0)) sec" : "\(item.target.min)–\(item.target.max) reps").foregroundStyle(Palette.secondary)
                                Spacer(minLength: 0)
                                Text("\(set.rir)").foregroundStyle(set.rir <= 1 ? Color.white : Color.black)
                                    .frame(width: 22, height: 22).background(set.rir <= 1 ? Color(red: 0.9, green: 0, blue: 0.22) : Color(red: 1, green: 0.68, blue: 0.03), in: Circle())
                                    .accessibilityLabel("\(set.rir) repetitions in reserve")
                            }.font(.system(size: 15))
                        }
                    }
                    Button { Haptics.tick(); options = WorkoutRoute(id: index) } label: {
                        Image(systemName: "ellipsis").rotationEffect(.degrees(90)).frame(width: 36, height: 44)
                    }.buttonStyle(.plain).accessibilityLabel("Exercise options for \(exercise?.name ?? "exercise")")

                }
                if let exercise { MuscleChips(exercise: exercise) }
                if !item.target.group.isEmpty { Label("Superset", systemImage: "link").font(.caption).foregroundStyle(Palette.secondary) }
                Divider().overlay(Palette.separator).padding(.top, 8)
            }
        }
    }
}

struct MuscleChips: View {
    let exercise: Exercise
    var body: some View {
        ScrollView(.horizontal) {
            HStack(spacing: 4) {
                ForEach(exercise.primary ?? [exercise.muscle], id: \.self) { Text($0).padding(6).background(Palette.control, in: RoundedRectangle(cornerRadius: 4)) }
                ForEach(exercise.secondary ?? [], id: \.self) { Text($0).padding(6).overlay(RoundedRectangle(cornerRadius: 4).stroke(Palette.separator)) }
            }.font(.system(size: 14))
        }.scrollIndicators(.hidden)
    }
}

struct WorkoutTargetEditor: View {
    @Environment(\.dismiss) var dismiss
    @State var target: Target
    let save: (Target) -> Void
    var body: some View {
        NavigationStack {
            Form {
                Section("Base Targets") {
                    Stepper("\(target.sets) sets", value: $target.sets, in: 1...20)
                    Stepper("Minimum: \(target.min) reps", value: $target.min, in: 1...target.max)
                    Stepper("Maximum: \(target.max) reps", value: $target.max, in: target.min...50)
                    Stepper("\(target.rir) repetitions in reserve", value: $target.rir, in: 0...6)
                    Stepper("Rest: \(target.rest) sec", value: $target.rest, in: 0...600, step: 15)
                }
                Section("Equipment") {
                    Stepper("Increment: \(target.increment.short) lb", value: $target.increment, in: 0.25...100, step: 0.25)
                }
                Section { Text("Weekly progression and lighter weeks are applied to these base targets. Custom cycle targets, if present, stay in place.").font(.footnote).foregroundStyle(Palette.secondary) }
            }.darkForm().navigationTitle("Exercise Targets").navigationBarTitleDisplayMode(.inline)
                .onChange(of: target.increment) { Haptics.tick() }.onChange(of: target.sets) { Haptics.tick() }.onChange(of: target.min) { Haptics.tick() }
                .onChange(of: target.max) { Haptics.tick() }.onChange(of: target.rir) { Haptics.tick() }.onChange(of: target.rest) { Haptics.tick() }
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) { Button("Cancel") { Haptics.tick(); dismiss() } }
                    ToolbarItem(placement: .confirmationAction) { Button("Save") { Haptics.tick(); save(target) } }
                }
        }
    }
}
