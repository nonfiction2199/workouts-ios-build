import SwiftUI

struct WorkoutView: View {
    @EnvironmentObject var store: TrainingStore
    let open: (AppSheet) -> Void
    @State private var expanded = true
    @State private var selectedDate: Date?
    private var week: [Date] {
        let calendar = Calendar.current
        let today = calendar.startOfDay(for: Date())
        let offset = (calendar.component(.weekday, from: today) + 5) % 7
        let start = calendar.date(byAdding: .day, value: -offset, to: today) ?? today
        return (0..<7).compactMap { calendar.date(byAdding: .day, value: $0, to: start) }
    }
    private func programTitle(_ state: TrainingState) -> String {
        let names = state.program.map { $0.name.lowercased() }
        let split = names.allSatisfy { $0.hasPrefix("full body") } ? "Full Body" : names.allSatisfy { $0.hasPrefix("upper") || $0.hasPrefix("lower") } ? "Upper/Lower Split" : "Program"
        return "\(state.settings.experience) \(split)"
    }
    var body: some View {
        ScrollView {
            VStack(spacing: 0) {
                VStack(spacing: 10) {
                    HStack(spacing: 10) {
                        ScreenTitle(text: "Workout"); Spacer(minLength: 0)
                        CircleAction(symbol: "calendar",label: "Workout history") { Haptics.tick(); open(.history) }
                        CircleAction(symbol: "plus",label: "New workout") { store.startEmpty() }
                        Menu {
                            Button("Edit program", systemImage: "pencil") { Haptics.tick(); open(.programEditor) }
                            Button("New program", systemImage: "plus") { Haptics.tick(); open(.newProgram) }
                            if let state = store.state, !state.program.isEmpty { Button("Start lighter workout", systemImage: "leaf") { store.start(state.next % state.program.count, lighter: true) } }
                        } label: { Image(systemName: "ellipsis").rotationEffect(.degrees(90)).frame(width: 40,height: 40).background(Palette.control, in: Circle()) }.simultaneousGesture(TapGesture().onEnded { Haptics.tick() }).accessibilityLabel("Workout options")
                    }
                    HStack(spacing: 12) { ForEach(week, id: \.self) { day in
                        Button { Haptics.tick(); selectedDate = day } label: {
                            VStack(spacing: 2) { Text(day.formatted(.dateTime.day())).font(.system(size: 14)); Text(day.formatted(.dateTime.weekday(.abbreviated)).prefix(2)).font(.system(size: 12)).foregroundStyle(Palette.secondary); Circle().fill(Calendar.current.isDateInToday(day) ? Color.primary : .clear).frame(width: 4,height: 4) }.frame(maxWidth: .infinity).frame(height: 58).overlay(Capsule().stroke(Palette.separator,lineWidth: 2))
                        }.buttonStyle(.plain).accessibilityLabel(day.formatted(date: .complete,time: .omitted))
                    } }
                }.padding(.horizontal, 16).padding(.top, 4).padding(.bottom, 10).background(Palette.surface)
                VStack(alignment: .leading, spacing: 18) {
                    if let active = store.state?.active {
                        PrimaryButton(label: "Resume \(active.name)") { Haptics.tick(); store.showLogger = true }
                    }
                    HStack { SectionHeading(title: "Active Program"); if let s = store.state, !s.program.isEmpty { Text("Week \((s.next / max(1,s.program.count)) % 6 + 1)").underline() } }
                    if let state = store.state, !state.program.isEmpty {
                        VStack(spacing: 0) {
                            Button { Haptics.tick(); withAnimation { expanded.toggle() } } label: {
                                HStack(spacing: 16) {
                                    RocketIcon(filled: true, color: .black.opacity(0.65)).frame(width: 28,height: 32).rotationEffect(.degrees(35)).frame(width: 48,height: 48).background(Color(red: 0.97,green: 0.20,blue: 0.27),in: RoundedRectangle(cornerRadius: 12))
                                    VStack(alignment: .leading,spacing: 4) { Text(programTitle(state)).font(.system(size: 17)); Text("\(state.program.count) workouts").foregroundStyle(Palette.secondary) }
                                    Spacer(); Image(systemName: expanded ? "chevron.up" : "chevron.down")
                                }.padding(16)
                            }.buttonStyle(.plain)
                            if expanded {
                                Divider().overlay(Palette.separator)
                                ForEach(Array(state.program.enumerated()), id: \.offset) { index, day in
                                    Button { store.openWorkout(index) } label: {
                                        HStack(spacing: 12) {
                                            WorkoutSummary(day: day)
                                            Image(systemName: "square").font(.system(size: 25, weight: .light)).foregroundStyle(Palette.secondary)
                                        }.padding(.horizontal, 16).padding(.vertical, 18).contentShape(Rectangle())
                                    }.buttonStyle(.plain)
                                    if index < state.program.count - 1 { Divider().overlay(Palette.separator).padding(.leading,16) }
                                }
                            }
                        }.card()
                    } else {
                        VStack(alignment: .leading, spacing: 20) {
                            Text("Your next workout starts here").font(.title3.bold())
                            Text("Build a program around your equipment, schedule and goal, or import your existing workouts in More.").foregroundStyle(Palette.secondary)
                            PrimaryButton(label: "Create Program") { Haptics.tick(); open(.newProgram) }
                            Button("Start Empty Workout") { store.startEmpty() }.frame(maxWidth: .infinity)
                        }.padding(20).card()
                    }
                }.padding(16).padding(.top, 20)
            }
        }.background(Palette.background, ignoresSafeAreaEdges: []).sheet(isPresented: Binding(get: { selectedDate != nil }, set: { if !$0 { selectedDate = nil } })) { if let selectedDate { HistoryView(date: selectedDate) } }
    }
}
struct WorkoutSummary: View {
    @EnvironmentObject var store: TrainingStore
    let day: ProgramDay
    var titlePrefix = ""
    private var muscles: [String] { Array(Set(day.items.flatMap { store.exercise($0.id)?.primary ?? [] })).sorted() }
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(titlePrefix + day.name).font(.system(size: 17))
            Text(day.items.compactMap { store.exercise($0.id)?.name }.joined(separator: ", ")).font(.system(size: 14)).foregroundStyle(Palette.secondary).lineLimit(2).multilineTextAlignment(.leading)
            ScrollView(.horizontal) { HStack(spacing: 4) { ForEach(muscles,id: \.self) { Text($0).font(.system(size: 14)).padding(.horizontal, 6).padding(.vertical, 5).background(Palette.control,in: RoundedRectangle(cornerRadius: 4)) } } }.scrollIndicators(.hidden)
        }.frame(maxWidth: .infinity,alignment: .leading)
    }
}
struct ShortcutsView: View {
    @AppStorage("shortcutWeight") private var shortcutWeight = true
    @AppStorage("shortcutPhotos") private var shortcutPhotos = true
    @AppStorage("shortcutMetrics") private var shortcutMetrics = true
    @AppStorage("shortcutHistory") private var shortcutHistory = true
    @AppStorage("shortcutNutrition") private var shortcutNutrition = true

    @EnvironmentObject var store: TrainingStore
    @Environment(\.dismiss) var dismiss
    let open: (AppSheet) -> Void
    @State private var utility: UtilityKind?
    @State private var contentHeight: CGFloat = 400
    var body: some View {
        VStack(spacing: 0) {
            HStack { Button { Haptics.tick(); dismiss() } label: { Image(systemName: "xmark").font(.title2).frame(width: 44,height: 44) }; Spacer(); Text("Shortcuts").font(.system(size: 20, weight: .bold)); Spacer(); Button { Haptics.tick(); open(.shortcutSettings) } label: { ReferenceSymbol(name: "slider.horizontal.3").font(.title2).frame(width: 44,height: 44) }.accessibilityLabel("Shortcut settings") }.padding(.horizontal,16).padding(.top,16).padding(.bottom,8)
            Divider().overlay(Palette.separator)
            ScrollView {
                VStack(spacing: 18) {
                    HStack { if shortcutWeight { utilityButton("Weight",symbol: "scalemass.fill",kind: .weight) }; if shortcutPhotos { utilityButton("Photos",symbol: "camera.fill",kind: .photos) }; if shortcutMetrics { utilityButton("Metrics",symbol: "ruler",kind: .metrics) }
                        if shortcutHistory { Button { Haptics.tick(); open(.history) } label: { VStack(spacing: 9) { ReferenceSymbol(name: "clock.arrow.circlepath").font(.title2).frame(width: 50,height: 50).background(Palette.control,in: Circle()); Text("History").font(.subheadline) }.frame(maxWidth: .infinity) }.buttonStyle(.plain) }
                    }
                    if shortcutNutrition {
                        VStack(alignment: .leading,spacing: 12) {
                            Text("Nutrition").font(.headline)
                            LazyVGrid(columns: [GridItem(.flexible()),GridItem(.flexible())],spacing: 10) {
                                foodButton("Food Diary",symbol: "fork.knife",route: .nutrition)
                                foodButton("Log Food",symbol: "plus.circle",route: .foodSearch)
                                foodButton("Photo & Label",symbol: "camera.viewfinder",route: .foodPhoto)
                                foodButton("Create Recipe",symbol: "book.closed",route: .foodRecipe)
                            }
                        }
                    }
                    if let state = store.state, !state.program.isEmpty {
                        let index = state.next % state.program.count
                        Button { Haptics.tick(); dismiss(); DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) { store.openWorkout(index, haptic: false) } } label: {
                            HStack(spacing: 12) { WorkoutSummary(day: state.program[index], titlePrefix: "Up Next • "); Image(systemName: "chevron.right").foregroundStyle(.tertiary) }.padding(16).overlay(RoundedRectangle(cornerRadius: 12).stroke(Palette.control,lineWidth: 2))
                        }.buttonStyle(.plain)
                    }
                    VStack(spacing: 0) {
                        SettingsRow(title: "Empty Workout",symbol: "arrow.right.to.line") { Haptics.tick(); dismiss(); DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) { store.startEmpty(haptic: false) } }
                        Divider().overlay(Palette.separator).padding(.leading, 65)
                        SettingsRow(title: "New Program",symbol: "point.topleft.down.to.point.bottomright.curvepath") { Haptics.tick(); open(.newProgram) }
                        Divider().overlay(Palette.separator).padding(.leading, 65)
                        SettingsRow(title: "New Workout",symbol: "dumbbell.fill") { Haptics.tick(); open(.newWorkout) }
                    }
                }.padding(.horizontal, 16).padding(.top, 18).padding(.bottom, 16)
                    .background(GeometryReader { geometry in
                        Color.clear.preference(key: ShortcutContentHeight.self, value: geometry.size.height)
                    })
            }
        }.sheet(item: $utility) { UtilityView(kind: $0) }
            .onPreferenceChange(ShortcutContentHeight.self) { height in
                if height > 0 { contentHeight = ceil(height) }
            }
            .presentationDetents([.height(min(750,max(280, contentHeight + 69))),.large])
            .presentationDragIndicator(.visible).presentationCornerRadius(16)
            .presentationBackground(Palette.surface)
    }
    private func foodButton(_ name: String,symbol: String,route: AppSheet) -> some View {
        Button { Haptics.tick(); open(route) } label: { HStack(spacing: 9) { Image(systemName: symbol); Text(name).font(.system(size: 13,weight: .medium)); Spacer(minLength: 0) }.padding(14).frame(minHeight: 48).background(Palette.control,in: RoundedRectangle(cornerRadius: 10)) }.buttonStyle(.plain)
    }
    private func utilityButton(_ name: String,symbol: String,kind: UtilityKind) -> some View {
        Button { Haptics.tick(); utility = kind } label: { VStack(spacing: 9) { ReferenceSymbol(name: symbol).font(.title2).frame(width: 50,height: 50).background(Palette.control,in: Circle()); Text(name).font(.subheadline) }.frame(maxWidth: .infinity) }.buttonStyle(.plain)
    }
}
private struct ShortcutContentHeight: PreferenceKey {
    static var defaultValue: CGFloat = 0
    static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) {
        value = max(value, nextValue())
    }
}
struct ProgramBuilderView: View {
    @EnvironmentObject var store: TrainingStore
    @Environment(\.dismiss) var dismiss
    @State private var goal = "Muscle growth"
    @State private var days = 3
    @State private var minutes = 60
    @State private var experience = "Intermediate"
    @State private var equipment = "Full gym"
    @State private var confirm = false
    var body: some View {
        NavigationStack {
            Form {
                Section("Training") {
                    Picker("Goal",selection: $goal) { ForEach(["Muscle growth","Strength"],id: \.self) { Text($0) } }
                    Picker("Experience",selection: $experience) { ForEach(["Beginner","Intermediate","Advanced"],id: \.self) { Text($0) } }
                    Picker("Equipment",selection: $equipment) { ForEach(["Full gym","Dumbbells","Bodyweight"],id: \.self) { Text($0) } }
                    Stepper("\(days) days per week",value: $days,in: 2...6)
                    Stepper("\(minutes) minutes per workout",value: $minutes,in: 30...90,step: 15)
                }
                Section { PrimaryButton(label: "Create Program") { Haptics.tick(); if store.state?.program.isEmpty == false { confirm = true } else { create() } } }
            }.darkForm().navigationTitle("New Program").navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Close") { Haptics.tick(); dismiss() } } }
                .onChange(of: goal) { Haptics.tick() }.onChange(of: days) { Haptics.tick() }.onChange(of: minutes) { Haptics.tick() }.onChange(of: experience) { Haptics.tick() }.onChange(of: equipment) { Haptics.tick() }
                .confirmationDialog("Replace your active program? Your workout history will stay saved.",isPresented: $confirm,titleVisibility: .visible) { Button("Replace Program",role: .destructive) { Haptics.tick(); create() } }
        }
    }
    private func create() { if store.send("generate", ["settings": ["goal": goal,"days": days,"minutes": minutes,"experience": experience,"equipment": equipment]]) { store.tab = 1; dismiss() } }
}
struct ProgramEditorView: View {
    var createNew = false
    @State private var loaded = false
    @EnvironmentObject var store: TrainingStore
    @Environment(\.dismiss) var dismiss
    @State private var program: [ProgramDay] = []
    @State private var addTo: Int?
    var body: some View {
        NavigationStack {
            List {
                ForEach(program.indices,id: \.self) { index in
                    Section {
                        TextField("Workout name",text: $program[index].name)
                        ForEach(program[index].items.indices,id: \.self) { item in
                            VStack(alignment: .leading,spacing: 8) {
                                Text(store.exercise(program[index].items[item].id)?.name ?? "Exercise")
                                Stepper("\(program[index].items[item].sets) sets",value: haptic($program[index].items[item].sets),in: 1...20)
                                HStack { Text("Reps"); Stepper("\(program[index].items[item].min)–\(program[index].items[item].max)",onIncrement: { if program[index].items[item].max < 50 { program[index].items[item].min += 1; program[index].items[item].max += 1 }; Haptics.tick() },onDecrement: { if program[index].items[item].min > 1 { program[index].items[item].min -= 1; program[index].items[item].max -= 1 }; Haptics.tick() }) }
                                Stepper("\(program[index].items[item].rir) RIR",value: haptic($program[index].items[item].rir),in: 0...6)
                                Stepper("Rest: \(program[index].items[item].rest)s",value: haptic($program[index].items[item].rest),in: 0...600,step: 15)
                            }.padding(.vertical,6)
                        }.onDelete { program[index].items.remove(atOffsets: $0); Haptics.tick() }.onMove { program[index].items.move(fromOffsets: $0,toOffset: $1); Haptics.tick() }
                        Button("Add Exercise",systemImage: "plus") { Haptics.tick(); addTo = index }.disabled(program[index].items.count >= 30)
                    } header: { Text("Workout \(index + 1)") }
                }
                if program.count < 7 { Button("Add Workout",systemImage: "plus") { Haptics.tick(); program.append(ProgramDay(name: "Workout \(program.count + 1)",items: [])) } }
            }.darkForm().navigationTitle("Edit Workouts").navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) { Button("Cancel") { Haptics.tick(); dismiss() } }
                    ToolbarItem(placement: .confirmationAction) { Button("Save") { do { if store.send("program",["program": try jsonObject(program)],haptic: true) { dismiss() } } catch { store.error = error.localizedDescription } } }
                }
                .onAppear { if !loaded { program = store.state?.program ?? []; if createNew && program.count < 7 { program.append(ProgramDay(name: "Workout \(program.count + 1)",items: [])) }; loaded = true } }
                .sheet(isPresented: Binding(get: { addTo != nil },set: { if !$0 { addTo = nil } })) {
                    ExerciseLibraryView(onSelect: { e in guard let index = addTo, program.indices.contains(index) else { return }; Haptics.tick(); program[index].items.append(Target(id: e.id,sets: 3,min: 8,max: 12,rir: 2,rest: 90,increment: e.increment,group: "")); addTo = nil })
                }
        }
    }
    private func haptic<T>(_ binding: Binding<T>) -> Binding<T> { Binding(get: { binding.wrappedValue },set: { binding.wrappedValue = $0; Haptics.tick() }) }

}
