import Foundation

struct Exercise: Codable, Identifiable {
    let id: String
    let name: String
    let muscle: String
    let equipment: String
    let cue: String
    let increment: Double
    var primary: [String]?
    var secondary: [String]?
    var instructions: [String]?
    var aliases: [String]?
    var category: String?
    var metric: String?
}
struct CycleTarget: Codable { var sets: Int; var min: Int; var max: Int; var rir: Int }
struct Target: Codable {
    var id: String; var sets: Int; var min: Int; var max: Int; var rir: Int
    var rest: Int; var increment: Double; var group: String
    var minWeight: Double?; var maxWeight: Double?; var availableWeights: [Double]?
    var loadMode: String?; var cycles: [CycleTarget]?
}
struct ProgramDay: Codable { var name: String; var items: [Target] }
struct LoggedSet: Codable {
    var weight: Double; var reps: Int; var rir: Int; var done: Bool; var kind: String
    var seconds: Double?; var distance: Double?; var manual: Bool?
}
struct SessionExercise: Codable { var target: Target; var sets: [LoggedSet]; var note: String }
struct Session: Codable, Identifiable {
    let id: String; var name: String; let started: String; var ended: String?
    var day: Int; var cycle: Int; var deload: Bool; var items: [SessionExercise]; var free: Bool?
}
struct TrainingSettings: Codable {
    var goal: String; var days: Int; var minutes: Int; var experience: String; var equipment: String
    var deload: Bool; var periodize: Bool; var deloadTiming: String?
    var progression: ProgressionSettings?
}
struct ProgressionSettings: Codable {
    var applyInSession: Bool?; var initialFill: String?; var expandRepRange: Bool?
    var weightMatch: Bool?; var maxIncreasePercent: Double?
}
struct TrainingState: Decodable {
    var settings: TrainingSettings; var program: [ProgramDay]; var history: [Session]
    var active: Session?; var next: Int; var custom: [Exercise]
}
struct MuscleContribution: Decodable, Identifiable {
    var id: String; var name: String; var sets: Double; var weighted: Double
}
struct MuscleLevel: Decodable {
    var sets: Double; var weekly: Double; var lifts: [MuscleContribution]
}
struct Recommendation: Decodable {
    var weight: Double; var reps: Int; var rir: Int; var reason: String
    var details: [String]; var warning: String?; var confidence: String; var mode: String
}
struct Review: Decodable { var status: String; var message: String }
struct Analysis: Decodable {
    var levels: [String: MuscleLevel]; var recommendations: [[Recommendation]]; var review: Review
}
struct Bootstrap: Decodable { let state: TrainingState; let exercises: [Exercise] }
struct DiskState: Codable { var schemaVersion: Int = 1; var stateJSON: String }
struct BackupDocument: Codable {
    var schemaVersion: Int = 1
    var state: String
}
let upperMuscles = ["Chest","Upper Back","Lats","Biceps","Triceps","Front Delts","Side Delts","Lower Back","Abs","Traps","Rear Delts","Forearms","Obliques","Neck","Lower Traps"]
let lowerMuscles = ["Quads","Hamstrings","Glutes","Adductors","Abductors","Calves","Tibialis"]
let rearMuscles: Set<String> = ["Upper Back","Lats","Lower Back","Traps","Lower Traps","Rear Delts","Triceps","Hamstrings","Glutes","Abductors","Calves"]
extension Double {
    var short: String { formatted(.number.precision(.fractionLength(0...1))) }
}
func jsonObject<T: Encodable>(_ value: T) throws -> Any {
    try JSONSerialization.jsonObject(with: JSONEncoder().encode(value))
}
func parseDate(_ value: String) -> Date {
    let f = ISO8601DateFormatter(); f.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
    return f.date(from: value) ?? ISO8601DateFormatter().date(from: value) ?? .distantPast
}

struct WorkoutRoute: Identifiable { let id: Int }
