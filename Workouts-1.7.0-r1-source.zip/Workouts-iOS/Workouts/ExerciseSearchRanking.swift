import Foundation

// Curated familiarity order, not global popularity telemetry. Only picker presentation changes.
enum ExerciseSearchRanking {
    private static let common = ["bench","squat","db-Barbell_Deadlift","pullup","pulldown","row","dbrow","ohp","legpress","rdl","incline","db-Dumbbell_Bench_Press","lateral","curl","triceps","pushup","legcurl","legext","db-Barbell_Hip_Thrust","goblet","hammer","calf","db-Plank","db-Chin-Up","db-Bent_Over_Barbell_Row","db-Front_Barbell_Squat","split","hip","fly","extension","preacher","reverse","dbrdl","db-Lying_Leg_Curls","db-Running_Treadmill"]
    private static let priority = Dictionary(uniqueKeysWithValues: common.enumerated().map { ($0.element,$0.offset) })
    private static let familiarAliases: [String:[String]] = [
        "bench":["bench press","flat bench","barbell bench"],
        "squat":["squat","back squat","barbell squat"],
        "db-Barbell_Deadlift":["deadlift","conventional deadlift"],
        "rdl":["rdl","romanian deadlift"],"dbrdl":["dumbbell rdl"],
        "pullup":["pull up","pullup"],"pushup":["push up","pushup"],
        "ohp":["shoulder press","overhead press"],"curl":["bicep curl","biceps curl"],
        "db-Front_Barbell_Squat":["front squat"],"db-Plank":["plank"]
    ]
    static func normalize(_ text: String) -> String {
        text.folding(options: [.caseInsensitive,.diacriticInsensitive],locale: Locale(identifier: "en_US_POSIX"))
            .split(whereSeparator: { !$0.isLetter && !$0.isNumber }).map { $0 == "db" ? "dumbbell" : ($0 == "bb" ? "barbell" : String($0)) }.joined(separator: " ")
    }
    static func results(_ exercises: [Exercise],query: String = "") -> [Exercise] {
        let q = normalize(query), tokens = q.split(separator: " ")
        return exercises.compactMap { exercise -> (Exercise,Int,Int,String)? in
            let name = normalize(exercise.name)
            let aliases = ((exercise.aliases ?? []) + (familiarAliases[exercise.id] ?? [])).map(normalize)
            let text = ([name,normalize(exercise.muscle),normalize(exercise.equipment)] + aliases).joined(separator: " ")
            guard tokens.allSatisfy({ text.contains($0) }) else { return nil }
            let relevance = q.isEmpty || name == q || aliases.contains(q) ? 0 : (name.contains(q) ? 1 : (aliases.contains { $0.contains(q) } ? 2 : 3))
            return (exercise,relevance,priority[exercise.id] ?? 10000,name)
        }.sorted { a,b in
            if a.1 != b.1 { return a.1 < b.1 }
            if a.2 != b.2 { return a.2 < b.2 }
            return a.3 == b.3 ? a.0.id < b.0.id : a.3 < b.3
        }.map { $0.0 }
    }
}
