import SwiftUI
import Charts

struct AnalyticsRoute: Identifiable {
    let title: String
    var kind = "workouts"
    var exerciseID: String? = nil
    var id: String { title + kind + (exerciseID ?? "") }
}
struct AnalyticsPoint: Identifiable { let date: Date; let value: Double; var id: Date { date } }

struct AnalyticsDetailView: View {
    @EnvironmentObject var store: TrainingStore
    let route: AnalyticsRoute
    let close: () -> Void
    @StateObject private var bodyRecords = UtilityStore()
    @State private var range = 7
    @State private var metric = "Sets"
    @State private var editor: UtilityKind?
    private let ranges = [7,30,90,180,365,0]
    private var choices: [String] {
        if route.kind == "exercise" { return ["1-RM", "3-RM", "10-RM", "Heaviest Weight", "Total Volume", "Best Set Volume", "Total Reps"] }
        return ["Sets", "Volume"]
    }
    private var isBody: Bool { ["weight", "bodyFat"].contains(route.kind) }
    private var points: [AnalyticsPoint] {
        let cutoff = range == 0 ? Date.distantPast : Calendar.current.date(byAdding: .day, value: -(range - 1), to: Calendar.current.startOfDay(for: Date()))!
        if isBody {
            return bodyRecords.records.compactMap { record in
                guard let date = ISO8601DateFormatter().date(from: record.id + "T12:00:00Z"), date >= cutoff, date <= Date(), let value = route.kind == "weight" ? record.weight : record.bodyFat else { return nil }
                return AnalyticsPoint(date: date,value: value)
            }.sorted { $0.date < $1.date }
        }
        var totals: [Date: Double] = [:]
        for session in store.state?.history ?? [] {
            let date = Calendar.current.startOfDay(for: parseDate(session.ended ?? session.started))
            guard date >= cutoff, date <= Date() else { continue }
            for item in session.items {
                if let id = route.exerciseID, item.target.id != id { continue }
                let exercise = store.exercise(item.target.id)
                let primary = exercise?.primary ?? [exercise?.muscle ?? ""]
                let secondary = exercise?.secondary ?? []
                let credit = route.kind == "muscle" ? (primary.contains(route.title) ? 1.0 : secondary.contains(route.title) ? 0.5 : 0) : 1
                guard credit > 0 else { continue }
                for set in item.sets where set.done && set.kind != "Warm-up" {
                    let value: Double
                    if route.kind == "exercise" {
                        switch metric {
                        case "Heaviest Weight": value = set.weight
                        case "Total Volume", "Best Set Volume": value = set.weight * Double(set.reps)
                        case "Total Reps": value = Double(set.reps)
                        default:
                            let denominator = metric == "3-RM" ? 1.1 : metric == "10-RM" ? (1 + 10.0 / 30) : 1
                            value = set.weight * (1 + Double(set.reps) / 30) / denominator
                        }
                    } else { value = metric == "Volume" ? set.weight * Double(set.reps) * credit : credit }
                    if route.kind == "exercise" && !["Total Volume", "Total Reps"].contains(metric) { totals[date] = max(totals[date] ?? 0, value) }
                    else { totals[date,default: 0] += value }
                }
            }
        }
        return totals.map { AnalyticsPoint(date: $0.key,value: $0.value) }.sorted { $0.date < $1.date }
    }
    private var chartStart: Date { range == 0 ? (points.first?.date ?? Date().addingTimeInterval(-6 * 86400)) : Date().addingTimeInterval(-Double(range - 1) * 86400) }
    private var unit: String { route.kind == "bodyFat" ? "%" : isBody || metric.contains("Weight") || metric.contains("RM") || metric.contains("Volume") ? "lb" : metric == "Total Reps" ? "reps" : "sets" }
    var body: some View {
        ScrollView {
            VStack(spacing: 0) {
                HStack {
                    Button(action: close) { Image(systemName: "chevron.left").frame(width: 44,height: 44) }.accessibilityLabel("Back to dashboard")
                    Text(route.title).font(.system(size: 17)).frame(maxWidth: .infinity).lineLimit(1)
                    if isBody { Button { editor = route.kind == "weight" ? .weight : .metrics } label: { Image(systemName: "plus").frame(width: 44,height: 44) }.accessibilityLabel("Add entry") } else { Color.clear.frame(width: 44,height: 44) }
                }.padding(.bottom, 10)
                if !isBody {
                    ScrollView(.horizontal) {
                        HStack(spacing: 24) { ForEach(choices,id: \.self) { name in Button { metric = name } label: { Text(name).font(.subheadline).padding(.vertical, 12).overlay(alignment: .bottom) { Rectangle().fill(metric == name ? Color.primary : .clear).frame(height: 3) } }.buttonStyle(.plain) } }.padding(.horizontal, 16)
                    }.scrollIndicators(.hidden)
                }
                VStack(alignment: .leading, spacing: 16) {
                    HStack(alignment: .top, spacing: 36) {
                        summary("Average", value: points.isEmpty ? nil : points.reduce(0) { $0 + $1.value } / Double(points.count))
                        summary(isBody ? "Difference" : "Total", value: isBody ? points.last.map { $0.value - (points.first?.value ?? 0) } : points.reduce(0) { $0 + $1.value })
                        Spacer(minLength: 0)
                    }
                    Text("\(chartStart.formatted(.dateTime.month(.abbreviated).day())) – \(Date().formatted(.dateTime.month(.abbreviated).day().year()))").font(.caption).foregroundStyle(Palette.secondary)
                    Chart(points) { point in
                        if isBody || metric.contains("RM") || metric == "Heaviest Weight" {
                            LineMark(x: .value("Date",point.date),y: .value("Value",point.value)).foregroundStyle(Palette.teal)
                            PointMark(x: .value("Date",point.date),y: .value("Value",point.value)).foregroundStyle(Palette.teal)
                        } else { BarMark(x: .value("Date",point.date, unit: .day),y: .value("Value",point.value)).foregroundStyle(Palette.coral) }
                    }.chartXScale(domain: chartStart...Date()).chartYScale(domain: 0...max(10, (points.map(\.value).max() ?? 0) * 1.15))
                        .chartYAxis { AxisMarks(position: .trailing) }.frame(height: 295)
                    HStack(spacing: 0) {
                        ForEach(ranges,id: \.self) { days in Button { range = days } label: { Text(rangeLabel(days)).font(.system(size: 12)).frame(maxWidth: .infinity).padding(.vertical, 10).foregroundStyle(range == days ? Palette.background : Color.primary).background(range == days ? Color.primary : .clear,in: Capsule()) }.buttonStyle(.plain) }
                    }.background(Palette.control,in: Capsule())
                }.padding(16)
            }.background(Palette.surface)
            VStack(spacing: 18) {
                Label(isBody ? route.title : metric,systemImage: "chart.bar.fill").font(.caption).frame(maxWidth: .infinity).padding(16).card()
                if points.isEmpty { Text("Your logged data will appear here.").font(.subheadline).foregroundStyle(Palette.secondary).padding(.vertical, 24) }
                if route.kind == "exercise" && metric.contains("RM") { Text("Rep-max values are estimates calculated from your completed sets.").font(.caption).foregroundStyle(Palette.secondary) }
                ForEach(points.reversed()) { point in
                    HStack { VStack(alignment: .leading,spacing: 5) { Text("\(point.value.short) \(unit)"); Text(point.date.formatted(date: .abbreviated,time: .omitted)).font(.caption).foregroundStyle(Palette.secondary) }; Spacer() }.padding(16).card()
                }
            }.padding(16)
        }.background(Palette.background).onAppear { if route.kind == "exercise" { metric = "1-RM" } }
            .sheet(item: $editor, onDismiss: { bodyRecords.reload() }) { UtilityView(kind: $0) }
    }
    private func rangeLabel(_ days: Int) -> String { [7:"1W",30:"1M",90:"3M",180:"6M",365:"1Y",0:"All"][days] ?? "All" }
    private func summary(_ title: String,value: Double?) -> some View { VStack(alignment: .leading,spacing: 6) { Text(title).font(.caption).foregroundStyle(Palette.secondary); HStack(alignment: .firstTextBaseline,spacing: 3) { Text(value?.short ?? "––").font(.title2); Text(unit).font(.caption).foregroundStyle(Palette.secondary) } } }
}

struct HabitDetailView: View {
    let title: String
    let dates: Set<String>
    let close: () -> Void
    @State private var month = Date()
    private let calendar = Calendar.current
    private var start: Date { calendar.date(from: calendar.dateComponents([.year,.month],from: month))! }
    private var grid: [Date] {
        let offset = (calendar.component(.weekday,from: start) + 5) % 7
        return (0..<42).compactMap { calendar.date(byAdding: .day,value: $0-offset,to: start) }
    }
    private func key(_ date: Date) -> String { date.formatted(.iso8601.year().month().day().dateSeparator(.dash)) }
    var body: some View {
        ScrollView {
            VStack(alignment: .leading,spacing: 22) {
                HStack { Button(action: close) { Image(systemName: "chevron.left").frame(width: 44,height: 44) }; Text(title).frame(maxWidth: .infinity); Color.clear.frame(width: 44,height: 44) }
                Text("\(dates.count) days tracked").font(.title3).foregroundStyle(Palette.secondary)
                LazyVGrid(columns: Array(repeating: GridItem(.flexible()),count: 7),spacing: 15) {
                    ForEach(grid,id: \.self) { date in
                        Text("\(calendar.component(.day,from: date))").font(.subheadline).frame(width: 40,height: 40)
                            .background(dates.contains(key(date)) ? Palette.coral : .clear,in: Circle())
                            .overlay(Circle().stroke(Calendar.current.isDateInToday(date) ? Color.primary : Palette.separator))
                            .opacity(calendar.isDate(date,equalTo: month,toGranularity: .month) ? 1 : 0.25)
                    }
                }
                HStack { Button { month = calendar.date(byAdding: .month,value: -1,to: month)! } label: { Image(systemName: "chevron.left").padding(12) }; Spacer(); Text(month.formatted(.dateTime.month(.wide).year())); Spacer(); Button { month = calendar.date(byAdding: .month,value: 1,to: month)! } label: { Image(systemName: "chevron.right").padding(12) } }
                HStack { Label("Tracked",systemImage: "circle.fill").foregroundStyle(Palette.coral); Label("Untracked",systemImage: "circle").foregroundStyle(Palette.secondary) }.font(.caption).frame(maxWidth: .infinity).padding(14).card()
                Text(month.formatted(.dateTime.year())).font(.title3.bold())
                let yearStart = calendar.date(from: calendar.dateComponents([.year],from: month))!
                LazyVGrid(columns: Array(repeating: GridItem(.flexible(),spacing: 3),count: 26),spacing: 3) {
                    ForEach(0..<(calendar.range(of: .day,in: .year,for: month)?.count ?? 365),id: \.self) { offset in
                        let date = calendar.date(byAdding: .day,value: offset,to: yearStart)!
                        Rectangle().fill(dates.contains(key(date)) ? Palette.coral : Palette.control).frame(height: 7)
                    }
                }
            }.padding(16)
        }.background(Palette.surface)
    }
}
