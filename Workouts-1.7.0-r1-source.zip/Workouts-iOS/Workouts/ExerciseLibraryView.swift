import SwiftUI

struct ExerciseLibraryView: View {
    @EnvironmentObject var store: TrainingStore
    @Environment(\.dismiss) var dismiss
    var onSelect: ((Exercise) -> Void)? = nil
    @State private var search = ""
    @State private var muscle = "All"
    @State private var videosOnly = false
    private var filtered: [Exercise] {
        let eligible = store.catalog.filter { exercise in
            (!videosOnly || ExerciseVideo.forExercise(exercise) != nil || ExerciseVideo.customURL(exercise.id) != nil) && (muscle == "All" || (exercise.primary ?? [exercise.muscle]).contains(muscle))
        }
        return ExerciseSearchRanking.results(eligible,query: search)

    }
    var body: some View {
        NavigationStack {
            List {
                Picker("Muscle",selection: $muscle) { Text("All muscles").tag("All"); ForEach(upperMuscles + lowerMuscles,id: \.self) { Text($0).tag($0) } }
                Toggle("With demonstration",isOn: $videosOnly)
                Section("\(filtered.count) exercises · Common first") {
                    ForEach(filtered) { exercise in
                        if let onSelect {
                            Button { onSelect(exercise) } label: { row(exercise) }.buttonStyle(.plain).accessibilityIdentifier("exercise-result-" + exercise.id)
                        } else { NavigationLink { ExerciseDetailView(exercise: exercise) } label: { row(exercise) }.accessibilityIdentifier("exercise-result-" + exercise.id) }
                    }
                }
            }.darkForm().onChange(of: muscle) { if onSelect != nil { Haptics.tick() } }.searchable(text: $search,placement: .navigationBarDrawer(displayMode: .always),prompt: "Name, equipment or muscle").navigationTitle(onSelect == nil ? "Exercises" : "Add Exercise").navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Close") { if onSelect != nil { Haptics.tick() }; dismiss() } } }
        }
    }
    private func row(_ exercise: Exercise) -> some View {
        HStack(spacing: 14) { Image(systemName: "dumbbell").font(.title3).frame(width: 38,height: 38).background(Palette.control,in: RoundedRectangle(cornerRadius: 8)); VStack(alignment: .leading,spacing: 5) { Text(exercise.name); Text("\(exercise.muscle) · \(exercise.equipment)").font(.caption).foregroundStyle(Palette.secondary) } }.padding(.vertical,4)
    }
}
struct ExerciseDetailView: View {
    @EnvironmentObject var store: TrainingStore
    @Environment(\.dismiss) private var dismiss
    let exercise: Exercise
    @State private var tab = "Instructions"
    @State private var expanded = true
    @State private var newestFirst = true
    @State private var historyMetric = "Weight & Reps"
    private var instructions: [String] { exercise.instructions?.isEmpty == false ? exercise.instructions! : [exercise.cue] }
    private var history: [Session] {
        (store.state?.history ?? []).filter { $0.items.contains { $0.target.id == exercise.id && $0.sets.contains(where: \.done) } }
            .sorted { newestFirst ? $0.started > $1.started : $0.started < $1.started }
    }
    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Button { Haptics.tick(); dismiss() } label: { Image(systemName: "xmark").frame(width: 44, height: 44) }.accessibilityLabel("Close exercise information")
                Text(exercise.name).font(.system(size: 17, weight: .semibold)).multilineTextAlignment(.center).frame(maxWidth: .infinity)
                Color.clear.frame(width: 44, height: 44)
            }.padding(.horizontal, 12).padding(.top, 12)
            HStack(spacing: 0) {
                ForEach(["Instructions", "Details", "History"], id: \.self) { name in
                    Button { Haptics.tick(); tab = name } label: {
                        Text(name).font(.system(size: 15)).frame(maxWidth: .infinity).padding(.vertical, 15)
                            .overlay(alignment: .bottom) { Rectangle().fill(tab == name ? Color.primary : .clear).frame(height: 3) }
                    }.buttonStyle(.plain).accessibilityAddTraits(tab == name ? [.isSelected] : [])
                }
            }
            ScrollView {
                if tab == "Instructions" { instructionsContent }
                else if tab == "Details" { detailsContent }
                else { historyContent }
            }.id(tab)
        }.background(Palette.surface).toolbar(.hidden, for: .navigationBar)
            .presentationDetents([.large]).presentationDragIndicator(.visible).presentationCornerRadius(18)
            .onAppear {
                #if DEBUG
                let screen = ProcessInfo.processInfo.environment["WORKOUTS_PREVIEW_SCREEN"]
                if screen == "exercise-details" { tab = "Details" }
                if screen == "exercise-history" { tab = "History" }
                #endif
            }
    }
    private var instructionsContent: some View {
        VStack(alignment: .leading, spacing: 0) {
            ExerciseDemoView(exercise: exercise)
            VStack(alignment: .leading, spacing: 18) {
                Button { Haptics.tick(); withAnimation { expanded.toggle() } } label: {
                    HStack { Text("How to Perform").font(.headline); Spacer(); Text(expanded ? "Collapse" : "Expand").font(.subheadline).underline() }
                }.buttonStyle(.plain)
                if expanded {
                    ForEach(Array(instructions.enumerated()), id: \.offset) { index, instruction in
                        HStack(alignment: .top, spacing: 10) {
                            Text("\(index + 1).").frame(width: 18, alignment: .trailing)
                            Text(instruction).lineSpacing(5).fixedSize(horizontal: false, vertical: true)
                        }.font(.system(size: 15)).foregroundStyle(Palette.secondary)
                    }
                }
            }.padding(20)
        }
    }
    private var detailsContent: some View {
        VStack(alignment: .leading, spacing: 26) {
            VStack(alignment: .leading, spacing: 12) {
                SectionHeading(title: "Target Muscles")
                ScrollView(.horizontal) {
                    HStack(spacing: 10) {
                        ForEach(Array(Set((exercise.primary ?? [exercise.muscle]) + (exercise.secondary ?? []))).sorted(), id: \.self) { muscle in
                            HStack(spacing: 8) {
                                BodyMap(back: rearMuscles.contains(muscle), selected: muscle, thumbnail: true).frame(width: 66, height: 70)
                                VStack(alignment: .leading, spacing: 4) {
                                    Text(muscle).font(.subheadline)
                                    Text((exercise.primary ?? [exercise.muscle]).contains(muscle) ? "Primary" : "Secondary").font(.caption).foregroundStyle(Palette.secondary)
                                }
                            }.padding(6).overlay(RoundedRectangle(cornerRadius: 10).stroke(Palette.separator))
                        }
                    }
                }.scrollIndicators(.hidden)
            }
            VStack(alignment: .leading, spacing: 12) {
                SectionHeading(title: "Resistance Equipment")
                VStack(alignment: .leading, spacing: 14) { Image(systemName: "dumbbell").font(.title2).foregroundStyle(Palette.secondary); Text(exercise.equipment).font(.subheadline) }
                    .padding(16).frame(maxWidth: .infinity, alignment: .leading).overlay(RoundedRectangle(cornerRadius: 10).stroke(Palette.separator))
            }
            VStack(alignment: .leading, spacing: 0) {
                SectionHeading(title: "Details").padding(.bottom, 12)
                detailRow("Alternative Names", value: exercise.aliases?.joined(separator: ", ") ?? "—")
                if let category = exercise.category { detailRow("Type", value: category) }
                detailRow("Metrics", value: exercise.metric == "time" ? "Time" : exercise.metric == "distance" ? "Distance" : "Weight & Reps")
                detailRow("Weight Increment", value: "\(exercise.increment.short) lb")
            }
            Text("Set targets, rest and equipment increments can be edited from this exercise’s Targets menu in your workout.").font(.footnote).foregroundStyle(Palette.secondary)
        }.padding(16)
    }
    private func detailRow(_ title: String, value: String) -> some View {
        VStack(alignment: .leading, spacing: 5) { Text(title).font(.subheadline); Text(value.isEmpty ? "—" : value).font(.caption).foregroundStyle(Palette.secondary); Divider().overlay(Palette.separator).padding(.top, 12) }.padding(.vertical, 10)
    }
    private var historyContent: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                Menu { ForEach(["Weight & Reps", "Volume", "Estimated 1-RM"], id: \.self) { name in Button(name) { Haptics.tick(); historyMetric = name } } } label: { Label(historyMetric, systemImage: "chevron.down").font(.caption).padding(10).background(Palette.control, in: Capsule()) }
                Spacer()
                Button { Haptics.tick(); newestFirst.toggle() } label: { Label(newestFirst ? "Most Recent" : "Oldest First", systemImage: "chevron.down").font(.caption).padding(10).background(Palette.control, in: Capsule()) }
            }
            if history.isEmpty {
                Label("You haven’t logged this exercise yet. Once you log this exercise, history details will appear here.", systemImage: "clock.badge.questionmark")
                    .font(.subheadline).foregroundStyle(Palette.secondary).padding(16).frame(maxWidth: .infinity, alignment: .leading).overlay(RoundedRectangle(cornerRadius: 10).stroke(Palette.separator))
            }
            ForEach(history) { session in
                VStack(alignment: .leading, spacing: 12) {
                    Text(parseDate(session.ended ?? session.started).formatted(date: .abbreviated, time: .omitted)).font(.headline)
                    ForEach(Array(session.items.filter { $0.target.id == exercise.id }.enumerated()), id: \.offset) { _, item in
                        ForEach(Array(item.sets.filter(\.done).enumerated()), id: \.offset) { index, set in
                            HStack { Text("\(index + 1)").foregroundStyle(Palette.secondary); Text(historyValue(set)); Spacer(); Text("\(set.rir) RIR").foregroundStyle(Palette.secondary) }.font(.subheadline)
                        }
                    }
                    Divider().overlay(Palette.separator)
                }.padding(.vertical, 8)
            }
        }.padding(16)
    }
    private func historyValue(_ set: LoggedSet) -> String {
        if let seconds = set.seconds { return "\(seconds.short) sec" }
        if historyMetric == "Volume" { return "\((set.weight * Double(set.reps)).short) lb" }
        if historyMetric == "Estimated 1-RM" { return "\((set.weight * (1 + Double(set.reps) / 30)).short) lb (estimate)" }
        return "\(set.weight.short) lb × \(set.reps)"
    }
}
struct HistoryView: View {
    @EnvironmentObject var store: TrainingStore
    @Environment(\.dismiss) var dismiss
    var date: Date? = nil
    private var sessions: [Session] { (store.state?.history ?? []).filter { session in date.map { Calendar.current.isDate(parseDate(session.ended ?? session.started),inSameDayAs: $0) } ?? true }.sorted { $0.started > $1.started } }
    var body: some View {
        NavigationStack {
            List {
                if sessions.isEmpty { ContentUnavailableView("No completed workouts",systemImage: "dumbbell",description: Text("Completed sessions appear here.")) }
                ForEach(sessions) { session in
                    NavigationLink { SessionDetailView(session: session) } label: {
                        VStack(alignment: .leading,spacing: 6) { Text(session.name).font(.headline); Text(parseDate(session.started).formatted(date: .abbreviated,time: .shortened)).font(.caption).foregroundStyle(Palette.secondary); Text("\(session.items.count) exercises · \(session.items.reduce(0) { $0 + $1.sets.count }) sets").font(.subheadline) }
                    }
                }
            }.darkForm().navigationTitle(date?.formatted(date: .abbreviated,time: .omitted) ?? "History").navigationBarTitleDisplayMode(.inline).toolbar { ToolbarItem(placement: .cancellationAction) { Button("Close") { dismiss() } } }
        }
    }
}
struct SessionDetailView: View {
    @EnvironmentObject var store: TrainingStore
    let session: Session
    var body: some View {
        List { ForEach(Array(session.items.enumerated()),id: \.offset) { _, item in
            Section(store.exercise(item.target.id)?.name ?? item.target.id) {
                ForEach(Array(item.sets.enumerated()),id: \.offset) { index, set in
                    HStack { Text("\(index+1)").foregroundStyle(Palette.secondary); Text(set.seconds != nil ? "\((set.seconds ?? 0).short)s" : "\(set.weight.short) lb × \(set.reps)"); Spacer(); Text("\(set.rir) RIR").foregroundStyle(Palette.secondary); if set.kind != "Work" { Text(set.kind).font(.caption) } }
                }; if !item.note.isEmpty { Text(item.note).foregroundStyle(Palette.secondary) }
            }
        } }.darkForm().navigationTitle(session.name)
    }
}
