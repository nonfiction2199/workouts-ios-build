import Foundation
import SQLite3

// Serialized, read-only queries keep the large catalogue off the main thread.
actor FoodDatabase {
    static let shared = FoodDatabase()
    private var db: OpaquePointer?
    private let transient = unsafeBitCast(-1, to: sqlite3_destructor_type.self)
    init(url: URL? = Bundle.main.url(forResource: "branded-foods",withExtension: "sqlite")) {
        if let url {
            var handle: OpaquePointer?
            if sqlite3_open_v2(url.path,&handle,SQLITE_OPEN_READONLY,nil) == SQLITE_OK { db = handle }
            else { sqlite3_close(handle) }
        }
    }
    func count() -> Int {
        var stmt: OpaquePointer?
        defer { sqlite3_finalize(stmt) }
        guard sqlite3_prepare_v2(db,"SELECT count(*) FROM foods",-1,&stmt,nil) == SQLITE_OK,sqlite3_step(stmt) == SQLITE_ROW else { return 0 }
        return Int(sqlite3_column_int64(stmt,0))
    }
    func search(_ query: String,limit: Int = 60) -> [FoodItem] {
        guard db != nil else { return [] }
        let digits = query.filter(\.isNumber)
        if digits.count >= 8 && digits.count <= 14 && query.allSatisfy({ $0.isNumber || $0.isWhitespace }) { return barcode(digits) }
        let words = query.folding(options: [.caseInsensitive,.diacriticInsensitive],locale: Locale(identifier: "en_US_POSIX")).split(whereSeparator: { !$0.isLetter && !$0.isNumber }).prefix(12)
        guard !words.isEmpty else { return [] }
        let expression = words.map { "\"\($0)\"*" }.joined(separator: " AND ")
        return rows("SELECT f.* FROM food_search s JOIN foods f ON f.id=s.rowid WHERE food_search MATCH ? ORDER BY bm25(food_search) LIMIT ?",text: expression,limit: limit)
    }
    func barcode(_ code: String) -> [FoodItem] {
        let normalized = String(code.drop(while: { $0 == "0" }))
        guard (8...14).contains(code.count),code.allSatisfy(\.isNumber),!normalized.isEmpty else { return [] }
        return rows("SELECT * FROM foods WHERE barcode=? LIMIT ?",text: normalized,limit: 1)
    }
    private func rows(_ sql: String,text: String,limit: Int) -> [FoodItem] {
        var stmt: OpaquePointer?
        defer { sqlite3_finalize(stmt) }
        guard sqlite3_prepare_v2(db,sql,-1,&stmt,nil) == SQLITE_OK else { return [] }
        sqlite3_bind_text(stmt,1,text,-1,transient); sqlite3_bind_int(stmt,2,Int32(max(1,min(limit,100))))
        var foods: [FoodItem] = []
        func string(_ i: Int32) -> String { sqlite3_column_text(stmt,i).map { String(cString: $0) } ?? "" }
        while sqlite3_step(stmt) == SQLITE_ROW {
            let name = string(1),brand = string(2),serving = sqlite3_column_double(stmt,10),servingText = string(11)
            var food = FoodItem(id: "usda-brand-\(sqlite3_column_int64(stmt,0))",name: name,category: string(3),source: "USDA Branded · April 2026",referenceGrams: 100,macros: FoodMacros(calories: sqlite3_column_double(stmt,5),protein: sqlite3_column_double(stmt,6),carbs: sqlite3_column_double(stmt,7),fat: sqlite3_column_double(stmt,8),fiber: sqlite3_column_double(stmt,9)),portions: serving > 0 && serving <= 100000 ? [FoodPortion(name: servingText.isEmpty ? "1 label serving" : servingText,grams: serving)] : [])
            food.brand = brand; food.barcode = string(4); food.fiberMissing = sqlite3_column_type(stmt,9) == SQLITE_NULL
            if food.valid { foods.append(food) }
        }
        return foods
    }
}

// Ranking proposes candidates only; it never silently substitutes a nutrient profile.
enum FoodMatching {
    static func candidates(_ query: String,in foods: [FoodItem],limit: Int = 60) -> [FoodItem] {
        func words(_ text: String) -> Set<String> {
            Set(text.folding(options: [.caseInsensitive,.diacriticInsensitive],locale: Locale(identifier: "en_US_POSIX")).split(whereSeparator: { !$0.isLetter && !$0.isNumber }).map(String.init))
        }
        let wanted = words(query)
        guard !wanted.isEmpty else { return Array(foods.prefix(limit)) }
        let scored = foods.compactMap { food -> (FoodItem,Double)? in
            let tokens = words(food.name + " " + (food.brand ?? ""))
            let hits = wanted.intersection(tokens).count
            guard hits > 0 else { return nil }
            let score = Double(hits)/Double(wanted.count) + Double(hits)/Double(max(tokens.count,1))*0.35
            return (food,score)
        }.sorted { $0.1 == $1.1 ? $0.0.name < $1.0.name : $0.1 > $1.1 }
        return Array(scored.prefix(limit).map(\.0))
    }
}

// Editorial common-food ordering; no global usage statistics are collected or claimed.
// Aliases are display/search labels only. IDs, source names and nutrient profiles stay intact.
enum FoodSearchRanking {
    private static let common: [(String,String)] = [
        ("usda-2706932", "Burger (beef, medium patty, white bun)"),
        ("usda-2709224", "Banana (raw)"),
        ("usda-2707598", "Bread (white)"),
        ("usda-2705956", "Chicken breast (roasted, skinless)"),
        ("usda-2708408", "Rice (white, cooked, no added fat)"),
        ("usda-2707154", "Egg (boiled or poached)"),
        ("usda-2708616", "Pizza (cheese, restaurant, medium crust)"),
        ("usda-2708357", "Pasta (cooked)"),
        ("usda-2709215", "Apple (raw)"),
        ("usda-2705385", "Milk (whole)"),
        ("usda-2705854", "Beef (ground)"),
        ("usda-2709643", "Broccoli (raw)"),
        ("usda-2710155", "Butter (stick)"),
        ("usda-2707684", "Bagel (plain)"),
        ("usda-2706538", "Biryani (chicken)"),
        ("usda-2707613", "Naan"),
        ("usda-2708400", "Quinoa (cooked, no added fat)"),
        ("usda-2709223", "Avocado (raw)"),
        ("usda-2705709", "Cheese (cheddar)"),
        ("usda-2707537", "Peanut butter"),
        ("usda-170894", "Yogurt (Greek, plain, nonfat)"),
        ("usda-2708378", "Oatmeal (plain, fast food)"),
        ("usda-2706286", "Salmon (baked or broiled)"),
        ("usda-2709524", "Potato (baked, peel eaten)"),
        ("usda-2709461", "Fries (potato, fast food)"),
        ("usda-2708304", "Pancakes (plain)"),
        ("usda-2709171", "Orange (raw)"),
        ("usda-2709242", "Mango (raw)"),
        ("usda-2707402", "Hummus (plain)"),
        ("usda-2707408", "Falafel"),
        ("usda-2710077", "Kimchi"),
        ("usda-2707796", "Injera (Ethiopian bread)"),
        ("usda-2707124", "Pho (with meat)"),
        ("usda-2706437", "Chicken curry"),
        ("usda-2707425", "Lentils (cooked, no added fat)"),
        ("usda-2707824", "Tortilla (flour)"),
        ("usda-2708961", "Sushi (California roll)"),
        ("usda-2710375", "Coffee (brewed)"),
        ("usda-2710707", "Water (tap)"),
        ("usda-170273", "Chocolate (dark, 70–85% cacao)"),
        ("usda-2709660", "Carrot (raw)"),
        ("usda-2709784", "Cucumber (raw)"),
        ("usda-2709283", "Strawberry (raw)"),
        ("usda-2709237", "Grapes (raw)"),
        ("usda-2709614", "Spinach (raw)"),
        ("usda-2709239", "Kiwi (raw)"),
        ("usda-2709254", "Pear (raw)"),
        ("usda-2709249", "Peach (raw)"),
        ("usda-2709260", "Pineapple (raw)"),
        ("usda-2709275", "Blueberry (raw)"),
        ("usda-2709281", "Raspberry (raw)"),
        ("usda-2709270", "Watermelon (raw)"),
        ("usda-2709231", "Cherry (raw)"),
        ("usda-170567", "Almonds"),
        ("usda-170187", "Walnuts"),
        ("usda-2707418", "Chickpeas (cooked, no added fat)"),
        ("usda-2707435", "Tofu"),
        ("usda-2706030", "Chicken thigh (roasted, skinless)"),
        ("usda-2705834", "Steak (beef sirloin, lean)"),
        ("usda-174519", "Turkey breast (roasted, meat only)"),
        ("usda-2706311", "Tuna (canned)"),
        ("usda-2705630", "Ice cream (vanilla)"),
        ("usda-2710301", "Jam"),
        ("usda-2710281", "Honey"),
        ("usda-2709757", "Tomato soup"),
        ("usda-2706880", "Sandwich (unspecified)"),
        ("usda-2706167", "Hot dog (beef)"),
        ("usda-2708219", "Popcorn (air-popped, no butter)"),
        ("usda-2708325", "Waffle (plain)"),
        ("usda-2708063", "Donut (plain, cake)"),
        ("usda-2709719", "Tomato (raw)"),
        ("usda-168191", "Dates (medjool)"),
    ]
    private static let titles = Dictionary(uniqueKeysWithValues: common)
    private static let priority = Dictionary(uniqueKeysWithValues: common.enumerated().map { ($0.element.0,$0.offset) })
    static func normalize(_ text: String) -> String {
        text.folding(options: [.caseInsensitive,.diacriticInsensitive],locale: Locale(identifier: "en_US_POSIX"))
            .split(whereSeparator: { !$0.isLetter && !$0.isNumber }).joined(separator: " ")
    }
    static func title(_ food: FoodItem) -> String { titles[food.id] ?? food.name }
    static func isBarcode(_ query: String) -> Bool {
        let digits = query.filter(\.isNumber)
        return (8...14).contains(digits.count) && query.allSatisfy { $0.isNumber || $0.isWhitespace }
    }
    private static func matches(_ query: String,_ food: FoodItem) -> Bool {
        if query.isEmpty { return true }
        let label = normalize(title(food)), original = normalize(food.name), brand = normalize(food.brand ?? "")
        if query.count == 1 { return label.hasPrefix(query) }
        let words = (label + " " + original + " " + brand).split(separator: " ").map(String.init)
        return query.split(separator: " ").allSatisfy { token in
            let q = token.count > 3 && token.hasSuffix("s") ? String(token.dropLast()) : String(token)
            return words.contains { $0.hasPrefix(q) }
        }
    }
    private static func family(_ food: FoodItem) -> String {
        // Collapse browse choices only; expanded results retain every preparation/brand.
        guard food.id.hasPrefix("usda-"), !food.id.hasPrefix("usda-brand-") else {
            if !food.id.hasPrefix("usda-brand-") && !food.source.hasPrefix("Open Food Facts") { return food.id }
            return normalize(food.name) + "|" + normalize(food.brand ?? "")
        }
        let text = normalize(food.name)
        let parts = food.name.split(separator: ",").map { normalize(String($0)) }
        if parts.count > 1 && ["fish","nuts","beef"].contains(parts[0]) { return parts[0] + " " + parts[1] }
        if text.split(separator: " ").contains("naan") { return "naan" }
        if text.hasPrefix("hamburger") { return "hamburger" }
        if text.hasPrefix("biryani") { return "biryani" }
        if text.hasPrefix("potato french fries") { return "fries" }
        return normalize(String(food.name.split(separator: ",").first ?? Substring(food.name)))
    }
    static func results(_ query: String,in foods: [FoodItem],compact: Bool = true,limit: Int = 100) -> [FoodItem] {
        let q = normalize(query)
        let ranked = foods.filter { matches(q,$0) }.map { food -> (FoodItem,(Int,Int,Int,Int),String) in
            let label = normalize(title(food)), original = normalize(food.name)
            let base = normalize(String(title(food).split(separator: "(").first ?? Substring(title(food))))
            let relevance = q.isEmpty || q.count == 1 ? 0 : (label == q || base == q || original == q ? 0 : (label.hasPrefix(q) || original.hasPrefix(q) ? 1 : 2))
            let sourcePenalty = food.id.hasPrefix("usda-brand-") || food.source.hasPrefix("Open Food Facts") ? 10 : 0
            let score = (relevance + sourcePenalty,priority[food.id] == nil ? 1 : 0,priority[food.id] ?? 9999,food.source.hasPrefix("FNDDS") ? 0 : 1)
            return (food,score,label)
        }.sorted { a,b in
            if a.1 != b.1 { return a.1 < b.1 }
            if a.2.count != b.2.count { return a.2.count < b.2.count }
            return a.2 == b.2 ? a.0.id < b.0.id : a.2 < b.2
        }.map { $0.0 }
        var ids = Set<String>(),families = Set<String>()
        return Array(ranked.filter { food in
            guard ids.insert(food.id).inserted else { return false }
            return !compact || families.insert(family(food)).inserted
        }.prefix(limit))
    }
}
