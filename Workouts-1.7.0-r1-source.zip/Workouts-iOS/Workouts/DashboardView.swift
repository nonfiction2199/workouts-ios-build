import SwiftUI

struct DashboardView: View {
    @EnvironmentObject var store: TrainingStore
    let open: (AppSheet) -> Void
    @AppStorage("dashboardInsights") private var dashboardInsights = true
    @AppStorage("dashboardHabits") private var dashboardHabits = true
    @AppStorage("dashboardMetrics") private var dashboardMetrics = true
    @AppStorage("dashboardMuscles") private var dashboardMuscles = true
    @AppStorage("dashboardExercises") private var dashboardExercises = true
    @State private var activeOnly = true
    @State private var page = 0
    @State private var recordMetric = "Volume"
    @State private var analytics: AnalyticsRoute?
    @State private var habit: String?
    @State private var utility: UtilityKind?
    @State private var bodyRecords: [BodyRecord] = []
    private var recent: [Session] { (store.state?.history ?? []).filter { parseDate($0.ended ?? $0.started) > Date().addingTimeInterval(-7 * 86400) && (!activeOnly || $0.free != true) } }
    private var sets: Int { recent.reduce(0) { $0 + $1.items.reduce(0) { $0 + $1.sets.filter { $0.done && $0.kind != "Warm-up" }.count } } }
    private var exerciseIDs: Set<String> { Set(recent.flatMap { $0.items.map { $0.target.id } }) }
    private var muscles: Set<String> { Set(exerciseIDs.flatMap { store.exercise($0)?.primary ?? [] }) }
    private var targets: [Target] { store.state?.program.flatMap(\.items) ?? [] }
    var body: some View {
        Group {
            if let analytics { AnalyticsDetailView(route: analytics) { self.analytics = nil } }
            else if let habit { HabitDetailView(title: habit, dates: habit == "Workouts" ? Set((store.state?.history ?? []).map { dayKey(parseDate($0.ended ?? $0.started)) }) : Set(bodyRecords.filter { $0.weight != nil }.map(\.id))) { self.habit = nil } }
            else { dashboard }
        }
    }
    private var dashboard: some View {
        ScrollView {
            VStack(spacing: 0) {
                VStack(alignment: .leading, spacing: 22) {
                    HStack { ScreenTitle(text: "Dashboard"); Spacer(minLength: 4); CircleAction(symbol: "slider.horizontal.3", label: "Dashboard options") { open(.dashboardSettings) } }
                    TabView(selection: $page) {
                        VStack(alignment: .leading, spacing: 16) {
                    SectionHeading(title: "Weekly Workouts")
                    GeometryReader { geo in
                        let small = max(1, (geo.size.width - 32) / 3.82)
                        HStack(spacing: 16) {
                            progress(value: muscles.count, target: Set(targets.flatMap { store.exercise($0.id)?.primary ?? [] }).count, title: "Muscles", diameter: small, ringHeight: small * 1.82, color: Palette.ringBlue)
                            progress(value: sets, target: targets.reduce(0) { $0 + $1.sets }, title: "Sets", diameter: small * 1.82, ringHeight: small * 1.82, color: Palette.coral)
                            progress(value: exerciseIDs.count, target: Set(targets.map(\.id)).count, title: "Exercises", diameter: small, ringHeight: small * 1.82, color: Palette.teal)
                        }.frame(maxWidth: .infinity, maxHeight: .infinity)
                    }.frame(height: 240)
                    HStack(spacing: 0) { scope("Active Program", active: true); scope("All Workouts", active: false) }.background(Palette.control.opacity(0.8), in: Capsule()).frame(maxWidth: 250).frame(maxWidth: .infinity).padding(.bottom, 12)
                        }.tag(0)
                        RecentRecordsView(metric: $recordMetric).tag(1)
                    }.tabViewStyle(.page(indexDisplayMode: .never)).frame(height: 345)

                }.padding(.horizontal, 16).padding(.top, 4).padding(.bottom, 16).background(Palette.surface)
                HStack(spacing: 6) { ForEach(0..<2) { index in Circle().fill(page == index ? Color.primary : Palette.secondary.opacity(0.35)).frame(width: 4,height: 4) } }.frame(maxWidth: .infinity).padding(.top, 15)
                VStack(alignment: .leading, spacing: 32) {
                    if dashboardInsights {
                    section("Insights & Analytics") {
                        metric(title: "Workouts", subtitle: "Last 7 Workouts", value: workoutValues.isEmpty ? "––" : workoutValues.reduce(0,+).short, unit: "sets", values: workoutValues, action: { analytics = AnalyticsRoute(title: "Workouts") })
                        metric(title: "Weight Trend", subtitle: "Last 7 Days", value: weightValues.last?.short ?? "––", unit: "lb", values: weightValues, line: true, action: { analytics = AnalyticsRoute(title: "Weight Trend",kind: "weight") })
                    }
                    }
                    if dashboardHabits {
                    section("Habits") {
                        habitCard(title: "Weigh-In", dates: Set(bodyRecords.filter { $0.weight != nil }.map(\.id)), action: { habit = "Weigh-In" })
                        habitCard(title: "Workouts", dates: Set((store.state?.history ?? []).map { dayKey(parseDate($0.ended ?? $0.started)) }), action: { habit = "Workouts" })
                    }
                    }
                    if dashboardMetrics {
                    section("Body Metrics") {
                        metric(title: "Scale Weight", subtitle: "Last 7 Entries", value: bodyRecords.first { $0.weight != nil }?.weight?.short ?? "––", unit: "lb", action: { analytics = AnalyticsRoute(title: "Scale Weight",kind: "weight") })
                        metric(title: "Visual Body Fat", subtitle: "Last 7 Entries", value: bodyRecords.first { $0.bodyFat != nil }?.bodyFat?.short ?? "––", unit: "%", action: { analytics = AnalyticsRoute(title: "Visual Body Fat",kind: "bodyFat") })
                    }
                    }
                    if dashboardMuscles {
                    section("Muscle Groups") {
                        muscleCard("Chest"); muscleCard("Upper Back")
                    }
                    }
                    if dashboardExercises {
                    VStack(alignment: .leading, spacing: 14) {
                        HStack { SectionHeading(title: "Exercises"); Button("See All") { open(.catalog) }.fixedSize().underline() }
                        if targets.isEmpty { Text("Create a program to see your exercise stats here.").foregroundStyle(Palette.secondary).padding(20).frame(maxWidth: .infinity, alignment: .leading).card() }
                        else { HStack(alignment: .top, spacing: 10) { ForEach(Array(targets.prefix(2).enumerated()), id: \.offset) { _, target in
                            metric(title: store.exercise(target.id)?.name ?? target.id, subtitle: "Last 7 Workouts", value: bestWeight(target.id), unit: "lb", action: { analytics = AnalyticsRoute(title: store.exercise(target.id)?.name ?? "Exercise",kind: "exercise",exerciseID: target.id) })
                        } } }
                    }
                    }
                }.padding(16).padding(.top, 20)
            }
        }.background(Palette.background, ignoresSafeAreaEdges: [])
            .onAppear { bodyRecords = UtilityStore().records
                #if DEBUG
                if ProcessInfo.processInfo.environment["WORKOUTS_PREVIEW_SCREEN"] == "records" { page = 1 }
                if ProcessInfo.processInfo.environment["WORKOUTS_PREVIEW_SCREEN"] == "analytics" { analytics = AnalyticsRoute(title: "Workouts") }
                #endif
            }
            .sheet(item: $utility, onDismiss: { bodyRecords = UtilityStore().records }) { UtilityView(kind: $0) }
    }
    private func dayKey(_ date: Date) -> String { date.formatted(.iso8601.year().month().day().dateSeparator(.dash)) }
    private var workoutValues: [Double] { (store.state?.history ?? []).sorted { $0.started < $1.started }.suffix(7).map { session in Double(session.items.reduce(0) { $0 + $1.sets.filter { $0.done && $0.kind != "Warm-up" }.count }) } }
    private var weightValues: [Double] {
        let first = dayKey(Calendar.current.date(byAdding: .day, value: -6, to: Date())!)
        return bodyRecords.filter { $0.id >= first && $0.id <= dayKey(Date()) }.sorted { $0.id < $1.id }.compactMap(\.weight)
    }
    private func habitCard(title: String, dates: Set<String>, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 5) {
                Text(title).font(.system(size: 18)); Text("Last 30 Days").font(.system(size: 14)).foregroundStyle(Palette.secondary)
                LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 5), count: 10), spacing: 8) {
                    ForEach(0..<30) { offset in
                        let date = Calendar.current.date(byAdding: .day, value: offset - 29, to: Date())!
                        Rectangle().fill(dates.contains(dayKey(date)) ? Palette.teal : Palette.control.opacity(0.6)).frame(height: 9)
                    }
                }.padding(.vertical, 14)
                HStack { Text("\(dates.filter { $0 >= dayKey(Date().addingTimeInterval(-6 * 86400)) }.count) this week").font(.caption); Spacer(); Image(systemName: "chevron.right").font(.caption).foregroundStyle(.tertiary) }
            }.padding(15).frame(maxWidth: .infinity, alignment: .leading).frame(height: 140).card()
        }.buttonStyle(.plain)
    }
    private func scope(_ title: String, active: Bool) -> some View {
        Button { activeOnly = active } label: {
            Text(title).font(.system(size: 14)).frame(maxWidth: .infinity).padding(.vertical, 11)
                .foregroundStyle(activeOnly == active ? Palette.background : Color.primary)
                .background(activeOnly == active ? Color.primary : Color.clear, in: Capsule())
        }.buttonStyle(.plain).accessibilityAddTraits(activeOnly == active ? [.isSelected] : [])
    }
    private func bestWeight(_ id: String) -> String {
        let weights = (store.state?.history.suffix(7) ?? []).flatMap(\.items).filter { $0.target.id == id }.flatMap(\.sets).filter(\.done).map(\.weight)
        return weights.max()?.short ?? "––"
    }
    private func progress(value: Int, target: Int, title: String, diameter: CGFloat, ringHeight: CGFloat, color: Color) -> some View {
        VStack(spacing: 22) {
            ZStack {
                Circle().stroke(Palette.separator, lineWidth: 4)
                Circle().trim(from: 0,to: target > 0 ? min(1,Double(value)/Double(target)) : 0).stroke(color, style: StrokeStyle(lineWidth: 4,lineCap: .round)).rotationEffect(.degrees(-90))
                VStack(spacing: 0) { Text("\(value)").font(.system(size: 26,weight: .bold)); Text("\(max(0,target-value)) left").font(.system(size: 14)).foregroundStyle(Palette.secondary) }
            }.frame(width: diameter, height: diameter).frame(height: ringHeight)
            VStack(spacing: 7) { Text(title).font(.system(size: 18)); Text("\(target) target").font(.system(size: 14)).foregroundStyle(Palette.secondary) }.fixedSize()
        }.frame(width: diameter).accessibilityElement(children: .ignore).accessibilityLabel("\(title): \(value) of \(target)")
    }
    private func section<Content: View>(_ title: String, @ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading,spacing: 14) {
            HStack { SectionHeading(title: title); if title == "Muscle Groups" { Button("See All") { store.tab = 2 }.underline().fixedSize() } }
            HStack(alignment: .top,spacing: 10,content: content)
        }
    }
    private func muscleCard(_ name: String) -> some View { metric(title: name, subtitle: "Last 7 Days", value: recent.isEmpty ? "––" : (store.analysis?.levels[name]?.weekly ?? 0).short, unit: "sets", action: { analytics = AnalyticsRoute(title: name,kind: "muscle") }) }
    private func metric(title: String, subtitle: String, value: String, unit: String, values: [Double] = [], line: Bool = false, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(alignment: .leading,spacing: 4) {
                Text(title).font(.system(size: 18)).lineLimit(1); Text(subtitle).font(.system(size: 14)).foregroundStyle(Palette.secondary)
                MiniTrend(values: values, line: line).frame(maxWidth: .infinity).frame(height: 50).padding(.top, 10); Divider().overlay(Palette.separator)
                HStack { Text(value).font(.system(size: 19)).lineLimit(1).minimumScaleFactor(0.65); Text(unit).foregroundStyle(Palette.secondary).font(.system(size: 14)); Spacer(minLength: 0); Image(systemName: "chevron.right").foregroundStyle(.tertiary) }.padding(.top, 7)
            }.padding(15).frame(maxWidth: .infinity, alignment: .leading).frame(height: 155).card()
        }.buttonStyle(.plain)
    }
}

struct MiniTrend: View {
    let values: [Double]
    var line = false
    private var color: Color { line ? Color(red: 0.69, green: 0.51, blue: 0.94) : Palette.coral }
    var body: some View {
        GeometryReader { geo in
            if !values.isEmpty {
                let low = values.min() ?? 0
                let high = values.max() ?? 1
                let range = max(high - low, 1)
                if line {
                    Path { path in
                        for (i, value) in values.enumerated() {
                            let x = values.count == 1 ? geo.size.width / 2 : CGFloat(i) / CGFloat(values.count - 1) * (geo.size.width - 6) + 3
                            let y = high == low ? geo.size.height / 2 : geo.size.height - 4 - (value - low) / range * (geo.size.height - 8)
                            if i == 0 { path.move(to: CGPoint(x: x, y: y)) } else { path.addLine(to: CGPoint(x: x, y: y)) }
                        }
                    }.stroke(color, lineWidth: 2)
                    ForEach(values.indices, id: \.self) { i in
                        Circle().fill(Palette.surface).overlay(Circle().stroke(color, lineWidth: 2)).frame(width: 6, height: 6)
                            .position(x: values.count == 1 ? geo.size.width / 2 : CGFloat(i) / CGFloat(values.count - 1) * (geo.size.width - 6) + 3, y: high == low ? geo.size.height / 2 : geo.size.height - 4 - (values[i] - low) / range * (geo.size.height - 8))
                    }
                } else {
                    HStack(alignment: .bottom, spacing: 6) {
                        ForEach(values.indices, id: \.self) { i in Rectangle().fill(color).frame(height: max(1, values[i] / max(high, 1) * geo.size.height)) }
                    }.frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottom)
                }
            }
        }.accessibilityHidden(true)
    }
}

struct RecentRecordsView: View {
    @EnvironmentObject var store: TrainingStore
    @Binding var metric: String
    private var records: [(String, Double)] {
        var best: [String: Double] = [:]
        for session in store.state?.history ?? [] {
            for item in session.items {
                for set in item.sets where set.done && set.kind != "Warm-up" && set.seconds == nil {
                    let value = metric == "Volume" ? set.weight * Double(set.reps) : metric == "Reps" ? Double(set.reps) : set.weight * (1 + Double(set.reps) / 30)
                    best[item.target.id] = max(best[item.target.id] ?? 0, value)
                }
            }
        }
        return best.map { ($0.key,$0.value) }.sorted { $0.1 > $1.1 }.prefix(7).map { $0 }
    }
    var body: some View {
        VStack(alignment: .leading,spacing: 14) {
            SectionHeading(title: "Recent Records")
            VStack(spacing: 12) {
                if records.isEmpty {
                    ForEach(0..<7) { index in
                        HStack { Text("No Records Yet").font(.system(size: 12)).foregroundStyle(Palette.secondary.opacity(0.25)).frame(width: 100,alignment: .leading); Rectangle().fill(Palette.control).frame(width: CGFloat(190-index*21),height: 12); Spacer(minLength: 0) }
                    }
                } else {
                    ForEach(records,id: \.0) { id,value in HStack { Text(store.exercise(id)?.name ?? id).lineLimit(1); Spacer(); Text(value.short).foregroundStyle(Palette.secondary) }.font(.subheadline) }
                }
            }.frame(maxHeight: .infinity)
            HStack(spacing: 0) { ForEach(["Volume","Reps","1-RM"],id: \.self) { name in Button { metric = name } label: { Text(name).font(.subheadline).padding(.horizontal,14).padding(.vertical,10).foregroundStyle(metric == name ? Palette.background : Color.primary).background(metric == name ? Color.primary : .clear,in: Capsule()) }.buttonStyle(.plain) } }.background(Palette.control,in: Capsule()).frame(maxWidth: .infinity)
        }.padding(.bottom, 12)
    }
}
