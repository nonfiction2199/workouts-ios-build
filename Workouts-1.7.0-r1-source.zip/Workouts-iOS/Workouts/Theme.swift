import SwiftUI

// A small set of deliberate palettes. Layout, type sizes and hit targets are
// shared; color is the only variable when switching styles.
struct ThemeColors {
    let background: UInt32
    let surface: UInt32
    let control: UInt32
    let secondary: UInt32
    let separator: UInt32
    let blue: UInt32
    let ringBlue: UInt32
    let coral: UInt32
    let teal: UInt32
    let action: UInt32
    let actionText: UInt32
    let bodySilhouette: UInt32
    let bodyNeutral: UInt32
}

extension UInt32 {
    var uiColor: UIColor {
        UIColor(red: CGFloat((self >> 16) & 0xff) / 255,
                green: CGFloat((self >> 8) & 0xff) / 255,
                blue: CGFloat(self & 0xff) / 255, alpha: 1)
    }
    var swiftColor: Color { Color(uiColor: uiColor) }
}

enum AppTheme: String, CaseIterable, Identifiable {
    case system, light, dark, monochrome, goldBlack, midnight, forest, porcelain
    var id: String { rawValue }
    static func stored(_ value: String) -> AppTheme {
        if let theme = AppTheme(rawValue: value) { return theme }
        let replacements: [String: AppTheme] = ["fieldNotes": .forest, "blueprint": .midnight, "terracotta": .porcelain, "cinder": .goldBlack, "studio": .light]
        return replacements[value] ?? .dark
    }
    static var current: AppTheme { stored(UserDefaults.standard.string(forKey: "appearance") ?? "dark") }
    var name: String {
        switch self {
        case .system: "System"
        case .light: "Light"
        case .dark: "Dark"
        case .monochrome: "Monochrome"
        case .goldBlack: "Black & Gold"
        case .midnight: "Midnight"
        case .forest: "Forest"
        case .porcelain: "Porcelain"
        }
    }
    var subtitle: String {
        switch self {
        case .system: "Follows your device"
        case .light: "Clean and familiar"
        case .dark: "Classic graphite"
        case .monochrome: "Pure black. Sharp lines."
        case .goldBlack: "Warm gold on deep black"
        case .midnight: "Ink, ice and electric blue"
        case .forest: "Deep green and fresh lime"
        case .porcelain: "Soft ivory and plum"
        }
    }
    var cardRadius: CGFloat {
        switch self { case .monochrome: 8; case .goldBlack: 18; case .forest, .porcelain: 22; default: 14 }
    }
    var colorScheme: ColorScheme? {
        switch self { case .system: nil; case .light, .porcelain: .light; default: .dark }
    }
    func resolved(for style: UIUserInterfaceStyle) -> AppTheme {
        self == .system ? (style == .dark ? .dark : .light) : self
    }
    var colors: ThemeColors {
        switch self {
        case .system: return Self.dark.colors
        case .dark:
            return ThemeColors(background: 0x111111, surface: 0x1D1D1D, control: 0x333333,
                secondary: 0xBDBDBD, separator: 0x383838, blue: 0x3263E8,
                ringBlue: 0x528CFF, coral: 0xFF805C, teal: 0x00B3C2,
                action: 0xFFFFFF, actionText: 0x141414, bodySilhouette: 0x383838, bodyNeutral: 0x535353)
        case .light:
            return ThemeColors(background: 0xF5F5F5, surface: 0xFFFFFF, control: 0xEBEBEB,
                secondary: 0x666666, separator: 0xDBDBDB, blue: 0x2878F2,
                ringBlue: 0x528CFF, coral: 0xE36648, teal: 0x087D89,
                action: 0x171717, actionText: 0xFFFFFF, bodySilhouette: 0xC7C7C7, bodyNeutral: 0xA3A3A3)
        case .monochrome:
            return ThemeColors(background: 0x000000, surface: 0x111111, control: 0x242424,
                secondary: 0xAAAAAA, separator: 0x353535, blue: 0xFFFFFF,
                ringBlue: 0xF0F0F0, coral: 0xA0A0A0, teal: 0xD5D5D5,
                action: 0xFFFFFF, actionText: 0x000000, bodySilhouette: 0x303030, bodyNeutral: 0x555555)
        case .goldBlack:
            return ThemeColors(background: 0x080808, surface: 0x171512, control: 0x29251F,
                secondary: 0xC4BBAE, separator: 0x443B2D, blue: 0xE6C477,
                ringBlue: 0xF0D28A, coral: 0xCF9875, teal: 0xA9B49A,
                action: 0xE6C477, actionText: 0x18130B, bodySilhouette: 0x34312B, bodyNeutral: 0x666057)
        case .midnight:
            return ThemeColors(background: 0x070C18, surface: 0x111C30, control: 0x1B2D48,
                secondary: 0xB4C6DD, separator: 0x304765, blue: 0x69C5FF,
                ringBlue: 0x79A7FF, coral: 0xCF9BFF, teal: 0x5FD3CD,
                action: 0x77CEFF, actionText: 0x061423, bodySilhouette: 0x2A394F, bodyNeutral: 0x526A84)
        case .forest:
            return ThemeColors(background: 0x07140F, surface: 0x10271C, control: 0x214331,
                secondary: 0xB2CCBC, separator: 0x365A46, blue: 0xB8E777,
                ringBlue: 0xB8E777, coral: 0xF0B18A, teal: 0x79D4B5,
                action: 0xC5ED8B, actionText: 0x102215, bodySilhouette: 0x2D4838, bodyNeutral: 0x587562)
        case .porcelain:
            return ThemeColors(background: 0xF5F1ED, surface: 0xFFFCF8, control: 0xEAE0DD,
                secondary: 0x6E5C66, separator: 0xD8C8D0, blue: 0x75425D,
                ringBlue: 0x92546F, coral: 0xAA5A3D, teal: 0x456E63,
                action: 0x65354E, actionText: 0xFFFFFF, bodySilhouette: 0xD6C9CC, bodyNeutral: 0xA995A0)
        }
    }
}
