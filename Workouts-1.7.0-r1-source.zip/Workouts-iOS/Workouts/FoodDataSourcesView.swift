import SwiftUI

struct FoodDataSourcesView: View {
    @EnvironmentObject private var nutrition: NutritionStore
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            List {
                Section("Offline library") {
                    LabeledContent("Common foods and dishes",value: nutrition.catalogue.count.formatted())
                    LabeledContent("Branded products",value: nutrition.brandedCount.formatted())
                    Text("USDA FoodData Central: FNDDS 2021–2023, SR Legacy 2018, and Branded Foods April 2026. Public-domain / CC0 data. Branded entries require calories, protein, carbs and fat; implausible per-100 g profiles are omitted and duplicate barcodes retain the highest qualifying FDC identifier.").font(.footnote).foregroundStyle(Palette.secondary)
                    Link("USDA FoodData Central",destination: URL(string: "https://fdc.nal.usda.gov/")!)
                }.listRowBackground(Palette.surface)
                Section("International products") {
                    Text("Open Food Facts is a community database of packaged-food labels. International lookup requires internet, uses no provider key, and sends only your search text or scanned barcode. Products you select are cached on this iPhone for offline use.").font(.footnote).foregroundStyle(Palette.secondary)
                    Text("Contains information from Open Food Facts, made available under the Open Database License (ODbL). Cached records retain their source and can be included in your nutrition backup export.").font(.footnote).foregroundStyle(Palette.secondary)
                    Link("Open Food Facts",destination: URL(string: "https://world.openfoodfacts.org/")!)
                    Link("Open Database License 1.0",destination: URL(string: "https://opendatacommons.org/licenses/odbl/1-0/")!)
                }.listRowBackground(Palette.surface)
                Section("Check before logging") {
                    Text("Choose the exact food and preparation. Product formulas and labels can change; compare your package. A photo identifies possible foods but does not measure weight or hidden ingredients. Missing fiber is explicitly marked. Nutrients are scaled from the database record using your confirmed portion.").font(.footnote).foregroundStyle(Palette.secondary)
                }.listRowBackground(Palette.surface)
            }.darkForm().navigationTitle("Food Sources").navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Done") { dismiss() } } }
        }
    }
}
