import SwiftUI

// Original vector drawing for the reference's upright rocket navigation silhouette.
struct RocketIcon: View {
    var filled = false
    var color: Color = .primary
    var body: some View {
        GeometryReader { geo in
            let scale = min(geo.size.width / 28, geo.size.height / 32)
            ZStack {
                Path { p in
                    p.move(to: CGPoint(x: 14, y: 2)); p.addCurve(to: CGPoint(x: 21, y: 23), control1: CGPoint(x: 22, y: 9), control2: CGPoint(x: 22, y: 16))
                    p.addLine(to: CGPoint(x: 7, y: 23)); p.addCurve(to: CGPoint(x: 14, y: 2), control1: CGPoint(x: 6, y: 16), control2: CGPoint(x: 6, y: 9)); p.closeSubpath()
                }.fill(filled ? color : Color.clear)
                Path { p in
                    p.move(to: CGPoint(x: 14, y: 2)); p.addCurve(to: CGPoint(x: 21, y: 23), control1: CGPoint(x: 22, y: 9), control2: CGPoint(x: 22, y: 16)); p.addLine(to: CGPoint(x: 7, y: 23)); p.addCurve(to: CGPoint(x: 14, y: 2), control1: CGPoint(x: 6, y: 16), control2: CGPoint(x: 6, y: 9)); p.closeSubpath()
                    p.move(to: CGPoint(x: 7, y: 16)); p.addLine(to: CGPoint(x: 3, y: 22)); p.addLine(to: CGPoint(x: 3, y: 28)); p.addLine(to: CGPoint(x: 8, y: 25))
                    p.move(to: CGPoint(x: 21, y: 16)); p.addLine(to: CGPoint(x: 25, y: 22)); p.addLine(to: CGPoint(x: 25, y: 28)); p.addLine(to: CGPoint(x: 20, y: 25))
                    p.move(to: CGPoint(x: 11, y: 26)); p.addLine(to: CGPoint(x: 14, y: 30)); p.addLine(to: CGPoint(x: 17, y: 26))
                }.stroke(color, style: StrokeStyle(lineWidth: 2, lineCap: .round, lineJoin: .round))
                Circle().fill(filled ? Palette.surface : color).frame(width: 6, height: 6).position(x: 14, y: 12)
            }.frame(width: 28, height: 32).scaleEffect(scale, anchor: .topLeading)
                .frame(width: geo.size.width, height: geo.size.height, alignment: .center)
        }.accessibilityHidden(true)
    }
}

// Compact monochrome controls, drawn in a common 24-point coordinate system.
struct ReferenceSymbol: View {
    let name: String
    var body: some View {
        Group {
            switch name {
            case "slider.horizontal.3":
                Canvas { context, size in
                    let s = size.width / 24
                    for (y,x) in [(6.0,15.0),(12.0,8.0),(18.0,14.0)] {
                        var line = Path(); line.move(to: CGPoint(x: 3*s,y: y*s)); line.addLine(to: CGPoint(x: 21*s,y: y*s))
                        context.stroke(line,with: .foreground,lineWidth: 2*s)
                        context.fill(Path(CGRect(x: (x-1.5)*s,y: (y-3)*s,width: 3*s,height: 6*s)),with: .foreground)
                    }
                }.frame(width: 22,height: 22)
            case "calendar":
                Image(systemName: "calendar").symbolRenderingMode(.monochrome).overlay { Rectangle().fill(Palette.control).frame(width: 14,height: 10).offset(y: 3) }
            case "scalemass.fill":
                ZStack { RoundedRectangle(cornerRadius: 3).fill(.primary).frame(width: 19,height: 23); Circle().fill(Palette.control).frame(width: 7,height: 7).offset(y: -5); Text("•••").font(.system(size: 4)).foregroundStyle(.primary).offset(y: -5) }
            case "camera.fill", "camera.badge.ellipsis":
                Image(systemName: "camera.fill").overlay(alignment: .topTrailing) { Image(systemName: "plus").font(.system(size: 10,weight: .heavy)).offset(x: 5,y: -5) }
            case "ruler": MeasuringTapeIcon().frame(width: 25, height: 25)
            case "clock.arrow.circlepath": Image(systemName: "doc.text.fill").overlay(alignment: .bottomTrailing) { Image(systemName: "arrow.counterclockwise").font(.system(size: 13,weight: .bold)).padding(1).background(Palette.control,in: Circle()).offset(x: 5,y: 4) }
            case "dumbbell.fill": Image(systemName: name).rotationEffect(.degrees(-45))
            case "arrow.right.to.line": Image(systemName: "arrow.right").overlay(alignment: .leading) { Rectangle().frame(width: 2,height: 14).offset(x: -5) }
            default: Image(systemName: name)
            }
        }.accessibilityHidden(true)
    }
}
struct DashboardIcon: View {
    let filled: Bool
    var body: some View {
        VStack(spacing: 3) { ForEach(0..<2) { _ in HStack(spacing: 3) { ForEach(0..<2) { _ in Rectangle().fill(filled ? Color.primary : Color.clear).overlay(Rectangle().stroke(Color.primary,lineWidth: filled ? 0 : 2)).frame(width: 9,height: 9) } } } }.frame(width: 24,height: 24).accessibilityHidden(true)
    }
}

// An explicit vector avoids relying on a symbol absent on some supported iOS versions.
struct MeasuringTapeIcon: View {
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 5).fill(Color.primary).frame(width: 22,height: 17).offset(y: -2)
            Circle().fill(Palette.control).frame(width: 7,height: 7).offset(y: -3)
            RoundedRectangle(cornerRadius: 1).fill(Color.primary).frame(width: 24,height: 5).offset(y: 8)
            HStack(spacing: 4) { ForEach(0..<4) { _ in Rectangle().fill(Palette.control).frame(width: 1,height: 3) } }.offset(y: 9)
        }.frame(width: 25,height: 25).accessibilityHidden(true)
    }
}
private struct MeasuringTapeShape: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        path.move(to: CGPoint(x: 4, y: 21))
        path.addLine(to: CGPoint(x: 4, y: 11))
        path.addCurve(to: CGPoint(x: 22, y: 11), control1: CGPoint(x: 4, y: -1), control2: CGPoint(x: 22, y: -1))
        path.addCurve(to: CGPoint(x: 13, y: 21), control1: CGPoint(x: 22, y: 17), control2: CGPoint(x: 19, y: 21))
        path.closeSubpath()
        path.addEllipse(in: CGRect(x: 10, y: 7, width: 6, height: 6))
        path.addRect(CGRect(x: 1, y: 16, width: 2, height: 5))
        let scale = min(rect.width, rect.height) / 24
        return path.applying(CGAffineTransform(a: scale, b: 0, c: 0, d: scale,
            tx: rect.midX - 12 * scale, ty: rect.midY - 12 * scale))
    }
}
