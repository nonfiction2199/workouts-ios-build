# Workouts 1.0.7

Reference: user recording ScreenRecording_09-28-2026 14-42-47_1.mp4, 148.433 seconds, 512 × 1112. Reviewed chronological frames at one-second intervals and revisited screen groups at larger scale. No reference clips have been copied into the exercise demo library.

## Implemented
- Dashboard swipe carousel: Weekly Workouts and Records with Volume/Reps/estimated 1-RM.
- Dedicated workout, muscle, exercise, scale-weight and body-fat analytics with selected time ranges and real saved data.
- Habit detail calendar, month navigation and annual activity grid; square dashboard habit cells.
- Exercise information: fixed header and Instructions/Details/History tabs; collapsible instructions, compact horizontal muscle cards, equipment and catalog metadata, history sorting and metric selection.
- Inline demonstration speeds 0.2×/0.5×/1×, progress bar, pause/resume, muted offline looping.
- Custom Exercise Options sheet, Targets, Superset-with-next/unlink, Swap, Duplicate, Remove and reordering.
- Levels period sheet: 1 week, 1 month, 3 months. Monthly normalization uses 30 and 90 days.
- Metrics icon built from basic shapes; content-measured Shortcuts retained and tightened.
- More grouping, local profile header, Data Visibility, Tutorials, About and version display.

## Unchanged and incomplete
- Training/coaching algorithm and program generator unchanged.
- Existing 38 Goulart demonstration files / 47 exercise-name mappings retained and attributed. No new Nippard videos. Single-angle files cannot provide the original's three camera views.
- Catalog does not have verified ROM/stability scores or full support-equipment metadata; these were not fabricated.
- Steps/HealthKit, account/subscription services, complete units conversion, all per-exercise overrides and exact original artwork remain outside this build.
- Physical-device haptics, Signulous installation and real workout use need device verification.
- No quantified visual-parity claim. Compare matching state and data; generated simulator program differs from the user's reference program.

## Source layout
The repository keeps its existing source ZIP as a baseline for bundled media. NativeSource contains reviewable edited files applied over that baseline. CI creates a complete Workouts-1.0.7-source.zip after merging them. Use that assembled archive for a standalone source handoff.
