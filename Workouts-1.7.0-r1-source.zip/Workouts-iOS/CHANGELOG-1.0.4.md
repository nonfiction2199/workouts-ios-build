# 1.0.4 — visual and native demonstration pass

- Revised display glyph proportions, secondary text contrast, section typography and separators.
- Reference-style Dashboard, settings, calendar and shortcut controls.
- Dashboard and Shortcuts visibility preferences, persistent on-device.
- New Workout shortcut creates an editable unsaved workout draft.
- Silent native AVQueuePlayer/AVPlayerLooper demonstrations with pause, background handling and Reduce Motion support.
- 38 curated CC BY-SA 4.0 clips by Goulart via wger; exact manually reviewed mappings only. This is not the MacroFactor/Jeff Nippard library.
- Import a local MP4/MOV for any exercise; imported media persists through updates but is separate from workout JSON backups.
- Filter exercise library to available demonstrations. Actual frame thumbnails in workout overview.
- Credits, original source links, license and transformation notices included.
- Coaching engine, bundle identifier and workout storage schema unchanged.

Known gaps: no 600-video library, exact MacroSans glyphs or proprietary muscle artwork; More remains limited to implemented capabilities. Similarity estimates are subjective.
