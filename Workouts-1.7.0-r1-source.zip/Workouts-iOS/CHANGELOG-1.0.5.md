# 1.0.5 — visual refinement candidate

This is source awaiting a macOS/Xcode build and simulator review. It has not been measured as 90% visually similar.

- Replaced the missing Metrics SF Symbol with an original vector tape-measure icon.
- Balanced dashboard circle heights across iPhone widths; increased ring caption legibility.
- Matched larger add/rotate controls, workout thumbnails, RIR colors, duration formatting and menu tap targets.
- Adjusted workout row spacing and Shortcuts sheet surface, corner radius and padding.
- Refined shared front/back muscle contours and Levels caption sizing; retained centered geometry.
- Aligned More separators and theme previews; added the existing Weight screen under Feature Settings. Progression remains accessible through Preferences.
- Added bounded simulator recording and two extra playback-frame screenshots for review.

No saved-state schema, bundle identifier, exercise IDs, workout history or coaching algorithm changed.

Media remains 38 Goulart clips / 47 exact exercise-name mappings, with credits retained. No Jeff Nippard clips have been added. Public MacroFactor material describes 638 exercise demonstrations but does not supply a reusable download collection in the sources reviewed.

Validation: all 33 existing engine tests pass; all 38 bundled MP4 files decode and retain attribution; 47 exact exercise-name mappings resolve; shell syntax checks pass. Native compilation, UI screenshot review, video-loop verification and Signulous installation still require the cloud macOS build / iPhone.
