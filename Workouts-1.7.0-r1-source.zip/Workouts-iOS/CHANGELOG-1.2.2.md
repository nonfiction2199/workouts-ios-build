# Workouts 1.2.2 — common exercises first

- Shared exercise picker now prioritizes familiar lifts over niche variations for logging, adding/replacing exercises and library browsing.
- Bench press, back squat and conventional deadlift lead the default list. Specific searches still find specialized exercises, with exact name/alias matches first.
- Existing muscle and demonstration filters are preserved. Common abbreviations and aliases are supported.
- No changes to workout order, progression, targets, exercise IDs or history; ranking is presentation-only and curated rather than measured global usage.
- Includes the simplified food catalogue and prefix browsing from 1.2.1, plus consistent spaced-barcode handling.
