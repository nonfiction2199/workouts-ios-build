import Foundation

@main
struct NutritionTests {
    @MainActor static func main() async throws {
        func check(_ condition: Bool,_ message: String) { if !condition { fatalError(message) } }
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent("nutrition-test-\(UUID())")
        defer { try? FileManager.default.removeItem(at: directory) }
        let store = NutritionStore(directory: directory,loadCatalogue: false)
        let meal = FoodItem(id: "custom-test",name: "Rice & lentils",category: "Custom",source: "Test",referenceGrams: 200,macros: FoodMacros(calories: 400,protein: 20,carbs: 60,fat: 8,fiber: 6),portions: [FoodPortion(name: "1 serving",grams: 200)])
        let date = Date(timeIntervalSince1970: 1791075600)
        check(store.saveFood(meal),"save food")
        check(store.log(meal,grams: 100,date: date,meal: .dinner),"log portion")
        check(store.total(on: date).calories == 200,"correct serving scaling")
        var changed = meal; changed.macros.calories = 600
        check(store.saveFood(changed),"edit saved food")
        check(store.total(on: date).calories == 200,"history snapshots must not change")
        let reopened = NutritionStore(directory: directory,loadCatalogue: false)
        check(reopened.state.entries.count == 1,"persist/reload")
        var entry = store.state.entries[0]; entry.grams = 50; entry.macros = entry.macros.scaled(0.5)
        check(store.update(entry),"edit entry")
        check(store.total(on: date).calories == 100,"edited totals")
        let backup = try store.export(); store.importBackup(backup)
        check(store.state.entries.count == 1,"idempotent merge import")
        var bad = entry; bad.grams = -.infinity
        check(!store.log([bad]),"reject nonfinite portion")
        check(store.state.entries.count == 1,"invalid mutation cannot publish")
        var invalid = store.state; invalid.schemaVersion = 99
        check(!store.commit(invalid),"reject future schema")
        check(!NutritionDay.valid("2026-02-30"),"reject impossible day")
        var calendar = Calendar(identifier: .gregorian); calendar.timeZone = TimeZone(identifier: "America/New_York")!
        let late = ISO8601DateFormatter().date(from: "2026-10-04T01:00:00Z")!
        check(NutritionDay.key(late,calendar: calendar) == "2026-10-03","local date rather than UTC")
        let ingredient = MealIngredient(foodID: meal.id,name: meal.name,grams: 200,macros: meal.macros)
        let recipe = FoodItem(id: "recipe-test",name: "Batch",category: "Recipe",source: "Test",referenceGrams: 300,macros: ingredient.macros,portions: [FoodPortion(name: "1 serving",grams: 150)],ingredients: [ingredient])
        check(recipe.nutrition(grams: 150).calories == 200,"cooked weight and serving arithmetic")
        // Older backups omit the new optional cache fields and still decode.
        let legacy = Data("{\"schemaVersion\":1,\"customFoods\":[],\"entries\":[],\"favorites\":[]}".utf8)
        let legacyState = try JSONDecoder().decode(NutritionState.self,from: legacy)
        check(legacyState.valid,"legacy nutrition backup migration")
        let product: [String:Any] = ["code":"1234567890123","product_name":"Test cereal","brands":"Test brand","serving_quantity":30,"serving_quantity_unit":"g","nutriments":["energy-kcal_100g":400,"proteins_100g":10,"carbohydrates_100g":70,"fat_100g":8]]
        let parsed = InternationalFoodService.food(product)!
        check(parsed.macros.calories == 400 && parsed.fiberMissing == true && parsed.portions.first?.grams == 30,"international label parsing and missing fiber")
        var impossible = product; impossible["nutriments"] = ["energy-kcal_100g":1500,"proteins_100g":10,"carbohydrates_100g":70,"fat_100g":8]
        check(InternationalFoodService.food(impossible) == nil,"implausible per100g product profiles rejected")
        var searchProduct = product; searchProduct["brands"] = ["Test brand","Second brand"]
        check(InternationalFoodService.food(searchProduct)?.brand == "Test brand, Second brand","search endpoint brand arrays")
        var liquid = product; liquid["serving_quantity_unit"] = "ml"
        check(InternationalFoodService.food(liquid)?.portions.isEmpty == true,"milliliters cannot become grams")
        var incomplete = product; incomplete["nutriments"] = ["energy-kcal_100g":400,"proteins_100g":10]
        check(InternationalFoodService.food(incomplete) == nil,"incomplete product macros cannot be invented")
        check(store.remember(parsed),"cache selected international food")
        check(NutritionStore(directory: directory,loadCatalogue: false).food(parsed.id)?.source == parsed.source,"cached source survives relaunch")
        check(store.log(parsed,grams: 25,date: date,meal: .snack),"log source-backed product")
        check(store.state.entries.last?.macros.calories == 100 && store.state.entries.last?.source == parsed.source,"database nutrients scale with confirmed weight")
        let ranked = FoodMatching.candidates("rice",in: [parsed,meal])
        check(ranked.first?.id == meal.id,"photo matches rank food words without automatic substitution")
        let pages = try FileManager.default.contentsOfDirectory(at: URL(fileURLWithPath: "Workouts/Resources"),includingPropertiesForKeys: nil).filter { $0.lastPathComponent.hasPrefix("food-catalog-") && Int($0.deletingPathExtension().lastPathComponent.replacingOccurrences(of: "food-catalog-",with: "")) != nil }
        let commonFoods = try pages.flatMap { try JSONDecoder().decode([FoodItem].self,from: Data(contentsOf: $0)) }
        check(FoodSearchRanking.isBarcode("0160 0027 5287"),"typed barcode spaces match database normalization")
        let naan = FoodSearchRanking.results("naan",in: commonFoods)
        check(naan.count == 1 && naan.first?.id == "usda-2707613","naan search starts with one representative common food")
        let allNaan = FoodSearchRanking.results("naan",in: commonFoods,compact: false)
        check(allNaan.count == 3,"expanded naan keeps all source preparations")
        let b = FoodSearchRanking.results("B",in: commonFoods)
        check(b.first?.id == "usda-2706932" && b.prefix(3).map(FoodSearchRanking.title) == ["Burger (beef, medium patty, white bun)","Banana (raw)","Bread (white)"],"B starts with familiar foods rather than substring matches")
        check(b.allSatisfy { FoodSearchRanking.normalize(FoodSearchRanking.title($0)).hasPrefix("b") },"single letter results start with the chosen letter")
        check(FoodSearchRanking.results("naan whole wheat",in: commonFoods).first?.id == "usda-174077","specific preparation remains searchable")
        check(FoodSearchRanking.results("biryani",in: commonFoods).count == 1 && FoodSearchRanking.results("biryani vegetables",in: commonFoods).first?.id == "usda-2708985","grouping preserves specific cultural preparations")
        let originalBurger = commonFoods.first { $0.id == b.first?.id }!
        check(b.first?.name == originalBurger.name && b.first?.macros == originalBurger.macros,"friendly search titles cannot alter food identity or nutrients")
        let aResult = FoodSearchRanking.results("A",in: commonFoods)
        check(aResult.allSatisfy { FoodSearchRanking.normalize(FoodSearchRanking.title($0)).hasPrefix("a") },"prefix browsing generalizes beyond B")
        var categoryNoise = meal; categoryNoise.name = "Oats"; categoryNoise.category = "Banana dishes"
        check(FoodSearchRanking.results("banana",in: [categoryNoise]).isEmpty,"category-only matches do not pollute search")
        let database = FoodDatabase(url: URL(fileURLWithPath: "Workouts/Resources/branded-foods.sqlite"))
        let databaseManifest = try JSONSerialization.jsonObject(with: Data(contentsOf: URL(fileURLWithPath: "Workouts/Resources/branded-food-provenance.json"))) as! [String:Any]
        let databaseCount = databaseManifest["foods"] as! Int
        check(await database.count() == databaseCount,"bundled branded dataset is complete")
        let cereals = await database.search("cheerios")
        check(!cereals.isEmpty && cereals.allSatisfy(\.valid),"indexed brand lookup")
        if let cereal = cereals.first,let barcode = cereal.barcode {
            let padded = String(repeating: "0",count: max(0,14-barcode.count)) + barcode
            check(await database.barcode(padded).first?.id == cereal.id,"barcode lookup normalizes GTIN leading zeros")
        }
        let barcodeFood = await database.barcode("016000275287").first!
        check(store.log(barcodeFood,grams: 100,date: date,meal: .lunch),"log actual bundled barcode product")
        let brandedReload = NutritionStore(directory: directory,loadCatalogue: false)
        check(!brandedReload.blocked && brandedReload.food(barcodeFood.id)?.barcode == barcodeFood.barcode,"branded food cache survives relaunch")
        check(brandedReload.entries(on: date).contains { $0.foodID == barcodeFood.id && $0.macros == barcodeFood.macros },"branded food diary and exact nutrients survive relaunch")
        check(await database.search("\" OR * \" ; DROP TABLE foods").count == 0,"FTS query is tokenized and bound")
        check(await database.count() == databaseCount,"search cannot mutate the database")
        check(RestaurantLookupResponse.requested("daves hot chicken roulette, no bread, jus tthe chicken",sourceURL: ""),"restaurant descriptions do not require from or at")
        check(!RestaurantLookupResponse.requested("  ",sourceURL: ""),"empty notes skip lookup")
        check(RestaurantLookupResponse.requested("",sourceURL: "https://example.com/menu"),"direct menu links still trigger lookup")
        // Restaurant and adjusted photo entries retain identity, provenance and snapshots.
        let photo = FoodAIItem(name: meal.name,grams: 100,macros: FoodMacros(calories: 999),uncertainty: "Estimated weight")
        let matched = FoodPhotoMatching.match(photo,in: [meal])
        check(matched.matchedFood?.id == meal.id && matched.macros.calories == 200,"exact photo match scales database nutrition to photo grams")
        check(matched.photoMacros?.calories == 999 && matched.photoGrams == 100,"database matches preserve the independent photo estimate for later adjustments")
        var duplicate = meal; duplicate.id = "other-meal"
        check(FoodPhotoMatching.match(photo,in: [meal,duplicate]).matchedFood == nil,"ambiguous identities remain review suggestions")
        let web = FoodWebCandidate(id: "pizza",name: "Margherita pizza",description: "Tomato and mozzarella",sourceURL: "https://example.com/menu",sourceTitle: "Example Pizzeria",servingSize: "1 pizza (400 g)",referenceGrams: 400,macros: FoodMacros(calories: 1000,protein: 40,carbs: 120,fat: 40,fiber: 4),fiberMissing: false)
        check(web.valid && web.food?.nutrition(grams: 200).calories == 500,"restaurant known weight scales half a source serving")
        var noWeight = web; noWeight.referenceGrams = nil; noWeight.servingSize = "1 slice"
        check(noWeight.valid && noWeight.food == nil,"unknown serving weight cannot be invented as grams")
        check(noWeight.basis(query: "Example",servings: 2).referenceMacros?.scaled(2).calories == 2000,"serving counts use the source serving profile")
        var basis = web.basis(query: "Example Pizzeria Brooklyn"); basis.adjusted = true; basis.sourceFoodID = "restaurant-pizza"
        let adjusted = FoodLogEntry(day: NutritionDay.key(date),meal: .dinner,foodID: meal.id,name: meal.name,grams: 100,macros: FoodMacros(calories: 240,protein: 12,carbs: 30,fat: 10,fiber: 3),source: "Test · adjusted",estimated: true,nutritionBasis: basis)
        check(store.log([adjusted]),"adjusted matched nutrients can be logged without rewriting base food")
        let adjustedReload = NutritionStore(directory: directory,loadCatalogue: false)
        check(adjustedReload.state.entries.last?.foodID == meal.id && adjustedReload.state.entries.last?.macros.calories == 240,"manual macros retain matched identity after relaunch")
        check(adjustedReload.state.entries.last?.nutritionBasis?.sourceURL == web.sourceURL && adjustedReload.state.entries.last?.nutritionBasis?.adjusted == true,"source links and adjusted status persist")
        let exported = try JSONDecoder().decode(NutritionState.self,from: Data(contentsOf: adjustedReload.export()))
        check(exported.entries.last?.nutritionBasis?.referenceMacros?.calories == 1000,"backup preserves original source profile and adjusted snapshot separately")
        var badSource = adjusted; badSource.nutritionBasis?.sourceURL = "http://localhost/private"
        check(!store.log([badSource]),"invalid provenance cannot enter a backup or diary")
        var legacyEntry = try JSONSerialization.jsonObject(with: JSONEncoder().encode(entry)) as! [String:Any]
        legacyEntry.removeValue(forKey: "nutritionBasis")
        check(try JSONDecoder().decode(FoodLogEntry.self,from: JSONSerialization.data(withJSONObject: legacyEntry)).valid,"old entries without provenance still decode")
        let oldAI = Data("{\"items\":[{\"name\":\"Pizza\",\"grams\":200,\"macros\":{\"calories\":500,\"protein\":20,\"carbs\":60,\"fat\":20,\"fiber\":2},\"uncertainty\":\"Weight estimate\"}],\"notes\":\"Review\",\"questions\":[]}".utf8)
        check(try JSONDecoder().decode(FoodAIResponse.self,from: oldAI).valid,"protocol 2 providers remain compatible")
        check(RestaurantLookupResponse.requested("Pizza FROM a Brooklyn pizzeria",sourceURL: ""),"case-insensitive place detection")
        let file = directory.appendingPathComponent("nutrition-v1.json"); try Data("broken".utf8).write(to: file)
        let blocked = NutritionStore(directory: directory,loadCatalogue: false)
        check(blocked.blocked && !blocked.saveFood(meal),"unreadable state cannot be overwritten")
        let preserved = try String(contentsOf: file)
        check(preserved == "broken","original corruption preserved")
        print("Nutrition persistence, portions, snapshots, recipes, import, validation and local-date checks passed")
    }
}
