import Foundation
@main
struct ExerciseSearchTests {
    static func main() throws {
        func check(_ value: Bool,_ message: String) { if !value { fatalError(message) } }
        let database = try JSONDecoder().decode([Exercise].self,from: Data(contentsOf: URL(fileURLWithPath: "Engine/lib/data/exercises.json")))
        let bench = Exercise(id: "bench",name: "Barbell bench press",muscle: "Chest",equipment: "Barbell",cue: "",increment: 5)
        let squat = Exercise(id: "squat",name: "Barbell back squat",muscle: "Quads",equipment: "Barbell",cue: "",increment: 5)
        let rdl = Exercise(id: "rdl",name: "Barbell Romanian deadlift",muscle: "Hamstrings",equipment: "Barbell",cue: "",increment: 5)
        let all = [bench,squat,rdl] + database
        let ordered = ExerciseSearchRanking.results(all)
        check(ordered.prefix(3).map(\.id) == ["bench","squat","db-Barbell_Deadlift"],"default picker promotes staple lifts")
        check(ordered.count == all.count && Set(ordered.map(\.id)) == Set(all.map(\.id)),"ranking retains every exercise and original ID")
        check(ExerciseSearchRanking.results(all,query: "bench press").first?.id == "bench","common bench precedes niche bench variants")
        check(ExerciseSearchRanking.results(all,query: "squat").first?.id == "squat","back squat precedes niche squat variants")
        check(ExerciseSearchRanking.results(all,query: "deadlift").first?.id == "db-Barbell_Deadlift","conventional deadlift is first")
        check(ExerciseSearchRanking.results(all,query: "rdl").first?.id == "rdl","common abbreviations resolve")
        check(ExerciseSearchRanking.results(all,query: "bb bench").first?.id == "bench","barbell abbreviation retained")
        check(ExerciseSearchRanking.results(all,query: "zercher squat").first?.id == "db-Zercher_Squats","specific rare exercise remains findable")
        check(ExerciseSearchRanking.results(all,query: "dumbbell").allSatisfy { ($0.name + " " + $0.equipment).lowercased().contains("dumbbell") },"equipment search remains available")
        let chest = all.filter { ($0.primary ?? [$0.muscle]).contains("Chest") }
        check(ExerciseSearchRanking.results(chest).first?.id == "bench","muscle filtering preserves common-first order")
        print("Exercise familiarity ordering, exact searches, abbreviations, filters and catalogue preservation passed")
    }
}
