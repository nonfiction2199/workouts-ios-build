import {test} from 'node:test';
import assert from 'node:assert/strict';
import {bootstrap,run,analyze,preview} from '../Engine/bridge';
const initial=()=>JSON.parse(bootstrap()).state;
const command=(state:any,action:string,args:any={})=>JSON.parse(run(JSON.stringify({state,action,args})));
test('native bridge completes a program workout, survives JSON round trip, and updates heatmap',()=>{
 let s=command(initial(),'generate',{settings:{days:4}});
 s=command(s,'start',{day:0});
 const id=s.active.id;
 s=command(s,'set',{item:0,set:0,values:{weight:100,reps:10,rir:2}});
 s=command(s,'toggle',{item:0,set:0});
 s=command(s,'finish');
 assert.equal(s.active,null);assert.equal(s.next,1);assert.equal(s.history[0].id,id);assert.equal(s.history[0].items.length,1);
 const restored=command(JSON.parse(JSON.stringify(s)),'validate');
 assert.deepEqual(restored,s);
 const info=JSON.parse(analyze(JSON.stringify({state:s,days:7})));
 assert.ok(Object.values(info.levels).some((x:any)=>x.weekly>0));
});
test('import keeps local history, deduplicates IDs, and restores an active web workout',()=>{
 let incoming=command(initial(),'generate',{settings:{}});incoming=command(incoming,'start',{day:0});
 incoming=command(incoming,'set',{item:0,set:0,values:{weight:45,reps:8,rir:2}});incoming=command(incoming,'toggle',{item:0,set:0});incoming=command(incoming,'finish');
 let s=command(initial(),'import',{state:incoming});s=command(s,'import',{state:incoming});assert.equal(s.history.length,1);
 incoming=command(incoming,'start',{day:1});s=command(s,'import',{state:incoming});assert.equal(s.active.id,incoming.active.id);
 assert.throws(()=>command(s,'import',{state:incoming}),/current workout/);
});
test('rejects invalid imports and cannot replace an active program',()=>{
 assert.throws(()=>command(initial(),'import',{state:{history:[]}}));
 let s=command(initial(),'generate',{settings:{}});s=command(s,'start',{day:0});
 assert.throws(()=>command(s,'generate',{settings:{}}),/current workout/);
 assert.throws(()=>command(s,'program',{program:[]}),/current workout/);
 assert.throws(()=>command(s,'set',{item:0,set:0,values:{weight:-10}}));
});
test('manual prescriptions remain protected during live adaptation',()=>{
 let s=command(initial(),'generate',{settings:{}});s=command(s,'start',{day:0});
 s=command(s,'set',{item:0,set:1,values:{weight:77.5,reps:9,rir:2}});
 s=command(s,'set',{item:0,set:0,values:{weight:100,reps:12,rir:0}});s=command(s,'toggle',{item:0,set:0});
 assert.equal(s.active.items[0].sets[1].weight,77.5);
 assert.equal(s.active.items[0].sets[1].manual,true);
});
test('empty workout refuses empty completion; adding an exercise creates real prescriptions',()=>{
 let s=command(initial(),'empty');assert.throws(()=>command(s,'finish'),/at least one/);
 s=command(s,'addExercise',{id:'bench'});assert.equal(s.active.items.length,1);assert.equal(s.active.items[0].sets.length,3);
 s=command(s,'addSet',{item:0});assert.equal(s.active.items[0].sets.length,4);
 s=command(s,'removeSet',{item:0,set:3});assert.equal(s.active.items[0].sets.length,3);
});

test('overview is read-only and its prescriptions match start, including cycle six deload',()=>{
 for(const next of [0,16,20]){
  const s=command(initial(),'generate',{settings:{days:4}});s.next=next;
  const before=JSON.stringify(s);
  const p=JSON.parse(preview(JSON.stringify({state:s,day:0})));
  assert.equal(JSON.stringify(s),before);assert.equal(s.active,null);
  const started=command(s,'start',{day:0}).active;
  assert.deepEqual(p.items,started.items);assert.equal(p.cycle,started.cycle);assert.equal(p.deload,started.deload);
 }
});
test('editing future workout does not change saved history; preview updates after removal and replacement',()=>{
 let s=command(initial(),'generate',{settings:{days:4}});
 s=command(s,'start',{day:0});s=command(s,'set',{item:0,set:0,values:{weight:100,reps:10,rir:2}});s=command(s,'toggle',{item:0,set:0});s=command(s,'finish');
 const history=JSON.stringify(s.history);const program=structuredClone(s.program);
 program[0].items.splice(0,1);program[0].items[0].id='rdl';program[0].items[0].sets=4;
 s=command(s,'program',{program});const p=JSON.parse(preview(JSON.stringify({state:s,day:0})));
 assert.equal(JSON.stringify(s.history),history);assert.equal(p.items.length,program[0].items.length);
 assert.equal(p.items[0].target.id,'rdl');assert.equal(p.items[0].sets.length,4);
 assert.throws(()=>preview(JSON.stringify({state:s,day:-1})),/not found/);
});

test('duplicate and superset targets survive program save, preview and backup validation',()=>{
 let s=command(initial(),'generate',{settings:{days:4}});
 const program=structuredClone(s.program);
 program[0].items[0].group='SS-test';program[0].items[1].group='SS-test';
 program[0].items.splice(2,0,{...program[0].items[0],group:''});
 s=command(s,'program',{program});
 const p=JSON.parse(preview(JSON.stringify({state:s,day:0})));
 assert.equal(p.items[0].target.group,'SS-test');assert.equal(p.items[1].target.group,'SS-test');
 assert.equal(p.items[2].target.id,p.items[0].target.id);assert.equal(p.items[2].target.group,'');
 assert.deepEqual(command(s,'validate').program,program);
});
test('one-month and three-month levels normalize the same completed sets by selected duration',()=>{
 let s=command(initial(),'generate',{settings:{days:4}});s=command(s,'start',{day:0});
 s=command(s,'set',{item:0,set:0,values:{weight:100,reps:10,rir:2}});s=command(s,'toggle',{item:0,set:0});s=command(s,'finish');
 const levels=(days:number)=>JSON.parse(analyze(JSON.stringify({state:s,days}))).levels;
 const week=levels(7),month=levels(30),quarter=levels(90);
 for(const name of Object.keys(week)) { assert.ok(Math.abs(month[name].weekly-week[name].weekly*7/30)<1e-10);assert.ok(Math.abs(quarter[name].weekly-week[name].weekly*7/90)<1e-10); }
});
