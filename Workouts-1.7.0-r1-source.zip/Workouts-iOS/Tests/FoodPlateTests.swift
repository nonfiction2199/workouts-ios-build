import Foundation
@main struct FoodPlateTests {
    static func main() throws {
        var checks = 0
        func check(_ value: Bool,_ reason: String) { checks += 1; if !value { fatalError(reason) } }
        let food = FoodItem(id: "rice",name: "Cooked rice",category: "Grains",source: "Test",referenceGrams: 100,macros: FoodMacros(calories: 130,protein: 2.7,carbs: 28,fat: 0.3,fiber: 0.4),portions: [FoodPortion(name: "1 bowl",grams: 200)])
        let added = FoodPlate.added(food)
        check(added.grams == 200 && added.macros.calories == 260 && added.needsPortionReview,"added foods retain library nutrition and require portion review")
        let half = FoodPlate.scaled(added,by: 0.5,reason: "Your fraction")!
        check(half.grams == 100 && half.macros.calories == 130 && half.matchedFood?.id == food.id,"plate fractions scale weight and all nutrients while keeping identity")
        check(half.nutritionBasis?.referenceGrams == 100 && half.nutritionBasis?.referenceMacros?.calories == 130,"reference profile never changes when a plate is scaled")
        check(half.photoMacros?.calories == 260 && half.photoGrams == 200 && !half.needsPortionReview,"original estimate survives and reviewed fraction is explicit")
        let target = FoodPlate.calories(added,target: 390)!
        check(target.grams == 300 && target.macros.calories == 390 && target.macros.carbs == 84,"known calories set a proportional amount without inventing a new macro profile")
        check(FoodPlate.calories(added,target: 0) == nil && FoodPlate.calories(added,target: .nan) == nil && FoodPlate.scaled(added,by: 100000,reason: "Invalid") == nil,"invalid scaling cannot enter the diary")
        var counted = FoodAIItem(name: "Chicken tender",grams: 500,macros: FoodMacros(calories: 1400,protein: 120,carbs: 60,fat: 80),uncertainty: "Estimated weight",nutritionBasis: FoodNutritionBasis(referenceMacros: FoodMacros(calories: 140,protein: 12,carbs: 6,fat: 8),servings: 10,resolution: "restaurant",quantityCount: 10,quantityUnit: "tenders",referenceCount: 1),quantity: FoodAIQuantity(count: 10,unit: "tenders",basis: "user",weightBasis: "photo"))
        let five = FoodPlate.scaled(counted,by: 0.5,reason: "Your fraction")!
        check(five.macros.calories == 700 && five.nutritionBasis?.servings == 5 && five.nutritionBasis?.quantityCount == 5 && five.quantity?.count == 5,"count-only source serving evidence scales together with calories")
        counted.grams = 5
        check(FoodPlate.qualityWarnings(counted).isEmpty,"unknown gram weights cannot discredit a valid count-only source")
        let bad = FoodAIItem(name: "Chicken",grams: 100,macros: FoodMacros(calories: 2000,protein: 100,carbs: 100,fat: 100),uncertainty: "Estimate")
        check(!FoodPlate.qualityWarnings(bad).isEmpty && bad.needsIdentityReview && bad.needsPortionReview,"unsupported dense photo nutrition is flagged rather than silently approved")
        var mismatch = added; mismatch.macros.calories = 1000
        check(FoodPlate.qualityWarnings(mismatch).contains { $0.contains("disagree") },"major calorie/macro inconsistencies are exposed")
        check(FoodPlate.qualityWarnings(added).isEmpty,"ordinary rounding and fiber do not generate false warnings")
        let recipe = FoodPlate.recipe([added,half],name: "My rice meal")!
        check(recipe.ingredients?.count == 2 && recipe.referenceGrams == 300 && recipe.macros.calories == 390,"saved plate snapshots each ingredient and portion")
        let recipeItem = FoodPlate.added(recipe,grams: 150)
        let expanded = FoodPlate.expanded(recipeItem)!
        check(expanded.count == 2 && expanded.reduce(0) { $0 + $1.grams } == 150 && expanded.reduce(0) { $0 + $1.macros.calories } == 195,"expanding replaces parent with scaled ingredients without double counting")
        var edited = recipeItem; edited.nutritionBasis?.adjusted = true
        check(FoodPlate.expanded(edited) == nil,"edited recipe macros cannot revert silently to original ingredients")
        check(FoodPlate.recipe([],name: "Empty") == nil && FoodPlate.recipe([added],name: " ") == nil,"empty meal recipes cannot be saved")
        let snapshot = FoodLogEntry(day: "2026-10-05",meal: .lunch,foodID: food.id,name: half.name,grams: half.grams,macros: half.macros,source: "Test",nutritionBasis: half.nutritionBasis)
        let restored = try JSONDecoder().decode(FoodLogEntry.self,from: JSONEncoder().encode(snapshot))
        check(restored.valid && restored.nutritionBasis?.portionReviewed == true,"reviewed portion evidence survives backups")
        let old = "{\"resolution\":\"ai\",\"adjusted\":false}"
        let basis = try JSONDecoder().decode(FoodNutritionBasis.self,from: Data(old.utf8))
        check(basis.valid && basis.portionReviewed == nil && basis.identityReviewed == nil,"older diary provenance remains decodable")
        print("\(checks) plate accuracy and snapshot checks passed")
    }
}
