import {test} from 'node:test';
import assert from 'node:assert/strict';
import {begin,defaults,exercises,initial,type LoggedSet,type Session,type State,type Target} from '../Engine/lib/training';
import {addWorkingSet,applyRecommendation,createSessionExercise,cycleTarget,makeLighter,predictSet,progressionSettings,recommendationsForItem,refreshSession,trainingReview} from '../Engine/lib/progression';
import {stateSchema} from '../Engine/lib/state-schema';
const now=Date.parse('2026-09-25T12:00:00Z'),DAY=86400000;
const bench=exercises.find(e=>e.id==='bench')!;
const target:Target={id:'bench',sets:3,min:8,max:12,rir:2,rest:150,increment:5,group:''};
const set=(patch:Partial<LoggedSet>={}):LoggedSet=>({weight:100,reps:10,rir:2,done:true,kind:'Work',...patch});
function session(i:number,sets:LoggedSet[]=[set(),set({reps:9}),set({reps:8})],id='bench'):Session{
 return {id:`s${i}-${id}`,name:'Upper',started:new Date(now-(30-i*4)*DAY).toISOString(),ended:new Date(now-(30-i*4)*DAY+3600000).toISOString(),day:0,cycle:1,deload:false,items:[{target:{...target,id},sets,note:''}]};
}
const history=Array.from({length:6},(_,i)=>session(i));
const context={target,exercise:bench,history,settings:defaults,now};
function stateWith(historyValue=history):State{
 const s:State=structuredClone({...initial,settings:{...defaults,deload:false},program:[{name:'Upper',items:[target]}],history:historyValue});
 s.active=begin(s,0,false,now);return s;
}
const estimate=(r:{weight:number;reps:number;rir:number})=>r.weight*(1+(r.reps+r.rir)/30);

test('first session calibrates from a real completed set instead of guessing a load',()=>{
 const s=stateWith([]);assert.equal(s.active!.items[0].sets[0].weight,0);
 Object.assign(s.active!.items[0].sets[0],set({manual:true}));
 refreshSession(s,exercises,false,now);
 assert.equal(s.active!.items[0].sets[0].weight,100);
 assert.ok(s.active!.items[0].sets[1].weight>0);
 assert.ok(s.active!.items[0].sets[1].reps<=10);
});
test('repeat performances match a feasible weight and adapt to the RIR target',()=>{
 const r=predictSet(context);assert.equal(r.weight,100);assert.equal(r.reps,10);
 const easy=predictSet({...context,target:{...target,rir:4}});
 assert.ok(easy.weight<=r.weight);assert.ok(easy.reps+4>=r.reps+2-1);
});
test('actual RIR affects capacity, even with identical weight and reps',()=>{
 const hard=predictSet({...context,history:[session(1,[set({rir:0})])]});
 const easy=predictSet({...context,history:[session(1,[set({rir:4})])]});
 assert.ok(estimate(easy)>estimate(hard));
});
test('history is date ordered, future sessions excluded, and sessions deduplicated',()=>{
 const future={...session(7),id:'future',started:new Date(now+DAY).toISOString(),items:[{target,sets:[set({weight:900})],note:''}]};
 const a=predictSet(context),b=predictSet({...context,history:[future,...history.slice().reverse(),history[2]]});
 assert.equal(b.sessions,a.sessions);assert.equal(b.weight,a.weight);assert.equal(b.reps,a.reps);
});
test('unusual loads do not cause an unrestricted increase',()=>{
 const abnormal=session(6,[set({weight:900})]);
 const r=predictSet({...context,history:[...history,abnormal]});
 assert.ok(r.weight<=130,`Unusual log produced ${r.weight} lb`);
});
test('warm-up and specialty sets do not inflate estimated capacity or set position',()=>{
 const clean=predictSet({...context,history:[session(2)]});
 const polluted=predictSet({...context,history:[session(2,[set({kind:'Warm-up',weight:500}),set(),set({kind:'Drop',weight:500}),set({reps:9}),set({kind:'Partial',weight:500}),set({kind:'Myo',weight:500}),set({reps:8})])]});
 assert.equal(polluted.weight,clean.weight);assert.equal(polluted.reps,clean.reps);
});
test('failure sets are learned as zero RIR',()=>{
 const work=predictSet({...context,history:[session(1,[set({rir:0})])]});
 const failure=predictSet({...context,history:[session(1,[set({kind:'Failure',rir:4})])]});
 assert.equal(work.weight,failure.weight);assert.equal(work.reps,failure.reps);
});
test('later sets reflect learned fatigue rather than repeating the first set target',()=>{
 const first=predictSet(context),later=predictSet({...context,setIndex:2});
 assert.ok(estimate(later)<estimate(first));assert.ok(later.fatiguePercent>0);
});
test('a harder set today lowers upcoming targets without rewriting the completed set',()=>{
 const s=stateWith();const baseline=recommendationsForItem(s,0,exercises,now)[1];
 Object.assign(s.active!.items[0].sets[0],set({weight:90,reps:6,rir:0,manual:true}));
 const logged=structuredClone(s.active!.items[0].sets[0]);
 refreshSession(s,exercises,false,now);
 assert.deepEqual(s.active!.items[0].sets[0],logged);
 assert.ok(estimate(s.active!.items[0].sets[1])<estimate(baseline));
});
test('manual edits, legacy in-progress sets, and disabled live updates are protected',()=>{
 const s=stateWith();s.active!.items[0].sets[0]=set({weight:90,reps:6,rir:0,manual:true});
 s.active!.items[0].sets[1]={...set({done:false,weight:77,reps:7}),manual:true};
 delete s.active!.items[0].sets[2].manual;
 const before=structuredClone(s.active!.items[0].sets.slice(1));
 refreshSession(s,exercises,false,now);assert.deepEqual(s.active!.items[0].sets.slice(1),before);
 refreshSession(s,exercises,true,now);assert.deepEqual(s.active!.items[0].sets[1],before[0]);assert.equal(s.active!.items[0].sets[2].manual,false);
 s.settings.progression={applyInSession:false};const all=structuredClone(s.active);
 s.active!.items[0].sets[0].weight=50;const modified=structuredClone(s.active);
 assert.equal(refreshSession(s,exercises,false,now),0);assert.deepEqual(s.active,modified);assert.notDeepEqual(s.active,all);
});
test('explicit suggestion can replace a manual entry, but never a completed set',()=>{
 const r=predictSet(context),manual=set({done:false,manual:true,weight:77});
 assert.equal(applyRecommendation(manual,r),true);assert.equal(manual.manual,false);assert.equal(manual.weight,r.weight);
 manual.done=true;const before=structuredClone(manual);assert.equal(applyRecommendation(manual,{...r,weight:50}),false);assert.deepEqual(manual,before);
});
test('coarse equipment jumps expand reps only when enabled and never apply blocked values',()=>{
 const t={...target,min:8,max:8,increment:25,availableWeights:[100,125]};
 const h=[session(1,[set({reps:9})])];
 const r=predictSet({...context,target:t,history:h});assert.equal(r.weight,100);assert.equal(r.reps,9);assert.equal(r.expanded,true);assert.equal(r.blocked,false);
 const blocked=predictSet({...context,target:t,history:h,settings:{...defaults,progression:{expandRepRange:false}}});
 assert.equal(blocked.blocked,true);const pending=set({done:false});assert.equal(applyRecommendation(pending,blocked),false);
});
test('available weights and minimum-load offsets are respected',()=>{
 const r=predictSet({...context,target:{...target,increment:20,minWeight:45,maxWeight:105}});
 assert.equal((r.weight-45)%20,0);assert.ok(r.weight<=105);
 const listed=predictSet({...context,target:{...target,availableWeights:[75,92.5,107.5]}});
 assert.ok([75,92.5,107.5].includes(listed.weight));
});
test('load increases stay within the configured cap after rounding',()=>{
 for(const weight of [7.5,20,55,100,225]){
  const r=predictSet({...context,target:{...target,min:4,max:6,increment:2.5},history:[session(1,[set({weight,reps:15})])],settings:{...defaults,progression:{maxIncreasePercent:3}}});
  assert.ok(r.weight<=weight+Math.max(2.5,weight*.03)+.001);
 }
});
test('bodyweight and added-weight bodyweight work do not create fictitious load estimates',()=>{
 const exercise=exercises.find(e=>e.id==='pushup')!,t={...target,id:'pushup'};
 const r=predictSet({...context,target:t,exercise,history:[session(1,[set({weight:0,reps:12})],'pushup')]});
 assert.equal(r.mode,'bodyweight');assert.equal(r.weight,0);assert.equal(r.reps,12);
 const added=predictSet({...context,target:t,exercise,history:[session(1,[set({weight:25,reps:10})],'pushup')]});assert.equal(added.weight,25);
});
test('timed and assisted exercises preserve appropriate previous values',()=>{
 const timed={...bench,metric:'time'},h=[session(1,[set({weight:0,reps:0,seconds:65,distance:1.5})])];
 const r=predictSet({...context,exercise:timed,history:h});assert.equal(r.seconds,65);assert.equal(r.distance,1.5);assert.equal(r.mode,'time');
 const assisted=predictSet({...context,exercise:{...bench,name:'Assisted pull-up'}});assert.equal(assisted.mode,'manual');assert.equal(assisted.weight,100);
});
test('previous-value log fill is distinct from a new progression target',()=>{
 const settings={...defaults,progression:{initialFill:'previous' as const}};
 const t={...target,min:4,max:6};
 const item=createSessionExercise(t,history,bench,settings,undefined,exercises,now);
 assert.equal(item.sets[0].weight,100);assert.equal(item.sets[0].reps,10);assert.equal(item.sets[0].rir,2);
});
test('old histories lower confidence without advancing program cycles',()=>{
 const stale=history.map(s=>({...s,started:new Date(Date.parse(s.started)-70*DAY).toISOString()}));
 const r=predictSet({...context,history:stale});assert.equal(r.confidence,'Learning');assert.ok(r.details.some(d=>d.includes('days ago')));
 const s=stateWith(stale);assert.equal(s.active!.cycle,1);assert.equal(s.next,0);
});
test('cycle targets and first/last deloads apply consistently at session start',()=>{
 const t={...target,cycles:Array.from({length:6},(_,i)=>({sets:4,min:5+i,max:7+i,rir:3}))};
 const settings={...defaults,periodize:true};
 const fourth=cycleTarget(t,4,settings,false);assert.equal(fourth.min,8);assert.equal(fourth.rir,3);
 const light=cycleTarget(t,6,settings,true);assert.equal(light.sets,2);assert.equal(light.rir,4);
 const s=stateWith();s.settings={...settings,deloadTiming:'first'};s.active=begin(s,0,false,now);assert.equal(s.active.deload,true);assert.equal(s.active.items[0].sets.length,2);
 s.settings.deloadTiming='last';s.next=5;s.active=begin(s,0,false,now);assert.equal(s.active.deload,true);
});
test('making a workout lighter keeps completed and manually edited sets and program intact',()=>{
 const s=stateWith();s.active!.items[0].sets.push({...s.active!.items[0].sets[2]});
 s.active!.items[0].sets[0]=set({manual:true});s.active!.items[0].sets[1].manual=true;s.active!.items[0].sets[1].weight=77;
 const logged=structuredClone(s.active!.items[0].sets.slice(0,2)),program=structuredClone(s.program);
 makeLighter(s,exercises);assert.equal(s.active!.deload,true);assert.deepEqual(s.active!.items[0].sets.slice(0,2),logged);assert.deepEqual(s.program,program);assert.equal(s.active!.items[0].target.rir,4);
});
test('deload logs do not reset the normal capacity baseline',()=>{
 const lighter={...session(6,[set({weight:50,reps:10,rir:4})]),deload:true};
 const a=predictSet(context),b=predictSet({...context,history:[...history,lighter]});assert.equal(a.weight,b.weight);assert.equal(a.reps,b.reps);
});
test('sustained flat performance and declines across multiple lifts are reviewable',()=>{
 assert.equal(predictSet(context).trend,'Steady');
 const longer=history.map((h,i)=>i===0?{...h,started:new Date(now-32*DAY).toISOString()}:h);
 assert.equal(predictSet({...context,history:longer}).trend,'Plateau');
 const declining=Array.from({length:6},(_,i)=>session(i,[set({weight:i>=4?80:100})]));
 const s=stateWith(declining);s.program[0].items.push({...target,id:'row'});
 s.history.push(...declining.map(h=>({...structuredClone(h),id:h.id+'-row',items:[{...h.items[0],target:{...target,id:'row'}}]})));
 const review=trainingReview(s,exercises,now);assert.equal(review.status,'Review recovery');assert.equal(review.exercises.filter(e=>e.trend==='Declining').length,2);
});
test('personal rep relationship waits for sufficient varied data',()=>{
 assert.equal(predictSet(context).personalizedCurve,false);
 const varied=[5,12,6,14,5,13,7,15].map((reps,i)=>({...session(i,[set({weight:180/(1+(reps+2)/20),reps})]),started:new Date(now-(16-i*2)*DAY).toISOString()}));
 assert.equal(predictSet({...context,history:varied}).personalizedCurve,true);
});
test('adding a set respects the set position and does not clone completion or overrides',()=>{
 const s=stateWith();s.active!.items[0].sets[2].manual=true;s.active!.items[0].sets[2].weight=77;
 addWorkingSet(s,0,exercises);const extra=s.active!.items[0].sets.at(-1)!;
 assert.equal(extra.done,false);assert.equal(extra.manual,false);assert.notEqual(extra.weight,77);assert.equal(extra.kind,'Work');
});
test('old backups remain valid and new controls and prescriptions survive a save round trip',()=>{
 assert.equal(stateSchema.safeParse(initial).success,true);
 const s=stateWith();s.settings.progression=progressionSettings();s.settings.deloadTiming='last';
 s.program[0].items[0].availableWeights=[95,100,105];s.program[0].items[0].cycles=Array.from({length:6},()=>({sets:3,min:8,max:12,rir:2}));
 const parsed=stateSchema.parse(JSON.parse(JSON.stringify(s)));
 assert.deepEqual(parsed,s);assert.ok(parsed.active!.items[0].sets[0].prescription);
 assert.equal(stateSchema.safeParse({...s,settings:{...s.settings,progression:{maxIncreasePercent:99}}}).success,false);
});
test('scenario sweep keeps recommendations finite, legal, and equipment aligned',()=>{
 let count=0;
 for(const weight of [5,17.5,55,100,225,500])for(const reps of [1,5,8,15,30,45])for(const rir of [0,2,6])for(const increment of [.25,2.5,10]){
  const r=predictSet({...context,target:{...target,increment},history:[session(1,[set({weight,reps,rir})])],setIndex:2});
  assert.ok(Number.isFinite(r.weight)&&r.weight>=0&&r.weight<=3000);assert.ok(Number.isInteger(r.reps)&&r.reps>=1&&r.reps<=50);
  if(!r.blocked)assert.ok(Math.abs(r.weight/increment-Math.round(r.weight/increment))<.001);
  count++;
 }
 assert.equal(count,324);
});
