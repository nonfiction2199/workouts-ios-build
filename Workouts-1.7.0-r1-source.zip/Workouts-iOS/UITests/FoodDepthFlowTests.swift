import XCTest
final class FoodDepthFlowTests:XCTestCase {
    func testSimpleLoggingDoesNotExposeDepthForms() throws {
        let app=XCUIApplication();app.launchEnvironment["WORKOUTS_PREVIEW_SCREEN"]="food-photo";app.launchEnvironment["WORKOUTS_NUTRITION_TEST"]=UUID().uuidString;app.launch()
        XCTAssertTrue(app.buttons["Camera"].waitForExistence(timeout:20))
        XCTAssertTrue(app.buttons["Upload"].exists)
        XCTAssertFalse(app.buttons["nutrition-depth-start"].exists)
        XCTAssertFalse(app.buttons["nutrition-depth-estimate"].exists)
        XCTAssertFalse(app.textFields["nutrition-Reference volume (mL)"].exists)
        XCTAssertFalse(app.textViews["nutrition-meal-details"].exists)
        XCTAssertTrue(app.buttons["Add details"].exists)
    }
    func testAutomaticMetricPortionLogsAndPersists() throws {
        let app=XCUIApplication();app.launchEnvironment["WORKOUTS_PREVIEW_SCREEN"]="food-depth";app.launchEnvironment["WORKOUTS_NUTRITION_TEST"]=UUID().uuidString;app.launchEnvironment["WORKOUTS_PREVIEW_THEME"]="midnight";app.launch()
        let food=app.buttons["nutrition-review-Cooked rice"]
        XCTAssertTrue(food.waitForExistence(timeout:20))
        XCTAssertFalse(app.buttons["nutrition-depth-food"].exists)
        food.tap()
        let grams=app.textFields["nutrition-Grams"]
        XCTAssertTrue(grams.waitForExistence(timeout:10))
        let expected=pow(29*0.36/100,2)*0.04*1_000_000*158/236.5882365
        XCTAssertEqual(Double(grams.value as? String ?? "") ?? 0,expected,accuracy:0.1)
        let save=app.buttons["nutrition-save-match"]
        for _ in 0..<10 { if save.isHittable { break };app.swipeUp() };XCTAssertTrue(save.isEnabled);save.tap()
        let log=app.buttons["nutrition-log-meal"]
        for _ in 0..<5 { if log.isHittable { break };app.swipeUp() };XCTAssertTrue(log.isEnabled);log.tap()
        app.terminate();app.launchEnvironment["WORKOUTS_PREVIEW_SCREEN"]="nutrition";app.launch()
        let entry=app.buttons.containing(.staticText,identifier:"Cooked rice").firstMatch
        for _ in 0..<5 { if entry.isHittable { break };app.swipeUp() };XCTAssertTrue(entry.waitForExistence(timeout:10));entry.tap()
        let reference=app.staticTexts.matching(NSPredicate(format:"label BEGINSWITH %@","3D scan reference:")).firstMatch
        for _ in 0..<8 { if reference.exists && reference.isHittable { break };app.swipeUp() }
        XCTAssertTrue(reference.exists)
    }
}
