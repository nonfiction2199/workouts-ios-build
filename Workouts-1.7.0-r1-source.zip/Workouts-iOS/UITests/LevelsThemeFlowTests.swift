import XCTest
final class LevelsThemeFlowTests: XCTestCase {
    func testLevelsFlipAndMuscleDetail() throws {
        let app = XCUIApplication()
        app.launchEnvironment["WORKOUTS_PREVIEW_SCREEN"] = "levels"
        app.launchEnvironment["WORKOUTS_PREVIEW_THEME"] = "dark"
        app.launch()
        let flip = app.buttons["Show back muscles"]
        XCTAssertTrue(flip.waitForExistence(timeout: 20)); flip.tap()
        XCTAssertTrue(app.buttons["Show front muscles"].waitForExistence(timeout: 5))
        let upperBack = app.buttons["levels-row-Upper Back"]
        for _ in 0..<5 { if upperBack.isHittable { break }; app.swipeUp() }
        XCTAssertTrue(upperBack.exists); upperBack.tap()
        XCTAssertTrue(app.navigationBars["Upper Back"].waitForExistence(timeout: 10))
    }
    func testThemeSelectionPersists() throws {
        let app = XCUIApplication()
        app.launchEnvironment["WORKOUTS_PREVIEW_SCREEN"] = "theme-picker"
        app.launchEnvironment["WORKOUTS_PREVIEW_THEME"] = "dark"
        app.launch()
        let gold = app.buttons["Black & Gold theme"]
        for _ in 0..<8 { if gold.exists && gold.isHittable { break }; app.swipeUp() }
        XCTAssertTrue(gold.exists); gold.tap()
        XCTAssertTrue(gold.isSelected)
        app.terminate(); app.launchEnvironment.removeValue(forKey: "WORKOUTS_PREVIEW_THEME"); app.launch()
        for _ in 0..<8 { if gold.exists && gold.isHittable { break }; app.swipeUp() }
        XCTAssertTrue(gold.isSelected)
        XCTAssertTrue(app.buttons["Monochrome theme"].exists)
    }
}
