# Native UI reference notes

Official references inspected 2026-09-26:
- https://macrofactor.com/wp-content/uploads/2026/01/Program-Dark.png
- https://macrofactor.com/wp-content/uploads/2026/01/Dashboard-Light.png
- https://www.pentagram.com/work/macrofactor

Measured Program-Dark pixels: surface #1F1F1F; control #383838;
outline ~#4E4E4E. Root #101010 is our darker interpretation.
Dashboard: wide geometric heading, large center sets ring, blue/coral/teal
ring colors, capsule scope selector. No copied logos or proprietary font files.

Workouts Display derives from bundled Unbounded (OFL 1.1), instantiated at
weight 680 with widths scaled to 94%, metrics transformed with outlines.
See Scripts/build-display-font.py and Resources/unbounded.txt for source and license.

User-confirmed behavior: no haptics on tabs or dashboard; haptics for Workout,
Shortcuts, and actual More setting changes. Haptic intensity is not established
by screenshots. Reuse UISelectionFeedbackGenerator for a crisp selection tick.
