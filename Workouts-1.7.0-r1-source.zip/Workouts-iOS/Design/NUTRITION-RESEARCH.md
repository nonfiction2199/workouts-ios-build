# Nutrition foundation research — 4 October 2026

Primary references were reviewed before implementation:

- MacroFactor's unified food logging exposes search, barcode/label scanning, quick adding, Describe and custom foods/recipes, launched from the + button. Its personal library includes favorite foods and saved recipes. https://help.macrofactorapp.com/en/articles/215-how-to-log-food-in-macrofactor
- Its AI photo workflow accepts camera/upload and photo-plus-text, generates editable plate entries and estimated portions, and lets users review ingredients before Log Foods. This is the design basis for our review-before-save photo flow. https://help.macrofactorapp.com/en/articles/258-ai-food-logging
- Custom foods can be entered manually or imported from product/label photos. https://help.macrofactorapp.com/en/articles/5-create-and-add-a-custom-food
- MacroFactor supports coached, collaborative and manual programs. Our first nutrition release implements manual goals only; its expenditure and coaching are not copied or claimed equivalent. https://help.macrofactorapp.com/macro_program/program_styles
- USDA supplies bulk JSON/CSV downloads, including FNDDS and SR Legacy. Its data are public domain/CC0. Source nutrient profiles and serving weights can be bundled offline. https://fdc.nal.usda.gov/download-datasets/ and https://fdc.nal.usda.gov/api-guide/
- Gemini supports image inputs and structured output. The source service uses the current Interactions steps/model_output response schema and store:false. Hosting, provider credentials and a real photo evaluation remain outstanding. https://ai.google.dev/gemini-api/docs/image-understanding and https://ai.google.dev/gemini-api/docs/interactions-breaking-changes-may-2026

Foundation scope: logging, accurate arithmetic, immutable historical snapshots, local persistence and recovery guards, manual goals, saved foods/recipes, broad source-backed catalogue, consistent themes and a photo service contract. Next stages: provider deployment and evaluation, better catalogue matching of AI identities, branded/barcode catalogue, description/voice logging, nutrient-completeness reporting, nutrition/body-weight trend linkage and carefully validated independent adaptive coaching.
