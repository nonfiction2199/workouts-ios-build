import test from 'node:test';
import assert from 'node:assert/strict';
import {createService,validateScanInput,stripJSONFence} from './server.mjs';
const photo=Buffer.from([255,216,255,217]).toString('base64');
const token='test-token-with-at-least-24-characters';
const meal={items:[{name:'Cooked rice',grams:250,macros:{calories:325,protein:6,carbs:70,fat:1,fiber:1},uncertainty:'Recipe estimate',requestedName:'rice',quantity:{count:null,unit:'',basis:'photo',weightBasis:'user'},exclude:[],add:[]}],restaurantName:'',restaurantLocation:'',notes:'Estimate; review portions',questions:[]};
test('Describe accepts text alone or two photos and rejects empty, oversized, legacy or malformed evidence',()=>{
 assert.deepEqual(validateScanInput({workflow:4,context:'250 g cooked rice'}),{images:[]});
 assert.equal(validateScanInput({workflow:4,images:[photo,photo],mimeType:'image/jpeg'}).images.length,2);
 for(const input of [{workflow:4,context:' '},{workflow:4,images:'not an array'},{workflow:4,images:[photo,photo,photo],mimeType:'image/jpeg'},{workflow:4,images:[photo],mimeType:'image/png'},{workflow:4,images:[Buffer.from('non JPEG').toString('base64')],mimeType:'image/jpeg'},{workflow:4,context:'x'.repeat(2001)},{workflow:3,context:'rice'}])assert.ok(validateScanInput(input).error);
 const large=Buffer.alloc(2_000_001);large[0]=255;large[1]=216;
 assert.ok(validateScanInput({workflow:4,images:[large.toString('base64'),large.toString('base64')],mimeType:'image/jpeg'}).error);
});
test('a complete JSON code fence is tolerated without extracting prose or partial responses',()=>{
 assert.deepEqual(JSON.parse(stripJSONFence('```json\n'+JSON.stringify(meal)+'\n```')),meal);
 assert.equal(stripJSONFence('Explanation '+JSON.stringify(meal)),'Explanation '+JSON.stringify(meal));
});
for(const count of [0,2])test('workflow 4 '+(count?'multi-photo':'text-only')+' stays one bounded local request with editable food data',async()=>{
 let calls=0;
 const server=createService({token,provider:'ollama',fetchImpl:async(url,request)=>{
  calls++;const body=JSON.parse(request.body);
  assert.equal(body.messages[0].images?.length??0,count);assert.equal(body.think,false);assert.equal(body.options.num_predict,2200);
  assert.match(body.messages[0].content,/SAME food/);assert.match(body.messages[0].content,/text-only/i);
  return {ok:true,json:async()=>({done:true,done_reason:'stop',message:{content:'```json\n'+JSON.stringify(meal)+'\n```'}})};
 }});
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 try{
  const base='http://127.0.0.1:'+server.address().port;
  assert.equal((await (await fetch(base+'/health')).json()).workflow,4);
  const reply=await fetch(base+'/analyze',{method:'POST',headers:{Authorization:'Bearer '+token,'Content-Type':'application/json'},body:JSON.stringify({workflow:4,context:'250 g cooked rice',images:Array(count).fill(photo),mimeType:'image/jpeg'})});
  assert.equal(reply.status,200);const result=await reply.json();assert.equal(result.workflow,4);assert.equal(result.items[0].grams,250);assert.equal(result.items[0].quantity.weightBasis,'user');assert.equal(calls,1);
 }finally{await new Promise(r=>server.close(r));}
});
test('text-only hosted requests omit image parts without changing privacy or structured validation',async()=>{
 const server=createService({token,apiKey:'test-key',fetchImpl:async(url,request)=>{
  const body=JSON.parse(request.body);assert.equal(body.input.length,1);assert.equal(body.store,false);
  return {ok:true,json:async()=>({steps:[{type:'model_output',content:[{type:'text',text:JSON.stringify(meal)}]}]})};
 }});await new Promise(r=>server.listen(0,'127.0.0.1',r));
 try{const reply=await fetch('http://127.0.0.1:'+server.address().port+'/analyze',{method:'POST',headers:{Authorization:'Bearer '+token,'Content-Type':'application/json'},body:JSON.stringify({workflow:4,context:'250g rice'})});assert.equal(reply.status,200);}finally{await new Promise(r=>server.close(r));}
});
test('closing a scan cancels local inference so retry does not wait the entire deadline',async()=>{
 let inferenceStarted;const started=new Promise(r=>inferenceStarted=r);
 let cancelled;const stopped=new Promise(r=>cancelled=r);
 const server=createService({token,provider:'ollama',fetchImpl:async(url,{signal})=>{
  inferenceStarted();return new Promise((resolve,reject)=>signal.addEventListener('abort',()=>{cancelled();reject(signal.reason);},{once:true}));
 }});await new Promise(r=>server.listen(0,'127.0.0.1',r));
 try{
  const abort=new AbortController();const call=fetch('http://127.0.0.1:'+server.address().port+'/analyze',{method:'POST',signal:abort.signal,headers:{Authorization:'Bearer '+token,'Content-Type':'application/json'},body:JSON.stringify({workflow:4,context:'rice'})}).catch(()=>{});
  await started;abort.abort();await stopped;await call;
 }finally{server.closeAllConnections();await new Promise(r=>server.close(r));}
});
test('named weights attach to their own food and cannot be borrowed from another component',async()=>{
 const {groundMealResult}=await import('./server.mjs');
 const base=structuredClone(meal);const chicken=structuredClone(base.items[0]);chicken.name='Grilled chicken';chicken.grams=100;base.items.push(chicken);
 const grounded=groundMealResult(base,'250g cooked rice, 150g grilled chicken');
 assert.equal(grounded.items[0].grams,250);assert.equal(grounded.items[1].grams,150);assert.equal(grounded.items[1].quantity.weightBasis,'user');
 const ambiguous=groundMealResult(structuredClone(base),'400g rice and chicken combined');
 assert.equal(ambiguous.items[1].quantity.weightBasis,'photo','total dish weight is not chicken weight');assert.equal(ambiguous.items[0].quantity.weightBasis,'photo','combined weight cannot become rice weight');
 const borrowed=groundMealResult(structuredClone(meal),'100g chicken, rice on the side');
 assert.equal(borrowed.items[0].quantity.weightBasis,'photo','chicken weight cannot claim measured rice');
});
test('correcting a supplied weight scales the fallback macro estimate rather than retaining totals for the wrong weight',async()=>{
 const {groundMealResult}=await import('./server.mjs');const base=structuredClone(meal);
 const corrected=groundMealResult(base,'100g cooked rice');assert.equal(corrected.items[0].grams,100);assert.equal(corrected.items[0].macros.calories,130);
});

test('one weight in a combined description cannot imply independently measured components',async()=>{
 const {groundMealResult}=await import('./server.mjs');const base=structuredClone(meal);const chicken=structuredClone(base.items[0]);chicken.name='Grilled chicken';base.items.push(chicken);
 const combined=groundMealResult(structuredClone(base),'250g rice and chicken');assert.ok(combined.items.every(i=>i.quantity.weightBasis==='photo'));
 const separate=groundMealResult(structuredClone(base),'250g rice, chicken on the side');assert.equal(separate.items[0].quantity.weightBasis,'user');assert.equal(separate.items[1].quantity.weightBasis,'photo');
});
test('negative or conflicting supplied weights cannot become positive measured evidence',async()=>{
 const {groundMealResult}=await import('./server.mjs');
 for(const context of ['-100g rice','100g rice; 200g rice'])assert.equal(groundMealResult(structuredClone(meal),context).items[0].quantity.weightBasis,'photo');
});
