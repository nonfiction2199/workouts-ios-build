import https from 'node:https';
import { lookup } from 'node:dns/promises';
import { isIP } from 'node:net';
import { createHash } from 'node:crypto';
import { pdfNutrition } from './nutrition-pdf.mjs';

// Web pages are evidence, never instructions. No photos, service tokens or AI keys
// are passed to a search engine or restaurant. Search snippets cannot supply macros.
export const clean = value => String(value ?? '').replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g,'$1').replace(/<[^>]*>/g,' ').replace(/&(?:amp|lt|gt|quot|apos|#0?39);/g,x=>({'&amp;':'&','&lt;':'<','&gt;':'>','&quot;':'"','&apos;':"'",'&#39;':"'",'&#039;':"'"}[x])).replace(/\s+/g,' ').trim();
const words = s => clean(s).toLowerCase().normalize('NFD').replace(/\p{M}/gu,'').match(/[\p{L}\p{N}]+/gu) ?? [];
// A small discovery registry contains URLs, never guessed or embedded food macros.
const chains=[{pattern:/\bdave[’']?s\s+hot\s+chicken\b/i,name:"Dave's Hot Chicken",url:'https://store.daveshotchicken.com/nutrition-information/'}];
export function restaurantQuery(context) {
  const text=String(context??'').replace(/https?:\/\/\S+/gi,'').trim();
  const match=text.match(/\b(?:from|at)\s+(.+)/i),chain=chains.find(c=>c.pattern.test(text));
  let place=match?.[1]??(chain?text.slice(text.search(chain.pattern)): /\b(?:pizzeria|restaurant|cafe|café|diner|steakhouse)\b/i.test(text)?text:'');
  place=place.split(/[;\n]|,\s*and\b|\s+from\s+|,\s*(?:no\b|without\b|just\b|jus\b|only\b|extra\b|add\b|remove\b)|\b(?:without|roulette)\b|\bno\s+(?:bread|bun|sauce|fries)\b/i)[0].trim().replace(/[,\s]+$/,'');
  if(chain && chain.pattern.test(place))place=place.replace(chain.pattern,chain.name);
  return clean(place).slice(0,220);
}
export function publicAddress(address) {
  if(isIP(address)===4) {
    const [a,b]=address.split('.').map(Number);
    return !(a===0||a===10||a===127||a>=224||(a===169&&b===254)||(a===172&&b>=16&&b<=31)||(a===192&&(b===168||b===0))||(a===100&&b>=64&&b<=127)||(a===198&&(b===18||b===19)));
  }
  // Global IPv6 unicast only; excludes loopback, mapped IPv4, local/link-local.
  return isIP(address)===6 && /^[23][0-9a-f]{3}:/i.test(address) && !/^2001:(?:db8|0):/i.test(address);
}
export function publicURL(value) {
  const u=new URL(value);
  if(u.protocol!=='https:'||u.username||u.password||(u.port&&u.port!=='443')||u.href.length>2000||u.hostname.endsWith('.local')||u.hostname==='localhost') throw new Error('Public HTTPS URL required');
  if(isIP(u.hostname.replace(/^\[|\]$/g,''))&&!publicAddress(u.hostname.replace(/^\[|\]$/g,'')))throw new Error('Private address');
  return u;
}
async function withSignal(promise,signal) {
  if(!signal)return promise;
  signal.throwIfAborted();
  let abort;
  try {return await Promise.race([promise,new Promise((_,reject)=>{abort=()=>reject(signal.reason);signal.addEventListener('abort',abort,{once:true});})]);}
  finally {if(abort)signal.removeEventListener('abort',abort);}
}
export async function publicText(value,{signal,redirects=0,resolve=lookup,get=https.get}={}) {
  const u=publicURL(value);
  const addresses=await withSignal(resolve(u.hostname,{all:true}),signal);
  signal?.throwIfAborted();
  if(!addresses.length||addresses.some(a=>!publicAddress(a.address))) throw new Error('Private DNS address');
  // Pin the checked DNS result for this request, including every redirect.
  return new Promise((resolveResult,reject)=>{
    const pinned=addresses[0];
    const req=get(u,{signal,family:pinned.family,autoSelectFamily:false,headers:{'User-Agent':'WorkoutsNutrition/1.3 (+https://github.com/nonfiction2199/workouts-ios)','Accept':'text/html,application/pdf,application/xhtml+xml,application/rss+xml,application/json;q=0.8','Accept-Encoding':'identity'},lookup:(_host,_options,cb)=>cb(null,pinned.address,pinned.family)},res=>{
      if([301,302,303,307,308].includes(res.statusCode)) {
        res.resume();if(redirects>=3||!res.headers.location)return reject(new Error('Redirect limit'));
        publicText(new URL(res.headers.location,u).href,{signal,redirects:redirects+1,resolve,get}).then(resolveResult,reject);return;
      }
      if(res.statusCode!==200){res.resume();return reject(new Error('Source unavailable'));}
      const isPdf=/^application\/pdf\b/i.test(res.headers['content-type']??'');
      if(!isPdf&&!/^(?:text\/(?:html|plain|xml)|application\/(?:rss\+xml|xhtml\+xml|json|xml))/i.test(res.headers['content-type']??'')){res.resume();return reject(new Error('Unsupported source format'));}
      const chunks=[];let size=0;
      res.on('data',chunk=>{size+=chunk.length;if(size>(isPdf?5_000_000:1_000_000)){res.destroy();reject(new Error('Source too large'));}else chunks.push(chunk);});
      res.on('end',()=>{const data=Buffer.concat(chunks);resolveResult(isPdf?{url:u.href,pdf:data}:{url:u.href,text:data.toString('utf8')});});res.on('error',reject);
    });req.on('error',reject);
  });
}
function numericLabel(text) {
  // US thousands grouping versus decimal commas; a leading zero stays decimal.
  return Number(/^[1-9]\d{0,2}(?:,\d{3})+(?:\.\d+)?$/.test(text) ? text.replaceAll(',','') : text.replace(',','.'));
}
function nutrient(value,kind) {
  if(typeof value==='number')return Number.isFinite(value)&&value>=0?value:null;
  if(typeof value!=='string')return null;
  const match=value.trim().match(/^([\d]+(?:[.,]\d+)?)\s*(kcal|calories?|kilocalories?|g|grams?|mg|milligrams?|kj|kilojoules?)?$/i);
  if(!match)return null;
  let n=numericLabel(match[1]),unit=(match[2]??'').toLowerCase();
  if(kind==='calories') {if(['kj','kilojoules','kilojoule'].includes(unit))n/=4.184;else if(unit&&!/^(kcal|calories?|kilocalories?)$/.test(unit))return null;}
  else {if(/^(mg|milligrams?)$/.test(unit))n/=1000;else if(unit&&!/^(g|grams?)$/.test(unit))return null;}
  return n;
}
function grams(value) {
  const m=clean(value).match(/(?:^|[\s(])([\d]+(?:[.,]\d+)?)\s*(g|grams?|kg|oz|ounces?)\b/i);
  if(!m)return null;
  const n=numericLabel(m[1])*(/kg/i.test(m[2])?1000:/oz|ounce/i.test(m[2])?28.349523125:1);
  return n>0&&n<=10000?n:null;
}
function candidate(node,url,title) {
  const type=Array.isArray(node['@type'])?node['@type']:[node['@type']];
  if(!type.some(t=>/^(MenuItem|Product)$/i.test(t??''))||typeof node.name!=='string'||!node.name.trim())return null;
  const name=clean(node.name).slice(0,300),description=clean(node.description).slice(0,400);
  const n=node.nutrition,servingSize=clean(n?.servingSize).slice(0,200);
  let macros=null,fiberMissing=false;
  if(n&&servingSize) {
    const m={calories:nutrient(n.calories,'calories'),protein:nutrient(n.proteinContent,'protein'),carbs:nutrient(n.carbohydrateContent,'carbs'),fat:nutrient(n.fatContent,'fat'),fiber:nutrient(n.fiberContent,'fiber')};
    fiberMissing=m.fiber===null;if(fiberMissing)m.fiber=0;
    if(Object.values(m).every(v=>v!==null&&v>=0&&v<=20000)&&m.calories>0) {
      const energy=4*m.protein+4*m.carbs+9*m.fat;
      // Catch major column/unit corruption, while allowing label rounding and fiber.
      if(Math.abs(energy-m.calories)<=Math.max(100,m.calories*.5))macros=m;
    }
  }
  return {id:createHash('sha256').update(url+'\n'+name+'\n'+servingSize).digest('hex').slice(0,24),name,description,sourceURL:url,sourceTitle:title,servingSize,referenceGrams:grams(servingSize),macros,fiberMissing};
}
export function parseMenu(html,url,dishes=[],{all=false}={}) {
  const title=clean(html.match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1]??new URL(url).hostname).slice(0,200),found=[];
  const visit=(n,depth=0)=>{if(!n||typeof n!=='object'||depth>25)return;if(Array.isArray(n)){n.slice(0,1000).forEach(x=>visit(x,depth+1));return;}const c=candidate(n,url,title);if(c)found.push(c);Object.values(n).forEach(x=>visit(x,depth+1));};
  for(const m of html.matchAll(/<script\b[^>]*type\s*=\s*["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script\s*>/gi)){try{visit(JSON.parse(m[1]));}catch{}}
  // Explicit HTML nutrition tables: use named columns, never proximity of numbers.
  for(const table of html.matchAll(/<table\b[^>]*>([\s\S]*?)<\/table>/gi)) {
    const rows=[...table[1].matchAll(/<tr\b[^>]*>([\s\S]*?)<\/tr>/gi)].map(r=>[...r[1].matchAll(/<t[dh]\b[^>]*>([\s\S]*?)<\/t[dh]>/gi)].map(c=>clean(c[1])));
    const header=rows.findIndex(r=>r.some(c=>/^calories(?:\s*\(kcal\))?$/i.test(c))&&r.some(c=>/^protein/i.test(c)));
    if(header<0)continue;
    const h=rows[header],index=pattern=>h.findIndex(c=>pattern.test(c));
    const ni=index(/^(?:item|food|menu item|product|name)$/i),si=index(/^(?:serving|serving size|portion)(?:\s*\((?:g|grams?|oz|ml)\))?$/i),ci=index(/^calories/i),pi=index(/^protein/i),bi=index(/^(?:total )?carb/i),fi=index(/^(?:total )?fat(?:\s*\((?:g|grams?|mg)\))?$/i),di=index(/^(?:dietary )?fib(?:er|re)/i);
    if([ni,si,ci,pi,bi,fi].some(i=>i<0))continue;
    const unitValue=(r,i)=>{const value=r[i];if(value===undefined)return undefined;const unit=h[i]?.match(/\((g|grams?|mg|oz|ml|kcal|kj)\)/i)?.[1];return unit&&/^\d+(?:[.,]\d+)?$/.test(value)?value+' '+unit:value;};
    for(const r of rows.slice(header+1,header+101)){const c=candidate({'@type':'MenuItem',name:r[ni],nutrition:{servingSize:unitValue(r,si),calories:unitValue(r,ci),proteinContent:unitValue(r,pi),carbohydrateContent:unitValue(r,bi),fatContent:unitValue(r,fi),fiberContent:unitValue(r,di)}},url,title);if(c)found.push(c);}
  }
  return {title,candidates:all?[...new Map(found.map(c=>[c.id,c])).values()].slice(0,400):rankCandidates(found,dishes),links:nutritionLinks(html,url)};
}
export function rankCandidates(found,dishes=[],context='') {
  const brandWords=new Set(words(restaurantQuery(context)));
  const queries=dishes.flatMap(words).filter(w=>w.length>2&&!brandWords.has(w)&&!['from','with','the','and','without','just','bread','roulette','daves','hot'].includes(w));
  const chicken=queries.includes('chicken')||/\b(?:just|only|jus)\s+(?:the\s+|tthe\s+)?chicken\b/i.test(context);
  const exclusions=/\b(?:no|without)\s+(?:the\s+)?(?:bread|bun)\b|\bjust\s+(?:the\s+)?chicken\b/i.test(context);
  return [...new Map(found.map(c=>[c.id,c])).values()].map(c=>{
    const name=words(c.name),poultry=chicken&&/tender|bites/i.test(c.name)&&!/not chicken/i.test(c.name);
    let score=queries.filter(w=>name.includes(w)).length+(poultry?3:0)+(c.macros?1:0);
    if(exclusions&&/slider|fries|hot box|saucy|not chicken|#\d/i.test(c.name))score-=5;
    if(/roulette/i.test(context)&&/tender/i.test(c.name))score+=2;
    return {c,score,relevant:(!queries.length||queries.some(w=>name.includes(w))||poultry)&&!(chicken&&exclusions&&/slider|fries|hot box|saucy|not chicken|#\d/i.test(c.name))};
  }).filter(x=>x.relevant).sort((a,b)=>b.score-a.score||a.c.name.localeCompare(b.c.name)).slice(0,12).map(x=>x.c);
}
export function nutritionLinks(html,url) {
  const raw=[...html.matchAll(/<a\b[^>]*href\s*=\s*["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi)].map(m=>({url:m[1],label:clean(m[2])}));
  // WordPress Divi stores its clickable columns as JSON. Parse that literal;
  // never execute page JavaScript. Then follow the normal bounded HTTPS path.
  for(const match of html.matchAll(/\b(?:var|let|const)\s+et_link_options_data\s*=\s*(\[[^;]{1,20000}\])\s*;/g)) {
    try {for(const x of JSON.parse(match[1]).slice(0,20))if(typeof x.url==='string')raw.push({url:x.url,label:x.url});}catch{}
  }
  const ranked=raw.filter(x=>/menu|nutrition/i.test(x.url+' '+x.label)&&!(/allergen/i.test(x.url+' '+x.label)&&!/nutrition/i.test(x.url+' '+x.label))).map(x=>{
    try {const link=publicURL(new URL(x.url,url).href).href;return {link,score:(/nutrition/i.test(x.label+' '+link)?10:0)+(/\.pdf(?:$|[?#])/i.test(link)?5:0)};}catch{return null;}
  }).filter(Boolean).sort((a,b)=>b.score-a.score);
  return [...new Set(ranked.map(x=>x.link))].filter(x=>x!==url).slice(0,4);
}

export function rssSources(xml) {
  return [...xml.matchAll(/<item\b[^>]*>([\s\S]*?)<\/item>/gi)].map(m=>({title:clean(m[1].match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1]).slice(0,200),url:clean(m[1].match(/<link[^>]*>([\s\S]*?)<\/link>/i)?.[1])})).filter(x=>{try{publicURL(x.url);return true;}catch{return false;}}).slice(0,4);
}
export function createRestaurantLookup({read=publicText}={}) {
  const cache=new Map();let active=0;
  return async({context='',sourceURL='',dishes=[],restaurantName='',restaurantLocation='',components=[]}={})=>{
    const query=restaurantName?clean(restaurantName+' '+restaurantLocation).slice(0,220):restaurantQuery(context),key=JSON.stringify([query,sourceURL,dishes,components]);
    if(!query&&!sourceURL)return {query:'',status:'not_requested',notes:'',sources:[],candidates:[]};
    const saved=cache.get(key);if(saved&&saved.until>Date.now())return saved.result;
    if(active>=2)throw new Error('Lookup busy');active++;
    try {
      const signal=AbortSignal.timeout(18000),sources=[],candidates=[];
      let initial;
      const chain=chains.find(c=>c.pattern.test(query)),outsideUS=/\b(?:uk|united kingdom|london|canada|toronto|dubai|uae|saudi)\b/i.test(query);
      if(sourceURL){publicURL(sourceURL);initial=[{url:sourceURL,title:'Provided menu link'}];}
      else if(chain&&!outsideUS)initial=[{url:chain.url,title:chain.name+' · US nutrition'}];
      else {const search=new URL('https://www.bing.com/search');search.searchParams.set('q',query+' nutrition nutritional information');search.searchParams.set('format','rss');initial=rssSources((await read(search.href,{signal})).text);}
      const seen=new Set();
      async function discover(s,depth=0) {
        if(seen.has(s.url)||seen.size>=10||signal.aborted)return;seen.add(s.url);
        try {
          const page=await read(s.url,{signal});
          const pdf=page.pdf?await pdfNutrition(page.pdf,{signal}):null;
          const title=pdf?(s.title||new URL(page.url).pathname.split('/').pop()||'Published nutrition PDF'):null;
          const parsed=parseMenu(pdf?'<title>'+clean(title)+'</title>'+pdf.html:page.text,page.url,[],{all:true});
          if(depth===0&&!sourceURL) {
            const nameWords=words(query).filter(w=>w.length>2&&!['the','restaurant','pizzeria','pizza','cafe','avenue','street','from','and','with','for'].includes(w)).slice(0,2);
            const pageWords=new Set(words((pdf?.text??clean(page.text))+' '+new URL(page.url).hostname));
            if(nameWords.length&&!nameWords.some(w=>pageWords.has(w)))return;
          }
          sources.push({url:page.url,title:parsed.title});
          candidates.push(...parsed.candidates);
          // Follow nutrition first, including linked CDNs/PDFs and one intermediate
          // download page. Each URL still receives pinned, public-only DNS checks.
          if(depth<2&&!parsed.candidates.some(c=>c.macros))await Promise.allSettled(parsed.links.slice(0,2).map(url=>discover({url,title:parsed.title+' · nutrition document'},depth+1)));
        } catch { /* A failed source cannot discard another successful source. */ }
      }
      await Promise.allSettled(initial.slice(0,3).map(s=>discover(s)));
      const ranked=rankCandidates(candidates,dishes,context);
      const extras=candidates.filter(c=>components.some(q=>{const wanted=words(q);return wanted.length&&wanted.every(w=>words(c.name).includes(w));}));
      const unique=[...new Map([...ranked.slice(0,8),...extras.slice(0,4),...ranked.slice(8)].map(c=>[c.id,c])).values()].slice(0,12),usable=unique.some(c=>c.macros);
      const status=usable?'nutrition_found':sources.length?'menu_only':'not_found';
      const result={query,status,notes:usable?'Published nutrition found. Confirm restaurant, country, dish and reference serving. Photo portions remain estimates.':sources.length?'No complete nutrition with a serving size was found. Use a database or photo estimate; restaurant identity still needs confirmation.':'No usable source was found. Keep the photo estimate, or provide a menu link.',sources:[...new Map(sources.map(s=>[s.url,s])).values()].slice(0,6),candidates:unique};
      if(/\b(?:no|without)\s+(?:the\s+)?(?:bread|bun)\b/i.test(context)) {
        const warning=' You requested no bread. Listed servings may include accompaniments; these values have not been adjusted or confirmed bread-free. Do not use a full meal profile for chicken alone.';
        result.notes+=warning;for(const c of result.candidates)c.description=(c.description+' Listed serving; bread exclusion has not been verified.').trim().slice(0,400);
      }

      if(cache.size>=200)cache.delete(cache.keys().next().value);cache.set(key,{until:Date.now()+(usable?86400000:60000),result});return result;
    } finally {active--;}
  };
}
