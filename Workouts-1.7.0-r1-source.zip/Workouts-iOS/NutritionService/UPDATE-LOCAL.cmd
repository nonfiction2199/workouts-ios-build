@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0UPDATE-LOCAL.ps1"
pause
