import test from 'node:test';
import assert from 'node:assert/strict';
import { publicAddress,publicURL,publicText,restaurantQuery,parseMenu,createRestaurantLookup } from './restaurant.mjs';
import { EventEmitter } from 'node:events';
import { createService } from './server.mjs';
const url='https://restaurant.example/menu';
const node={'@type':'MenuItem',name:'Margherita pizza',description:'Tomato, mozzarella, basil',nutrition:{servingSize:'1 pizza (400 g)',calories:'1000 kcal',proteinContent:'40 g',carbohydrateContent:'120 g',fatContent:'40 g'}};
const html=n=>'<title>Example Pizzeria · Brooklyn</title><script type="application/ld+json">'+JSON.stringify(n)+'</script>';
test('restaurant descriptions generalize beyond the example and ordinary notes skip lookup',()=>{
 assert.equal(restaurantQuery('Pizza from Example Pizzeria Avenue M Brooklyn NY'),'Example Pizzeria Avenue M Brooklyn NY');
 assert.equal(restaurantQuery('Dosa at Chennai Cafe; 200 g'),'Chennai Cafe');
 assert.equal(restaurantQuery('rice 250 g, added oil'),'');
});
test('complete explicit nutrition keeps its serving, optional fiber and gram basis',()=>{
 const c=parseMenu(html(node),url,['Margherita pizza']).candidates[0];
 assert.equal(c.referenceGrams,400);assert.equal(c.macros.calories,1000);assert.equal(c.fiberMissing,true);assert.equal(c.sourceURL,url);
 const other={...node,nutrition:{...node.nutrition,servingSize:'1 slice'}};
 assert.equal(parseMenu(html(other),url,['pizza']).candidates[0].referenceGrams,null);
 const liquid={...node,nutrition:{...node.nutrition,servingSize:'250 ml'}};
 assert.equal(parseMenu(html(liquid),url,['pizza']).candidates[0].referenceGrams,null);
});
test('published comma thousands and decimal fractions retain their intended units',()=>{
 const profile=structuredClone(node);profile.nutrition.calories='1,000 kcal';profile.nutrition.servingSize='1 pizza (1,000 g)';profile.nutrition.fatContent='0,5 grams';
 const c=parseMenu(html(profile),url,['pizza']).candidates[0];assert.equal(c.macros.calories,1000);assert.equal(c.referenceGrams,1000);assert.equal(c.macros.fat,0.5);
});
test('missing carbs or serving cannot be presented as restaurant nutrition; recipes are excluded',()=>{
 const incomplete=structuredClone(node);delete incomplete.nutrition.carbohydrateContent;
 assert.equal(parseMenu(html(incomplete),url,['pizza']).candidates[0].macros,null);
 const noServing=structuredClone(node);delete noServing.nutrition.servingSize;
 assert.equal(parseMenu(html(noServing),url,['pizza']).candidates[0].macros,null);
 assert.equal(parseMenu(html({...node,'@type':'Recipe'}),url,['pizza']).candidates.length,0);
});
test('table parsing uses named columns and units, not neighboring numbers or menu prices',()=>{
 const table='<table><tr><th>Item</th><th>Serving size</th><th>Calories</th><th>Protein (g)</th><th>Carbs (g)</th><th>Total Fat (g)</th></tr><tr><td>Pizza</td><td>200 g</td><td>500</td><td>20</td><td>60</td><td>20</td></tr></table>';
 assert.equal(parseMenu(table,url,['pizza']).candidates[0].macros.calories,500);
 assert.equal(parseMenu('<p>Pizza $20 500 calories</p>',url,['pizza']).candidates.length,0);
 const units=table.replace('<th>Serving size</th>','<th>Serving size (g)</th>').replace('<td>200 g</td>','<td>200</td>').replace('Protein (g)','Protein (mg)').replace('<td>20</td><td>60','<td>20000</td><td>60');
 const parsed=parseMenu(units,url,['pizza']).candidates[0];assert.equal(parsed.referenceGrams,200);assert.equal(parsed.macros.protein,20);
});
test('lookup searches without photos/keys, caches evidence, never treats RSS snippets as nutrition',async()=>{
 const calls=[];const lookup=createRestaurantLookup({read:async(u)=>{calls.push(u);return u.includes('bing.com')?{url:u,text:'<rss><item><title>Pizza 500 calories</title><link>'+url+'</link></item></rss>'}:{url:u,text:html(node)};}});
 const request={context:'Pizza from Example Pizzeria Brooklyn',dishes:['Margherita pizza']};
 const result=await lookup(request);assert.equal(result.status,'nutrition_found');assert.equal(result.candidates[0].macros.calories,1000);
 assert.ok(new URL(calls[0]).searchParams.get('q').includes('Example Pizzeria Brooklyn'));assert.equal(calls.length,2);
 await lookup(request);assert.equal(calls.length,2);
 const withoutNutrition=createRestaurantLookup({read:async u=>({url:u,text:u.includes('bing.com')?'<rss><item><title>Pizza 500 calories</title><link>'+url+'</link></item></rss>':'<p>Pizza $20</p>'})});
 assert.equal((await withoutNutrition(request)).status,'menu_only');
});
test('network errors preserve usable evidence and incomplete lookup returns honest fallback',async()=>{
 const lookup=createRestaurantLookup({read:async u=>{if(u.includes('bing'))return {url:u,text:'<rss><item><link>'+url+'</link></item><item><link>https://bad.example/</link></item></rss>'};if(u.includes('bad'))throw new Error('offline');return {url:u,text:html(node)};}});
 assert.equal((await lookup({context:'pizza from Example',dishes:['pizza']})).status,'nutrition_found');
 const empty=createRestaurantLookup({read:async u=>({url:u,text:'<rss/>'})});assert.equal((await empty({context:'pizza from Example',dishes:['pizza']})).status,'not_found');
});
test('source fetching rejects private destinations, credentials, unsafe protocols and mapped IPv6',()=>{
 for(const ip of ['127.0.0.1','10.0.0.2','172.20.0.1','192.168.0.1','169.254.169.254','100.100.100.100','::1','fc00::1','fe80::1','::ffff:127.0.0.1'])assert.equal(publicAddress(ip),false,ip);
 assert.ok(publicAddress('8.8.8.8'));assert.ok(publicAddress('2606:4700:4700::1111'));
 for(const u of ['http://example.com','https://localhost','https://127.0.0.1','https://0x7f000001','https://[::ffff:127.0.0.1]','https://user:pass@example.com','https://example.com:8080'])assert.throws(()=>publicURL(u),u);
});
test('public fetch pins DNS, checks redirects and bounds DNS time instead of rebinding',async()=>{
 await assert.rejects(publicText(url,{resolve:async()=>[{address:'127.0.0.1',family:4}],get:()=>{throw Error('Must not connect');}}),/Private DNS/);
 const controller=new AbortController();const slow=publicText(url,{signal:controller.signal,resolve:()=>new Promise(()=>{})});controller.abort();await assert.rejects(slow);
 let connections=0;
 const get=(_u,options,callback)=>{
   connections++;assert.equal(options.family,4);assert.equal(options.autoSelectFamily,false);
   options.lookup('ignored',{},(error,address,family)=>{assert.equal(error,null);assert.equal(address,'8.8.8.8');assert.equal(family,4);});
   const request=new EventEmitter(),response=new EventEmitter();response.resume=()=>{};
   response.statusCode=302;response.headers={location:'https://127.0.0.1/private'};
   queueMicrotask(()=>callback(response));return request;
 };
 await assert.rejects(publicText(url,{resolve:async()=>[{address:'8.8.8.8',family:4}],get}),/Private address/);assert.equal(connections,1);
});
test('unrelated search pages do not become restaurant menu context',async()=>{
 const lookup=createRestaurantLookup({read:async u=>({url:u,text:u.includes('bing')?'<rss><item><link>'+url+'</link></item></rss>':html(node)})});
 const result=await lookup({context:'Pizza from CompletelyDifferentBrand Cleveland',dishes:['pizza']});assert.equal(result.candidates.length,0);assert.equal(result.status,'not_found');
});
test('authenticated lookup is independent from scan concurrency/quota and failures preserve photo service',async()=>{
 const token='test-token-with-at-least-24-characters';let seen;
 const server=createService({token,provider:'ollama',restaurantLookup:async input=>{seen=input;return {query:'Cafe',status:'not_found',notes:'No nutrition',sources:[],candidates:[]};},fetchImpl:async()=>({ok:true,json:async()=>({message:{content:JSON.stringify({items:[],notes:'Review estimates',questions:[]})}})})});
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 try{
 const base='http://127.0.0.1:'+server.address().port,headers={Authorization:'Bearer '+token,'Content-Type':'application/json'};
 assert.equal((await fetch(base+'/restaurant',{method:'POST'})).status,401);
 const reply=await fetch(base+'/restaurant',{method:'POST',headers,body:JSON.stringify({context:'pizza from Cafe',dishes:['pizza']})});assert.equal(reply.status,200);assert.equal(seen.context,'pizza from Cafe');assert.equal(seen.image,undefined);
 assert.equal((await fetch(base+'/analyze',{method:'POST',headers,body:JSON.stringify({image:Buffer.from([255,216,255,217]).toString('base64'),mimeType:'image/jpeg'})})).status,200);
 }finally{await new Promise(r=>server.close(r));}
});

test('bare restaurant names, roulette and bread modifiers produce a clean place query',()=>{
 assert.equal(restaurantQuery('daves hot chicken roulette, no bread, jus tthe chicken'),"Dave's Hot Chicken");
 assert.equal(restaurantQuery("Chicken FROM Dave’s Hot Chicken, without the bread, just chicken"),"Dave's Hot Chicken");
 assert.equal(restaurantQuery('Pizza from Example Pizzeria, Brooklyn NY, no bread'),'Example Pizzeria, Brooklyn NY');
 assert.equal(restaurantQuery('rice 250 g, no bread'),'');
});
test('fat calories can never be mistaken for grams of total fat and implausible profiles fail closed',()=>{
 const table='<table><tr><th>Menu Item</th><th>Serving Size</th><th>Calories</th><th>Fat Calories</th><th>Total Fat (g)</th><th>Protein (g)</th><th>Carb (g)</th></tr><tr><td>Tender</td><td>224g</td><td>550</td><td>310</td><td>35</td><td>25</td><td>31</td></tr></table>';
 assert.deepEqual(parseMenu(table,url,['tender']).candidates[0].macros,{calories:550,protein:25,carbs:31,fat:35,fiber:0});
 assert.equal(parseMenu(table.replace('<td>35</td>','<td>310</td>'),url,['tender']).candidates[0].macros,null);
});
test('discovery prioritizes nutrition PDFs, follows explicit CDN links and parses Divi links without executing scripts',async()=>{
 const {nutritionLinks}=await import('./restaurant.mjs');
 const page='<a href="/menu">Menu</a><a href="https://cdn.example/nutrition.pdf">Nutrition</a><a href="/allergen.pdf">Allergens</a><script>var et_link_options_data = [{"url":"/nutrition-download/"}];</script>';
 assert.deepEqual(nutritionLinks(page,url),['https://cdn.example/nutrition.pdf','https://restaurant.example/nutrition-download/']);
 assert.deepEqual(nutritionLinks('<a href="https://127.0.0.1/nutrition">Nutrition</a>',url),[]);
});
test('following multiple nutrition links preserves a usable source when the first fails',async()=>{
 const calls=[];
 const lookup=createRestaurantLookup({read:async u=>{calls.push(u);if(u===url)return{url:u,text:'<a href="/nutrition-broken">Nutrition</a><a href="/nutrition-download">Nutrition</a>'};if(u.endsWith('broken'))throw Error('offline');if(u.endsWith('download'))return{url:u,text:'<a href="https://cdn.example/nutrition-table">Nutrition</a>'};return{url:u,text:html(node)};}});
 const result=await lookup({sourceURL:url,dishes:['pizza']});assert.equal(result.status,'nutrition_found');assert.equal(result.candidates[0].sourceURL,'https://cdn.example/nutrition-table');assert.ok(calls.includes('https://cdn.example/nutrition-table'));
});
test('no bread keeps published macros intact and does not claim a modified serving is exact',async()=>{
 const tender={'@type':'MenuItem',name:'Single Tender (no sides), Mild-Reaper Spice',nutrition:{servingSize:'224g',calories:550,proteinContent:25,carbohydrateContent:31,fatContent:35}};
 const lookup=createRestaurantLookup({read:async u=>({url:u,text:html(tender)})});
 const result=await lookup({sourceURL:url,context:'chicken from Example Cafe, no bread, just chicken',dishes:['chicken']});
 assert.equal(result.candidates.length,1);assert.equal(result.candidates[0].macros.calories,550);assert.match(result.notes,/not been adjusted/);assert.match(result.candidates[0].description,/not been verified/);
});
test('ordinary portion notes perform no external fetch',async()=>{
 const lookup=createRestaurantLookup({read:async()=>{throw Error('must not search');}});
 assert.equal((await lookup({context:'200g cooked rice',dishes:['rice']})).status,'not_requested');
});
test('public PDF fetch returns bounded binary bytes while retaining DNS pinning',async()=>{
 const bytes=Buffer.from('%PDF-1.3\nfixture');
 const get=(_u,options,callback)=>{
   const request=new EventEmitter(),response=new EventEmitter();response.resume=()=>{};response.destroy=()=>{};response.statusCode=200;response.headers={'content-type':'application/pdf'};
   queueMicrotask(()=>{callback(response);response.emit('data',bytes);response.emit('end');});return request;
 };
 const result=await publicText('https://cdn.example/nutrition.pdf',{get,resolve:async()=>[{address:'8.8.8.8',family:4}]});
 assert.deepEqual(result.pdf,bytes);assert.equal(result.text,undefined);
});

test('structured lookup separates place and location from marketing dishes and recipe changes',async()=>{
 const calls=[];const lookup=createRestaurantLookup({read:async u=>{calls.push(u);return u.includes('bing.com')?{url:u,text:'<rss><item><link>'+url+'</link></item></rss>'}:{url:u,text:html(node)};}});
 const result=await lookup({context:'surprise pizza, no bread, and one other item from Example Pizzeria Brooklyn',restaurantName:'Example Pizzeria',restaurantLocation:'Brooklyn',dishes:['Margherita pizza'],components:['bread']});
 assert.equal(result.query,'Example Pizzeria Brooklyn');assert.equal(result.status,'nutrition_found');
 const query=new URL(calls[0]).searchParams.get('q');assert.ok(query.includes('Example Pizzeria Brooklyn'));assert.equal(query.includes('no bread'),false);assert.equal(query.includes('one other item'),false);
});
