import { Worker } from 'node:worker_threads';
const escape = s => String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
// Only explicit, horizontal nutrition tables with named columns are accepted.
// No OCR, number proximity guesses, or inferred weights for empty serving cells.
export function nutritionTableRows(items) {
  const lines=[];
  for(const item of items.filter(i=>i.horizontal && i.text.trim()).sort((a,b)=>b.y-a.y||a.x-b.x)) {
    let line=lines.at(-1); if(line && Math.abs(line.y-item.y)>2)line=null;
    if(!line){line={y:item.y,items:[]};lines.push(line);} line.items.push(item);
  }
  const headers=lines.filter(l=>l.items.some(i=>/^calories(?:\s*\(kcal\))?$/i.test(i.text.trim()))&&l.items.some(i=>/^protein(?:\s*\(g\))?$/i.test(i.text.trim())));
  const tables=[];
  for(const header of headers) {
    const h=header.items.sort((a,b)=>a.x-b.x),labels=h.map(i=>i.text.trim());
    const ni=labels.findIndex(s=>/^(?:menu item|item|food|product|name)$/i.test(s));
    const si=labels.findIndex(s=>/^(?:serving size|serving|portion)(?:\s*\((?:g|grams?|oz|ml)\))?$/i.test(s));
    if(ni!==0||si!==1||!labels.some(s=>/^(?:total )?fat\s*\(g\)$/i.test(s))||!labels.some(s=>/^(?:total )?carb/i.test(s)))continue;
    const boundaries=h.slice(1).map((v,i)=>i===0?v.x-5:(h[i].x+h[i].width+v.x)/2);
    const cells=line=>{
      const out=labels.map(()=>[]);
      for(const i of line.items) {const cx=i.x+i.width/2;let col=boundaries.findIndex(b=>cx<b);if(col<0)col=labels.length-1;out[col].push(i);}
      return out.map(a=>a.sort((a,b)=>a.x-b.x).map(i=>i.text.trim()).join(' ').trim());
    };
    const body=lines.filter(l=>l.y<header.y-3 && !headers.some(other=>other.y<header.y&&l.y<other.y));
    const rows=body.map(l=>({y:l.y,c:cells(l)}));
    for(let i=0;i<rows.length;i++) {
      const r=rows[i];
      // Wrapped names share their row with one explicit serving and numeric cells.
      if(r.c[0]&&!r.c[1]&&r.c.slice(2).every(c=>!c)) {
        const neighbors=[rows[i-1],rows[i+1]].filter(n=>n?.c[1]&&Math.abs(n.y-r.y)<=14);
        if(neighbors.length===1) {const n=neighbors[0];n.c[0]=r.y>n.y?r.c[0]+' '+n.c[0]:n.c[0]+' '+r.c[0];r.c[0]='';}
      }
    }
    const values=rows.filter(r=>r.c[0]&&r.c[1]&&/\d/.test(r.c[1])&&r.c.slice(2).filter(c=>/^\d+(?:[.,]\d+)?$/.test(c)).length>=4).slice(0,100).map(r=>r.c);
    if(values.length)tables.push([labels,...values]);
  }
  return tables;
}
export async function pdfNutrition(data,{signal}={}) {
  if(!Buffer.isBuffer(data)||data.length>5_000_000||data.subarray(0,5).toString()!=='%PDF-')throw new Error('Invalid PDF');
  signal?.throwIfAborted();
  const worker=new Worker(new URL('./nutrition-pdf-worker.mjs',import.meta.url),{workerData:data,resourceLimits:{maxOldGenerationSizeMb:96,maxYoungGenerationSizeMb:16},execArgv:[]});
  let timer,abort;
  try {
    const pages=await new Promise((resolve,reject)=>{
      timer=setTimeout(()=>reject(new Error('PDF deadline')),6500);
      abort=()=>reject(signal.reason); signal?.addEventListener('abort',abort,{once:true});
      worker.once('message',m=>m.error?reject(new Error(m.error)):resolve(m.pages));
      worker.once('error',reject);worker.once('exit',code=>{if(code!==0)reject(new Error('PDF worker failed'));});
    });
    const tables=pages.flatMap(nutritionTableRows);
    return {text:pages.flat().map(i=>i.text).join(' ').slice(0,250000),html:tables.map(t=>'<table>'+t.map((r,i)=>'<tr>'+r.map(v=>'<'+(i?'td':'th')+'>'+escape(v)+'</'+(i?'td':'th')+'>').join('')+'</tr>').join('')+'</table>').join('')};
  } finally {clearTimeout(timer);signal?.removeEventListener('abort',abort);await worker.terminate();}
}
