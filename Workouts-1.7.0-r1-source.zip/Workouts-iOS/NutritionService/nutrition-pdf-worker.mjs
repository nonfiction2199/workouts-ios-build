import { parentPort, workerData } from 'node:worker_threads';
let pdfjs;
try { pdfjs=await import('./vendor/pdfjs/pdf.mjs'); }
catch(error) { if(error.code!=='ERR_MODULE_NOT_FOUND')throw error;pdfjs=await import('pdfjs-dist/legacy/build/pdf.mjs'); }
const { getDocument }=pdfjs;
// Text extraction only. No document URLs, scripts, attachments or rendering.
const task = getDocument({ data: new Uint8Array(workerData), isEvalSupported: false,
  useSystemFonts: false, disableFontFace: true, useWasm: false, useWorkerFetch: false,
  stopAtErrors: true, verbosity: 0 });
try {
  const document = await task.promise;
  if (document.numPages > 12) throw new Error('Too many PDF pages');
  const pages = []; let count = 0, characters = 0;
  for (let p = 1; p <= document.numPages; p++) {
    const page = await document.getPage(p), content = await page.getTextContent();
    const items = content.items.filter(i => typeof i.str === 'string' && i.str.trim()).map(i => {
      count++; characters += i.str.length;
      if (count > 50000 || characters > 250000) throw new Error('PDF text too large');
      return { text: i.str.slice(0,1000), x: i.transform[4], y: i.transform[5], width: i.width,
        height: i.height, horizontal: i.transform[0] > 0 && i.transform[3] > 0 && Math.abs(i.transform[1]) < .01 && Math.abs(i.transform[2]) < .01 };
    });
    pages.push(items); page.cleanup();
  }
  parentPort.postMessage({ pages });
} catch { parentPort.postMessage({ error: 'PDF could not be read' }); }
finally { await task.destroy(); }
