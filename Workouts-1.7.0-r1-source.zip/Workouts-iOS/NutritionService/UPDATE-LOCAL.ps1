param([string]$InstallDirectory = "$env:USERPROFILE\Downloads\Workouts-Local-Food-AI\Workouts-Local-Food-AI")
$ErrorActionPreference = 'Stop'
try {
    if (-not (Test-Path (Join-Path $InstallDirectory 'local-service-token.txt'))) {
        Add-Type -AssemblyName System.Windows.Forms
        $picker = New-Object System.Windows.Forms.OpenFileDialog
        $picker.Title = 'Choose start-local.ps1 in your EXISTING working food AI folder'
        $picker.Filter = 'Existing launcher (start-local.ps1)|start-local.ps1'
        if ($picker.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { throw 'Update cancelled. No service files changed.' }
        $InstallDirectory = Split-Path $picker.FileName -Parent
    }
    $InstallDirectory = (Resolve-Path $InstallDirectory).Path
    $tokenPath = Join-Path $InstallDirectory 'local-service-token.txt'
    if (-not (Test-Path $tokenPath)) { throw 'Choose the existing folder containing local-service-token.txt. Your connection token must be preserved.' }
    $tokenBefore = [IO.File]::ReadAllBytes($tokenPath)
    $node = Get-Command node -ErrorAction Stop
    $nodeVersion = [version]((& node --version).TrimStart('v'))
    if ($nodeVersion -lt [version]'22.13.0') { throw 'Update Node.js to 22.13 or newer before updating this service.' }
    foreach ($required in @('server.mjs','restaurant.mjs','nutrition-pdf.mjs','nutrition-pdf-worker.mjs','vendor/pdfjs/pdf.mjs','vendor/pdfjs/pdf.worker.mjs','vendor/pdfjs/LICENSE','vendor/pdfjs/VERSION.json','start-local.ps1','README.md')) {
        if (-not (Test-Path (Join-Path $PSScriptRoot $required))) { throw 'Extract the entire update ZIP before running UPDATE-LOCAL.cmd. No process was stopped.' }
    }
    # Stop only the Node adapter verified by its local health protocol and listener.
    $listeners = @(Get-NetTCPConnection -LocalPort 8080 -State Listen -ErrorAction SilentlyContinue)
    if ($listeners.Count -gt 0) {
        $health = Invoke-RestMethod 'http://127.0.0.1:8080/health' -TimeoutSec 5
        if ($health.status -ne 'ok' -or $health.protocol -ne 2 -or -not $health.localRevision) { throw 'Port 8080 belongs to a different service. No process was stopped.' }
        foreach ($owner in @($listeners.OwningProcess | Select-Object -Unique)) {
            $process = Get-CimInstance Win32_Process -Filter "ProcessId=$owner"
            if ($process.Name -ne 'node.exe' -or $process.CommandLine -notmatch 'server\.mjs') { throw 'Could not safely identify the existing adapter. Stop your food adapter, then run this updater again.' }
            Stop-Process -Id $owner -ErrorAction Stop
        }
        Start-Sleep -Seconds 2
    }
    foreach ($name in @('server.mjs','restaurant.mjs','nutrition-pdf.mjs','nutrition-pdf-worker.mjs','vendor/pdfjs/pdf.mjs','vendor/pdfjs/pdf.worker.mjs','vendor/pdfjs/LICENSE','vendor/pdfjs/VERSION.json','start-local.ps1','README.md')) {
        $target = Join-Path $InstallDirectory $name
        [IO.Directory]::CreateDirectory((Split-Path $target -Parent)) | Out-Null
        if (Test-Path $target) { Copy-Item $target ($target + '.before-1.7.0') -Force }
        Copy-Item (Join-Path $PSScriptRoot $name) $target -Force
    }
    $tokenAfter = [IO.File]::ReadAllBytes($tokenPath)
    if ([Convert]::ToBase64String($tokenBefore) -ne [Convert]::ToBase64String($tokenAfter)) { throw 'Token verification failed.' }
    # Same installation path: existing login tasks and Tailscale settings still apply.
    $launcher = Join-Path $InstallDirectory 'start-local.ps1'
    $outLog = Join-Path $InstallDirectory 'startup-out.log'
    $errorLog = Join-Path $InstallDirectory 'startup-error.log'
    $worker = Start-Process powershell.exe -WindowStyle Hidden -WorkingDirectory $InstallDirectory -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"' + $launcher + '"')) -RedirectStandardOutput $outLog -RedirectStandardError $errorLog -PassThru
    Write-Host 'Starting the service and loading the model. This can take a few minutes...'
    $ready = $false
    $startupDeadline = (Get-Date).AddSeconds(240)
    while ((Get-Date) -lt $startupDeadline) {
        try {
            $health = Invoke-RestMethod 'http://127.0.0.1:8080/health' -TimeoutSec 2
            if ($health.status -eq 'ok' -and $health.protocol -eq 2 -and $health.localRevision -eq 10) { $ready = $true; break }
        } catch { }
        $worker.Refresh()
        if ($worker.HasExited) { throw "The service could not start. Check $errorLog or run the existing start-local.ps1 to see the error." }
        Start-Sleep -Seconds 2
    }
    if (-not $ready) { throw "The update was copied, but startup could not be verified. Check $errorLog or run the existing start-local.ps1." }
    Write-Host 'Workouts 1.7.0 service is ready and running in the background (localRevision 10).'
    Write-Host 'Your existing token, app URL and Tailscale connection are unchanged.'
    Write-Host 'Install the paired Workouts 1.7.0 app for the improved photo portions and themes.'
} catch {
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
}
