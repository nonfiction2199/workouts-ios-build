import test from 'node:test';
import assert from 'node:assert/strict';
import {createService,evidencePrompt,applyPhotoPortions,groundMealResult,normalizeProviderResult} from './server.mjs';
const token='test-token-with-at-least-24-characters';
const photo=Buffer.from([255,216,255,217]).toString('base64');
const pizza={name:'Cheese pizza',grams:150,macros:{calories:390,protein:15,carbs:45,fat:16,fiber:2},uncertainty:'Size and recipe estimate',requestedName:'',quantity:{count:null,unit:'',basis:'photo',weightBasis:'photo'},exclude:[],add:[]};
const meal=items=>({items,notes:'Estimate; review before logging',questions:[],restaurantName:'',restaurantLocation:''});
async function scan(replies,input={}) {
 const requests=[];
 const server=createService({token,provider:'ollama',fetchImpl:async(url,request)=>{
  requests.push(JSON.parse(request.body));
  assert.equal(url,'http://127.0.0.1:11434/api/chat');
  return {ok:true,json:async()=>({done:true,done_reason:'stop',message:{content:JSON.stringify(replies[Math.min(requests.length-1,replies.length-1)])}})};
 }});
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 try {
  const response=await fetch('http://127.0.0.1:'+server.address().port+'/analyze',{method:'POST',headers:{Authorization:'Bearer '+token,'Content-Type':'application/json'},body:JSON.stringify({workflow:4,images:[photo],mimeType:'image/jpeg',context:'',...input})});
  return {status:response.status,value:await response.json(),requests};
 }finally{await new Promise(r=>server.close(r));}
}
test('photo-only input does not require food text and retains the real image',async()=>{
 assert.match(evidencePrompt,/Missing text never means missing food/);
 assert.doesNotMatch(evidencePrompt,/No food descriptions means empty items/);
 const {status,value,requests}=await scan([meal([pizza])]);
 assert.equal(status,200);assert.equal(value.items[0].name,'Cheese pizza');assert.equal(requests.length,1);assert.deepEqual(requests[0].messages[0].images,[photo]);
});
test('empty photo answer is rechecked once using the same images and grounded constraints',async()=>{
 const {status,value,requests}=await scan([meal([]),meal([pizza])]);
 assert.equal(status,200);assert.equal(value.items.length,1);assert.equal(requests.length,2);
 assert.deepEqual(requests[1].messages[0].images,requests[0].messages[0].images);
 assert.match(requests[1].messages[0].content,/Do not invent food/);assert.equal(requests[1].think,false);
});
test('genuinely empty answers remain empty after at most one recheck',async()=>{
 const {status,value,requests}=await scan([meal([])]);
 assert.equal(status,200);assert.deepEqual(value.items,[]);assert.equal(requests.length,2);
 const text=await scan([meal([])],{images:[],context:'This is not a meal'});assert.equal(text.requests.length,1);
});
test('visible piece arithmetic updates every nutrient and retains a photo estimate basis',async()=>{
 const sized={...structuredClone(pizza),nutrientsPer100g:{calories:260,protein:10,carbs:30,fat:16/1.5,fiber:2/1.5},portionEstimate:{count:2,unit:'slices',gramsPerUnit:125}};
 const {status,value,requests}=await scan([meal([sized])],{portionEvidence:true});
 assert.equal(status,200);assert.equal(value.items[0].grams,250);
 for(const k of ['calories','protein','carbs','fat','fiber'])assert.ok(Math.abs(value.items[0].macros[k]-pizza.macros[k]*250/150)<1e-8);
 assert.equal(value.items[0].quantity.basis,'photo');assert.equal(value.items[0].quantity.count,2);
 assert.ok(requests[0].format.properties.items.items.required.includes('portionEstimate'));
 assert.ok(requests[0].format.properties.items.items.required.includes('nutrientsPer100g'));
 assert.equal(requests[0].format.properties.items.items.properties.macros,undefined);
});
test('per-100g density replaces incompatible portion totals, including protein and fiber',()=>{
 const raw=meal([{...structuredClone(pizza),grams:400,macros:{calories:1,protein:1,carbs:1,fat:1,fiber:1},nutrientsPer100g:{calories:260,protein:10,carbs:30,fat:11,fiber:2}}]);
 const next=normalizeProviderResult(raw,{mealMode:true,compact:true});
 assert.deepEqual(next.items[0].macros,{calories:1040,protein:40,carbs:120,fat:44,fiber:8});
 assert.equal(raw.items[0].macros.calories,1);
});
test('an invalid density cannot sneak through with old portion totals',()=>{
 const value=normalizeProviderResult(meal([{...structuredClone(pizza),nutrientsPer100g:{calories:1000,protein:80,carbs:80,fat:80,fiber:0}}]),{mealMode:true,compact:true});
 assert.equal(value.items[0].macros,undefined);
});
test('measured weights override visual piece arithmetic without mixing macro portions',()=>{
 const value=normalizeProviderResult(meal([{...structuredClone(pizza),portionEstimate:{count:2,unit:'slices',gramsPerUnit:125}}]),{mealMode:true,compact:true});
 const grounded=groundMealResult(applyPhotoPortions(value),'200 g cheese pizza');
 assert.equal(grounded.items[0].grams,200);assert.equal(grounded.items[0].quantity.weightBasis,'user');assert.equal(grounded.items[0].macros.calories,520);
});
test('invalid or conflicting optional piece evidence cannot replace nutrition',()=>{
 for(const p of [{count:0,unit:'slice',gramsPerUnit:125},{count:2,unit:'slice',gramsPerUnit:-1},{count:99,unit:'slice',gramsPerUnit:9000},{count:2,unit:'',gramsPerUnit:125},null]) {
  const value=applyPhotoPortions(meal([{...structuredClone(pizza),portionEstimate:p}]));
  assert.equal(value.items[0].grams,150);assert.deepEqual(value.items[0].macros,pizza.macros);assert.equal(value.items[0].portionEstimate,undefined);
 }
});
