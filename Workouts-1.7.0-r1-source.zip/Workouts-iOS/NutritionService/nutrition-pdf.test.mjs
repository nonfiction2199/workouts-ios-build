import test from 'node:test';
import assert from 'node:assert/strict';
import { nutritionTableRows,pdfNutrition } from './nutrition-pdf.mjs';
import { parseMenu } from './restaurant.mjs';
const headers=['Menu Item','Serving Size','Calories','Fat Calories','Total Fat (g)','Protein (g)','Carb (g)','Fiber (g)'];
const xs=[20,220,280,330,390,460,530,600];
const item=(text,x,y,width=30)=>({text,x,y,width,height:8,horizontal:true});
const row=(values,y)=>values.map((v,i)=>item(v,xs[i]+(i?5:0),y));
const items=[...row(headers,500),...row(['Tender','224g','550','310','35','25','31','0'],480)];
test('PDF tables require explicit column headers and a stated serving',()=>{
 assert.equal(nutritionTableRows(items).length,1);
 assert.equal(nutritionTableRows(items.filter(i=>i.text!=='224g')).flat().length,0);
 assert.equal(nutritionTableRows(items.filter(i=>i.text!=='Serving Size')).length,0);
 assert.equal(nutritionTableRows(items.map(i=>({...i,horizontal:false}))).length,0);
});
test('wrapped PDF names attach to one nearby serving row without inventing nutrients',()=>{
 const multi=[...items,item('Mild-Reaper Spice',20,468,75)];
 const table=nutritionTableRows(multi)[0];assert.equal(table[1][0],'Tender Mild-Reaper Spice');assert.equal(table[1][2],'550');
});
// A minimal synthetic PDF fixture exercises the actual vendored decoder offline.
function fixturePDF() {
 const content=items.map(i=>'BT /F1 8 Tf 1 0 0 1 '+i.x+' '+i.y+' Tm ('+i.text.replace(/[\\()]/g,'\\$&')+') Tj ET').join('\n');
 const objects=['<< /Type /Catalog /Pages 2 0 R >>','<< /Type /Pages /Kids [3 0 R] /Count 1 >>','<< /Type /Page /Parent 2 0 R /MediaBox [0 0 700 550] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>','<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>','<< /Length '+Buffer.byteLength(content)+' >>\nstream\n'+content+'\nendstream'];
 let out='%PDF-1.3\n',offsets=[0];for(let i=0;i<objects.length;i++){offsets.push(Buffer.byteLength(out));out+=(i+1)+' 0 obj\n'+objects[i]+'\nendobj\n';}const start=Buffer.byteLength(out);out+='xref\n0 6\n0000000000 65535 f \n'+offsets.slice(1).map(o=>String(o).padStart(10,'0')+' 00000 n \n').join('')+'trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n'+start+'\n%%EOF';return Buffer.from(out);
}
test('portable PDF worker decodes complete macros and cleans up without native rendering',async()=>{
 const result=await pdfNutrition(fixturePDF());const candidate=parseMenu(result.html,'https://example.com/nutrition.pdf').candidates[0];
 assert.deepEqual(candidate.macros,{calories:550,protein:25,carbs:31,fat:35,fiber:0});assert.equal(candidate.referenceGrams,224);
});
test('invalid, oversized and aborted PDFs fail closed',async()=>{
 await assert.rejects(pdfNutrition(Buffer.from('not a pdf')));
 await assert.rejects(pdfNutrition(Buffer.alloc(5_000_001)));
 await assert.rejects(pdfNutrition(Buffer.from('%PDF-1.3\ncorrupt')));
 const controller=new AbortController();controller.abort();await assert.rejects(pdfNutrition(fixturePDF(),{signal:controller.signal}));
});
