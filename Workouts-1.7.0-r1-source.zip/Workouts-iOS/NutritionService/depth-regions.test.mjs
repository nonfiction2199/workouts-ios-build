import test from 'node:test';
import assert from 'node:assert/strict';
import {createService,normalizeProviderResult} from './server.mjs';
const token='test-token-with-at-least-24-characters';
const item={name:'Cooked rice',grams:150,macros:{calories:195,protein:4,carbs:42,fat:1,fiber:1},uncertainty:'Estimate',requestedName:'',quantity:{count:null,unit:'',basis:'photo',weightBasis:'photo'},exclude:[],add:[],imageRegion:[0.2,0.3,0.7,0.8]};
const meal={items:[item],restaurantName:'',restaurantLocation:'',notes:'Estimate',questions:[]};
test('invalid optional image regions are discarded without corrupting food nutrition',()=>{
 for(const box of [[0.8,0.1,0.2,0.4],[-1,0,1,1],['0.1',0,1,1],[0,0,1],{},[0,0,Infinity,1]]){
  const value=structuredClone(meal);value.items[0].imageRegion=box;
  const clean=normalizeProviderResult(value,{mealMode:true,compact:true});assert.equal(clean.items[0].imageRegion,undefined);assert.equal(clean.items[0].grams,150);
 }
 assert.deepEqual(normalizeProviderResult(meal,{mealMode:true,compact:true}).items[0].imageRegion,item.imageRegion);
});
test('depth semantics are opt-in and still use one bounded request with no depth upload',async()=>{
 let seen;
 const service=createService({token,provider:'ollama',fetchImpl:async(url,{body})=>{seen=JSON.parse(body);return {ok:true,json:async()=>({done:true,done_reason:'stop',message:{content:JSON.stringify(meal)}})};}});
 await new Promise(r=>service.listen(0,'127.0.0.1',r));
 try{
  const response=await fetch('http://127.0.0.1:'+service.address().port+'/analyze',{method:'POST',headers:{Authorization:'Bearer '+token,'Content-Type':'application/json'},body:JSON.stringify({workflow:4,images:[Buffer.from([255,216,255,217]).toString('base64')],mimeType:'image/jpeg',context:'rice',depthRegions:true})});
  assert.equal(response.status,200);assert.deepEqual((await response.json()).items[0].imageRegion,item.imageRegion);
  assert.ok(seen.format.properties.items.items.required.includes('imageRegion'));assert.equal(seen.options.num_predict,2200);assert.equal(seen.think,false);
 }finally{await new Promise(r=>service.close(r));}
});
