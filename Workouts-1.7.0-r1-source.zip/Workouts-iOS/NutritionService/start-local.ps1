$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
if (-not (Get-Command node -ErrorAction SilentlyContinue)) { throw 'Install Node.js 22 or newer from https://nodejs.org, then reopen PowerShell.' }
$nodeVersion = [version]((& node --version).TrimStart('v'))
if ($nodeVersion -lt [version]'22.13.0') { throw 'Node.js 22.13 or newer is required. Update Node.js, then rerun this launcher.' }
$model = 'qwen3-vl:8b-instruct'
try {
    $tags = Invoke-RestMethod -Uri 'http://127.0.0.1:11434/api/tags' -TimeoutSec 10
} catch {
    $ollamaCommand = Get-Command ollama -ErrorAction SilentlyContinue
    if (-not $ollamaCommand) { throw 'Ollama could not be found. Open Ollama, then run this launcher again.' }
    Write-Host 'Starting Ollama in the background...'
    Start-Process -FilePath $ollamaCommand.Source -ArgumentList 'serve' -WindowStyle Hidden
    $tags = $null
    for ($attempt = 0; $attempt -lt 15; $attempt++) {
        Start-Sleep -Seconds 2
        try { $tags = Invoke-RestMethod -Uri 'http://127.0.0.1:11434/api/tags' -TimeoutSec 2; break } catch { }
    }
    if (-not $tags) { throw 'Ollama did not become ready. Open Ollama and retry.' }
}
if (-not ($tags.models | Where-Object { $_.name -eq $model })) { throw 'Download the vision model first: ollama pull qwen3-vl:8b-instruct' }
Write-Host 'Loading the local vision model. First startup can take a moment...'
$warm = @{model=$model;stream=$false;keep_alive='30m'} | ConvertTo-Json
Invoke-RestMethod -Uri 'http://127.0.0.1:11434/api/generate' -Method Post -ContentType 'application/json' -Body $warm -TimeoutSec 180 | Out-Null
$tokenPath = Join-Path $PSScriptRoot 'local-service-token.txt'
if (-not (Test-Path $tokenPath)) {
    $bytes = New-Object byte[] 32
    $rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
    try { $rng.GetBytes($bytes) } finally { $rng.Dispose() }
    $token = ([BitConverter]::ToString($bytes)).Replace('-','').ToLowerInvariant()
    [IO.File]::WriteAllText($tokenPath,$token)
}
$env:FOOD_PROVIDER = 'ollama'
$env:OLLAMA_MODEL = $model
$env:OLLAMA_URL = 'http://127.0.0.1:11434'
$env:FOOD_BIND_HOST = '127.0.0.1'
$env:FOOD_SERVICE_TOKEN = ([IO.File]::ReadAllText($tokenPath)).Trim()
$env:MAX_DAILY_SCANS = '0'
$env:PORT = '8080'
Write-Host 'Service token for the iPhone app (also saved in local-service-token.txt):'
Write-Host 'Open local-service-token.txt only if you need to reconnect the app.'
Write-Host 'Keep this window open. In another PowerShell window, run:'
Write-Host 'tailscale serve --bg http://127.0.0.1:8080'
Write-Host 'Use the HTTPS address Tailscale prints, followed by /analyze.'
& node server.mjs
