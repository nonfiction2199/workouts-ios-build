# Workouts 1.5.0 · Evidence and editable meal plates

Photo-only scans previously required a single image, hid the reference image during review, offered no batch total or missing-food addition, and required manual number editing for partial meals. Describe now accepts text alone or text plus up to two photos of one meal. The service distinguishes supporting evidence from duplicate portions, checks workflow compatibility and cancels local inference when a request closes. Inputs remain private to the configured adapter; no paid key is required for local Ollama.

Review displays source evidence, photos, calories/macros/fiber totals and separate nutrition/portion review flags. Add a missing library food, delete duplicate items, half/double the plate, edit an individual amount or scale a selected profile to known calories. Calorie-derived weight and macros remain estimates. Save the plate as a reusable recipe with ingredient snapshots; expanding a recipe replaces its parent instead of double-counting it, and refuses to silently discard edited totals.

Native consistency checks flag unusually dense nutrition and large calorie/macro conflicts. Count-only published profiles do not get rejected by unsupported photo gram weights. Named measured weights attach to the appropriate food; combined meal weights cannot claim measured component weights. Weight corrections also scale the fallback macro estimate. Equivalent grilled/broiled, roasted/baked and steamed/boiled search preparations resolve together, while raw/fried and other incompatible preparations remain separate. Suggestions now include the offline branded library, requiring user selection.

Food identity, reference profiles, portion decisions, edits and backup snapshots remain separate. New review metadata is optional so existing diaries remain compatible. The app ID stays app.sudais.workouts and all eight palettes use the shared theme system. Service Revision 8 supports previous app workflows alongside workflow 4.

## Research informing this update

- MacroFactor's May 2026 update documents Snap and Describe, multiple photos, text, portions and exclusions: https://macrofactor.com/mm-may-2026/
- Editable plate entries, ingredient inspection and photo guidance: https://help.macrofactorapp.com/en/articles/258-ai-food-logging
- Describe quantities and compound-dish double-counting limitations: https://help.macrofactorapp.com/en/articles/216-log-foods-with-describe
- Scaling a food profile using known calories/macros: https://help.macrofactorapp.com/en/articles/245-log-by-calories-or-macros
- Ollama structured JSON and vision interfaces: https://docs.ollama.com/capabilities/structured-outputs and https://docs.ollama.com/capabilities/vision

These sources describe public product behavior, not MacroFactor's proprietary model, training, prompts or matching implementation. Our implementation is independent. A stronger workflow does not establish a measured 8/10 photo-nutrition accuracy; that requires representative real meals, verified quantities and labels, and testing on the user's actual laptop/iPhone.

## Validation

Backend HTTP tests cover text-only/two-photo input, authentication, JPEG/size bounds, old workflows, disconnection cancellation, code-fence representation, explicit named weights and total-weight ambiguity. Foundation checks cover fractions, calorie scaling, independent source counts, density/energy flags, recipe snapshots/expansion and older backups. Native simulator tests exercise corrections, added foods, recipe persistence, calorie scaling, Describe and all eight palettes. Current results are recorded in the build run and release notes.
