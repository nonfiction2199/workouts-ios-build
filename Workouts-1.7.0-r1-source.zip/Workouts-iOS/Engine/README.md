# Progression engine v2

This is an independent, deterministic coaching model, not MacroFactor's private implementation. Tests demonstrate consistent software behavior; they do not establish physiological accuracy or product parity.

## Public behavior used as the reference

- [Smart Progressions](https://help.macrofactorapp.com/en/articles/305-understanding-and-using-smart-progressions): performance, target RIR, rep ranges, in-session application, previous/smart prefills, rep-range expansion, weight matching, and equipment warnings.
- [Why targets can decrease](https://help.macrofactorapp.com/en/articles/373-why-does-the-app-sometimes-recommend-lowering-weight-or-reps): logged performance and effort can justify lighter future targets.
- [Custom periodization](https://help.macrofactorapp.com/en/articles/388-how-to-enable-periodization-for-custom-programs): cycle-specific set counts, reps, and effort.
- [Scheduled deloads](https://help.macrofactorapp.com/en/articles/297-deload-first-cycle-or-last-cycle): first-cycle, last-cycle, or no scheduled deload.

The implementation's formulas, eight-session window, confidence labels, thresholds, and fatigue estimates are our own design choices.

## Model

1. Sort history by date, deduplicate sessions, exclude future entries and deloads, and retain up to eight recent exposures to the exact exercise. Repeated occurrences in the same workout do not become independent observations.
2. Working and failure sets qualify. Failure means zero RIR. Warm-ups, drops, myo sets, partials, zero reps, and sets over 50 reps are excluded from the strength baseline. High reps and high/censored RIR get lower weight.
3. Capacity starts with `load × (1 + (reps + RIR) / k)`, initially `k = 30`. Close-in-time first sets spanning different rep ranges can fit an individual `k`. At least five usable first sets and four qualifying comparisons are needed. The fit is shrunk toward the baseline and bounded to 22–42.
4. Estimate set-position fatigue from later-set capacity relative to first sets. Shrink sparse observations toward a small default decline and limit the curve to 65–100% of first-set capacity. Normalize historical sets by this curve before estimating baseline capacity, avoiding double-counting fatigue.
5. Recent sessions get exponentially greater influence. Within-session and historical extremes are bounded. A very unusual log cannot directly become the whole baseline.
6. Compare earlier overlapping muscle work with the exercise's typical position. This is a small context adjustment, bounded to −8% / +4%; it is not measured muscular recovery.
7. Blend completed sets from the current exercise into the estimate. One live set has 65% influence when a historical baseline exists, with a maximum of 85% for multiple sets. Large deviations are bounded, and the explanation asks the user to check their entry.
8. Search feasible load and integer-rep combinations at the target RIR. Respect minimum-load offsets, maximum load, custom available-weight lists, and increments. Limit an increase to the configured percentage or one step. Prefer a matching prior weight when feasible. Only expand the range by at most three reps when the original range cannot fit. A mismatch over 0.75 estimated reps is flagged and never silently applied.

Confidence is a qualitative description of coverage, recency, and consistency—not a calibrated probability. After a long gap, confidence falls and current sets recalibrate the estimate; dates never advance the program cycle.

## Other tracking modes

- Bodyweight uses reps plus RIR at the same added weight. It never treats body mass as zero in a loaded-lift formula or invents a new added load.
- Assisted, band, and explicitly manual exercises repeat prior entries. The app does not infer effective resistance without that information.
- Timed movements repeat prior duration. They do not receive strength-based automatic time increases.
- Loading mode is overridable per exercise target. Similar exercise names do not transfer machine strength automatically.

## User control and storage

`manual`, `prescription`, progression preferences, equipment constraints, and cycle targets are optional fields. Old backups remain valid. New fields survive schema validation, save, and export. Each set stores only a compact numeric prescription, not a large explanation.

Automatic refresh touches only unchecked working sets explicitly marked as unedited. Existing active sessions lacking that marker are protected. Completed sets, explicit manual entries, and specialty sets remain untouched. The user can apply a specific suggestion to replace an unchecked manual entry.

Exercise swaps retain already completed sets. New movements use their own history. Starting, adding, swapping, and adding sets all use the same progression engine.

Programs retain six-cycle scheduling. Optional per-cycle targets specify sets, minimum/maximum reps, and RIR. Without custom targets, effort periodization lowers RIR by one in cycles 4–5. Deloads can occur in the first or last cycle; they halve sets, raise target RIR to at least four, and reserve 5% of estimated capacity. The explicit lighter-workout action retains completed/manual sets and reduces untouched remaining work. It is idempotent.

Training review compares median estimates from the last two versus previous two exposures. It labels improving, steady, declining, and sustained flat trends. Plateau detection requires at least six exposures over 21 days. Multiple declining lifts trigger a suggestion to review recovery; no automatic volume escalation or diagnosis occurs. The heatmap remains a record of set volume.

## Verification

Run `node scripts/test-progression.mjs`. The suite covers initial calibration, RIR, date ordering, unusual logs, specialty sets, fatigue, live adjustment, protected inputs, constraints, bodyweight/timed/manual modes, previous-value prefills, long breaks, cycle targets, deloads, trends, individualized curves, added sets, and backward-compatible storage. A deterministic sweep covers 324 combinations of load, reps, RIR, and increments.

Phone UI verification uses synthetic state in temporary development-only routes. It checks that live changes update untouched fields, manual overrides remain fixed until explicitly replaced, settings work, and dialogs stay inside 375px and 430px viewports. Optimized production CSS is checked because a previous development-only check missed a transform issue. Temporary routes and styles are removed before publication.
