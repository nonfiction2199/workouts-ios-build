import {initial,exercises,begin,generate,type State,type Target} from './lib/training';
import {newId} from './lib/id';
import {createSessionExercise,refreshSession,addWorkingSet,recommendationsForItem,trainingReview} from './lib/progression';
import {calculateLevels} from './lib/levels';
import {stateSchema} from './lib/state-schema';
export const bootstrap=()=>JSON.stringify({state:initial,exercises});
export function run(input:string):string{
 const {state:raw,action,args:a={}}=JSON.parse(input);
 const s=stateSchema.parse(raw) as State;
 const catalog=[...exercises,...s.custom];
 const item=()=>{const i=s.active?.items[a.item];if(!i)throw Error('Exercise no longer exists.');return i;};
 switch(action){
 case 'generate': if(s.active)throw Error('Finish your current workout first.');s.settings={...s.settings,...a.settings};s.program=generate(s.settings);s.next=0;break;
 case 'start': if(s.active)throw Error('Resume or finish your current workout first.');if(!s.program[a.day])throw Error('Workout not found.');s.active=begin(s,a.day,!!a.lighter);break;
 case 'empty': if(s.active)throw Error('Resume your current workout first.');s.active={id:newId(),name:'Empty Workout',started:new Date().toISOString(),day:0,cycle:1,deload:false,free:true,items:[]};break;
 case 'set': {const x=item().sets[a.set];if(!x)throw Error('Set not found.');Object.assign(x,a.values,{manual:true});if(x.kind==='Failure')x.rir=0;refreshSession(s,catalog);break;}
 case 'toggle': {const x=item().sets[a.set];if(!x)throw Error('Set not found.');if(!x.done&&!(x.reps>0||(x.seconds??0)>0))throw Error('Enter repetitions or duration before completing the set.');x.done=!x.done;if(x.done)x.manual=true;refreshSession(s,catalog);break;}
 case 'addSet': if(item().sets.length>=30)throw Error('Maximum 30 sets per exercise.');addWorkingSet(s,a.item,catalog);break;
 case 'removeSet': item().sets.splice(a.set,1);refreshSession(s,catalog);break;
 case 'note': item().note=String(a.note);break;
 case 'addExercise': {
  if(!s.active)throw Error('Start a workout first.');if(s.active.items.length>=30)throw Error('Maximum 30 exercises.');
  const e=catalog.find(e=>e.id===a.id);if(!e)throw Error('Exercise not found.');
  const t:Target={id:e.id,sets:3,min:8,max:12,rir:2,rest:90,increment:e.increment||5,group:''};
  s.active.items.push(createSessionExercise(t,s.history,e,s.settings,s.active,catalog));break;
 }
 case 'removeExercise': item();s.active!.items.splice(a.item,1);refreshSession(s,catalog);break;
 case 'finish': {
  if(!s.active)throw Error('No active workout.');const completed={...s.active,items:s.active.items.map(i=>({...i,sets:i.sets.filter(x=>x.done)})).filter(i=>i.sets.length),ended:new Date().toISOString()};
  if(!completed.items.length)throw Error('Complete at least one set, or discard this workout.');
  s.history.push(completed);if(!completed.free)s.next++;s.active=null;break;
 }
 case 'discard': s.active=null;break;
 case 'settings': s.settings={...s.settings,...a.values,progression:{...s.settings.progression,...a.values?.progression}};break;
 case 'program': if(s.active)throw Error('Finish the current workout before editing your program.');s.program=a.program;break;
 case 'import': {
  const incoming=stateSchema.parse(a.state) as State;
  if(s.active)throw Error('Finish or discard your current workout before importing.');
  const h=new Map(s.history.map(x=>[x.id,x]));for(const x of incoming.history)if(!h.has(x.id))h.set(x.id,x);s.history=[...h.values()];
  const c=new Map(s.custom.map(x=>[x.id,x]));for(const x of incoming.custom)if(!c.has(x.id))c.set(x.id,x);s.custom=[...c.values()];
  if(!s.program.length){s.program=incoming.program;s.settings=incoming.settings;s.next=incoming.next;}
  s.active=incoming.active;break;
 }
 case 'validate': break;
 default:throw Error('Unknown action.');
 }
 return JSON.stringify(stateSchema.parse(s));
}
export function analyze(input:string):string{
 const {state,days=7}=JSON.parse(input);const s=state as State;const catalog=[...exercises,...s.custom];
 return JSON.stringify({levels:calculateLevels(s.history,s.custom,days),recommendations:s.active?.items.map((_,i)=>recommendationsForItem(s,i,catalog))??[],review:trainingReview(s,catalog)});
}

// Read-only preview uses the same prescription path as Start Workout.
export function preview(input:string):string{
 const {state,day}=JSON.parse(input);const s=stateSchema.parse(state) as State;
 if(!Number.isInteger(day)||!s.program[day])throw Error('Workout not found.');
 return JSON.stringify(begin(s,day));
}
