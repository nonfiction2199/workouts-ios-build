import type {Exercise,LoggedSet,Prescription,Session,SessionExercise,Settings,State,Target} from './training';

/** Independent, deterministic model. Constants are conservative product heuristics,
 * not MacroFactor's formulas or a physiological measurement of recovery. */
export const PROGRESSION_VERSION=2;
export type ProgressionSettings={applyInSession:boolean;initialFill:'smart'|'previous';expandRepRange:boolean;weightMatch:boolean;maxIncreasePercent:number};
export const progressionDefaults:ProgressionSettings={applyInSession:true,initialFill:'smart',expandRepRange:true,weightMatch:true,maxIncreasePercent:5};
export const progressionSettings=(settings?:Settings):ProgressionSettings=>({...progressionDefaults,...settings?.progression});
export type Recommendation=Prescription&{
 reason:string;details:string[];warning?:string;blocked:boolean;expanded:boolean;
 confidence:'Learning'|'Building'|'Established';sessions:number;liveSets:number;
 trend:'Learning'|'Improving'|'Steady'|'Plateau'|'Declining';change:number|null;
 fatiguePercent:number;personalizedCurve:boolean;mode:'weighted'|'bodyweight'|'manual'|'time';
};
type Sample={set:LoggedSet;ordinal:number};
type Exposure={session:Session;item:SessionExercise;itemIndex:number;sets:Sample[];at:number};
type Context={target:Target;history:Session[];exercise?:Exercise;setIndex?:number;settings?:Settings;active?:Session;itemIndex?:number;catalog?:Exercise[];deload?:boolean;now?:number};
const DAY=86400000;
const clamp=(n:number,min:number,max:number)=>Math.max(min,Math.min(max,n));
const round=(n:number)=>Math.round(n*100)/100;
const median=(values:number[])=>{const a=[...values].sort((a,b)=>a-b);return a.length?(a[Math.floor((a.length-1)/2)]+a[Math.ceil((a.length-1)/2)])/2:0;};
const average=(values:{value:number;weight:number}[])=>{const sum=values.reduce((n,v)=>n+v.weight,0);return sum?values.reduce((n,v)=>n+v.value*v.weight,0)/sum:0;};
export const isPerformanceSet=(set:LoggedSet)=>set.kind==='Work'||set.kind==='Failure';
const effort=(set:LoggedSet)=>set.kind==='Failure'?0:clamp(set.rir,0,6);
const valid=(set:LoggedSet)=>set.done&&isPerformanceSet(set)&&Number.isFinite(set.weight)&&set.weight>=0&&Number.isFinite(set.reps)&&set.reps>0&&set.reps<=50&&Number.isFinite(set.rir);
const quality=(set:LoggedSet)=>(effort(set)>=6?.2:effort(set)>=4?.55:1)*(set.reps>30?.2:set.reps>20?.5:1);
const capacity=(set:LoggedSet,slope=30)=>set.weight*(1+(set.reps+effort(set))/slope);
function samples(item:SessionExercise):Sample[]{
 let ordinal=0;
 return item.sets.flatMap(set=>isPerformanceSet(set)?[{set,ordinal:ordinal++}]:[]);
}
function exposures(history:Session[],id:string,now:number):Exposure[]{
 const unique=new Map<string,Session>();
 for(const session of history)if(!session.deload&&Number.isFinite(Date.parse(session.started))&&Date.parse(session.started)<=now)unique.set(session.id,session);
 return [...unique.values()].sort((a,b)=>Date.parse(a.started)-Date.parse(b.started)).flatMap(session=>{
  // Repeated occurrences of a movement in one workout must not count as independent sessions.
  const itemIndex=session.items.findIndex(item=>item.target.id===id&&samples(item).some(s=>valid(s.set)));
  if(itemIndex<0)return [];
  const item=session.items[itemIndex];
  return [{session,item,itemIndex,sets:samples(item).filter(s=>valid(s.set)),at:Date.parse(session.started)}];
 }).slice(-8);
}
export function loadMode(target:Target,exercise?:Exercise):Recommendation['mode']{
 if(exercise?.metric==='time')return 'time';
 if(target.loadMode&&target.loadMode!=='auto')return target.loadMode;
 if(/assisted|band\b/i.test(`${exercise?.name??''} ${exercise?.equipment??''}`))return 'manual';
 if(/body|pull-up|chin-up/i.test(`${exercise?.equipment??''} ${exercise?.name??''}`))return 'bodyweight';
 return 'weighted';
}
function learnSlope(past:Exposure[]):{slope:number;learned:boolean}{
 // Close-in-time first sets reduce the confounding from fatigue and long-term progress.
 const first=past.map(p=>({set:p.sets.find(s=>s.ordinal===0)?.set,at:p.at})).filter(p=>p.set&&p.set.weight>0&&quality(p.set)>=.5);
 const fits:number[]=[];
 for(let i=0;i<first.length;i++)for(let j=i+1;j<first.length;j++){
  const a=first[i].set!,b=first[j].set!;
  const x=a.reps+effort(a),y=b.reps+effort(b);
  if(first[j].at-first[i].at>14*DAY||Math.abs(x-y)<4||Math.abs(a.weight-b.weight)<Math.max(1,a.weight*.03))continue;
  const k=(b.weight*y-a.weight*x)/(a.weight-b.weight);
  if(k>=15&&k<=60)fits.push(k);
 }
 if(first.length<5||fits.length<4)return {slope:30,learned:false};
 const shrink=Math.min(.5,fits.length/(fits.length+10));
 return {slope:clamp(30+(median(fits)-30)*shrink,22,42),learned:true};
}
function fatigueCurve(past:Exposure[],slope:number,rest:number){
 return (ordinal:number)=>{
  if(!ordinal)return 1;
  const prior=Math.pow(rest<90?.965:.975,ordinal);
  const ratios=past.flatMap(p=>{
   const first=p.sets.find(s=>s.ordinal===0)?.set,later=p.sets.find(s=>s.ordinal===ordinal)?.set;
   if(!first||!later||first.weight<=0||later.weight<=0||quality(first)<.5||quality(later)<.5)return [];
   const ratio=capacity(later,slope)/capacity(first,slope);
   return ratio>=.6&&ratio<=1.08?[ratio]:[];
  });
  const shrink=ratios.length/(ratios.length+3);
  return clamp(prior*(1-shrink)+(ratios.length?median(ratios):prior)*shrink,.65,1);
 };
}
function sessionStrength(past:Exposure[],slope:number,fatigue:(i:number)=>number){
 return past.flatMap(p=>{
  const rows=p.sets.filter(s=>s.set.weight>0).map(s=>({value:capacity(s.set,slope)/fatigue(s.ordinal),weight:quality(s.set)/(1+s.ordinal*.12)}));
  if(!rows.length)return [];
  const middle=median(rows.map(r=>r.value));
  return [{value:average(rows.map(r=>({...r,value:clamp(r.value,middle*.8,middle*1.2)}))),weight:average(rows.map(r=>({value:r.weight,weight:1}))),at:p.at}];
 });
}
function trendFor(values:{value:number;at:number}[]):Pick<Recommendation,'trend'|'change'>{
 if(values.length<4)return {trend:'Learning',change:null};
 const recent=median(values.slice(-2).map(v=>v.value)),previous=median(values.slice(-4,-2).map(v=>v.value));
 const change=previous?recent/previous-1:0;
 const plateau=values.length>=6&&values.at(-1)!.at-values[0].at>=21*DAY&&Math.abs(change)<.015&&Math.max(...values.slice(-4).map(v=>v.value))/Math.min(...values.slice(-4).map(v=>v.value))<1.05;
 return {trend:change>=.025?'Improving':change<=-.045?'Declining':plateau?'Plateau':'Steady',change};
}
function recencyAverage(values:{value:number;weight?:number;at:number}[]){
 const middle=median(values.map(v=>v.value));
 const latest=values.at(-1)?.at??0;
 return average(values.map((v,i)=>({value:values.length>=3?clamp(v.value,middle*.8,middle*1.2):v.value,weight:(v.weight??1)*Math.pow(.7,values.length-i-1)*Math.pow(2,-(latest-v.at)/(42*DAY))})));
}
function overlapBefore(session:Session,itemIndex:number,exercise:Exercise,catalog:Exercise[]){
 const muscles=new Set(exercise.primary??[exercise.muscle]);
 return session.items.slice(0,itemIndex).reduce((n,item)=>{
  const other=catalog.find(e=>e.id===item.target.id);
  if(!other)return n;
  const overlap=(other.primary??[other.muscle]).some(m=>muscles.has(m))?1:(other.secondary??[]).some(m=>muscles.has(m))?.5:0;
  return n+overlap*item.sets.filter(s=>s.done&&s.kind!=='Warm-up'&&s.reps>0).reduce((total,s)=>total+(effort(s)>=4?.5:1),0);
 },0);
}
function weightCandidates(target:Target,strength:number,slope:number,rir:number,lo:number,hi:number,reference:number,maxIncrease:number){
 const step=Math.max(.25,target.increment),origin=target.minWeight??0;
 const limit=Math.min(target.maxWeight??3000,reference>0?reference+Math.max(step,reference*maxIncrease/100):3000);
 const min=Math.max(.25,origin),max=Math.max(0,limit);
 if(target.availableWeights?.length)return [...new Set(target.availableWeights)].filter(w=>w>=min&&w<=max).sort((a,b)=>a-b);
 const values=new Set<number>();
 function addAround(weight:number){
  const i=Math.floor((weight-origin)/step);
  for(let offset=-1;offset<=2;offset++){const w=round(origin+(i+offset)*step);if(w>=min&&w<=max)values.add(w);}
 }
 for(let reps=lo;reps<=hi;reps++)addAround(strength/(1+(reps+rir)/slope));
 addAround(reference);addAround(min);addAround(max);
 return [...values].sort((a,b)=>a-b);
}
export function predictSet({target,history,exercise,setIndex=0,settings,active,itemIndex=0,catalog=[],deload=active?.deload??false,now=Date.now()}:Context):Recommendation{
 const prefs=progressionSettings(settings),mode=loadMode(target,exercise),past=exposures(history,target.id,now);
 const activeItem=active?.items[itemIndex];
 const work=samples(activeItem??{target,sets:[],note:''});
 const before=work.filter(s=>s.ordinal<setIndex&&valid(s.set));
 const previous=past.at(-1)?.sets.find(s=>s.ordinal===setIndex)?.set??past.at(-1)?.sets[0]?.set;
 const last=before.at(-1)?.set??previous;
 const result:Recommendation={weight:last?.weight??0,reps:Math.round((target.min+target.max)/2),rir:target.rir,reason:'',details:[],blocked:false,expanded:false,confidence:'Learning',sessions:past.length,liveSets:before.length,trend:'Learning',change:null,fatiguePercent:0,personalizedCurve:false,mode};
 if(mode==='time'||mode==='manual'){
  const timed=history.filter(h=>Date.parse(h.started)<=now).slice().sort((a,b)=>Date.parse(a.started)-Date.parse(b.started)).flatMap(h=>h.items.filter(e=>e.target.id===target.id).map(e=>e.sets.filter(s=>s.done&&s.kind!=='Warm-up'))).filter(s=>s.length).at(-1);
  const prior=timed?.[setIndex]??timed?.[0];
  return {...result,weight:prior?.weight??0,reps:mode==='time'?0:prior?.reps??result.reps,seconds:mode==='time'?prior?.seconds??30:undefined,distance:mode==='time'?prior?.distance:undefined,reason:mode==='time'?'Repeat your previous duration, then adjust for the exercise and effort.':'Repeat your previous entry. Assistance, bands, and manual movements need your choice of resistance.',details:['Automatic strength estimates are disabled for this tracking mode.']};
 }
 if(mode==='bodyweight'){
  const anchor=last?.weight??0;
  const values=past.flatMap(p=>{const match=p.sets.find(s=>s.ordinal===setIndex&&s.set.weight===anchor)??p.sets.find(s=>s.ordinal===0&&s.set.weight===anchor);return match?[{value:Math.max(1,match.set.reps+effort(match.set)-(setIndex-match.ordinal)),at:p.at}]:[];});
  let repCapacity=recencyAverage(values);
  if(before.length){const s=before.at(-1)!;const live=Math.max(1,s.set.reps+effort(s.set)-(setIndex-s.ordinal));repCapacity=repCapacity?repCapacity*.3+live*.7:live;}
  const predicted=repCapacity?Math.round(repCapacity-target.rir):result.reps;
  const low=prefs.expandRepRange?Math.max(1,target.min-3):target.min,high=prefs.expandRepRange?Math.min(50,target.max+3):target.max;
  const reps=clamp(predicted,low,high),blocked=repCapacity>0&&(predicted<low||predicted>high);
  return {...result,weight:anchor,reps,expanded:reps<target.min||reps>target.max,blocked,confidence:values.length>=3?'Building':'Learning',reason:repCapacity?'Reps adjust to your logged RIR at the same added weight.':'First exposure: choose reps that leave the target RIR.',warning:blocked?'Your rep capacity falls outside this range. Adjust the rep range or choose a different added load or variation.':undefined,details:['Added weight stays unchanged. Body mass is not treated as zero or converted into a barbell strength estimate.','Later sets use your matching set history, then today’s completed sets.']};
 }
 const {slope,learned}=learnSlope(past),fatigue=fatigueCurve(past,slope,target.rest);
 const strengths=sessionStrength(past,slope,fatigue);
 let strength=recencyAverage(strengths);
 const historical=strength;
 const trend=trendFor(strengths.filter(s=>s.weight>.5));
 Object.assign(result,trend,{personalizedCurve:learned,fatiguePercent:Math.round((1-fatigue(setIndex))*100)});
 if(exercise&&active&&strength&&past.length>=3){
  const typical=median(past.map(p=>overlapBefore(p.session,p.itemIndex,exercise,catalog)));
  const today=overlapBefore(active,itemIndex,exercise,catalog);
  const adjustment=clamp(1-(today-typical)*.008,.92,1.04);
  strength*=adjustment;
  if(Math.abs(adjustment-1)>.015)result.details.push(`Exercise order: ${Math.round((adjustment-1)*100)}% estimate adjustment for overlapping work compared with your usual sessions.`);
 }
 const live=before.filter(s=>s.set.weight>0);
 if(live.length){
  const liveStrength=average(live.map(s=>({value:capacity(s.set,slope)/fatigue(s.ordinal),weight:quality(s.set)*(1+s.ordinal*.2)})));
  const bounded=strength?clamp(liveStrength,strength*.75,strength*1.2):liveStrength;
  const influence=historical?Math.min(.85,.55+live.length*.1):1;
  strength=strength*(1-influence)+bounded*influence;
  result.details.push(`${live.length} completed set${live.length===1?'':'s'} today ${liveStrength<historical?'lowered':'updated'} the estimate for the remaining sets.`);
  if(historical&&Math.abs(liveStrength/historical-1)>.25)result.details.push('Today differs greatly from history. The effect is bounded; check your entered load and reps.');
 }
 const recentDays=past.length?(now-past.at(-1)!.at)/DAY:0;
 const spread=strengths.length?median(strengths.map(s=>Math.abs(s.value/(median(strengths.map(v=>v.value))||1)-1))):1;
 result.confidence=strengths.length>=5&&spread<.07&&recentDays<28&&strengths.every(s=>s.weight>.5)?'Established':strengths.length>=3&&recentDays<56?'Building':'Learning';
 if(!strength)return {...result,weight:0,reason:'Choose your first working weight. Complete a set with actual reps and RIR to calibrate the remaining sets.',details:['No starting load is guessed from your experience level or another exercise.']};
 strength*=fatigue(setIndex)*(deload?.95:1);
 if(recentDays>=28)result.details.push(`Last exposure was ${Math.floor(recentDays)} days ago. Confidence is lower; today’s sets recalibrate the estimate.`);
 if(deload)result.details.push('Deload: fewer sets, higher RIR, and a 5% reserve in the capacity estimate.');
 result.details.push(`${strengths.length} recent non-deload sessions, with more influence on recent and lower-RIR working sets. Warm-ups, drop, myo, and partial sets are excluded.`);
 result.details.push(learned?'The load–rep relationship is partially personalized from varied rep ranges in your recent first sets.':'The load–rep relationship uses a baseline until enough varied rep ranges are logged.');
 if(setIndex>0)result.details.push(`Set ${setIndex+1}: about ${result.fatiguePercent}% lower capacity than a first working set, based on your set pattern.`);
 const reference=(last?.weight??0)>0?last!.weight:past.at(-1)?.sets.find(s=>s.set.weight>0)?.set.weight??0;
 function solve(low:number,high:number){
  return weightCandidates(target,strength,slope,target.rir,low,high,reference,prefs.maxIncreasePercent).map(weight=>{
   const predicted=slope*(strength/weight-1)-target.rir,reps=clamp(Math.round(predicted),low,high),error=Math.abs(predicted-reps);
   const score=error+Math.abs(reps-(target.min+target.max)/2)*.018+(prefs.weightMatch&&Math.abs(weight-reference)>.01?.22:0);
   return {weight,reps,error,score,predicted};
  }).sort((a,b)=>a.score-b.score||a.weight-b.weight);
 }
 let candidates=solve(target.min,target.max),best=candidates[0];
 if(prefs.expandRepRange&&(!best||best.error>.75)){
  const expanded=solve(Math.max(1,target.min-3),Math.min(50,target.max+3));
  if(expanded[0]&&(!best||expanded[0].error<best.error))best=expanded[0];
 }
 if(!best)return {...result,weight:reference,blocked:true,warning:'No available weight fits your equipment limits and progression cap. Check the minimum, maximum, and weight step.',reason:'A recommendation is unavailable with these equipment settings.'};
 result.weight=best.weight;result.reps=best.reps;
 result.expanded=best.reps<target.min||best.reps>target.max;
 result.blocked=best.error>.75;
 if(result.blocked)result.warning='Available weights cannot fit your rep range and target RIR. Edit the weight step or rep range, or enable rep-range expansion.';
 if(result.expanded)result.details.push(`Rep range expanded to ${best.reps} reps because the available load steps could not fit ${target.min}–${target.max} reps.`);
 result.reason=`${best.weight} lb × ${best.reps} at ${target.rir} RIR. ${best.weight>reference?'Increase the load to match your logged capacity.':best.weight<reference?'Use a lighter load to match your target effort.':'Keep the load and use the rep target.'}`;
 if(result.trend==='Plateau')result.details.push('Recent comparable performance is flat. Review your effort, rest, and technique before adding volume.');
 if(result.trend==='Declining')result.details.push('Recent comparable performance is lower. Check your logs and recovery; a lighter workout is an option.');
 return result;
}

export function cycleTarget(original:Target,cycle:number,settings:Settings,deload:boolean):Target{
 const custom=settings.periodize?original.cycles?.[cycle-1]:undefined;
 const target={...original,...custom};
 if(settings.periodize&&!custom&&cycle>=4&&cycle<=5)target.rir=Math.max(0,target.rir-1);
 if(deload){target.sets=Math.max(1,Math.ceil(target.sets/2));target.rir=Math.max(4,target.rir);}
 return target;
}
function prescription(r:Recommendation):Prescription{return {weight:r.weight,reps:r.reps,rir:r.rir,...r.seconds!==undefined?{seconds:r.seconds}:{},...r.distance!==undefined?{distance:r.distance}:{}};}
export function createSessionExercise(target:Target,history:Session[],exercise:Exercise|undefined,settings:Settings,active?:Session,catalog:Exercise[]=[],now=Date.now(),itemIndex=active?.items.length??0):SessionExercise{
 const item:SessionExercise={target:{...target},note:'',sets:[]};
 const previous=history.filter(h=>Date.parse(h.started)<=now&&!h.deload).slice().sort((a,b)=>Date.parse(a.started)-Date.parse(b.started)).flatMap(h=>h.items.filter(e=>e.target.id===target.id)).at(-1)?.sets.filter(s=>s.done&&isPerformanceSet(s));
 for(let i=0;i<target.sets;i++){
  const r=predictSet({target,history,exercise,settings,setIndex:i,active,itemIndex,catalog,now});
  const prior=previous?.[i]??previous?.[0];
  const usePrevious=progressionSettings(settings).initialFill==='previous'&&prior&&!active?.deload;
  // Constrained recommendations are never applied silently.
  const values=usePrevious?{weight:prior.weight,reps:prior.reps,seconds:prior.seconds,distance:prior.distance,rir:target.rir}:r.blocked?{weight:prior?.weight??0,reps:prior?.reps??Math.round((target.min+target.max)/2),rir:target.rir}:prescription(r);
  item.sets.push({...values,done:false,kind:'Work',manual:false,...!r.blocked?{prescription:prescription(r)}:{}});
 }
 return item;
}
export function recommendationsForItem(state:State,itemIndex:number,catalog:Exercise[],now=Date.now()):Recommendation[]{
 const active=state.active,item=active?.items[itemIndex];
 if(!active||!item)return [];
 let ordinal=0;
 return item.sets.map(set=>predictSet({target:{...item.target,rir:set.kind==='Failure'?0:item.target.rir},history:state.history,exercise:catalog.find(e=>e.id===item.target.id),setIndex:isPerformanceSet(set)?ordinal++:ordinal,settings:state.settings,active,itemIndex,catalog,now}));
}
export function applyRecommendation(set:LoggedSet,recommendation:Recommendation):boolean{
 if(set.done||!isPerformanceSet(set)||recommendation.blocked)return false;
 Object.assign(set,prescription(recommendation),{manual:false,prescription:prescription(recommendation)});
 return true;
}
/** Mutates only future unedited working sets. Legacy in-progress logs are protected. */
export function refreshSession(state:State,catalog:Exercise[],explicit=false,now=Date.now()):number{
 if(!state.active||(!explicit&&!progressionSettings(state.settings).applyInSession))return 0;
 let changed=0;
 state.active.items.forEach((item,ei)=>{
  const recommendations=recommendationsForItem(state,ei,catalog,now);
  item.sets.forEach((set,i)=>{
   if(set.done||set.kind!=='Work'||set.manual===true||(!explicit&&set.manual!==false))return;
   const prior=JSON.stringify(set);
   applyRecommendation(set,recommendations[i]);
   if(JSON.stringify(set)!==prior)changed++;
  });
 });
 return changed;
}
export function addWorkingSet(state:State,itemIndex:number,catalog:Exercise[]){
 const item=state.active?.items[itemIndex];if(!item||item.sets.length>=30)return;
 item.sets.push({weight:0,reps:Math.round((item.target.min+item.target.max)/2),rir:item.target.rir,done:false,kind:'Work',manual:false});
 const r=recommendationsForItem(state,itemIndex,catalog).at(-1)!;
 applyRecommendation(item.sets.at(-1)!,r);
}
export function makeLighter(state:State,catalog:Exercise[]){
 if(!state.active||state.active.deload)return;
 state.active.deload=true;
 for(const item of state.active.items){
  item.target.rir=Math.max(4,item.target.rir);
  const working=item.sets.filter(isPerformanceSet);
  let keep=Math.max(0,Math.ceil(working.length/2)-working.filter(s=>s.done||s.manual!==false).length);
  item.sets=item.sets.filter(set=>set.done||set.manual!==false||!isPerformanceSet(set)||keep-->0);
 }
 refreshSession(state,catalog,true);
}
export type TrainingReview={status:'Learning'|'On track'|'Review recovery';message:string;exercises:{id:string;trend:Recommendation['trend'];change:number|null;sessions:number}[]};
export function trainingReview(state:State,catalog:Exercise[],now=Date.now()):TrainingReview{
 const ids=[...new Set(state.program.flatMap(d=>d.items.map(t=>t.id)))];
 const results=ids.map(id=>{const target=state.program.flatMap(d=>d.items).find(t=>t.id===id)!;const r=predictSet({target,history:state.history,exercise:catalog.find(e=>e.id===id),settings:state.settings,now});return {id,trend:r.trend,change:r.change,sessions:r.sessions};});
 const known=results.filter(r=>r.sessions>=4),down=known.filter(r=>r.trend==='Declining'),flat=known.filter(r=>r.trend==='Plateau');
 if(down.length>=2&&down.length>=known.length/2)return {status:'Review recovery',message:'Several lifts are below their recent baseline. Review your effort, rest, and logs. Consider a lighter session if you feel run down.',exercises:results};
 return {status:known.length?'On track':'Learning',message:flat.length?`${flat.length} movement${flat.length===1?' has':'s have'} a flat recent trend. Keep technique and RIR consistent before changing your workload.`:known.length?'Recommendations follow your recorded capacity. A stable load can be the right target.':'Log repeat exposures to the same exercises to build useful trends.',exercises:results};
}
