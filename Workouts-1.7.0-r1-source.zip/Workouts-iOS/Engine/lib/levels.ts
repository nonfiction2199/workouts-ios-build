import { exercises, type Exercise, type Session } from './training';
export const upperMuscles=['Chest','Upper Back','Lats','Front Delts','Side Delts','Rear Delts','Traps','Lower Traps','Biceps','Triceps','Forearms','Abs','Obliques','Lower Back','Neck'];
export const lowerMuscles=['Quads','Hamstrings','Glutes','Adductors','Abductors','Calves','Tibialis'];
export const muscleGroups=[...upperMuscles,...lowerMuscles];
export type Contribution={id:string;name:string;sets:number;weighted:number;primary:string[];secondary:string[]};
export type MuscleLevel={sets:number;weekly:number;lifts:Contribution[]};
export const isResistance=(e:Exercise)=>!['cardio','stretching'].includes(e.category??'strength');
export function calculateLevels(history:Session[],custom:Exercise[]=[],days=7,indirect=true,now=Date.now()):Record<string,MuscleLevel>{
 const index=new Map([...exercises,...custom].map(e=>[e.id,e]));const out=Object.fromEntries(muscleGroups.map(m=>[m,{sets:0,weekly:0,lifts:[] as Contribution[]}]));
 const cutoff=now-days*86400000;
 for(const h of history){const time=Date.parse(h.ended??h.started);if(time<cutoff||time>now)continue;for(const item of h.items){const e=index.get(item.target.id);if(!e||!isResistance(e))continue;const n=item.sets.filter(s=>s.done&&s.kind!=='Warm-up'&&(s.reps>0||(s.seconds??0)>0)).length;if(!n)continue;const primary=e.primary??[e.muscle];const secondary=(e.secondary??[]).filter(m=>!primary.includes(m));for(const [m,w]of [...primary.map(m=>[m,1] as const),...(indirect?secondary.map(m=>[m,.5] as const):[])]){if(!out[m])out[m]={sets:0,weekly:0,lifts:[]};out[m].sets+=n*w;const prev=out[m].lifts.find(x=>x.id===e.id);if(prev){prev.sets+=n;prev.weighted+=n*w;}else out[m].lifts.push({id:e.id,name:e.name,sets:n,weighted:n*w,primary,secondary});}}}
 for(const v of Object.values(out)){v.weekly=v.sets*7/days;v.lifts.sort((a,b)=>b.weighted-a.weighted);}return out;
}
export const heatColors=['#e5e7eb','#cbdaf5','#9ebcf0','#76a0e7','#4b83db','#2563c8'];
export function heatColor(sets:number){return heatColors[sets<=0?0:sets<5?1:sets<10?2:sets<15?3:sets<20?4:5];}
export const formatSets=(n:number)=>Number(n.toFixed(1)).toString();
export function searchExercises(list:Exercise[],query:string,muscle='All muscles',equipment='All equipment',category='All types'){
 const expanded=query.toLowerCase().replace(/\bdb\b/g,'dumbbell').replace(/\bbb\b/g,'barbell').replace(/\brdl\b/g,'romanian deadlift').replace(/\bsldl\b/g,'stiff legged deadlift').replace(/\btbar\b/g,'t bar');
 const normal=(s:string)=>s.toLowerCase().replace(/[^a-z0-9 ]/g,' ').replace(/\s+/g,' ');
 const tokens=normal(expanded).split(' ').filter(Boolean);
 return list.filter(e=>(muscle==='All muscles'||(e.primary??[e.muscle]).includes(muscle)||(e.secondary??[]).includes(muscle))&&(equipment==='All equipment'||e.equipment===equipment)&&(category==='All types'||e.category===category)&&tokens.every(t=>normal([e.name,e.muscle,e.equipment,...e.aliases??[]].join(' ')).includes(t))).sort((a,b)=>a.name.localeCompare(b.name));
}
