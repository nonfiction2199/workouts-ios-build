// Original technique notes for the built-in starter exercises.
export const technique:Record<string,string[]> = {
  "bench": [
    "Set the rack so you can unrack with nearly straight arms. Lie with your eyes under the bar, feet planted, and shoulder blades drawn back against the bench. Use a closed grip slightly wider than shoulder width.",
    "Brace your torso, unrack, and position the bar over your shoulders. Lower it under control toward the lower chest, keeping your wrists above your forearms and your elbows at a comfortable angle.",
    "Touch lightly without bouncing, then press upward and slightly back toward the starting position. Keep your hips on the bench and maintain control when reracking. Use safety arms or a spotter."
  ],
  "squat": [
    "Set the bar in a rack just below shoulder height. Position it securely across your upper back, grip evenly, brace your torso, then stand up and take a short step back.",
    "Choose a stable stance with toes slightly turned out. Bend your hips and knees together, keeping pressure through your whole foot and allowing your knees to follow the direction of your toes.",
    "Descend as far as you can maintain balance and a controlled trunk position. Drive through your feet to stand, keeping your chest and hips rising together. Rebrace before the next repetition and use rack safeties."
  ],
  "rdl": [
    "Stand with the bar in front of your thighs, feet about hip width apart and knees slightly bent. Brace your torso and keep the bar close to your legs.",
    "Push your hips backward while maintaining a small bend in the knees. Lower the bar along your thighs and shins until you feel a hamstring stretch, stopping before your back position changes. The bar does not need to reach the floor.",
    "Drive your hips forward to return to standing, keeping the bar close. Finish upright without leaning backward or shrugging, then reset your brace for the next repetition."
  ],
  "pulldown": [
    "Adjust the thigh pad so it holds your legs securely. Take a comfortable overhand grip on the bar, sit tall, and begin with your arms extended overhead.",
    "Keep a small, consistent backward lean and draw your elbows down toward your sides. Bring the bar toward the upper chest without swinging your torso or pulling behind your neck.",
    "Let the bar rise under control until your arms are extended again. Keep the weight stack from slamming and use a repeatable range of motion."
  ],
  "row": [
    "Adjust the cable and foot supports, take the handle, and sit with a slight bend in your knees. Keep your torso stable and begin with your arms reaching forward.",
    "Pull the handle toward your lower ribs, allowing your shoulder blades to move together while your elbows travel back. Avoid throwing your torso backward to move the weight.",
    "Return the handle slowly, allowing your arms and shoulder blades to reach forward while maintaining control of your torso. Repeat without bouncing the weight stack."
  ],
  "incline": [
    "Set the bench to a modest incline and bring the dumbbells into position over your upper chest. Plant your feet and keep your shoulder blades supported against the bench.",
    "Lower the dumbbells under control to either side of your chest, with wrists stacked over forearms and elbows at a comfortable angle.",
    "Press upward until your arms are nearly straight, keeping the movement smooth. Avoid clashing the dumbbells together, and lower them safely when finished."
  ]
};
