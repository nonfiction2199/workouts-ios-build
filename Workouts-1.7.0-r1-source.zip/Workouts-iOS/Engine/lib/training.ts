import {newId} from './id';
import {technique} from './technique';
import catalog from "./data/exercises.json";
import { supplemental } from "./supplemental";
import {createSessionExercise,cycleTarget,predictSet,type ProgressionSettings} from './progression';
export type Exercise = {id:string;name:string;muscle:string;equipment:string;cue:string;increment:number; primary?:string[];secondary?:string[];instructions?:string[];aliases?:string[];category?:string;level?:string;source?:string;metric?:string};
const legacyExercises:Exercise[] = [
['bench','Barbell bench press','Chest','Full gym','Keep feet planted and lower the bar under control.',5],
['incline','Incline dumbbell press','Chest','Dumbbells','Keep your shoulder blades stable; use a comfortable incline.',5],
['fly','Cable chest fly','Chest','Full gym','Bring your arms together without bouncing out of the stretch.',5],
['pushup','Push-up','Chest','Bodyweight','Maintain a straight torso. Log 0 for no added weight.',5],
['ohp','Dumbbell shoulder press','Shoulders','Dumbbells','Brace your torso and press through a comfortable range.',5],
['lateral','Dumbbell lateral raise','Shoulders','Dumbbells','Raise with control; avoid swinging your torso.',2.5],
['triceps','Cable triceps pushdown','Triceps','Full gym','Keep upper arms still as you extend your elbows.',5],
['extension','Dumbbell overhead extension','Triceps','Dumbbells','Keep your ribs down and elbows comfortable.',2.5],
['pulldown','Lat pulldown','Back','Full gym','Pull elbows down; avoid using a large backward swing.',5],
['row','Seated cable row','Back','Full gym','Keep your torso stable and control the return.',5],
['dbrow','One-arm dumbbell row','Back','Dumbbells','Log weight per dumbbell and reps per side consistently.',5],
['pullup','Pull-up','Back','Full gym','Use a controlled full range. Log added weight only.',2.5],
['reverse','Dumbbell reverse fly','Shoulders','Dumbbells','Use a light load and move through the shoulders.',2.5],
['curl','Dumbbell curl','Biceps','Dumbbells','Keep elbows still; log weight per dumbbell.',2.5],
['preacher','Preacher curl','Biceps','Full gym','Lower slowly and avoid bouncing at the bottom.',5],
['hammer','Hammer curl','Biceps','Dumbbells','Keep palms facing inward without swinging.',2.5],
['squat','Barbell back squat','Quads','Full gym','Brace before each rep and use a consistent comfortable depth.',5],
['legpress','Leg press','Quads','Full gym','Keep your pelvis supported and use repeatable depth.',10],
['goblet','Goblet squat','Quads','Dumbbells','Hold the dumbbell close and keep your feet planted.',5],
['split','Dumbbell split squat','Quads','Dumbbells','Use a stable stance; log load per dumbbell and reps per side.',5],
['rdl','Barbell Romanian deadlift','Hamstrings','Full gym','Hinge at the hips with soft knees; keep the bar close.',5],
['dbrdl','Dumbbell Romanian deadlift','Hamstrings','Dumbbells','Push hips back; stop before your back position changes.',5],
['legcurl','Seated leg curl','Hamstrings','Full gym','Keep hips supported and control the return.',5],
['legext','Leg extension','Quads','Full gym','Align the machine with your knees and avoid kicking.',5],
['hip','Dumbbell hip thrust','Glutes','Dumbbells','Finish through the hips without arching your lower back.',5],
['calf','Standing dumbbell calf raise','Calves','Dumbbells','Pause at the bottom and top without bouncing.',5],
['crunch','Cable crunch','Abs','Full gym','Flex through your trunk rather than pulling with your arms.',5],
['reversecrunch','Reverse crunch','Abs','Bodyweight','Curl your pelvis upward with control. Log 0 for bodyweight.',2.5],
['bwsquat','Bodyweight squat','Quads','Bodyweight','Keep depth and tempo consistent. Log added weight only.',5],
['bridge','Single-leg glute bridge','Glutes','Bodyweight','Keep your pelvis level; log reps per side.',5],
['pike','Pike push-up','Shoulders','Bodyweight','Keep hips high and lower your head with control.',5],
['prone','Prone reverse snow angel','Back','Bodyweight','Lift arms gently from the floor; this is light back work.',2.5],
['bwcalf','Single-leg calf raise','Calves','Bodyweight','Use support for balance; log reps per side.',2.5],
['walkout','Hamstring walkout','Hamstrings','Bodyweight','From a bridge, walk heels out and back without dropping hips.',2.5],
].map(([id,name,muscle,equipment,cue,increment])=>({id,name,muscle,equipment,cue,increment} as Exercise));
const legacyMap:Record<string,string[]>={bench:['Chest','Triceps','Front Delts'],incline:['Chest','Triceps','Front Delts'],ohp:['Front Delts','Triceps','Side Delts'],row:['Upper Back','Lats','Biceps'],dbrow:['Lats','Upper Back','Biceps'],pulldown:['Lats','Biceps','Upper Back'],squat:['Quads','Glutes','Adductors'],rdl:['Hamstrings','Glutes','Lower Back'],dbrdl:['Hamstrings','Glutes','Lower Back'],legpress:['Quads','Glutes'],reverse:['Rear Delts','Upper Back'],lateral:['Side Delts'],pullup:['Lats','Biceps'],split:['Quads','Glutes']};
const base=legacyExercises.map(e=>{const m=legacyMap[e.id]??[e.muscle==='Shoulders'?'Front Delts':e.muscle==='Back'?'Upper Back':e.muscle];return {...e,primary:[m[0]],secondary:m.slice(1),muscle:m[0],category:'strength',metric:'reps',instructions:technique[e.id]??[e.cue],aliases:[],source:'Personal exercise library',equipment:e.equipment==='Full gym'?(/Cable|cable|pulldown/.test(e.name)?'Cable':/Barbell/.test(e.name)?'Barbell':'Machine'):e.equipment};});
export const exercises:Exercise[]=[...base,...catalog.filter(e=>!base.some(b=>b.name.toLowerCase()===e.name.toLowerCase())),...supplemental.filter(e=>!catalog.some(b=>b.name.toLowerCase()===e.name.toLowerCase()))];
export type CycleTarget={sets:number;min:number;max:number;rir:number};
export type Target=CycleTarget&{id:string;rest:number;increment:number;group:string;minWeight?:number;maxWeight?:number;availableWeights?:number[];loadMode?:'auto'|'weighted'|'bodyweight'|'manual';cycles?:CycleTarget[]};
export type Day={name:string;items:Target[]};
export type Settings={goal:string;days:number;minutes:number;experience:string;equipment:string;deload:boolean;periodize:boolean;deloadTiming?:'first'|'last';progression?:Partial<ProgressionSettings>};
export type Prescription={weight:number;reps:number;rir:number;seconds?:number;distance?:number};
export type LoggedSet={weight:number;reps:number;rir:number;done:boolean;kind:string;seconds?:number;distance?:number;manual?:boolean;prescription?:Prescription};
export type SessionExercise={target:Target;sets:LoggedSet[];note:string};
export type Session={id:string;name:string;started:string;ended?:string;day:number;cycle:number;deload:boolean;items:SessionExercise[];free?:boolean;pausedAt?:string;pausedMs?:number};
export type State={settings:Settings;program:Day[];history:Session[];active:Session|null;next:number;custom:Exercise[]};
export const defaults:Settings={goal:'Muscle growth',days:3,minutes:60,experience:'Intermediate',equipment:'Full gym',deload:true,periodize:true};
export const initial:State={settings:defaults,program:[],history:[],active:null,next:0,custom:[]};
export function generate(s:Settings):Day[]{
 const gym=s.equipment==='Full gym',bw=s.equipment==='Bodyweight';
 const push=bw?['pushup','pike','pushup']:gym?['bench','incline','ohp','lateral','triceps']:['incline','ohp','lateral','extension'];
 const pull=bw?['prone','reversecrunch']:gym?['pulldown','row','reverse','preacher','hammer']:['dbrow','reverse','curl','hammer'];
 const legs=bw?['bwsquat','walkout','bridge','bwcalf','reversecrunch']:gym?['squat','rdl','legcurl','legext','calf']:['goblet','dbrdl','split','hip','calf'];
 const upper=[push[0],pull[0],push[1],pull[1],...(bw?[]:['lateral',gym?'triceps':'extension','curl'])];
 const full=[legs[0],push[0],pull[0],legs[1],bw?'reversecrunch':'lateral',bw?'bwcalf':'curl'];
 const plans=s.days<=3?Array.from({length:s.days},(_,i)=>({name:`Full body ${'ABC'[i]}`,ids:i%2?[...full.slice(1,3),full[0],...full.slice(3)]:full})):s.days===4?[{name:'Upper A',ids:upper},{name:'Lower A',ids:legs},{name:'Upper B',ids:[...upper]},{name:'Lower B',ids:[...legs]}]:Array.from({length:s.days},(_,i)=>({name:['Push','Pull','Legs'][i%3]+` ${i<3?'A':'B'}`,ids:[push,pull,legs][i%3]}));
 return plans.map(p=>({name:p.name,items:[...new Set(p.ids)].slice(0,s.minutes<=30?3:s.minutes<=45?4:6).map((id,i)=>({id,sets:s.experience==='Beginner'?2:3,min:s.goal==='Strength'&&i<2?4:8,max:s.goal==='Strength'&&i<2?6:12,rir:2,rest:i<2?150:90,increment:exercises.find(x=>x.id===id)?.increment??5,group:''}))}));
}
export function e1rm(s:LoggedSet){return s.weight>0?s.weight*(1+(s.reps+s.rir)/30):0;}
// Kept for callers that only need a single history-based suggestion.
export function recommend(t:Target,history:Session[],setIndex=0,deload=false){
 return predictSet({target:t,history,setIndex,deload,exercise:exercises.find(e=>e.id===t.id)});
}
export function begin(state:State,day:number,lighter=false,now=Date.now()):Session{
 const cycle=Math.floor(state.next/Math.max(1,state.program.length))%6+1;
 const deload=lighter||(state.settings.deload&&cycle===(state.settings.deloadTiming==='first'?1:6));
 const session:Session={id:newId(),name:state.program[day].name,started:new Date(now).toISOString(),day,cycle,deload,items:[]};
 const catalog=[...exercises,...state.custom];
 for(const original of state.program[day].items){
  const target=cycleTarget(original,cycle,state.settings,deload);
  session.items.push(createSessionExercise(target,state.history,catalog.find(e=>e.id===target.id),state.settings,session,catalog,now));
 }
 return session;
}
