# Workouts 1.3.0

- Restaurant context and optional menu links trigger a separate free web lookup before photo inference. Source menus help identify preparation; restaurant, dish and serving confirmation remain explicit.
- Complete published nutrition from structured menus or labelled HTML tables can be chosen in photo review. Source links and reference servings persist in diary history and backups; unknown source weights use confirmed serving counts.
- Unambiguous exact database names match automatically at the estimated photo weight. Similar names remain suggestions.
- Keep database identity while editing portion macros or using AI nutrient estimates. Known-weight nutrition scales with portions; adjusted values are entry snapshots and never rewrite catalogue records.
- Local revision 4 preserves the working instruct vision model, token and connection. Restaurant lookup failures fall back to photo logging without breaking scans.
- All themes use shared Palette components. Existing workout behavior and nutrition backups remain compatible.
