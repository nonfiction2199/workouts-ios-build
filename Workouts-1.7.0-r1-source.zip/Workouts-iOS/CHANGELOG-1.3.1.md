# Workouts 1.3.1

Restaurant meal descriptions can trigger lookup without requiring “from” or “at”. The service separates Dave’s Hot Chicken from roulette and bread exclusions, prioritizes nutrition documents, follows multiple safe links and reads explicit text PDF nutrition tables. A URL-only discovery entry points to Dave's official US nutrition page, fetching current values rather than embedding them.

Published restaurant servings remain reviewable references. Unverified bread/sauce exclusions and missing exact roulette profiles are disclosed. Chicken-only searches prioritize component profiles over full combos. Fat-calorie columns cannot be mistaken for grams of fat. Photo weights and hidden ingredients still require review; no exact calorie or portion claim is made from a review screenshot.

The local update preserves the working model, token, endpoint and background launch path. It bundles a portable PDF reader with its license and needs Node 22.13+. Protocol 2 and existing food data remain compatible. All custom themes use the existing palette and review screens.
