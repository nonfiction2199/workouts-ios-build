# Workouts 1.6.0: automatic depth portions, simple food logging

Open AI Food Logging and take or upload a photo. It analyzes automatically, shows foods and totals, and offers Log Meal. Add details is optional. Tap a food to edit it; More options contains saved meals, fractions and nutrition sources. There are no manual food outlines, plate taps, density forms or diagnostic percentages in logging.

On a supported rear-LiDAR iPhone, Camera captures RGB and up to five nearby synchronized metric depth frames. Keep the full meal visible and hold the phone steady, preferably above a flat plate. This is the same photo capture, with no extra scan mode. Uploaded JPEGs and unsupported iPhones use ordinary photo estimates.

## Background pipeline

* Each depth sample is filtered using ARKit high confidence. Camera poses reproject nearby frames into the captured camera coordinates; a per-frame z-buffer and temporal median/MAD reject inconsistent depths.
* Vision foreground segmentation limits the supporting-surface search. A deterministic RANSAC fit finds a stable, near-horizontal support plane. Low coverage, ambiguous lower surfaces, missing surrounding support and unresolved thin portions leave the photo estimate unchanged.
* Depth-height connected components isolate exposed food regions. Projected surface triangles estimate volume above the support plane, without filling depth holes or claiming to reconstruct hidden undersides.
* Optional approximate first-photo boxes from the existing food AI associate names with regions. Boxes are not physical measurements. Ambiguous associations, shared regions and absent boxes in multi-food meals do not change portions. Single-food/single-region captures can work with the older service too.
* Compatible USDA volume portions provide estimated bulk density. Conflicting references and unsupported volume units do not change portions. Measured user weights override depth, and count-only source nutrition remains count-based. The app never assumes volume equals weight.
* Weight and nutrition scale together from the selected profile. Original photo estimates, scan volume, density source and quality checks remain optional provenance in the saved entry/backup. Raw depth is only in the current draft and never sent to the service.

## Accuracy and validation

Experimental. Geometry tests and simulator flows do not establish real LiDAR accuracy or superiority over photo estimates. The accepted-cell fraction is not a calorie accuracy percentage and is not displayed in the logging flow. Depth cannot observe absorbed oil, ingredients, internal air gaps or a bowl's hidden bottom. Household portions provide a packing/preparation assumption, not a measured density. Unsupported cases retain the photo estimate automatically.

Before claiming an accuracy improvement, evaluate at least 20 independently weighed portions across foods and distances. Compare paired ordinary-photo and depth estimated weights; report median, mean, worst error and rejection rate, including failed scans. Choose the food profile and density before revealing the scale weight.

Use the paired Revision 9 laptop update for optional semantic image regions. The existing free qwen3-vl:8b-instruct model, token, Tailscale URL and workflow 4 stay compatible. No paid API, extra model or subscription is required.

Primary references:
* https://developer.apple.com/documentation/arkit/ardepthdata
* https://developer.apple.com/documentation/arkit/arcamera/transform
* https://developer.apple.com/documentation/vision/vninstancemaskobservation
* https://pmc.ncbi.nlm.nih.gov/articles/PMC7142738/ — results for an independent system, not this app.
* https://www.nist.gov/pml/owm/metric-household
