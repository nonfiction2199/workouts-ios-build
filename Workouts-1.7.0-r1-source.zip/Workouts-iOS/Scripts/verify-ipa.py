import pathlib, plistlib, re, sys, zipfile
path = pathlib.Path(sys.argv[1])
with zipfile.ZipFile(path) as archive:
    assert archive.testzip() is None, 'Damaged archive'
    prefix = 'Payload/Workouts.app/'
    info = plistlib.loads(archive.read(prefix + 'Info.plist'))
    assert info['CFBundleIdentifier'] == 'app.sudais.workouts', 'Bundle identifier changed; updates could create a second app'
    assert info['CFBundleExecutable'] == 'Workouts'
    assert info['CFBundleSupportedPlatforms'] == ['iPhoneOS'], 'Not a device build'
    assert re.fullmatch(r'[0-9]{1,4}\.[0-9]{1,2}\.[0-9]{1,2}', str(info['CFBundleVersion']))
    assert len([n for n in archive.namelist() if re.search(r'/food-catalog-[0-9]+\.json$', n)]) == 38, 'Offline catalogue pages missing'
    for name in ['branded-foods.sqlite','branded-food-provenance.json','food-data-licenses.txt','Workouts', 'engine.js', 'body-map.json', 'Unbounded.ttf', 'WorkoutsDisplay.ttf']:
        assert len(archive.read(prefix + name)) > 0, f'Missing {name}'
print(f'Checked IPA contents: {path.name}')
