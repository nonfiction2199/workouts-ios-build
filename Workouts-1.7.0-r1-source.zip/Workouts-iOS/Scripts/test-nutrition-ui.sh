#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
DEVICE="$(xcrun simctl list devices available -j | python3 -c 'import json,sys; d=json.load(sys.stdin); phones=[x for v in d["devices"].values() for x in v if "iPhone" in x["name"]]; print(next((x["udid"] for x in phones if "Pro Max" in x["name"]),phones[0]["udid"]))')"
TEST_SELECTION=(-only-testing:WorkoutsUITests/NutritionFlowTests -only-testing:WorkoutsUITests/ExerciseFlowTests -only-testing:WorkoutsUITests/FoodDepthFlowTests)
if [[ "${WORKOUTS_UI_TEST_SELECTION:-all}" == "update-recheck" ]]; then
  TEST_SELECTION=(-only-testing:WorkoutsUITests/FoodDepthFlowTests -only-testing:WorkoutsUITests/LevelsThemeFlowTests -only-testing:WorkoutsUITests/NutritionFlowTests/testPhotoDatabaseMatchReplacesAIMacros -only-testing:WorkoutsUITests/NutritionFlowTests/testRestaurantPortionAndAdjustedMatchPersist)
elif [[ "${WORKOUTS_UI_TEST_SELECTION:-all}" == "photo-library-recheck" ]]; then
  TEST_SELECTION=(-only-testing:WorkoutsUITests/NutritionFlowTests/testPhotoDatabaseMatchReplacesAIMacros)
elif [[ "${WORKOUTS_UI_TEST_SELECTION:-all}" == "depth-recheck" ]]; then
  TEST_SELECTION=(-only-testing:WorkoutsUITests/FoodDepthFlowTests)
elif [[ "${WORKOUTS_UI_TEST_SELECTION:-all}" == "logging-recheck" ]]; then
  TEST_SELECTION=(-only-testing:WorkoutsUITests/FoodDepthFlowTests -only-testing:WorkoutsUITests/NutritionFlowTests/testAddMissingFoodToScanPlate -only-testing:WorkoutsUITests/NutritionFlowTests/testPlateFractionsAndSavedMealSurviveRestart)
elif [[ "${WORKOUTS_UI_TEST_SELECTION:-all}" == "restaurant-recheck" ]]; then
  TEST_SELECTION=(-only-testing:WorkoutsUITests/NutritionFlowTests/testRestaurantPortionAndAdjustedMatchPersist -only-testing:WorkoutsUITests/NutritionFlowTests/testRestaurantServingWithoutWeightUsesServingCount)
fi
xcodebuild test -project Workouts.xcodeproj -scheme Workouts -configuration Debug \
  -destination "platform=iOS Simulator,id=$DEVICE" -derivedDataPath build/UITests \
  "${TEST_SELECTION[@]}" CODE_SIGNING_ALLOWED=NO \
  2>&1 | tee build/nutrition-ui.log
xcrun simctl shutdown "$DEVICE" || true
