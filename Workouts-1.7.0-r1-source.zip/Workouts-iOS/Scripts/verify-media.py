"""Validate bundled demonstration provenance, names and playback containers."""
import json, pathlib, subprocess
r=pathlib.Path(__file__).resolve().parents[1]/'Workouts'/'Resources'
clips=json.loads((r/'demo-library.json').read_text()); matches=json.loads((r/'demo-matches.json').read_text())
assert len({c['key'] for c in clips})==len(clips)
assert set(matches.values()) <= {c['key'] for c in clips}
for c in clips:
    assert c['author'] and c['source'].startswith('https://wger.de/media/exercise-video/')
    assert c['license']=='CC BY-SA 4.0' and c['changes']
    assert (r/c['poster']).stat().st_size>0
    info=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-of','json',str(r/c['file'])]))
    assert len(info['streams'])==1 and info['streams'][0]['codec_name']=='h264'
    assert float(info['streams'][0]['duration'])>1
    subprocess.run(['ffmpeg','-v','error','-i',str(r/c['file']),'-f','null','-'],check=True)
print(f'{len(clips)} silent H.264 clips validated; {len(matches)} exact name mappings.')
