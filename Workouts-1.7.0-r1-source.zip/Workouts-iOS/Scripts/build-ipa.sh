#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "This build requires macOS and Xcode. Use the included Codemagic or GitHub Actions workflow." >&2
  exit 1
fi
command -v xcodegen >/dev/null || { echo "Install XcodeGen first: brew install xcodegen" >&2; exit 1; }
VERSION="$(cat VERSION)"
# Numeric timestamp stays monotonic across different CI providers and reruns.
BUILD_NUMBER="${WORKOUTS_BUILD_NUMBER:-$(python3 - <<'PYBUILD'
from datetime import datetime, timezone
now = datetime.now(timezone.utc)
print(f'{(now.date() - datetime(2020,1,1).date()).days}.{now.hour}.{now.minute}')
PYBUILD
)}"
[[ "$VERSION" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]] || { echo "Invalid VERSION" >&2; exit 1; }
[[ "$BUILD_NUMBER" =~ ^[0-9]{1,4}\.[0-9]{1,2}\.[0-9]{1,2}$ ]] || { echo "Invalid build number" >&2; exit 1; }
test -f Workouts/Resources/branded-foods.sqlite || { echo "Run python3 Scripts/build-branded-catalog.py before building." >&2; exit 1; }
mkdir -p build
xcodegen generate
xcodebuild -project Workouts.xcodeproj -scheme Workouts -configuration Release \
  -sdk iphoneos -destination 'generic/platform=iOS' -derivedDataPath build/DerivedData \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY="" \
  MARKETING_VERSION="$VERSION" CURRENT_PROJECT_VERSION="$BUILD_NUMBER" \
  build 2>&1 | tee build/xcodebuild.log
APP="build/DerivedData/Build/Products/Release-iphoneos/Workouts.app"
test -f "$APP/Workouts"
test -f "$APP/engine.js"
# This is a device ARM64 executable, never a simulator .app renamed to an IPA.
xcrun lipo "$APP/Workouts" -verify_arch arm64
STAGING="$(mktemp -d "$PWD/build/package.XXXXXX")"
trap 'rm -rf "$STAGING"' EXIT
mkdir -p "$STAGING/Payload"
ditto "$APP" "$STAGING/Payload/Workouts.app"
IPA="$PWD/build/Workouts-$VERSION-$BUILD_NUMBER.ipa"
(cd "$STAGING" && /usr/bin/zip -qry "$IPA" Payload)
python3 Scripts/verify-ipa.py "$IPA"
shasum -a 256 "$IPA" > "$IPA.sha256"
echo "Unsigned device IPA ready for Signulous: $IPA"
