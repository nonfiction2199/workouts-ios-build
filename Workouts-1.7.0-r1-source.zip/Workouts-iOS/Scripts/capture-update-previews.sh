#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
DEVICE="$(xcrun simctl list devices available -j | python3 -c 'import json,sys; d=json.load(sys.stdin); p=[x for v in d["devices"].values() for x in v if "iPhone" in x["name"]]; print(next((x["udid"] for x in p if "Pro Max" in x["name"]),p[0]["udid"]))')"
xcrun simctl boot "$DEVICE" || true
trap 'xcrun simctl shutdown "$DEVICE" || true' EXIT
xcrun simctl bootstatus "$DEVICE" -b
APP="build/UITests/Build/Products/Debug-iphonesimulator/Workouts.app"
xcrun simctl install "$DEVICE" "$APP"
xcrun simctl status_bar "$DEVICE" override --time '9:41' --batteryState charged --batteryLevel 100
mkdir -p build/update-previews
for THEME in system light dark monochrome goldBlack midnight forest porcelain; do
  for SCREEN in levels food-portions theme-picker; do
    SIMCTL_CHILD_WORKOUTS_PREVIEW_THEME="$THEME" SIMCTL_CHILD_WORKOUTS_PREVIEW_SCREEN="$SCREEN" \
      SIMCTL_CHILD_WORKOUTS_NUTRITION_TEST="update-preview-$THEME-$SCREEN" \
      xcrun simctl launch --terminate-running-process "$DEVICE" app.sudais.workouts
    sleep 3
    xcrun simctl io "$DEVICE" screenshot "build/update-previews/$THEME-$SCREEN.png"
    sips -s format jpeg -s formatOptions 82 "build/update-previews/$THEME-$SCREEN.png" --out "build/update-previews/$THEME-$SCREEN.jpg" >/dev/null
    rm "build/update-previews/$THEME-$SCREEN.png"
  done
done
for SCREEN in levels-back levels-loaded food-photo; do
  SIMCTL_CHILD_WORKOUTS_PREVIEW_THEME=dark SIMCTL_CHILD_WORKOUTS_PREVIEW_SCREEN="$SCREEN" \
    SIMCTL_CHILD_WORKOUTS_NUTRITION_TEST="update-preview-$SCREEN" \
    xcrun simctl launch --terminate-running-process "$DEVICE" app.sudais.workouts
  sleep 3
  xcrun simctl io "$DEVICE" screenshot "build/update-previews/dark-$SCREEN.png"
  sips -s format jpeg -s formatOptions 82 "build/update-previews/dark-$SCREEN.png" --out "build/update-previews/dark-$SCREEN.jpg" >/dev/null
  rm "build/update-previews/dark-$SCREEN.png"
done
