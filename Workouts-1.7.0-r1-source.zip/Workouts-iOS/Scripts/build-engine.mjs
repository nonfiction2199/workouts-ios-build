import {build} from 'esbuild';
await build({entryPoints:['Engine/bridge.ts'],outfile:'Workouts/Resources/engine.js',bundle:true,format:'iife',globalName:'TrainingEngine',platform:'browser',target:'es2020',minify:true,legalComments:'eof'});
