"""Build Workouts Display from OFL Unbounded; not MacroSans font software.
Requires fonttools. Source copyright/license is retained in the output.
"""
from pathlib import Path
from fontTools.ttLib import TTFont
from fontTools.varLib.instancer import instantiateVariableFont
from fontTools.pens.ttGlyphPen import TTGlyphPen
from fontTools.pens.transformPen import TransformPen
from fontTools.pens.recordingPen import DecomposingRecordingPen
root = Path(__file__).resolve().parents[1] / 'Workouts' / 'Resources'
font = instantiateVariableFont(TTFont(root / 'Unbounded.ttf'), {'wght': 680}, inplace=False)
glyphs = font.getGlyphSet()
# A slightly narrower, heavy geometric display cut, with original proportions
# in the vertical axis. Transform metrics as well as outlines for correct layout.
width = 0.99
new_glyphs = {}
for name in font.getGlyphOrder():
    pen = TTGlyphPen(glyphs)
    recording = DecomposingRecordingPen(glyphs)
    glyphs[name].draw(recording)
    recording.replay(TransformPen(pen, (width, 0, 0, 0.90, 0, 0)))
    new_glyphs[name] = pen.glyph()
for name, glyph in new_glyphs.items():
    font['glyf'][name] = glyph
    advance, bearing = font['hmtx'].metrics[name]
    font['hmtx'].metrics[name] = (round(advance * width), round(bearing * width))
for n in font['name'].names[:]:
    if n.nameID in [1, 2, 3, 4, 6, 16, 17]: font['name'].names.remove(n)
for n, value in {1:'Workouts Display',2:'Regular',3:'Workouts Display 1.0',4:'Workouts Display',6:'WorkoutsDisplay-Regular',16:'Workouts Display',17:'Regular'}.items():
    font['name'].setName(value,n,3,1,0x409)
font['OS/2'].usWeightClass = 680
font.save(root / 'WorkoutsDisplay.ttf')
print(root / 'WorkoutsDisplay.ttf')
