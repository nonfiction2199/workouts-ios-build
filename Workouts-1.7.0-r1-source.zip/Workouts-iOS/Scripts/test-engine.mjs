import {build} from 'esbuild';
import {mkdir,rm} from 'node:fs/promises';
import {spawnSync} from 'node:child_process';
await mkdir('.test-build',{recursive:true});
try {
 for(const test of ['progression','bridge']) {
  await build({entryPoints:[`Tests/${test}.test.ts`],outfile:`.test-build/${test}.cjs`,bundle:true,platform:'node',format:'cjs',target:'node22',packages:'external'});
  const result=spawnSync(process.execPath,['--test',`.test-build/${test}.cjs`],{stdio:'inherit'});
  if(result.status)process.exitCode=result.status;
 }
} finally { await rm('.test-build',{recursive:true,force:true}); }
