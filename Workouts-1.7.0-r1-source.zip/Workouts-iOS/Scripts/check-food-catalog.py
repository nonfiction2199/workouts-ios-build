import json,math
from pathlib import Path
root=Path(__file__).parents[1]/'Workouts/Resources'
foods=[f for p in root.glob('food-catalog-[0-9]*.json') for f in json.loads(p.read_text())]
manifest=json.loads((root/'food-catalog-provenance.json').read_text())
assert len(foods)==manifest['foods']==13224
assert len({f['id'] for f in foods})==len(foods)
for f in foods:
    assert f['referenceGrams']==100 and f['name'] and f['source']
    assert all(math.isfinite(n) and 0<=n<=100000 for n in f['macros'].values())
    assert all(p['grams']>0 and p['grams']<=100000 and p['name'] for p in f['portions'])
for q in ['biryani','naan','kimchi','falafel','injera','pho','tortilla','curry']:
    assert any(q in f['name'].lower() for f in foods),q
print(f'{len(foods):,} source-backed profiles: identifiers, required macros, portions and cultural dish searches passed')

import sqlite3
branded = json.loads((root/'branded-food-provenance.json').read_text())
db = sqlite3.connect(f"file:{root/'branded-foods.sqlite'}?mode=ro",uri=True)
assert db.execute('PRAGMA integrity_check').fetchone()[0] == 'ok'
assert db.execute('SELECT count(*) FROM foods').fetchone()[0] == branded['foods'] and branded['foods'] > 400000
assert db.execute('SELECT count(*) FROM foods WHERE calories IS NULL OR protein IS NULL OR carbs IS NULL OR fat IS NULL').fetchone()[0] == 0
assert db.execute("SELECT count(*) FROM (SELECT barcode FROM foods WHERE barcode!='' GROUP BY barcode HAVING count(*)>1)").fetchone()[0] == 0
assert db.execute("SELECT count(*) FROM food_search WHERE food_search MATCH ?",('"cheerios"*',)).fetchone()[0] > 0
assert db.execute("SELECT count(*) FROM foods WHERE serving>100000 OR serving<0").fetchone()[0] == 0
print(f"{branded['foods']:,} indexed branded profiles: SQLite integrity, completeness, unique barcodes and search passed")
assert db.execute("SELECT count(*) FROM foods WHERE calories>1000 OR protein>105 OR carbs>105 OR fat>105 OR fiber>105 OR protein+carbs+fat>110").fetchone()[0] == 0
