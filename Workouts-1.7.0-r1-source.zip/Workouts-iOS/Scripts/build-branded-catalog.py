#!/usr/bin/env python3
"""Build a compact, indexed offline database from USDA's public-domain release."""
import csv,io,json,math,pathlib,sqlite3,sys,urllib.request,zipfile,hashlib
ROOT=pathlib.Path(__file__).resolve().parents[1]
URL='https://fdc.nal.usda.gov/fdc-datasets/FoodData_Central_branded_food_csv_2026-04-30.zip'
cache=pathlib.Path(sys.argv[1] if len(sys.argv)>1 else '/tmp/workouts-food-cache');cache.mkdir(parents=True,exist_ok=True)
archive=cache/'branded-2026.zip'
if not archive.exists(): urllib.request.urlretrieve(URL,archive)
sha=hashlib.file_digest(archive.open('rb'),'sha256').hexdigest()
if sha!='26050a5d03197469813754743a21ee0fad4ccf22b6aac2a995846a987719fc49': raise ValueError('USDA release checksum changed; review the source before rebuilding')
out=ROOT/'Workouts/Resources/branded-foods.sqlite';out.unlink(missing_ok=True)
db=sqlite3.connect(out);db.executescript('PRAGMA journal_mode=OFF; PRAGMA synchronous=OFF; CREATE TABLE foods(id INTEGER PRIMARY KEY,name TEXT,brand TEXT DEFAULT \'\',category TEXT DEFAULT \'Branded food\',barcode TEXT DEFAULT \'\',calories REAL,protein REAL,carbs REAL,fat REAL,fiber REAL,serving REAL,servingText TEXT);')
z=zipfile.ZipFile(archive)
def rows(name):
 path=next(n for n in z.namelist() if pathlib.PurePosixPath(n).name==name)
 return csv.DictReader(io.TextIOWrapper(z.open(path),encoding='utf-8-sig',newline=''))
def numeric(s):
 try:
  v=float(s);return v if math.isfinite(v) and 0<=v<=100000 else None
 except (ValueError,TypeError):return None
batch=[]
for r in rows('food.csv'):
 if r['data_type']!='branded_food':continue
 name=r['description'].strip()
 if not name or len(name)>220:continue
 batch.append((int(r['fdc_id']),name))
 if len(batch)>=10000:db.executemany('INSERT INTO foods(id,name) VALUES (?,?)',batch);batch=[]
db.executemany('INSERT INTO foods(id,name) VALUES (?,?)',batch);db.commit()
print('Loaded food names',db.execute('SELECT count(*) FROM foods').fetchone()[0],flush=True)
batch=[]
for r in rows('branded_food.csv'):
 serving=numeric(r.get('serving_size')) if r.get('serving_size_unit','').lower() in ('g','grm') else None
 batch.append((r.get('brand_name') or r.get('brand_owner',''),r.get('branded_food_category') or 'Branded food',r.get('gtin_upc','').lstrip('0'),serving,r.get('household_serving_fulltext','')[:100],int(r['fdc_id'])))
 if len(batch)>=10000:db.executemany('UPDATE foods SET brand=?,category=?,barcode=?,serving=?,servingText=? WHERE id=?',batch);batch=[]
db.executemany('UPDATE foods SET brand=?,category=?,barcode=?,serving=?,servingText=? WHERE id=?',batch);db.commit()
columns={'1008':'calories','1003':'protein','1005':'carbs','1004':'fat','1079':'fiber'}
batches={col:[] for col in columns.values()}
for r in rows('food_nutrient.csv'):
 col=columns.get(r['nutrient_id'])
 if not col:continue
 val=numeric(r['amount'])
 if val is None:continue
 batches[col].append((val,int(r['fdc_id'])))
 if len(batches[col])>=20000:db.executemany(f'UPDATE foods SET {col}=? WHERE id=?',batches[col]);batches[col]=[]
for col,batch in batches.items():db.executemany(f'UPDATE foods SET {col}=? WHERE id=?',batch)
db.commit()
original=db.execute('SELECT count(*) FROM foods').fetchone()[0]
db.executescript("DELETE FROM foods WHERE calories IS NULL OR protein IS NULL OR carbs IS NULL OR fat IS NULL OR calories>1000 OR protein>105 OR carbs>105 OR fat>105 OR fiber>105 OR protein+carbs+fat>110; DELETE FROM foods WHERE barcode!='' AND id NOT IN (SELECT max(id) FROM foods WHERE barcode!='' GROUP BY barcode); CREATE INDEX food_barcode ON foods(barcode); CREATE VIRTUAL TABLE food_search USING fts5(name,brand,category,content='foods',content_rowid='id',tokenize='unicode61 remove_diacritics 2'); INSERT INTO food_search(food_search) VALUES ('rebuild');")
db.commit();db.execute('VACUUM');count=db.execute('SELECT count(*) FROM foods').fetchone()[0];db.close()
manifest={'source':'USDA Branded Foods April 2026','license':'CC0 1.0 / public domain','url':URL,'archiveSHA256':sha,'foods':count,'original':original,'basis':'Nutrients per 100 g. Only complete calories/protein/carbs/fat profiles. Highest complete, plausible FDC identifier per barcode. Profiles with implausible per-100g energy or macro mass are omitted. Missing fiber is marked as unprovided. Milliliter servings are not converted to grams.'}
(ROOT/'Workouts/Resources/branded-food-provenance.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2),flush=True)
