#!/usr/bin/env python3
"""Reproduce the offline catalogue from CC0 USDA releases. No invented profiles."""
import json,math,pathlib,urllib.request,zipfile,sys,hashlib
ROOT=pathlib.Path(__file__).resolve().parents[1]
DATA=[('FNDDS 2021–2023','FoodData_Central_survey_food_json_2024-10-31.zip'),('SR Legacy 2018','FoodData_Central_sr_legacy_food_json_2018-04.zip')]
cache=pathlib.Path(sys.argv[1] if len(sys.argv)>1 else '/tmp/workouts-food-cache');cache.mkdir(parents=True,exist_ok=True)
foods=[];manifest=[]
for source,filename in DATA:
    path=cache/filename
    if not path.exists(): urllib.request.urlretrieve('https://fdc.nal.usda.gov/fdc-datasets/'+filename,path)
    archive=zipfile.ZipFile(path); raw=json.loads(archive.read(next(n for n in archive.namelist() if n.endswith('.json'))));items=next(iter(raw.values()));count=0
    for item in items:
        values={x['nutrient']['id']:x.get('amount') for x in item.get('foodNutrients',[])}
        # Omit profiles lacking energy or any primary macro rather than treating missing as zero.
        if not all(isinstance(values.get(n),(int,float)) and math.isfinite(values[n]) and values[n]>=0 for n in (1008,1003,1004,1005)): continue
        portions=[]
        for p in sorted(item.get('foodPortions',[]),key=lambda p:p.get('sequenceNumber',0)):
            grams=p.get('gramWeight',0); name=p.get('portionDescription') or ' '.join(str(p.get(k,'')) for k in ('amount','modifier')).strip()
            if not name or 'Quantity not specified' in name or 'Guideline' in name or grams<=0 or grams>100000 or any(x['name']==name for x in portions):continue
            portions.append({'name':name,'grams':grams})
        category=item.get('wweiaFoodCategory',{}).get('wweiaFoodCategoryDescription') or item.get('foodCategory',{}).get('description') or 'Common food'
        f={'id':'usda-'+str(item['fdcId']),'name':item['description'],'category':category,'source':source,'referenceGrams':100,'macros':{'calories':values[1008],'protein':values[1003],'carbs':values[1005],'fat':values[1004],'fiber':values.get(1079,0) or 0},'portions':portions[:12]}
        foods.append(f);count+=1
    manifest.append({'source':source,'url':'https://fdc.nal.usda.gov/fdc-datasets/'+filename,'archiveSHA256':hashlib.sha256(path.read_bytes()).hexdigest(),'included':count,'original':len(items)})
resources=ROOT/'Workouts/Resources'
for path in resources.glob('food-catalog-*.json'):path.unlink()
foods.sort(key=lambda f:f['name'].casefold())
# Moderate shards keep source updates reviewable and avoid oversized connector calls.
for i in range(0,len(foods),350):
    (resources/f'food-catalog-{i//350:03d}.json').write_text(json.dumps(foods[i:i+350],ensure_ascii=False,separators=(',',':'))+'\n')
manifest={'license':'CC0 1.0 / public domain','basis':'All nutrients per 100 g. Serving gram weights from USDA. Nutrient-incomplete profiles omitted. Fiber absent in source is not measured, shown as zero. Values describe typical foods, not a particular recipe.','foods':len(foods),'datasets':manifest}
(resources/'food-catalog-provenance.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2))
