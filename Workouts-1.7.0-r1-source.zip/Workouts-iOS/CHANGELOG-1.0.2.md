# 1.0.2

- Workout and Up Next open a read-only overview before starting.
- Target muscle cards, effective weekly set and RIR prescriptions, estimated duration, and fixed Start button.
- Add, replace, reorder, remove, and edit base targets; historical sessions stay unchanged.
- Exercise details show primary and secondary muscle diagrams, numbered instructions, and recent logged history.
- Verified public Jeff Nippard tutorials for barbell bench press, back squat, and Romanian deadlift open in an in-app browser. These are not MacroFactor in-app videos. Other exercises explicitly show missing video availability.
- Expanded original technique notes for six starter movements. Existing exercise-library instructions remain available.
- No saved-data schema or bundle identifier change.

Validation: 33 engine/bridge tests. Native build and simulator screenshots are checked during delivery. Device installation, haptics, and online video playback require real-device verification.
