# Workouts 1.0.8 — five additional styles

- Field Notes: warm paper and botanical green.
- Blueprint: deep drafting blue and pale cyan.
- Terracotta: sand, clay and muted olive.
- Cinder: charcoal steel and copper.
- Studio: cool white, cobalt and restrained red.

System, Light and Dark remain selectable. More now shows all eight styles in
large previews; Preferences lists the same choices. Shared palette colors
flow through cards, sheets, charts, buttons and the anatomy map. The five
palettes share the same sizing and accessibility labels as the base app.

The simulator capture script records Dashboard, Workout, Levels, More,
Shortcuts and the theme picker for each new style. The build workflow uploads a compact review
artifact alongside the IPA and existing screen captures.
