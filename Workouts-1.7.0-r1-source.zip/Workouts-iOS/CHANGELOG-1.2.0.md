# Workouts 1.2.0 — source-backed food logging

- 446,082 offline foods: existing 13,224 common profiles plus 432,858 branded profiles from USDA April 2026, indexed with SQLite FTS5.
- Name/brand search, typed barcode lookup, offline barcode photo reading, and optional international Open Food Facts search without user API keys.
- Selected international and branded foods persist for offline favorites, recent foods, recipes and nutrition backup exports.
- Photo review proposes food matches and lets the user select a database record. Nutrients then scale from that record by confirmed grams instead of AI-generated values. Unmatched items remain explicitly AI/manual estimates.
- Missing fiber is distinguished from measured zero. Milliliter servings are never automatically converted to grams.
- All screens use the existing eight appearance palettes. Existing diary/workout storage, bundle identifier and service settings are preserved.
- Photo-service failure messages now display safe backend error text rather than a generic failure.

## Rebuild
Run `python3 Scripts/build-branded-catalog.py` before tests or IPA packaging. The pinned public-domain archive is checksum-verified; the generated SQLite resource is excluded from git and rebuilt in CI. Source data provenance is bundled. International lookup is an optional network request; package labels and food identity require confirmation.
