# 1.0.3 — reference visual pass

- Reference charcoal page background (#141414), card/control colors retained.
- Removed added Dashboard date, corrected program/all-workout selector order.
- Two-column Insights, Habits, Body Metrics, Muscle Groups, and Exercise cards.
- Recorded-weight graph and workout bars replace decorative chart symbols. No fabricated measurements.
- Monday-first calendar with consistent outlined date pills and current-day dot.
- Original upright rocket drawing replaces the Levels person icon.
- More consistent section typography, program title, and centered Levels figure.
- Fixed safe-area backgrounds, restored card contrast, and aligned the empty heatmap message.
- Shortcuts now has a single-line Up Next heading, compact controls, and corrected theme previews.
- No changes to coaching algorithms, backup schema, or bundle ID.

Still differs: MacroSans glyphs, exact muscle-vector geometry, some icons, unavailable settings/features, and reference video library. This is not a claim of 100% visual equivalence.
