# 1.0.6 — Shortcuts layout candidate

- Shortcuts now measures its content and fits the sheet to that height instead of reserving 62% of every screen or expanding to an empty full-height sheet. Content remains scrollable when the device cannot fit it.
- Metrics uses an explicit filled SwiftUI Shape, independent of SF Symbol availability and Canvas foreground shading.
- Includes the prior 1.0.5 visual refinements. No workout data or algorithms changed.

Native compilation and device verification pending. No new similarity percentage is claimed. Confirm the installed build in More → About & Updates and review the Shortcuts screenshot before another visual iteration.

No Nippard videos were acquired or added. Existing demo library is unchanged.
