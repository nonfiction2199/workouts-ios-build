# Workouts 1.5.0

- Text-only Describe and photo + supporting photo logging.
- Editable meal plate with reference images, totals, add/remove foods and half/double portions.
- Known-calorie portion scaling, recipe saving and ingredient expansion.
- Separate match/portion review, density/energy checks, named-weight grounding and reliable cancel/retry.
- All eight themes, existing diary backups and app.sudais.workouts identity preserved.
- Pair this IPA with Local Food AI Revision 8 using UPDATE-LOCAL.cmd. No model change, paid key or new token.

Validation results follow in the GitHub build logs. Real food-image accuracy has not been benchmarked on the user's device.
