# Workouts 1.7.0

Photo-only recognition no longer requires written food notes. A validated empty local photo answer gets one bounded automatic recheck. Successful answers remain one request; both attempts share the existing deadline and cancellation.

The paired Revision 10 service estimates food identity, grams and per-100g nutrient density separately. It calculates all portion totals together; optional count × estimated grams-per-piece evidence uses bounded arithmetic. Supplied measured weights take precedence. A photo-estimated count no longer replaces the image weight with a restaurant standard serving when a gram-based profile exists. Slice/piece wording can match an otherwise compatible generic food preparation.

Food logging stays Camera/Upload → automatic analysis → review → Log Meal, with optional details collapsed. The app detects older services before sending the new portion request. Timeout errors now distinguish an unreachable laptop from slow AI analysis. The Windows launcher can start installed Ollama, and the updater verifies Revision 10 health before reporting success. Existing token, installation path and Tailscale configuration are preserved.

Themes: System, Light, Dark, Monochrome, Black & Gold, Midnight, Forest and Porcelain. New themes have distinct contrast, accents and card treatment. Old preferences migrate: Field Notes→Forest, Blueprint→Midnight, Terracotta→Porcelain, Cinder→Black & Gold, Studio→Light.

Levels uses newly authored vector anatomy checked against the supplied app recording: rounded chest and shoulder compartments, closer leg and arm proportions, more consistent gaps, neutral graphite tones and refined page spacing. Front/back switching and muscle details remain interactive. Source recordings are used for comparison and are not shipped in the app or public source.

Limits: photo grams and inferred recipe density remain estimates, not measured weights or verified ingredients. Local regression tests use provider fixtures and do not establish Qwen recognition accuracy on real photos. LiDAR remains experimental, with the existing geometry safeguards and fallbacks. Windows process startup behavior requires device verification; development occurs on Linux and macOS CI.
