import XCTest
final class ExerciseFlowTests: XCTestCase {
    func testCommonExerciseOrderAndWorkoutLogging() throws {
        let app = XCUIApplication()
        app.launchEnvironment["WORKOUTS_PREVIEW_SCREEN"] = "exercise-picker"
        app.launchEnvironment["WORKOUTS_WORKOUT_TEST"] = UUID().uuidString
        app.launchEnvironment["WORKOUTS_PREVIEW_THEME"] = "blueprint"
        app.launch()
        let add = app.buttons["Add Exercise"]
        XCTAssertTrue(add.waitForExistence(timeout: 25)); add.tap()
        let bench = app.buttons["exercise-result-bench"], squat = app.buttons["exercise-result-squat"], deadlift = app.buttons["exercise-result-db-Barbell_Deadlift"]
        XCTAssertTrue(bench.waitForExistence(timeout: 10)); XCTAssertTrue(squat.exists); XCTAssertTrue(deadlift.exists)
        XCTAssertLessThan(bench.frame.minY,squat.frame.minY); XCTAssertLessThan(squat.frame.minY,deadlift.frame.minY)
        let search = app.searchFields.firstMatch
        XCTAssertTrue(search.exists); search.tap(); search.typeText("bench press")
        XCTAssertTrue(bench.waitForExistence(timeout: 10)); bench.tap()
        XCTAssertTrue(app.staticTexts["Barbell bench press"].waitForExistence(timeout: 10))
        XCTAssertTrue(app.buttons["Finish Workout"].exists,"selection must add the lift to the real workout logger")
    }
}
