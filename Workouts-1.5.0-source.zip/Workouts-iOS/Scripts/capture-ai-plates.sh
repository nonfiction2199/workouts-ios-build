#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
DEVICE="$(xcrun simctl list devices available -j | python3 -c 'import json,sys; d=json.load(sys.stdin); p=[x for v in d["devices"].values() for x in v if "iPhone" in x["name"]]; print(next((x["udid"] for x in p if "Pro Max" in x["name"]),p[0]["udid"]))')"
xcrun simctl boot "$DEVICE" || true
xcrun simctl bootstatus "$DEVICE" -b
APP="$(python3 -c 'import pathlib; print(next(pathlib.Path("build/UITests/Build/Products/Debug-iphonesimulator").glob("Workouts.app")))')"
xcrun simctl install "$DEVICE" "$APP"
mkdir -p build/ai-plate-previews
for THEME in system light dark fieldNotes blueprint terracotta cinder studio; do
  SIMCTL_CHILD_WORKOUTS_PREVIEW_THEME="$THEME" SIMCTL_CHILD_WORKOUTS_PREVIEW_SCREEN=food-portions \
    SIMCTL_CHILD_WORKOUTS_NUTRITION_TEST="plate-preview-$THEME" \
    xcrun simctl launch --terminate-running-process "$DEVICE" app.sudais.workouts
  sleep 3
  xcrun simctl io "$DEVICE" screenshot "build/ai-plate-previews/$THEME.png"
  sips -s format jpeg -s formatOptions 82 "build/ai-plate-previews/$THEME.png" --out "build/ai-plate-previews/$THEME.jpg" >/dev/null
  rm "build/ai-plate-previews/$THEME.png"
done
xcrun simctl shutdown "$DEVICE" || true
