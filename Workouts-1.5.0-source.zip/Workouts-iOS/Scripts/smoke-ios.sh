#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p build/previews
PREVIEW_APP="build/UITests/Build/Products/Debug-iphonesimulator/Workouts.app"
if [ ! -d "$PREVIEW_APP" ]; then
  xcodebuild -project Workouts.xcodeproj -scheme Workouts -configuration Debug \
    -sdk iphonesimulator -destination 'generic/platform=iOS Simulator' \
    -derivedDataPath build/Simulator CODE_SIGNING_ALLOWED=NO build > build/simulator.log 2>&1
  PREVIEW_APP="build/Simulator/Build/Products/Debug-iphonesimulator/Workouts.app"
fi
DEVICE="$(xcrun simctl list devices available -j | python3 -c 'import json,sys; d=json.load(sys.stdin); phones=[x for v in d["devices"].values() for x in v if "iPhone" in x["name"] and x["state"]=="Shutdown"]; print(next((x["udid"] for x in phones if "Pro Max" in x["name"]),phones[0]["udid"]))')"
xcrun simctl boot "$DEVICE"
trap 'xcrun simctl shutdown "$DEVICE" || true' EXIT
xcrun simctl bootstatus "$DEVICE" -b
xcrun simctl status_bar "$DEVICE" override --time '9:41' --batteryState charged --batteryLevel 100
xcrun simctl install "$DEVICE" "$PREVIEW_APP"
for SCREEN in dashboard records analytics workout levels more shortcuts overview exercise-details exercise-history exercise-options exercise; do
  SIMCTL_CHILD_WORKOUTS_PREVIEW_SCREEN="$SCREEN" xcrun simctl launch --terminate-running-process "$DEVICE" app.sudais.workouts
  sleep 5
  xcrun simctl io "$DEVICE" screenshot "build/previews/$SCREEN.png"
done

# Capture two additional frames and a recording spanning at least two bench loops.
# Bound shutdown so a stuck simulator recorder cannot exhaust the CI job.
python3 - "$DEVICE" <<'PYRECORD'
import signal, subprocess, sys, time
from pathlib import Path
device = sys.argv[1]
video = Path('build/previews/demo-playback.mp4')
video.unlink(missing_ok=True)
recorder = subprocess.Popen(['xcrun','simctl','io',device,'recordVideo','--codec=h264',str(video)])
try:
    for index in range(2):
        time.sleep(4)
        subprocess.run(['xcrun','simctl','io',device,'screenshot',f'build/previews/demo-frame-{index+1}.png'],check=True)
    time.sleep(8)
finally:
    if recorder.poll() is None:
        recorder.send_signal(signal.SIGINT)
    try:
        recorder.wait(timeout=15)
    except subprocess.TimeoutExpired:
        recorder.terminate()
        try:
            recorder.wait(timeout=5)
        except subprocess.TimeoutExpired:
            recorder.kill()
            recorder.wait()
if not video.exists() or video.stat().st_size < 1024:
    raise SystemExit('Simulator did not produce a usable demo recording')
PYRECORD

# Exercise every palette on the five main surfaces. JPEG keeps the review
# artifact small enough to inspect without changing the app screenshots.
mkdir -p build/theme-previews
for THEME in fieldNotes blueprint terracotta cinder studio; do
  for SCREEN in dashboard workout levels more shortcuts theme-picker; do
    SIMCTL_CHILD_WORKOUTS_PREVIEW_THEME="$THEME" SIMCTL_CHILD_WORKOUTS_PREVIEW_SCREEN="$SCREEN" \
      xcrun simctl launch --terminate-running-process "$DEVICE" app.sudais.workouts
    sleep 3
    xcrun simctl io "$DEVICE" screenshot "build/theme-previews/$THEME-$SCREEN.png"
    sips -s format jpeg -s formatOptions 78 "build/theme-previews/$THEME-$SCREEN.png" \
      --out "build/theme-previews/$THEME-$SCREEN.jpg" >/dev/null
    rm "build/theme-previews/$THEME-$SCREEN.png"
  done
done

# Nutrition foundations across every selectable appearance (System resolves to device).
mkdir -p build/nutrition-previews
for THEME in system light dark fieldNotes blueprint terracotta cinder studio; do
  for SCREEN in nutrition food-search nutrition-goals food-photo food-match food-restaurant food-recipe; do
    SIMCTL_CHILD_WORKOUTS_PREVIEW_THEME="$THEME" SIMCTL_CHILD_WORKOUTS_PREVIEW_SCREEN="$SCREEN" \
      xcrun simctl launch --terminate-running-process "$DEVICE" app.sudais.workouts
    sleep 3
    xcrun simctl io "$DEVICE" screenshot "build/nutrition-previews/$THEME-$SCREEN.png"
    sips -s format jpeg -s formatOptions 78 "build/nutrition-previews/$THEME-$SCREEN.png" \
      --out "build/nutrition-previews/$THEME-$SCREEN.jpg" >/dev/null
    rm "build/nutrition-previews/$THEME-$SCREEN.png"
  done
done
