#!/usr/bin/env python3
"""Check readable text and action contrast in every shipped palette."""
import re
from pathlib import Path

source = (Path(__file__).parents[1] / "Workouts" / "Theme.swift").read_text()
source = source.split("var colors: ThemeColors", 1)[1]
dark = {"dark", "blueprint", "cinder"}
names = ("dark", "light", "fieldNotes", "blueprint", "terracotta", "cinder", "studio")


def luminance(rgb):
    channels = [(rgb >> shift & 255) / 255 for shift in (16, 8, 0)]
    channels = [v / 12.92 if v <= 0.04045 else ((v + 0.055) / 1.055) ** 2.4 for v in channels]
    return 0.2126 * channels[0] + 0.7152 * channels[1] + 0.0722 * channels[2]


def contrast(a, b):
    light, dark_value = sorted((luminance(a), luminance(b)), reverse=True)
    return (light + 0.05) / (dark_value + 0.05)


for name in names:
    match = re.search(r"case \." + name + r":.*?return ThemeColors\((.*?)\)", source, re.S)
    assert match, f"Missing palette: {name}"
    colors = {key: int(value, 16) for key, value in re.findall(r"(\w+): 0x([0-9A-Fa-f]{6})", match.group(1))}
    assert len(colors) == 13, f"Incomplete palette: {name}"
    primary = 0xFFFFFF if name in dark else 0x000000
    for label, a, b, minimum in (
        ("primary on background", primary, colors["background"], 7.0),
        ("primary on card", primary, colors["surface"], 7.0),
        ("secondary on card", colors["secondary"], colors["surface"], 4.5),
        ("action label", colors["actionText"], colors["action"], 4.5),
    ):
        ratio = contrast(a, b)
        assert ratio >= minimum, f"{name}: {label} {ratio:.2f}:1 below {minimum}:1"
    print(f"{name}: text and action contrast passed")
