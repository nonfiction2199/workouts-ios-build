import Foundation

struct FoodMacros: Codable, Equatable {
    var calories: Double = 0
    var protein: Double = 0
    var carbs: Double = 0
    var fat: Double = 0
    var fiber: Double = 0
    var valid: Bool { [calories,protein,carbs,fat,fiber].allSatisfy { $0.isFinite && $0 >= 0 && $0 <= 100000 } }
    func scaled(_ factor: Double) -> FoodMacros { FoodMacros(calories: calories * factor, protein: protein * factor, carbs: carbs * factor, fat: fat * factor, fiber: fiber * factor) }
    static func + (lhs: Self,rhs: Self) -> Self { Self(calories: lhs.calories+rhs.calories,protein: lhs.protein+rhs.protein,carbs: lhs.carbs+rhs.carbs,fat: lhs.fat+rhs.fat,fiber: lhs.fiber+rhs.fiber) }
    var macroCalories: Double { 4 * protein + 4 * carbs + 9 * fat }
}
struct FoodPortion: Codable, Identifiable {
    var name: String
    var grams: Double
    var id: String { name }
}
struct FoodItem: Codable, Identifiable {
    var id: String
    var name: String
    var category: String
    var source: String
    var referenceGrams: Double
    var macros: FoodMacros
    var portions: [FoodPortion]
    var brand: String? = nil
    var barcode: String? = nil
    var fiberMissing: Bool? = nil
    var ingredients: [MealIngredient]? = nil
    var valid: Bool { !id.isEmpty && !name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && name.count <= 300 && referenceGrams.isFinite && referenceGrams > 0 && referenceGrams <= 100000 && macros.valid && portions.allSatisfy { !$0.name.isEmpty && $0.grams.isFinite && $0.grams > 0 && $0.grams <= 100000 } && (ingredients?.allSatisfy(\.valid) ?? true) }
    func nutrition(grams: Double) -> FoodMacros { macros.scaled(grams / referenceGrams) }
    var isRecipe: Bool { ingredients != nil }
}
struct MealIngredient: Codable, Identifiable {
    var id: String = UUID().uuidString
    var foodID: String
    var name: String
    var grams: Double
    var macros: FoodMacros
    var valid: Bool { !id.isEmpty && !name.isEmpty && grams.isFinite && grams > 0 && grams <= 100000 && macros.valid }
}
enum FoodMeal: String, Codable, CaseIterable, Identifiable {
    case breakfast = "Breakfast", lunch = "Lunch", dinner = "Dinner", snack = "Snacks"
    var id: String { rawValue }
}
struct FoodLogEntry: Codable, Identifiable {
    var id: String = UUID().uuidString
    var day: String
    var loggedAt: Date = Date()
    var meal: FoodMeal
    var foodID: String
    var name: String
    var grams: Double
    // A snapshot: changing a recipe or its database source never rewrites history.
    var macros: FoodMacros
    var source: String
    var estimated: Bool = false
    var nutritionBasis: FoodNutritionBasis? = nil
    var valid: Bool { !id.isEmpty && NutritionDay.valid(day) && !name.isEmpty && name.count <= 300 && grams.isFinite && grams > 0 && grams <= 100000 && macros.valid && loggedAt.timeIntervalSince1970.isFinite && (nutritionBasis?.valid ?? true) }
}
struct NutritionGoals: Codable, Equatable {
    var intent = "Maintain"
    var macros = FoodMacros(calories: 2200,protein: 150,carbs: 250,fat: 65,fiber: 30)
    var valid: Bool { ["Lose","Maintain","Gain","Custom"].contains(intent) && macros.valid && macros.calories > 0 && macros.calories <= 20000 && [macros.protein,macros.carbs,macros.fat,macros.fiber].allSatisfy { $0 <= 3000 } }
}
struct NutritionState: Codable {
    var schemaVersion = 1
    var goals: NutritionGoals? = nil
    var customFoods: [FoodItem] = []
    var entries: [FoodLogEntry] = []
    var favorites: [String] = []
    var cachedFoods: [FoodItem]? = nil
    var valid: Bool { schemaVersion == 1 && (cachedFoods?.count ?? 0) <= 5000 && (cachedFoods?.allSatisfy(\.valid) ?? true) && Set((cachedFoods ?? []).map(\.id)).count == (cachedFoods?.count ?? 0) && (goals?.valid ?? true) && customFoods.allSatisfy(\.valid) && entries.allSatisfy(\.valid) && Set(customFoods.map(\.id)).count == customFoods.count && Set(entries.map(\.id)).count == entries.count && favorites.count <= 50000 && entries.count <= 250000 && customFoods.count <= 50000 }
}
enum NutritionDay {
    // Local calendar day, not UTC: a late dinner belongs to the displayed day.
    static func key(_ date: Date,calendar: Calendar = .current) -> String {
        let c = calendar.dateComponents([.year,.month,.day],from: date)
        return String(format: "%04d-%02d-%02d", c.year ?? 0,c.month ?? 0,c.day ?? 0)
    }
    static func valid(_ key: String) -> Bool {
        let f = DateFormatter(); f.locale = Locale(identifier: "en_US_POSIX"); f.timeZone = TimeZone(secondsFromGMT: 0); f.dateFormat = "yyyy-MM-dd"; f.isLenient = false
        guard let date = f.date(from: key) else { return false }; return f.string(from: date) == key
    }
}

extension Double { var foodInput: String { String(self) } }

enum FoodScanError: LocalizedError {
    case message(String)
    var errorDescription: String? { if case .message(let text) = self { return text }; return nil }
}

struct FoodAIResponse: Codable {
    var items: [FoodAIItem]
    var notes: String
    var questions: [String]
    var restaurant: RestaurantLookupResponse? = nil
    var restaurantName: String? = nil
    var restaurantLocation: String? = nil
    var workflow: Int? = nil
    enum CodingKeys: String, CodingKey { case items,notes,questions,restaurantName,restaurantLocation,workflow }
    var valid: Bool { items.count <= 30 && items.allSatisfy(\.valid) && notes.count <= 2000 && (restaurantName?.count ?? 0) <= 120 && (restaurantLocation?.count ?? 0) <= 160 && questions.count <= 8 && questions.allSatisfy { $0.count <= 500 } }
}
struct FoodAIQuantity: Codable {
    var count: Double?
    var unit: String
    var basis: String
    var weightBasis: String
    var valid: Bool { (count.map { $0.isFinite && $0 > 0 && $0 <= 100 } ?? true) && unit.count <= 30 && ["user","photo"].contains(basis) && ["user","photo"].contains(weightBasis) }
}
struct FoodAIItem: Codable, Identifiable {
    var id: String = UUID().uuidString
    var name: String
    var grams: Double
    var macros: FoodMacros
    var uncertainty: String
    var matchedFood: FoodItem? = nil
    var nutritionBasis: FoodNutritionBasis? = nil
    var photoMacros: FoodMacros? = nil
    var photoGrams: Double? = nil
    var requestedName: String? = nil
    var quantity: FoodAIQuantity? = nil
    var exclude: [String]? = nil
    var add: [String]? = nil
    enum CodingKeys: String, CodingKey { case name,grams,macros,uncertainty,requestedName,quantity,exclude,add }
    var valid: Bool { !name.isEmpty && name.count <= 300 && grams.isFinite && grams > 0 && grams <= 10000 && macros.valid && macros.calories <= 20000 && uncertainty.count <= 600 && (requestedName?.count ?? 0) <= 80 && (quantity?.valid ?? true) && [exclude,add].allSatisfy { ($0?.count ?? 0) <= 4 && ($0?.allSatisfy { !$0.isEmpty && $0.count <= 40 } ?? true) } && (nutritionBasis?.valid ?? true) }
}

// Optional provenance preserves old diaries and distinguishes the source profile
// from the portion estimate or user edits. Entries always retain macro snapshots.
struct FoodNutritionBasis: Codable {
    var restaurantQuery: String? = nil
    var sourceURL: String? = nil
    var sourceTitle: String? = nil
    var sourceFoodID: String? = nil
    var referenceServing: String? = nil
    var referenceGrams: Double? = nil
    var referenceMacros: FoodMacros? = nil
    var servings: Double? = nil
    var fiberMissing: Bool? = nil
    var adjusted = false
    var resolution: String? = nil
    var portionBasis: String? = nil
    var quantityCount: Double? = nil
    var quantityUnit: String? = nil
    var referenceCount: Double? = nil
    var warnings: [String]? = nil
    var modifications: [String]? = nil
    var identityReviewed: Bool? = nil
    var portionReviewed: Bool? = nil
    var valid: Bool {
        (restaurantQuery?.count ?? 0) <= 300 && (sourceTitle?.count ?? 0) <= 200 && (referenceServing?.count ?? 0) <= 200 &&
        (sourceFoodID?.count ?? 0) <= 200 && (sourceURL.map(Self.validURL) ?? true) && (referenceGrams.map { $0.isFinite && $0 > 0 && $0 <= 10000 } ?? true) &&
        (referenceMacros?.valid ?? true) && (servings.map { $0.isFinite && $0 > 0 && $0 <= 100 } ?? true) &&
        (resolution.map { ["restaurant","library","ai"].contains($0) } ?? true) && (portionBasis?.count ?? 0) <= 100 && (quantityUnit?.count ?? 0) <= 30 &&
        [quantityCount,referenceCount].allSatisfy { $0.map { $0.isFinite && $0 > 0 && $0 <= 100 } ?? true } &&
        (warnings?.count ?? 0) <= 8 && (warnings?.allSatisfy { $0.count <= 300 } ?? true) && (modifications?.count ?? 0) <= 8 && (modifications?.allSatisfy { $0.count <= 100 } ?? true)
    }
    static func validURL(_ value: String) -> Bool {
        guard value.count <= 2000,let url = URL(string: value),url.scheme == "https",url.host != nil,url.user == nil,url.password == nil else { return false }; return true
    }
}
struct FoodWebSource: Codable, Identifiable {
    var title: String
    var url: String
    var id: String { url }
    var valid: Bool { title.count <= 200 && FoodNutritionBasis.validURL(url) }
}
struct FoodWebCandidate: Codable, Identifiable {
    var id: String
    var name: String
    var description: String
    var sourceURL: String
    var sourceTitle: String
    var servingSize: String
    var referenceGrams: Double?
    var macros: FoodMacros?
    var fiberMissing: Bool
    var valid: Bool { !id.isEmpty && id.count <= 100 && !name.isEmpty && name.count <= 300 && description.count <= 400 && servingSize.count <= 200 && sourceTitle.count <= 200 && FoodNutritionBasis.validURL(sourceURL) && (referenceGrams.map { $0.isFinite && $0 > 0 && $0 <= 10000 } ?? true) && (macros?.valid ?? true) && (macros == nil || !servingSize.isEmpty) }
    var food: FoodItem? {
        guard let referenceGrams,let macros else { return nil }
        return FoodItem(id: "restaurant-" + id,name: name,category: "Restaurant",source: "Web nutrition · " + (URL(string: sourceURL)?.host ?? sourceTitle),referenceGrams: referenceGrams,macros: macros,portions: [FoodPortion(name: servingSize,grams: referenceGrams)],fiberMissing: fiberMissing)
    }
    func basis(query: String,servings: Double? = nil) -> FoodNutritionBasis {
        FoodNutritionBasis(restaurantQuery: query,sourceURL: sourceURL,sourceTitle: sourceTitle,referenceServing: servingSize,referenceGrams: referenceGrams,referenceMacros: macros,servings: servings,fiberMissing: fiberMissing)
    }
}
struct RestaurantLookupResponse: Codable {
    var query: String
    var status: String
    var notes: String
    var sources: [FoodWebSource]
    var candidates: [FoodWebCandidate]
    var valid: Bool { query.count <= 300 && ["not_requested","nutrition_found","menu_only","not_found","unavailable"].contains(status) && notes.count <= 1000 && sources.count <= 6 && sources.allSatisfy(\.valid) && candidates.count <= 12 && candidates.allSatisfy(\.valid) }
    static func requested(_ context: String,sourceURL: String) -> Bool {
        // Let the service identify restaurant cues, including names without
        // “from”/“at”. Ordinary portion notes return not_requested immediately.
        !sourceURL.isEmpty || !context.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }
}
enum FoodPhotoMatching {
    // Only an unambiguous exact name auto-selects. Similar preparations remain
    // suggestions in the correction screen, never silent calorie substitutions.
    static func match(_ item: FoodAIItem,in foods: [FoodItem]) -> FoodAIItem {
        var next = item; next.photoMacros = item.photoMacros ?? item.macros; next.photoGrams = item.photoGrams ?? item.grams
        let query = FoodSearchRanking.normalize(item.name)
        let matches = foods.filter { FoodSearchRanking.normalize($0.name) == query || FoodSearchRanking.normalize(FoodSearchRanking.title($0)) == query }
        guard matches.count == 1,let food = matches.first,food.valid else { return next }
        next.matchedFood = food; next.macros = food.nutrition(grams: item.grams)
        next.nutritionBasis = FoodNutritionBasis(referenceGrams: food.referenceGrams,referenceMacros: food.macros,fiberMissing: food.fiberMissing)
        return next.valid ? next : item
    }
}
