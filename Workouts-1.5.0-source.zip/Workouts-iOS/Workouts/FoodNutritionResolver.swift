import Foundation

// Nutrition identity and portion evidence are independent. A photograph can
// identify a preparation; it cannot verify a restaurant recipe or weigh it.
enum FoodNutritionResolver {
    static func resolve(_ item: FoodAIItem,restaurant: RestaurantLookupResponse?,foods: [FoodItem]) -> FoodAIItem {
        var next = item
        next.photoMacros = item.photoMacros ?? item.macros
        next.photoGrams = item.photoGrams ?? item.grams
        let changes = (item.exclude ?? []).map { "No " + $0 } + (item.add ?? []).map { "Add " + $0 }
        let hasPlace = restaurant != nil && restaurant?.status != "not_requested"
        var warnings: [String] = []
        let request = item.requestedName.flatMap { $0.isEmpty ? nil : $0 } ?? item.name
        let candidates = (restaurant?.candidates ?? []).filter { candidate in
            guard candidate.macros != nil,candidate.valid else { return false }
            // Matching a market name to a related component is not proof of a recipe.
            guard identity(candidate.name) == identity(request) else { return false }
            return modificationsSupported(item,by: candidate.name + " " + candidate.description)
        }
        // Multiple variants require review; never guess heat, size or included sides.
        if candidates.count == 1,let candidate = candidates.first,let macros = candidate.macros {
            var basis = candidate.basis(query: restaurant?.query ?? "")
            basis.sourceFoodID = "restaurant-" + candidate.id; basis.resolution = "restaurant"
            basis.modifications = changes
            let quantity = item.quantity
            let count = quantity?.count
            let sourceCount = countServing(candidate.servingSize,unit: quantity?.unit ?? "")
            if quantity?.weightBasis != "user",let count,let sourceCount {
                let factor = count / sourceCount
                next.macros = macros.scaled(factor); basis.servings = factor
                basis.referenceCount = sourceCount; basis.quantityCount = count; basis.quantityUnit = quantity?.unit
                basis.portionBasis = quantity?.basis == "user" ? "Your count × published serving" : "Photo count estimate × published serving"
                if let grams = candidate.referenceGrams { next.grams = grams * factor }
                else { warnings.append("The source has no gram weight; displayed grams remain a photo estimate.") }
            } else if let grams = candidate.referenceGrams {
                next.macros = macros.scaled(item.grams / grams)
                basis.portionBasis = quantity?.weightBasis == "user" ? "Your weight × published nutrition" : "Photo weight estimate × published nutrition"
            } else {
                // No compatible count and no gram weight means no supported scale.
                warnings.append("Published nutrition has no compatible portion; choose a source serving in review.")
                return libraryFallback(next,foods: foods,hasPlace: hasPlace,changes: changes,warnings: warnings)
            }
            next.matchedFood = candidate.food; next.nutritionBasis = basis
            basis.warnings = warnings; next.nutritionBasis = basis
            if next.valid { return next }
        }
        if hasPlace {
            warnings.append(changes.isEmpty ? "Restaurant recipe unverified; no unique matching nutrition profile." : "Published restaurant recipe does not verify these changes; no guessed ingredient subtraction.")
        }
        return libraryFallback(next,foods: foods,hasPlace: hasPlace,changes: changes,warnings: warnings)
    }
    private static func libraryFallback(_ item: FoodAIItem,foods: [FoodItem],hasPlace: Bool,changes: [String],warnings: [String]) -> FoodAIItem {
        var next = item
        let wanted = identity(item.name)
        let ranked = foods.compactMap { food -> (FoodItem,Double)? in
            // Generic estimates must not silently borrow a different brand's recipe.
            guard food.valid,(food.brand ?? "").isEmpty,!food.source.contains("Branded"),food.category != "Restaurant",!containsBrandHeading(food.name) else { return nil }
            let found = identity(food.name)
            guard !wanted.isEmpty,wanted.isSubset(of: found),compatible(item.name,food.name),modificationsSupported(item,by: food.name,generic: true) else { return nil }
            let normalized = normalize(food.name)
            guard !["frozen","school","baby","infant"].contains(where: { normalized.contains($0) }) else { return nil }
            var score = Double(wanted.count) / Double(max(found.count,1))
            if hasPlace && normalized.contains("from restaurant") { score += 0.5 }
            if found == wanted { score += 0.3 }
            if food.source.hasPrefix("FNDDS") { score += 0.05 }
            return (food,score)
        }.sorted { $0.1 == $1.1 ? $0.0.id < $1.0.id : $0.1 > $1.1 }
        var messages = warnings
        guard let first = ranked.first,ranked.count == 1 || first.1 - ranked[1].1 > 0.02 else {
            messages.append("No unambiguous food-library preparation. AI nutrition remains an estimate; review or select a food.")
            next.nutritionBasis = FoodNutritionBasis(resolution: "ai",portionBasis: item.quantity?.weightBasis == "user" ? "Your weight; AI nutrient estimate" : "Photo portion and nutrient estimate",warnings: messages,modifications: changes)
            return next
        }
        let food = first.0
        next.matchedFood = food; next.macros = food.nutrition(grams: item.grams)
        var basis = FoodNutritionBasis(sourceFoodID: food.id,referenceGrams: food.referenceGrams,referenceMacros: food.macros,fiberMissing: food.fiberMissing,resolution: "library",portionBasis: item.quantity?.weightBasis == "user" ? "Your weight × food-library nutrition" : "Photo weight estimate × food-library nutrition",warnings: messages,modifications: changes)
        // Generic per-piece weights are not restaurant piece weights. Keep the
        // image estimate unless the user explicitly supplied a measured weight.
        basis.quantityCount = item.quantity?.count; basis.quantityUnit = item.quantity?.unit
        if item.quantity?.count != nil { messages.append("Piece count does not establish weight for this generic food; confirm the grams.") }
        if !changes.isEmpty { messages.append("Recipe changes are an estimate, not verified restaurant nutrition.") }
        basis.warnings = messages; next.nutritionBasis = basis
        return next.valid ? next : item
    }
    static func normalize(_ value: String) -> String {
        value.folding(options: [.caseInsensitive,.diacriticInsensitive],locale: Locale(identifier: "en_US_POSIX")).split(whereSeparator: { !$0.isLetter && !$0.isNumber }).joined(separator: " ")
    }
    private static func identity(_ value: String) -> Set<String> {
        let ignored: Set<String> = ["a","an","the","and","or","with","from","restaurant","restaurants","style","family","single","no","sides","of","to","other","ns","nfs","as","prepared"]
        let aliases = ["broiled":"grilled","steamed":"boiled","roasted":"baked","tenders":"tender","strips":"tender","strip":"tender","fingers":"tender","finger":"tender","breaded":"fried","slices":"slice","pizzas":"pizza","burgers":"burger","margherita":"margherita","margarita":"margherita","chickens":"chicken","hamburger":"burger","hamburgers":"burger"]
        return Set(normalize(value).split(separator: " ").map { token -> String in let word = String(token); if let alias = aliases[word] { return alias }; if word.count > 4 && word.hasSuffix("ies") { return String(word.dropLast(3)) + "y" }; if word.count > 4 && word.hasSuffix("s") && !word.hasSuffix("ss") { return String(word.dropLast()) }; return word }.filter { !ignored.contains($0) && Double($0) == nil })
    }
    private static func compatible(_ wanted: String,_ found: String) -> Bool {
        let a = Set(normalize(wanted).split(separator: " ").map(String.init)), b = Set(normalize(found).split(separator: " ").map(String.init))
        let forms: Set<String> = ["soup","broth","sauce","dressing","powder","drink","beverage","juice","nectar","smoothie","sandwich","salad","stew","pie","cake","pudding","chip","noodles","dumpling","bar","cereal","baby","infant"]
        let wantedForms = identity(wanted),foundForms = identity(found)
        for form in forms { let key = identity(form); if !foundForms.isDisjoint(with: key) && wantedForms.isDisjoint(with: key) { return false } }
        let proteins: Set<String> = ["beef","pork","chicken","lamb","tofu","turkey"]
        if !wantedForms.isDisjoint(with: proteins) && !foundForms.intersection(proteins).isSubset(of: wantedForms) { return false }
        let preparations: [Set<String>] = [["fried","breaded"],["grilled","broiled"],["raw","uncooked"],["boiled","steamed"],["baked","roasted"]]
        let aGroups = preparations.indices.filter { !a.isDisjoint(with: preparations[$0]) }, bGroups = preparations.indices.filter { !b.isDisjoint(with: preparations[$0]) }
        if !aGroups.isEmpty && !bGroups.isEmpty && Set(aGroups).isDisjoint(with: Set(bGroups)) { return false }
        // Unspecified preparations must not choose a raw profile automatically.
        if aGroups.isEmpty && b.contains("raw") && ["chicken","beef","pork","fish"].contains(where: a.contains) { return false }
        for alternative in ["vegan","vegetarian","imitation","plant"] { if b.contains(alternative) && !a.contains(alternative) { return false } }
        return true
    }
    private static func modificationsSupported(_ item: FoodAIItem,by description: String,generic: Bool = false) -> Bool {
        let text = normalize(description)
        let excluded = item.exclude ?? [],added = item.add ?? []
        if !generic { return excluded.allSatisfy { text.contains("without " + normalize($0)) || text.contains("no " + normalize($0)) } && added.allSatisfy { text.contains("with " + normalize($0)) || text.contains("extra " + normalize($0)) } }
        // Bare meat/tenders do not include an accompanying bread slice. Breading
        // stays part of fried chicken. Changes to the dish itself need an explicit
        // compatible generic preparation (e.g. cheeseless pizza).
        for component in excluded {
            let c = normalize(component)
            let accompanying = ["bread","bun","sauce","dip","pickles","fries"].contains(c) && identity(item.name).contains("chicken") && !text.contains(c == "bread" ? "bread slice" : c)
            if accompanying { continue }
            if text.contains("without " + c) || text.contains("no " + c) { continue }
            return false
        }
        return added.allSatisfy { text.contains(normalize($0)) }
    }
    private static func containsBrandHeading(_ name: String) -> Bool {
        // SR Legacy includes chain names in all-capital headings even when its
        // brand field is empty. Such profiles are not generic preparations.
        guard let heading = name.split(separator: ",").first else { return false }
        let letters = heading.filter(\.isLetter)
        return letters.count >= 3 && letters == letters.uppercased() && letters != letters.lowercased()
    }
    static func countServing(_ text: String,unit: String) -> Double? {
        let aliases = ["tenders":"tender","strips":"tender","strip":"tender","slices":"slice","pieces":"piece","servings":"serving","pizzas":"pizza","burgers":"burger"]
        let u = normalize(unit),key = aliases[u] ?? u
        guard !key.isEmpty else { return nil }
        let units = [key] + aliases.filter { $0.value == key }.map(\.key)
        let alternatives = units.map { NSRegularExpression.escapedPattern(for: $0) }.joined(separator: "|")
        let pattern = "(?i)\\b(\\d+(?:[.,]\\d+)?(?:/\\d+)?|single)\\s+(?:" + alternatives + ")\\b"
        guard let regex = try? NSRegularExpression(pattern: pattern),let match = regex.firstMatch(in: text,range: NSRange(text.startIndex...,in: text)),let range = Range(match.range(at: 1),in: text) else { return nil }
        let raw = String(text[range]).lowercased().replacingOccurrences(of: ",",with: ".")
        let parts = raw.split(separator: "/").compactMap { Double($0) }
        let count = raw == "single" ? 1 : (parts.count == 2 && parts[1] > 0 ? parts[0]/parts[1] : Double(raw))
        guard let count,count > 0,count <= 100 else { return nil }; return count
    }
}

extension FoodAIItem {
    var nutritionLabel: String {
        let kind = nutritionBasis?.resolution
        if kind == "restaurant" { return "Published restaurant nutrition" + (nutritionBasis?.adjusted == true ? " · edited" : "") }
        if kind == "library" { return "Food-library estimate · " + (matchedFood?.source ?? "matched profile") + (nutritionBasis?.adjusted == true ? " · edited" : "") }
        return (matchedFood.map { "Matched: " + $0.source } ?? (nutritionBasis?.sourceURL == nil ? "AI nutrient estimate" : "Published nutrition · selected serving")) + (nutritionBasis?.adjusted == true ? " · edited" : "")
    }
}
