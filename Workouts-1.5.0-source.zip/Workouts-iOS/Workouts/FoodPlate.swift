import Foundation

// Review is an explicit user decision, not a model confidence percentage.
// Scaling keeps source identity and reference nutrition, including count-only sources.
enum FoodPlate {
    static func scaled(_ item: FoodAIItem,by factor: Double,reason: String) -> FoodAIItem? {
        guard factor.isFinite,factor > 0 else { return nil }
        var next = item
        next.grams *= factor; next.macros = item.macros.scaled(factor)
        next.quantity?.count = next.quantity?.count.map { $0 * factor }
        var basis = next.nutritionBasis ?? FoodNutritionBasis(resolution: "ai")
        basis.servings = basis.servings.map { $0 * factor }
        basis.quantityCount = basis.quantityCount.map { $0 * factor }
        basis.portionBasis = reason; basis.portionReviewed = true
        next.nutritionBasis = basis
        next.photoGrams = item.photoGrams ?? item.grams; next.photoMacros = item.photoMacros ?? item.macros
        return next.valid ? next : nil
    }
    static func calories(_ item: FoodAIItem,target: Double) -> FoodAIItem? {
        guard target.isFinite,target > 0,target <= 20000,item.macros.calories > 0 else { return nil }
        return scaled(item,by: target / item.macros.calories,reason: "Your calorie amount; weight and other nutrients estimated")
    }
    static func qualityWarnings(_ item: FoodAIItem) -> [String] {
        var warnings: [String] = []
        let m = item.macros
        // Count-only sources have no supported gram weight; don't use photo grams
        // to reject their published per-serving nutrition.
        let independentCount = item.nutritionBasis?.servings != nil && item.nutritionBasis?.referenceGrams == nil
        if !independentCount && (m.protein + m.carbs + m.fat > item.grams * 1.15 + 2 || m.calories > item.grams * 9.5 + 10) {
            warnings.append("Nutrition is unusually dense for this weight. Check grams, units and the food match.")
        }
        let energy = m.macroCalories - min(m.fiber,m.carbs) * 2
        if max(m.calories,energy) > 75 && abs(m.calories - energy) > max(75,max(m.calories,energy) * 0.35) {
            warnings.append("Calories and macros disagree substantially. Check the label or choose a database match.")
        }
        return warnings
    }
    static func added(_ food: FoodItem,grams: Double? = nil) -> FoodAIItem {
        let weight = grams ?? food.portions.first?.grams ?? food.referenceGrams
        return FoodAIItem(name: food.name,grams: weight,macros: food.nutrition(grams: weight),uncertainty: "Review the amount you ate",matchedFood: food,nutritionBasis: FoodNutritionBasis(sourceFoodID: food.id,referenceGrams: food.referenceGrams,referenceMacros: food.macros,fiberMissing: food.fiberMissing,resolution: "library",portionBasis: "Selected library portion; confirm amount eaten",identityReviewed: true,portionReviewed: false))
    }
    static func expanded(_ item: FoodAIItem) -> [FoodAIItem]? {
        guard let recipe = item.matchedFood,let ingredients = recipe.ingredients,!ingredients.isEmpty,ingredients.count <= 30,item.nutritionBasis?.adjusted != true else { return nil }
        let factor = item.grams / recipe.referenceGrams
        let children = ingredients.map { ingredient in
            FoodAIItem(name: ingredient.name,grams: ingredient.grams * factor,macros: ingredient.macros.scaled(factor),uncertainty: "Saved recipe ingredient; review substitutions and amount",nutritionBasis: FoodNutritionBasis(sourceFoodID: ingredient.foodID,referenceGrams: ingredient.grams,referenceMacros: ingredient.macros,resolution: "library",portionBasis: "Saved recipe ingredient scaled to your portion",identityReviewed: true,portionReviewed: item.nutritionBasis?.portionReviewed))
        }
        let total = children.reduce(FoodMacros()) { $0 + $1.macros }
        guard children.allSatisfy(\.valid),abs(total.calories - item.macros.calories) < 0.01,[total.protein - item.macros.protein,total.carbs - item.macros.carbs,total.fat - item.macros.fat,total.fiber - item.macros.fiber].allSatisfy({ abs($0) < 0.01 }) else { return nil }
        return children
    }
    static func recipe(_ items: [FoodAIItem],name: String) -> FoodItem? {
        let title = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !items.isEmpty,items.allSatisfy(\.valid),!title.isEmpty,title.count <= 100 else { return nil }
        let weight = items.reduce(0) { $0 + $1.grams }
        let ingredients = items.map { MealIngredient(foodID: $0.matchedFood?.id ?? $0.nutritionBasis?.sourceFoodID ?? "reviewed-" + $0.id,name: $0.name,grams: $0.grams,macros: $0.macros) }
        let food = FoodItem(id: "recipe-" + UUID().uuidString,name: title,category: "Recipe",source: "Your reviewed meal · estimates retained",referenceGrams: weight,macros: items.reduce(FoodMacros()) { $0 + $1.macros },portions: [FoodPortion(name: "1 saved meal",grams: weight)],ingredients: ingredients)
        return food.valid ? food : nil
    }
}
extension FoodAIItem {
    var needsIdentityReview: Bool { nutritionBasis?.identityReviewed != true && nutritionBasis?.resolution != "restaurant" && nutritionBasis?.resolution != "library" }
    var needsPortionReview: Bool { nutritionBasis?.portionReviewed != true && quantity?.weightBasis != "user" && !(nutritionBasis?.servings != nil && quantity?.basis == "user") }
}
