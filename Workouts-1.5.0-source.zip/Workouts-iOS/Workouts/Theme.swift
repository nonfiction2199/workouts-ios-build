import SwiftUI

// A small set of deliberate palettes. Layout, type sizes and hit targets are
// shared; color is the only variable when switching styles.
struct ThemeColors {
    let background: UInt32
    let surface: UInt32
    let control: UInt32
    let secondary: UInt32
    let separator: UInt32
    let blue: UInt32
    let ringBlue: UInt32
    let coral: UInt32
    let teal: UInt32
    let action: UInt32
    let actionText: UInt32
    let bodySilhouette: UInt32
    let bodyNeutral: UInt32
}

extension UInt32 {
    var uiColor: UIColor {
        UIColor(red: CGFloat((self >> 16) & 0xff) / 255,
                green: CGFloat((self >> 8) & 0xff) / 255,
                blue: CGFloat(self & 0xff) / 255, alpha: 1)
    }
    var swiftColor: Color { Color(uiColor: uiColor) }
}

enum AppTheme: String, CaseIterable, Identifiable {
    case system, light, dark, fieldNotes, blueprint, terracotta, cinder, studio
    var id: String { rawValue }
    static var current: AppTheme { AppTheme(rawValue: UserDefaults.standard.string(forKey: "appearance") ?? "dark") ?? .dark }
    var name: String {
        switch self {
        case .system: "System"
        case .light: "Light"
        case .dark: "Dark"
        case .fieldNotes: "Field Notes"
        case .blueprint: "Blueprint"
        case .terracotta: "Terracotta"
        case .cinder: "Cinder"
        case .studio: "Studio"
        }
    }
    var colorScheme: ColorScheme? {
        switch self {
        case .system: nil
        case .light, .fieldNotes, .terracotta, .studio: .light
        case .dark, .blueprint, .cinder: .dark
        }
    }
    func resolved(for style: UIUserInterfaceStyle) -> AppTheme {
        self == .system ? (style == .dark ? .dark : .light) : self
    }
    var colors: ThemeColors {
        switch self {
        case .system: return Self.dark.colors // Previews resolve System with the current device style.
        case .dark:
            return ThemeColors(background: 0x141414, surface: 0x1F1F1F, control: 0x383838,
                secondary: 0xC7C7C7, separator: 0x474747, blue: 0x2878F2,
                ringBlue: 0x528CFF, coral: 0xFF805C, teal: 0x00B3C2,
                action: 0xFFFFFF, actionText: 0x141414, bodySilhouette: 0x404040, bodyNeutral: 0x5E5E5E)
        case .light:
            return ThemeColors(background: 0xF5F5F5, surface: 0xFFFFFF, control: 0xEBEBEB,
                secondary: 0x666666, separator: 0xDBDBDB, blue: 0x2878F2,
                ringBlue: 0x528CFF, coral: 0xE36648, teal: 0x087D89,
                action: 0x171717, actionText: 0xFFFFFF, bodySilhouette: 0xC7C7C7, bodyNeutral: 0xA3A3A3)
        case .fieldNotes:
            // Worn field notebook: cream paper, botanical green, muted brass.
            return ThemeColors(background: 0xECEDE3, surface: 0xFAFAF2, control: 0xDBE2D3,
                secondary: 0x56645A, separator: 0xC2CCBD, blue: 0x367B68,
                ringBlue: 0x498574, coral: 0xA65C35, teal: 0x3B806B,
                action: 0x275140, actionText: 0xFFFFFF, bodySilhouette: 0xB7C4B3, bodyNeutral: 0x889F8C)
        case .blueprint:
            // Drafting table: ink blue, ruled slate, pale technical cyan.
            return ThemeColors(background: 0x091727, surface: 0x11253A, control: 0x233B50,
                secondary: 0xB1C8D4, separator: 0x385066, blue: 0x80D5DF,
                ringBlue: 0x71B4E8, coral: 0xF29A75, teal: 0x76CDC7,
                action: 0xB8E8E7, actionText: 0x09202D, bodySilhouette: 0x284056, bodyNeutral: 0x49647A)
        case .terracotta:
            // Sun-baked plaster with clay and olive accents.
            return ThemeColors(background: 0xEFE4D7, surface: 0xFCF5EB, control: 0xE8D3C2,
                secondary: 0x68574D, separator: 0xD7BFAF, blue: 0xA54D3C,
                ringBlue: 0xB2634A, coral: 0xA74732, teal: 0x657A53,
                action: 0x914232, actionText: 0xFFFFFF, bodySilhouette: 0xD3B9A7, bodyNeutral: 0xB88F78)
        case .cinder:
            // Smoke and copper, like a blackened steel gym interior.
            return ThemeColors(background: 0x191918, surface: 0x242421, control: 0x393A35,
                secondary: 0xC9C6BC, separator: 0x515149, blue: 0xD8AC72,
                ringBlue: 0xE4BB81, coral: 0xE79868, teal: 0xA8BA91,
                action: 0xE8C692, actionText: 0x25211C, bodySilhouette: 0x3C3D37, bodyNeutral: 0x65685E)
        case .studio:
            // Clean editorial studio: cool white, cobalt, restrained red.
            return ThemeColors(background: 0xE8ECF1, surface: 0xFCFDFE, control: 0xDCE4EE,
                secondary: 0x526071, separator: 0xC3CFDB, blue: 0x254DB1,
                ringBlue: 0x3465CE, coral: 0xBD4C43, teal: 0x2B7384,
                action: 0x234AA8, actionText: 0xFFFFFF, bodySilhouette: 0xBAC9DA, bodyNeutral: 0x91A8C3)
        }
    }
}
