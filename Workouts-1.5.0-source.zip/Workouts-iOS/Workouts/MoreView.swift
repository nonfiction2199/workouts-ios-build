import SwiftUI
import UniformTypeIdentifiers

struct MoreView: View {
    @EnvironmentObject var store: TrainingStore
    @Environment(\.colorScheme) private var colorScheme
    let open: (AppSheet) -> Void
    @AppStorage("appearance") private var appearance = "dark"
    @State private var importing = false
    @State private var exportURL: URL?
    @State private var about = false
    @State private var weightTrend = false
    @State private var visibility = false
    @State private var tutorials = false
    var body: some View {
        ScrollViewReader { reader in
        ScrollView {
            VStack(alignment: .leading,spacing: 32) {
                ScreenTitle(text: "More")
                HStack(spacing: 14) {
                    Image(systemName: "person.crop.circle.fill").font(.system(size: 44))
                    VStack(alignment: .leading,spacing: 5) { Text("Personal Workouts").font(.headline); Text("Saved on this iPhone").font(.caption).foregroundStyle(Palette.secondary) }
                    Spacer()
                }
                VStack(alignment: .leading,spacing: 16) {
                    SectionHeading(title: "General")
                    VStack(spacing: 0) {
                        SettingsRow(title: "Preferences",symbol: "slider.horizontal.3") { open(.preferences) }; Divider().overlay(Palette.separator).padding(.leading, 64)
                        SettingsRow(title: "Workout History",symbol: "clock.arrow.circlepath") { open(.history) }; Divider().overlay(Palette.separator).padding(.leading, 64)
                        SettingsRow(title: "Exercise Library",symbol: "list.bullet.rectangle") { open(.catalog) }; Divider().overlay(Palette.separator).padding(.leading,64)
                        SettingsRow(title: "Nutrition",symbol: "fork.knife",subtitle: "Food diary, meals and macro goals") { Haptics.tick(); open(.nutrition) }
                    }.card()
                }
                VStack(alignment: .leading,spacing: 16) {
                    SectionHeading(title: "Feature Settings")
                    VStack(spacing: 0) {
                        SettingsRow(title: "Dashboard",symbol: "square.grid.2x2.fill") { open(.dashboardSettings) }; Divider().overlay(Palette.separator).padding(.leading,64)
                        SettingsRow(title: "Workout",symbol: "dumbbell.fill") { open(.programEditor) }; Divider().overlay(Palette.separator).padding(.leading,64)
                        SettingsRow(title: "Shortcuts",symbol: "point.topleft.down.to.point.bottomright.curvepath") { open(.shortcutSettings) }; Divider().overlay(Palette.separator).padding(.leading,64)
                        SettingsRow(title: "Weight Trend",symbol: "scalemass.fill") { Haptics.tick(); weightTrend = true }; Divider().overlay(Palette.separator).padding(.leading,64)
                        SettingsRow(title: "Exercises",symbol: "list.bullet.rectangle.fill") { open(.catalog) }

                    }.card()
                }
                VStack(alignment: .leading,spacing: 16) {
                    SectionHeading(title: "Theme")
                    LazyVGrid(columns: [GridItem(.flexible(), spacing: 12), GridItem(.flexible(), spacing: 12)], spacing: 16) {
                        ForEach(AppTheme.allCases) { theme in themeTile(theme) }
                    }
                }.id("theme-picker")
                VStack(alignment: .leading,spacing: 16) {
                    SectionHeading(title: "Data Management")
                    VStack(spacing: 0) {
                        SettingsRow(title: "Export Workout Backup",symbol: "square.and.arrow.up",subtitle: "Workouts, program and custom exercises") { Haptics.tick(); do { exportURL = try store.exportData() } catch { store.error = error.localizedDescription } }; Divider().overlay(Palette.separator).padding(.leading,64)
                        SettingsRow(title: "Import Workout Backup",symbol: "square.and.arrow.down",subtitle: "Bring history from your web app") { Haptics.tick(); importing = true }
                    }.card()
                    SettingsRow(title: "Data Visibility",symbol: "eye.fill",subtitle: "Choose your dashboard sections") { visibility = true }.card()
                    Text("Workouts are stored on this iPhone. Export a backup before reinstalling or changing signing certificates. Photo and measurement records are stored separately on this device.").font(.footnote).foregroundStyle(Palette.secondary)
                }
                VStack(alignment: .leading,spacing: 16) {
                    SectionHeading(title: "Other")
                    VStack(spacing: 0) {
                        SettingsRow(title: "Tutorials",symbol: "questionmark.circle") { tutorials = true }
                        Divider().overlay(Palette.separator).padding(.leading,64)
                        SettingsRow(title: "About & Updates",symbol: "info.circle") { about = true }
                    }.card()
                }
                Text("Version \(Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "")").font(.caption).foregroundStyle(Palette.secondary).frame(maxWidth: .infinity)
            }.padding(16)
        }
        .onAppear {
            #if DEBUG
            if ProcessInfo.processInfo.environment["WORKOUTS_PREVIEW_SCREEN"] == "theme-picker" {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) { reader.scrollTo("theme-picker", anchor: .top) }
            }
            #endif
        }
        }
        .sheet(isPresented: $visibility) { DisplaySettingsView(shortcuts: false) }
        .sheet(isPresented: $tutorials) { WorkoutHelpView() }
        .fileImporter(isPresented: $importing,allowedContentTypes: [.json]) { result in switch result { case .success(let url): store.importData(url); case .failure(let error): store.error = error.localizedDescription } }
        .sheet(isPresented: Binding(get: { exportURL != nil },set: { if !$0 { exportURL = nil } })) { if let exportURL { ShareSheet(url: exportURL) } }
        .sheet(isPresented: $about) { AboutView() }
        .sheet(isPresented: $weightTrend) { UtilityView(kind: .weight) }
    }
    private func themeTile(_ theme: AppTheme) -> some View {
        let colors = theme.resolved(for: colorScheme == .dark ? .dark : .light).colors
        let ink = theme.colorScheme == .dark || (theme == .system && colorScheme == .dark) ? Color.white : Color.black
        return Button { appearance = theme.rawValue; Haptics.tick() } label: {
            VStack(alignment: .leading, spacing: 8) {
                VStack(alignment: .leading, spacing: 8) {
                    HStack(spacing: 5) {
                        RoundedRectangle(cornerRadius: 2).fill(colors.action.swiftColor).frame(width: 13,height: 13)
                        RoundedRectangle(cornerRadius: 2).fill(colors.coral.swiftColor).frame(width: 13,height: 13)
                        RoundedRectangle(cornerRadius: 2).fill(colors.teal.swiftColor).frame(width: 13,height: 13)
                        Spacer()
                        Circle().stroke(colors.secondary.swiftColor,lineWidth: 2).frame(width: 13,height: 13)
                    }
                    HStack(alignment: .bottom, spacing: 7) {
                        VStack(alignment: .leading, spacing: 6) {
                            RoundedRectangle(cornerRadius: 2).fill(ink.opacity(0.85)).frame(width: 45,height: 5)
                            RoundedRectangle(cornerRadius: 2).fill(colors.secondary.swiftColor).frame(width: 31,height: 4)
                        }
                        Spacer(minLength: 0)
                        RoundedRectangle(cornerRadius: 4).fill(colors.control.swiftColor).frame(width: 36,height: 30)
                            .overlay(Circle().fill(colors.blue.swiftColor).frame(width: 14,height: 14))
                    }.padding(9).background(colors.surface.swiftColor, in: RoundedRectangle(cornerRadius: 7))
                }.padding(10).frame(height: 87).background(colors.background.swiftColor, in: RoundedRectangle(cornerRadius: 10))
                HStack(spacing: 5) {
                    Text(theme.name).font(.system(size: 14,weight: appearance == theme.rawValue ? .semibold : .regular)).lineLimit(1)
                    Spacer(minLength: 0)
                    if appearance == theme.rawValue { Image(systemName: "checkmark.circle.fill").foregroundStyle(Palette.action) }
                }
            }.padding(5).overlay(RoundedRectangle(cornerRadius: 14).stroke(appearance == theme.rawValue ? Palette.action : Palette.separator, lineWidth: appearance == theme.rawValue ? 2 : 1))
        }.buttonStyle(.plain).accessibilityLabel("\(theme.name) theme").accessibilityAddTraits(appearance == theme.rawValue ? .isSelected : [])
    }

}
struct PreferencesView: View {
    @EnvironmentObject var store: TrainingStore
    @Environment(\.dismiss) var dismiss
    @AppStorage("restNotifications") private var notifications = false
    @AppStorage("appearance") private var appearance = "dark"
    @State private var progression = false
    var body: some View {
        NavigationStack {
            Form {
                Section("Rest Timer") { Toggle("Notify when rest finishes",isOn: Binding(get: { notifications },set: { value in Task { await store.setNotifications(value) } })); Text("An alert is scheduled after a completed set. Rest timing continues when you switch apps.").font(.footnote).foregroundStyle(Palette.secondary) }
                Section("Appearance") { Picker("Theme",selection: Binding(get: { appearance },set: { appearance = $0; Haptics.tick() })) { ForEach(AppTheme.allCases) { theme in Text(theme.name).tag(theme.rawValue) } } }
                Section("Training") { Button("Progression") { Haptics.tick(); progression = true } }
                Section("Workout Units") { LabeledContent("Load",value: "Pounds (lb)"); Text("This build uses the same pound-based loads as the existing web app. Imported numbers are kept unchanged.").font(.footnote).foregroundStyle(Palette.secondary) }
                Section("Haptics") { Text("Enabled for workout actions, shortcut actions and setting changes. Dashboard buttons and bottom tabs stay silent.").font(.footnote).foregroundStyle(Palette.secondary) }
            }.sheet(isPresented: $progression) { ProgressionView() }.darkForm().navigationTitle("Preferences").navigationBarTitleDisplayMode(.inline).toolbar { ToolbarItem(placement: .cancellationAction) { Button("Done") { dismiss() } } }
        }
    }
}
struct ProgressionView: View {
    @EnvironmentObject var store: TrainingStore
    @Environment(\.dismiss) var dismiss
    private var settings: ProgressionSettings? { store.state?.settings.progression }
    var body: some View {
        NavigationStack {
            Form {
                Section(store.analysis?.review.status ?? "Learning") { Text(store.analysis?.review.message ?? "Log working sets to build your performance history.") }
                Section("Recommendations") {
                    Toggle("Adapt during workout",isOn: bool("applyInSession",value: settings?.applyInSession ?? true))
                    Toggle("Expand rep range when useful",isOn: bool("expandRepRange",value: settings?.expandRepRange ?? true))
                    Toggle("Match equipment increments",isOn: bool("weightMatch",value: settings?.weightMatch ?? true))
                    Picker("Starting prescription",selection: Binding(get: { settings?.initialFill ?? "smart" },set: { save(["initialFill": $0]) })) { Text("Smart").tag("smart"); Text("Previous workout").tag("previous") }
                    Stepper("Maximum load increase: \((settings?.maxIncreasePercent ?? 5).short)%",value: Binding(get: { settings?.maxIncreasePercent ?? 5 },set: { save(["maxIncreasePercent": $0]) }),in: 1...10)
                }
                Section("Program Cycles") {
                    Toggle("Six-cycle periodization",isOn: Binding(get: { store.state?.settings.periodize ?? true },set: { _ = store.send("settings",["values": ["periodize": $0]],haptic: true) }))
                    Toggle("Scheduled deload",isOn: Binding(get: { store.state?.settings.deload ?? true },set: { _ = store.send("settings",["values": ["deload": $0]],haptic: true) }))
                    Picker("Deload cycle",selection: Binding(get: { store.state?.settings.deloadTiming ?? "last" },set: { _ = store.send("settings",["values": ["deloadTiming": $0]],haptic: true) })) { Text("First").tag("first"); Text("Last").tag("last") }
                }
                Section("How it works") { Text("The engine uses your recent completed working sets, reps in reserve, equipment increments and within-workout fatigue. Manually edited and completed sets stay protected. This is our independent model; it is not MacroFactor’s proprietary algorithm.").font(.footnote).foregroundStyle(Palette.secondary) }
            }.darkForm().navigationTitle("Progression").navigationBarTitleDisplayMode(.inline).toolbar { ToolbarItem(placement: .cancellationAction) { Button("Done") { dismiss() } } }
        }
    }
    private func bool(_ key: String,value: Bool) -> Binding<Bool> { Binding(get: { value },set: { save([key: $0]) }) }
    private func save(_ values: [String: Any]) { _ = store.send("settings",["values": ["progression": values]],haptic: true) }
}
struct AboutView: View {
    @Environment(\.dismiss) var dismiss
    var body: some View {
        NavigationStack {
            List {
                Section { Text("Workouts").font(.title.bold()); LabeledContent("Version",value: "\(Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "1.0.0") (\(Bundle.main.infoDictionary?["CFBundleVersion"] as? String ?? "1"))"); Text("Personal workout tracker. Independently developed and not affiliated with MacroFactor.").font(.footnote).foregroundStyle(Palette.secondary) }
                Section("Install an update") { Text("1. Export your workout backup in More.\n\n2. Upload the new Workouts IPA to Signulous.\n\n3. Keep the same bundle identifier and signing options. Install over this app; do not delete it first.\n\nUpdates are installed manually through Signulous."); Link("Open Signulous",destination: URL(string: "https://www.signulous.com/sign-apps")!) }
                Section("Licenses") { NavigationLink("Demonstration Credits") { DemoCreditsView() }; Text("Workouts Display is a modified Unbounded font under SIL Open Font License 1.1; it is an independent approximation, not MacroSans. Exercise catalogue credits are included with the source project.").font(.footnote) }
            }.darkForm().navigationTitle("About & Updates").navigationBarTitleDisplayMode(.inline).toolbar { ToolbarItem(placement: .cancellationAction) { Button("Done") { dismiss() } } }
        }
    }
}

struct DisplaySettingsView: View {
    let shortcuts: Bool
    @Environment(\.dismiss) private var dismiss
    private var keys: [(String,String)] {
        shortcuts ? [("shortcutWeight","Weight"),("shortcutPhotos","Photos"),("shortcutMetrics","Metrics"),("shortcutHistory","History"),("shortcutNutrition","Nutrition")] : [("dashboardInsights","Insights & Analytics"),("dashboardHabits","Habits"),("dashboardMetrics","Body Metrics"),("dashboardMuscles","Muscle Groups"),("dashboardExercises","Exercises")]
    }
    var body: some View {
        NavigationStack {
            Form { Section("Visible Items") { ForEach(keys,id: \.0) { key, name in PreferenceToggle(key: key, title: name) } } }
                .darkForm().navigationTitle(shortcuts ? "Shortcuts" : "Dashboard").navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { Haptics.tick(); dismiss() } } }
        }
    }
}
private struct PreferenceToggle: View {
    let key: String
    let title: String
    @State private var enabled = true
    var body: some View {
        Toggle(title,isOn: $enabled).onAppear { enabled = UserDefaults.standard.object(forKey: key) as? Bool ?? true }
            .onChange(of: enabled) { UserDefaults.standard.set(enabled,forKey: key); Haptics.tick() }
    }
}
