import SwiftUI

struct BodyRegion: Decodable { var name: String; var paired: Bool; var d: String }
struct BodyGeometry: Decodable {
    var silhouette: String; var front: [BodyRegion]; var back: [BodyRegion]
    static let shared: BodyGeometry? = {
        guard let url = Bundle.main.url(forResource: "body-map",withExtension: "json"),let data = try? Data(contentsOf: url) else { return nil }
        return try? JSONDecoder().decode(BodyGeometry.self,from: data)
    }()
}
// All geometry is authored in one 224 × 465 coordinate system. Both sides use
// the same scale and center; thumbnails use a view-box crop, never offsets.
struct MuscleShape: Shape {
    let data: String; var paired = false; var crop: CGRect = CGRect(x: 0,y: 0,width: 224,height: 465)
    func path(in rect: CGRect) -> Path {
        var p = SVGPath.parse(data)
        if paired { p.addPath(SVGPath.parse(data).applying(CGAffineTransform(a: -1,b: 0,c: 0,d: 1,tx: 224,ty: 0))) }
        let scale = min(rect.width/crop.width,rect.height/crop.height)
        return p.applying(CGAffineTransform(a: scale,b: 0,c: 0,d: scale,tx: rect.midX-crop.midX*scale,ty: rect.midY-crop.midY*scale))
    }
}
enum SVGPath {
    static func parse(_ value: String) -> Path {
        let regex = try! NSRegularExpression(pattern: "[MLHVQCZ]|-?[0-9]+(?:\\.[0-9]+)?")
        let ns = value as NSString
        let tokens = regex.matches(in: value,range: NSRange(location: 0,length: ns.length)).map { ns.substring(with: $0.range) }
        var path = Path(); var i = 0; var command = ""; var point = CGPoint.zero; var start = CGPoint.zero
        func n() -> CGFloat { defer { i += 1 }; return CGFloat(Double(tokens[i]) ?? 0) }
        func xy() -> CGPoint { let x = n(); return CGPoint(x: x,y: n()) }
        while i < tokens.count {
            if tokens[i].first?.isLetter == true { command = tokens[i]; i += 1 }
            switch command {
            case "M": guard i+1 < tokens.count else { return path }; point = xy(); start = point; path.move(to: point); command = "L"
            case "L": guard i+1 < tokens.count else { return path }; point = xy(); path.addLine(to: point)
            case "H": guard i < tokens.count else { return path }; point.x = n(); path.addLine(to: point)
            case "V": guard i < tokens.count else { return path }; point.y = n(); path.addLine(to: point)
            case "Q": guard i+3 < tokens.count else { return path }; let control = xy(); point = xy(); path.addQuadCurve(to: point,control: control)
            case "C": guard i+5 < tokens.count else { return path }; let c1 = xy(); let c2 = xy(); point = xy(); path.addCurve(to: point,control1: c1,control2: c2)
            case "Z": path.closeSubpath(); point = start; command = ""
            default: return path
            }
        }
        return path
    }
}
struct BodyMap: View {
    var levels: [String: MuscleLevel] = [:]
    var back = false
    var selected: String? = nil
    var thumbnail = false
    var select: ((String) -> Void)? = nil
    private var crop: CGRect {
        guard thumbnail, let selected else { return CGRect(x: 0,y: 0,width: 224,height: 465) }
        if ["Calves","Tibialis"].contains(selected) { return CGRect(x: 58,y: 328,width: 108,height: 134) }
        if lowerMuscles.contains(selected) { return CGRect(x: 54,y: 193,width: 116,height: 145) }
        if selected == "Forearms" { return CGRect(x: 15,y: 147,width: 194,height: 91) }
        return CGRect(x: 39,y: 59,width: 146,height: 136)
    }
    var body: some View {
        ZStack {
            if let geometry = BodyGeometry.shared {
                MuscleShape(data: geometry.silhouette,crop: crop).fill(Palette.bodySilhouette)
                ForEach(Array((back ? geometry.back : geometry.front).enumerated()),id: \.offset) { _, region in
                    MuscleShape(data: region.d,paired: region.paired,crop: crop)
                        .fill(thumbnail && region.name == selected ? Palette.blue : heat(levels[region.name]?.weekly ?? 0))
                        .contentShape(MuscleShape(data: region.d,paired: region.paired,crop: crop))
                        .onTapGesture { select?(region.name) }
                        .accessibilityLabel("\(region.name), \((levels[region.name]?.weekly ?? 0).short) weekly sets")
                        .accessibilityAddTraits(select == nil ? [] : .isButton)
                }
            }
        }.clipped().accessibilityHidden(thumbnail)
    }
    private func heat(_ value: Double) -> Color {
        if value <= 0 { return Palette.bodyNeutral }
        return Palette.blue.opacity(min(1,0.55+value/40))
    }
}
struct LevelsView: View {
    @EnvironmentObject var store: TrainingStore
    @State private var back = false
    @State private var selected: String?
    @State private var choosingPeriod = false
    private var levels: [String: MuscleLevel] { store.analysis?.levels ?? [:] }
    private var empty: Bool { !levels.values.contains { $0.weekly > 0 } }
    var body: some View {
        ScrollView {
            VStack(spacing: 0) {
                VStack(spacing: 20) {
                    ScreenTitle(text: "Levels").frame(maxWidth: .infinity,alignment: .leading)
                    ZStack(alignment: .bottomTrailing) {
                        ZStack {
                            BodyMap(levels: levels,back: back,select: { selected = $0 }).frame(width: 214).frame(maxWidth: .infinity)
                            if empty { Text("Complete workouts\nto see your Set Levels").font(.title3).foregroundStyle(Palette.secondary).multilineTextAlignment(.center).offset(y: -40).allowsHitTesting(false) }
                        }.frame(height: 440)
                        CircleAction(symbol: "arrow.triangle.2.circlepath",label: "Show \(back ? "front" : "back") muscles", diameter: 48) { back.toggle() }
                    }
                    HStack(spacing: 7) {
                        Circle().fill(Palette.blue).frame(width: 8,height: 8)
                        Text("Average weekly sets over").font(.system(size: 14))
                        Button { choosingPeriod = true } label: { Text(store.days == 7 ? "1-week" : store.days == 30 ? "1-month" : "3-months").underline().font(.system(size: 14)); Image(systemName: "chevron.down").font(.caption2) }

                    }.fixedSize(horizontal: false, vertical: true).padding(.bottom, 6)
                }.padding(.horizontal,16).padding(.top,10).padding(.bottom,16).background(Palette.surface)
                VStack(spacing: 30) { group("Upper Body Levels",muscles: upperMuscles); group("Lower Body Levels",muscles: lowerMuscles) }.padding(16).padding(.top, 14)
            }
        }.background(Palette.background, ignoresSafeAreaEdges: []).sheet(isPresented: $choosingPeriod) { LevelPeriodSheet(days: $store.days) }.sheet(isPresented: Binding(get: { selected != nil },set: { if !$0 { selected = nil } })) { if let selected { MuscleDetailView(name: selected,level: levels[selected]) } }
    }
    private func group(_ title: String,muscles: [String]) -> some View {
        VStack(alignment: .leading,spacing: 16) {
            SectionHeading(title: title)
            VStack(spacing: 0) {
                ForEach(muscles,id: \.self) { name in
                    Button { selected = name } label: {
                        HStack(spacing: 16) { BodyMap(back: rearMuscles.contains(name),selected: name,thumbnail: true).frame(width: 64,height: 64); VStack(alignment: .leading,spacing: 6) { Text(name == "Traps" ? "Upper Traps" : name).font(.system(size: 16)); Text("\((levels[name]?.weekly ?? 0).short) sets").foregroundStyle(Palette.secondary) }; Spacer(); Image(systemName: "chevron.right").foregroundStyle(.tertiary) }.padding(.horizontal, 14).padding(.vertical, 12).contentShape(Rectangle())
                    }.buttonStyle(.plain)
                    if name != muscles.last { Divider().overlay(Palette.separator).padding(.leading, 98) }
                }
            }.card()
        }
    }
}
struct MuscleDetailView: View {
    let name: String; let level: MuscleLevel?
    var body: some View {
        NavigationStack {
            List {
                Section { BodyMap(back: rearMuscles.contains(name),selected: name,thumbnail: true).frame(height: 140).frame(maxWidth: .infinity); Text("\((level?.weekly ?? 0).short) average weekly sets").font(.headline) }
                Section("Contributing exercises") { ForEach(level?.lifts ?? []) { lift in HStack { Text(lift.name); Spacer(); Text(lift.weighted.short).foregroundStyle(Palette.secondary) } } }
                Section { Text("Completed working sets count as 1 for a primary muscle and 0.5 for a secondary muscle. Warm-ups are excluded. This shows training volume, not measured recovery.").font(.footnote).foregroundStyle(Palette.secondary) }
            }.darkForm().navigationTitle(name).navigationBarTitleDisplayMode(.inline)
        }.presentationDragIndicator(.visible)
    }
}

struct LevelPeriodSheet: View {
    @Binding var days: Int
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        VStack(spacing: 0) {
            HStack { Button { dismiss() } label: { Image(systemName: "xmark").frame(width: 44,height: 44) }; Text("Time Period").font(.headline).frame(maxWidth: .infinity); Color.clear.frame(width: 44,height: 44) }.padding(10)
            ForEach([7,30,90],id: \.self) { value in
                Divider().overlay(Palette.separator)
                Button { days = value; dismiss() } label: { HStack { Text(value == 7 ? "1-week" : value == 30 ? "1-month" : "3-months"); Spacer(); Image(systemName: days == value ? "record.circle" : "circle") }.font(.subheadline).padding(20) }.buttonStyle(.plain)
            }
        }.background(Palette.surface).presentationDetents([.height(260)]).presentationDragIndicator(.visible)
    }
}
