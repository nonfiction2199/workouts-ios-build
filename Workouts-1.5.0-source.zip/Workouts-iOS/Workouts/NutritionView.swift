import SwiftUI
import UniformTypeIdentifiers

// All nutrition surfaces use the same semantic palette as the workout app.
enum NutritionRoute: String, Identifiable {
    case search, custom, recipe, goals, photo, library, quick
    var id: String { rawValue }
}
struct NutritionView: View {
    @EnvironmentObject private var nutrition: NutritionStore
    @Environment(\.dismiss) private var dismiss
    var initial: NutritionRoute? = nil
    @State private var date = Date()
    @State private var route: NutritionRoute?
    @State private var selectedEntry: FoodLogEntry?
    @State private var exportURL: URL?
    @State private var importing = false
    @State private var copied = false
    @State private var searchMeal: FoodMeal = .lunch
    private var entries: [FoodLogEntry] { nutrition.entries(on: date) }
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading,spacing: 22) {
                    HStack { ScreenTitle(text: "Nutrition"); Spacer(); Button { route = .goals; Haptics.tick() } label: { Image(systemName: "slider.horizontal.3").frame(width: 44,height: 44).background(Palette.control,in: Circle()) }.accessibilityLabel("Nutrition goals").accessibilityIdentifier("nutrition-goals-button") }
                    dateSelector
                    NutritionSummary(macros: nutrition.total(on: date),goals: nutrition.state.goals)
                    if nutrition.state.goals == nil { Button { route = .goals } label: { Label("Set your calorie and macro goals",systemImage: "target").font(.subheadline.weight(.semibold)).frame(maxWidth: .infinity,alignment: .leading).padding(16).card() }.buttonStyle(.plain) }
                    HStack(spacing: 10) { action("Log Food",symbol: "plus",route: .search); action("Photo",symbol: "camera",route: .photo); action("Quick Add",symbol: "bolt",route: .quick) }
                    HStack { SectionHeading(title: "Food Diary"); Menu { Button("Copy yesterday’s foods") { copyYesterday() }; Button("Saved foods & meals") { route = .library }; Button("Export nutrition backup") { do { exportURL = try nutrition.export() } catch { nutrition.error = error.localizedDescription } }; Button("Import nutrition backup") { importing = true } } label: { Image(systemName: "ellipsis.circle").font(.title2).frame(width: 44,height: 44) } }
                    if nutrition.blocked { ContentUnavailableView("Nutrition needs recovery",systemImage: "externaldrive.badge.exclamationmark",description: Text("Your saved file has been kept unchanged. Workout data is stored separately.")) }
                    else {
                        ForEach(FoodMeal.allCases) { meal in mealSection(meal) }
                    }
                    weeklyCard
                    HStack(spacing: 12) { action("Custom Food",symbol: "square.and.pencil",route: .custom); action("New Recipe",symbol: "book",route: .recipe) }
                    Text("Food values describe a typical preparation. For your exact recipe, weigh ingredients and save your own meal.").font(.footnote).foregroundStyle(Palette.secondary)
                }.padding(16)
            }.background(Palette.background).navigationBarTitleDisplayMode(.inline)
                .onChange(of: date) { copied = false }
                .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Done") { dismiss() } } }
                .sheet(item: $route) { item in routeView(item).presentationBackground(Palette.background).presentationDragIndicator(.visible) }
                .sheet(item: $selectedEntry) { FoodEntryEditor(entry: $0) }
                .sheet(isPresented: Binding(get: { exportURL != nil },set: { if !$0 { exportURL = nil } })) { if let exportURL { ShareSheet(url: exportURL) } }
                .fileImporter(isPresented: $importing,allowedContentTypes: [.json]) { result in switch result { case .success(let url): nutrition.importBackup(url); case .failure(let error): nutrition.error = error.localizedDescription } }
                .alert("Nutrition",isPresented: Binding(get: { nutrition.error != nil },set: { if !$0 { nutrition.error = nil } })) { Button("OK",role: .cancel) { nutrition.error = nil } } message: { Text(nutrition.error ?? "") }
                .onAppear {
                    if let initial { route = initial }
                    #if DEBUG
                    let screen = ProcessInfo.processInfo.environment["WORKOUTS_PREVIEW_SCREEN"]
                    if screen != nil { nutrition.seedPreview() }
                    if screen == "nutrition-goals" { route = .goals }
                    if screen == "food-search" { route = .search }
                    if screen == "food-library" { route = .library }
                    if screen == "food-photo" || screen == "food-match" || screen == "food-restaurant" || screen == "food-portions" { route = .photo }
                    if screen == "food-recipe" { route = .recipe }
                    #endif
                }
        }
    }
    private var dateSelector: some View {
        HStack {
            Button { move(-1) } label: { Image(systemName: "chevron.left").frame(width: 44,height: 44) }.accessibilityLabel("Previous day")
            Spacer(minLength: 0)
            DatePicker("Diary date",selection: $date,displayedComponents: .date).labelsHidden().datePickerStyle(.compact)
            Spacer(minLength: 0)
            Button { move(1) } label: { Image(systemName: "chevron.right").frame(width: 44,height: 44) }.accessibilityLabel("Next day")
        }.padding(4).background(Palette.surface,in: Capsule())
    }
    private func move(_ n: Int) { if let value = Calendar.current.date(byAdding: .day,value: n,to: date) { date = value; copied = false; Haptics.tick() } }
    private func action(_ label: String,symbol: String,route: NutritionRoute) -> some View {
        Button { Haptics.tick(); self.route = route } label: { VStack(spacing: 8) { Image(systemName: symbol).font(.system(size: 21)); Text(label).font(.system(size: 12,weight: .semibold)).multilineTextAlignment(.center) }.frame(maxWidth: .infinity,minHeight: 72).padding(4).background(Palette.control,in: RoundedRectangle(cornerRadius: 12)) }.buttonStyle(.plain)
    }
    @ViewBuilder private func routeView(_ item: NutritionRoute) -> some View {
        switch item {
        case .search: NutritionFoodSearch(date: date,initialMeal: searchMeal)
        case .library: NutritionFoodSearch(date: date,initialFilter: "My Foods")
        case .custom: CustomFoodEditor()
        case .quick: CustomFoodEditor(quickDate: date)
        case .recipe: RecipeEditor()
        case .goals: NutritionGoalsView()
        case .photo: FoodPhotoView(date: date)
        }
    }
    private func mealSection(_ meal: FoodMeal) -> some View {
        let foods = entries.filter { $0.meal == meal }
        let total = foods.reduce(FoodMacros()) { $0 + $1.macros }
        return VStack(alignment: .leading,spacing: 0) {
            HStack { Text(meal.rawValue).font(.headline); Spacer(); if !foods.isEmpty { Text("\(total.calories.short) kcal").font(.caption).foregroundStyle(Palette.secondary) }; Button { searchMeal = meal; route = .search; Haptics.tick() } label: { Image(systemName: "plus.circle").font(.title2).frame(width: 44,height: 44) }.accessibilityLabel("Add food to \(meal.rawValue)") }
                .padding(.horizontal,14).padding(.top,5)
            if foods.isEmpty { Text("No foods logged").font(.subheadline).foregroundStyle(Palette.secondary).padding(.horizontal,14).padding(.bottom,17) }
            ForEach(foods) { entry in
                Button { selectedEntry = entry; Haptics.tick() } label: {
                    HStack(alignment: .top,spacing: 12) {
                        Image(systemName: entry.estimated ? "sparkles" : "fork.knife").frame(width: 25).padding(.top,3)
                        VStack(alignment: .leading,spacing: 5) { Text(entry.name).font(.subheadline.weight(.medium)).multilineTextAlignment(.leading); Text("\(entry.grams.short) g\(entry.estimated ? " · Estimated" : "")").font(.caption).foregroundStyle(Palette.secondary); Text("P \(entry.macros.protein.short) · C \(entry.macros.carbs.short) · F \(entry.macros.fat.short)").font(.caption2).foregroundStyle(Palette.secondary) }
                        Spacer(minLength: 4); Text(entry.macros.calories.short).font(.subheadline.monospacedDigit()); Image(systemName: "chevron.right").font(.caption).foregroundStyle(Palette.secondary)
                    }.padding(14).contentShape(Rectangle())
                }.buttonStyle(.plain)
                if entry.id != foods.last?.id { Divider().padding(.leading,50) }
            }
        }.card()
    }
    private var weeklyCard: some View {
        let days = (0..<7).compactMap { Calendar.current.date(byAdding: .day,value: -$0,to: date) }.reversed()
        let logged = days.filter { !nutrition.entries(on: $0).isEmpty }
        let average = logged.isEmpty ? 0 : logged.reduce(0.0) { $0 + nutrition.total(on: $1).calories } / Double(logged.count)
        return VStack(alignment: .leading,spacing: 15) {
            HStack { Text("Last 7 Days").font(.headline); Spacer(); Text("\(logged.count) logged days").font(.caption).foregroundStyle(Palette.secondary) }
            HStack(alignment: .bottom,spacing: 12) {
                ForEach(Array(days),id: \.self) { day in
                    let amount = nutrition.total(on: day).calories
                    VStack(spacing: 7) { Capsule().fill(Palette.teal).frame(height: max(4,min(74,amount / max(nutrition.state.goals?.macros.calories ?? 2200,1) * 60))); Text(day.formatted(.dateTime.weekday(.narrow))).font(.caption2).foregroundStyle(Palette.secondary) }.frame(maxWidth: .infinity)
                }
            }.frame(height: 95,alignment: .bottom)
            Text(logged.isEmpty ? "Your nutrition history starts with your first meal." : "\(average.short) kcal average across logged days").font(.footnote).foregroundStyle(Palette.secondary)
        }.padding(16).card()
    }
    private func copyYesterday() {
        guard let previous = Calendar.current.date(byAdding: .day,value: -1,to: date) else { return }
        let source = nutrition.entries(on: previous)
        guard !source.isEmpty else { nutrition.error = "No foods were logged on the previous day."; return }
        guard !copied else { nutrition.error = "Yesterday’s foods have already been copied during this visit."; return }
        let next = source.map { old -> FoodLogEntry in var entry = old; entry.id = UUID().uuidString; entry.day = NutritionDay.key(date); entry.loggedAt = Date(); return entry }
        copied = nutrition.log(next)
    }
}
struct NutritionSummary: View {
    let macros: FoodMacros
    let goals: NutritionGoals?
    var body: some View {
        VStack(alignment: .leading,spacing: 18) {
            HStack(alignment: .center,spacing: 20) {
                ZStack {
                    Circle().stroke(Palette.control,lineWidth: 8)
                    Circle().trim(from: 0,to: min(1,goals == nil ? 0 : macros.calories / max(goals?.macros.calories ?? 1,1))).stroke(Palette.action,style: StrokeStyle(lineWidth: 8,lineCap: .round)).rotationEffect(.degrees(-90))
                    Image(systemName: "fork.knife").font(.system(size: 25))
                }.frame(width: 72,height: 72).accessibilityHidden(true)
                VStack(alignment: .leading,spacing: 5) {
                    Text("\(macros.calories.short)").font(.system(size: 35,weight: .semibold,design: .rounded)).monospacedDigit(); Text("kcal logged\(goals.map { " · " + $0.macros.calories.short + " goal" } ?? "")").font(.caption).foregroundStyle(Palette.secondary)
                    if let goals { let remaining = goals.macros.calories - macros.calories; Text(remaining >= 0 ? "\(remaining.short) remaining" : "\((-remaining).short) above goal").font(.caption).foregroundStyle(Palette.secondary) }
                }; Spacer(minLength: 0)
            }
            HStack(spacing: 14) { macro("Protein",value: macros.protein,target: goals?.macros.protein,color: Palette.ringBlue); macro("Carbs",value: macros.carbs,target: goals?.macros.carbs,color: Palette.coral); macro("Fat",value: macros.fat,target: goals?.macros.fat,color: Palette.teal) }
        }.padding(20).card()
    }
    private func macro(_ name: String,value: Double,target: Double?,color: Color) -> some View {
        VStack(alignment: .leading,spacing: 7) {
            Text(name).font(.caption).foregroundStyle(Palette.secondary)
            Text("\(value.short) g").font(.subheadline.weight(.semibold)).monospacedDigit()
            GeometryReader { g in ZStack(alignment: .leading) { Capsule().fill(Palette.control); Capsule().fill(color).frame(width: g.size.width * min(1,value / max(target ?? 200,1))) } }.frame(height: 4)
            Text(target.map { "of \($0.short) g" } ?? "No target").font(.caption2).foregroundStyle(Palette.secondary)
        }.frame(maxWidth: .infinity,alignment: .leading)
    }
}
struct NutritionFoodSearch: View {
    @EnvironmentObject private var nutrition: NutritionStore
    @Environment(\.dismiss) private var dismiss
    var date: Date = Date()
    var initialMeal: FoodMeal = .lunch
    var initialFilter = "All"
    var initialQuery = ""
    var onMatch: ((FoodItem) -> Void)? = nil
    var onIngredient: ((FoodItem,Double) -> Void)? = nil
    @State private var filter = "All"
    @State private var query = ""
    @State private var selected: FoodItem?
    @State private var editing: FoodItem?
    @State private var custom = false
    @State private var recipe = false
    @State private var results: [FoodItem] = []
    @State private var matchCount = 0
    @State private var expandedMatches = false
    @State private var refresh = 0
    @State private var sources = false
    @State private var onlineBusy = false
    @State private var onlineMessage: String?
    private let filters = ["All","Branded","International","Favorites","Recent","My Foods","Recipes"]
    private var searchKey: String { "\(query)|\(filter)|\(nutrition.loadingCatalogue)|\(nutrition.state.customFoods.count)|\(refresh)|\(expandedMatches)" }
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                HStack(spacing: 10) {
                    Image(systemName: "magnifyingglass").foregroundStyle(Palette.secondary)
                    TextField("Food, brand or barcode",text: $query,prompt: Text("Food, brand or barcode").foregroundStyle(Palette.secondary))
                        .textInputAutocapitalization(.never).autocorrectionDisabled().submitLabel(.search)
                        .accessibilityIdentifier("nutrition-food-query")
                        .onSubmit { hideNutritionKeyboard() }
                    if !query.isEmpty { Button { query = "" } label: { Image(systemName: "xmark.circle.fill").foregroundStyle(Palette.secondary) }.accessibilityLabel("Clear food search") }
                }.padding(.horizontal,12).frame(minHeight: 44).background(Palette.control,in: RoundedRectangle(cornerRadius: 10)).padding(.horizontal,16).padding(.top,10)
                ScrollView(.horizontal,showsIndicators: false) { HStack(spacing: 8) { ForEach(filters,id: \.self) { label in Button { filter = label; Haptics.tick() } label: { Text(label).font(.subheadline.weight(.medium)).padding(.horizontal,14).padding(.vertical,9).foregroundStyle(filter == label ? Palette.actionText : Color.primary).background(filter == label ? Palette.action : Palette.control,in: Capsule()) }.buttonStyle(.plain) } }.padding(.horizontal,16).padding(.vertical,10) }
                if query.isEmpty && filter == "All" {
                    ScrollView(.horizontal,showsIndicators: false) { HStack(spacing: 9) { ForEach(["Biryani","Naan","Kimchi","Falafel","Injera","Pho","Tortilla","Curry"],id: \.self) { name in Button(name) { query = name }.font(.caption).padding(8).background(Palette.surface,in: Capsule()) } }.padding(.horizontal,16).padding(.bottom,9) }
                }
                if filter == "International" {
                    VStack(alignment: .leading,spacing: 8) {
                        Text("Search Open Food Facts for international packaged foods. Only your search text or barcode is sent; photos and diary data stay private.").font(.caption).foregroundStyle(Palette.secondary)
                        Button { lookupInternational() } label: { Label(onlineBusy ? "Searching…" : "Search International Foods",systemImage: "globe").frame(maxWidth: .infinity,minHeight: 44).background(Palette.control,in: RoundedRectangle(cornerRadius: 10)) }.buttonStyle(.plain).disabled(onlineBusy || query.trimmingCharacters(in: .whitespacesAndNewlines).count < 2)
                        if let onlineMessage { Text(onlineMessage).font(.caption).foregroundStyle(Palette.secondary) }
                    }.padding(.horizontal,16).padding(.bottom,10)
                }
                if filter == "All" {
                    HStack {
                        Text(expandedMatches ? "All preparations & brands" : "Common foods first").font(.caption).foregroundStyle(Palette.secondary)
                        Spacer()
                        Button(expandedMatches ? "Simplify results" : "Show all matches") { expandedMatches.toggle() }
                            .font(.caption.weight(.semibold)).accessibilityIdentifier("nutrition-expand-results")
                    }.padding(.horizontal,16).padding(.bottom,8)
                }
                List {
                    Section {
                        if nutrition.loadingCatalogue { HStack { ProgressView(); Text("Opening food catalogue…").font(.subheadline) } }
                        if results.isEmpty && !nutrition.loadingCatalogue { ContentUnavailableView.search(text: query) }
                        ForEach(results) { food in
                            HStack(spacing: 12) {
                                Button { choose(food); Haptics.tick() } label: {
                                    HStack(alignment: .top,spacing: 12) {
                                        Image(systemName: food.isRecipe ? "book.closed" : "fork.knife").frame(width: 24).padding(.top,3)
                                        VStack(alignment: .leading,spacing: 5) { Text(FoodSearchRanking.title(food)).font(.subheadline.weight(.medium)); if let brand = food.brand,!brand.isEmpty { Text(brand).font(.caption).foregroundStyle(Palette.secondary) }; Text("\(food.macros.calories.short) kcal / \(food.referenceGrams.short) g · \(food.source)").font(.caption).foregroundStyle(Palette.secondary) }
                                        Spacer(minLength: 0)
                                    }.contentShape(Rectangle())
                                }.buttonStyle(.plain).accessibilityIdentifier("nutrition-result-" + food.id)
                                Button { if nutrition.remember(food) { nutrition.favorite(food.id); refresh += 1 } } label: { Image(systemName: nutrition.state.favorites.contains(food.id) ? "heart.fill" : "heart").frame(width: 38,height: 44) }.buttonStyle(.plain).accessibilityLabel(nutrition.state.favorites.contains(food.id) ? "Unfavorite \(food.name)" : "Favorite \(food.name)")
                            }.listRowBackground(Palette.surface)
                                .contextMenu { if nutrition.state.customFoods.contains(where: { $0.id == food.id }) { Button("Edit") { editing = food }; Button("Delete saved food",role: .destructive) { _ = nutrition.removeFood(food.id); refresh += 1 } } }
                        }
                    } header: { Text(query.isEmpty && filter == "All" ? "\(nutrition.databaseCount.formatted()) offline foods · browse or search" : "\(results.count.formatted()) results · up to 100 shown") }.listRowBackground(Palette.surface)
                    Section { Button { custom = true } label: { Label("Create Custom Food",systemImage: "square.and.pencil") }; if onIngredient == nil { Button { recipe = true } label: { Label("Create Recipe",systemImage: "book") } } }.listRowBackground(Palette.surface)
                }.listStyle(.insetGrouped).darkForm()
            }.background(Palette.background)
                .navigationTitle(onMatch != nil ? "Match Food" : (onIngredient == nil ? "Food Library" : "Add Ingredient")).navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Done") { dismiss() }.accessibilityIdentifier("nutrition-library-done") }; ToolbarItem(placement: .topBarTrailing) { Button { sources = true } label: { Image(systemName: "info.circle") }.accessibilityLabel("Food database sources") } }
                .sheet(isPresented: $sources) { FoodDataSourcesView() }
                .task(id: searchKey) { await search() }
                .onChange(of: query) { expandedMatches = false }
                .onChange(of: filter) { expandedMatches = false }
                .onAppear { filter = initialFilter; query = initialQuery }
                .sheet(item: $selected) { food in FoodPortionView(food: food,date: date,initialMeal: initialMeal,onIngredient: onIngredient.map { callback in { food, grams in callback(food,grams); dismiss() } }) }
                .sheet(item: $editing,onDismiss: { refresh += 1 }) { food in if food.isRecipe { RecipeEditor(existing: food) } else { CustomFoodEditor(existing: food) } }
                .sheet(isPresented: $custom,onDismiss: { refresh += 1 }) { CustomFoodEditor() }
                .sheet(isPresented: $recipe,onDismiss: { refresh += 1 }) { RecipeEditor() }
        }
    }
    private func choose(_ food: FoodItem) {
        if let onMatch { onMatch(food); dismiss() } else { selected = food }
    }
    private func lookupInternational() {
        hideNutritionKeyboard(); onlineBusy = true; onlineMessage = nil
        let requested = query
        Task { @MainActor in
            defer { onlineBusy = false }
            do {
                let found = try await InternationalFoodService.shared.search(requested)
                guard query == requested,filter == "International" else { return }
                results = found; matchCount = found.count
                onlineMessage = found.isEmpty ? "No products with complete calories and macros were found. Try the brand or barcode, or create a custom food." : "Community label data: confirm the product and nutrition label. Selected products are saved for offline use."
            } catch { if query == requested,filter == "International" { onlineMessage = error.localizedDescription } }
        }
    }
    private func search() async {
        try? await Task.sleep(for: .milliseconds(180)); guard !Task.isCancelled else { return }
        let searchQuery = query, mode = filter, expanded = expandedMatches
        if mode == "International" { results = []; onlineMessage = nil; return }
        var pool = nutrition.allFoods
        switch mode {
        case "Favorites": pool = pool.filter { nutrition.state.favorites.contains($0.id) }
        case "Recent": let ids = Array(nutrition.state.entries.reversed().map(\.foodID)); pool = pool.filter { ids.contains($0.id) }.sorted { (ids.firstIndex(of: $0.id) ?? 0) < (ids.firstIndex(of: $1.id) ?? 0) }
        case "Branded": pool = (nutrition.state.cachedFoods ?? []).filter { $0.source.hasPrefix("USDA Branded") }
        case "My Foods": pool = nutrition.state.customFoods
        case "Recipes": pool = nutrition.state.customFoods.filter(\.isRecipe)
        default: break
        }
        let commonOnly = mode == "All" && !expanded && !FoodSearchRanking.isBarcode(searchQuery)
        if commonOnly { pool = pool.filter { !$0.id.hasPrefix("usda-brand-") && !$0.source.hasPrefix("Open Food Facts") } }
        let local = await Task.detached { FoodSearchRanking.results(searchQuery,in: pool,compact: commonOnly) }.value
        guard !Task.isCancelled else { return }
        // Generic searches stay focused. Brand-specific queries fall back to packaged products.
        let needsBranded = mode == "Branded" || (mode == "All" && (!commonOnly || local.isEmpty))
        let branded = needsBranded ? await FoodDatabase.shared.search(searchQuery,limit: 100) : []
        guard !Task.isCancelled else { return }
        if mode == "Recent" {
            let matchingIDs = Set(local.map(\.id))
            results = Array(pool.filter { matchingIDs.contains($0.id) }.prefix(100))
        } else if FoodSearchRanking.isBarcode(searchQuery) {
            let code = String(searchQuery.filter(\.isNumber).drop(while: { $0 == "0" }))
            var ids = Set<String>()
            results = code.isEmpty ? [] : (pool.filter { String(($0.barcode ?? "").drop(while: { $0 == "0" })) == code } + branded).filter { ids.insert($0.id).inserted }
        } else {
            results = await Task.detached { FoodSearchRanking.results(searchQuery,in: local + branded,compact: commonOnly) }.value
        }
        guard !Task.isCancelled else { return }; matchCount = results.count
    }

}
struct FoodPortionView: View {
    let food: FoodItem
    var date: Date
    var initialMeal: FoodMeal = .lunch
    var onIngredient: ((FoodItem,Double) -> Void)? = nil
    @EnvironmentObject private var nutrition: NutritionStore
    @Environment(\.dismiss) private var dismiss
    @State private var amount = "1"
    @State private var unit = 0
    @State private var meal: FoodMeal = .lunch
    @State private var logDate = Date()
    private var portions: [FoodPortion] { [FoodPortion(name: "100 grams",grams: 100),FoodPortion(name: "gram",grams: 1),FoodPortion(name: "ounce",grams: 28.349523125)] + food.portions }
    private var grams: Double { (nutritionNumber(amount) ?? 0) * portions[min(unit,portions.count-1)].grams }
    var body: some View {
        NavigationStack {
            Form {
                Section { Text(FoodSearchRanking.title(food)).font(.title3.bold()); if FoodSearchRanking.title(food) != food.name { Text("Source entry: " + food.name).font(.caption).foregroundStyle(Palette.secondary) }; if let brand = food.brand,!brand.isEmpty { Text(brand).font(.subheadline) }; Text(food.category + " · " + food.source).font(.caption).foregroundStyle(Palette.secondary) }.listRowBackground(Palette.surface)
                Section("Portion") { nutritionField("Quantity",text: $amount); Picker("Unit",selection: $unit) { ForEach(Array(portions.enumerated()),id: \.offset) { i, portion in Text(portion.name).tag(i) } }; LabeledContent("Total",value: "\(grams.short) g") }.listRowBackground(Palette.surface)
                Section("Nutrition for this portion") { macroRows(food.nutrition(grams: grams)); if food.fiberMissing == true { Text("Fiber was not provided by this source; the displayed zero is not a measured value.").font(.caption).foregroundStyle(Palette.secondary) } }.listRowBackground(Palette.surface)
                if onIngredient == nil { Section("Log to") { DatePicker("Date",selection: $logDate,displayedComponents: .date); Picker("Meal",selection: $meal) { ForEach(FoodMeal.allCases) { Text($0.rawValue).tag($0) } } }.listRowBackground(Palette.surface) }
                if let ingredients = food.ingredients { Section("Recipe Ingredients") { ForEach(ingredients) { item in LabeledContent(item.name,value: "\(item.grams.short) g") } }.listRowBackground(Palette.surface) }
                Section { PrimaryButton(label: onIngredient == nil ? "Log Food" : "Add Ingredient") {
                    guard grams > 0 && grams <= 100000 && grams.isFinite else { nutrition.error = "Enter a valid portion."; return }
                    Haptics.tick()
                    if let onIngredient { guard nutrition.remember(food) else { return }; onIngredient(food,grams); dismiss() } else if nutrition.log(food,grams: grams,date: logDate,meal: meal) { dismiss() }
                }.disabled(grams <= 0 || grams > 100000).accessibilityIdentifier("nutrition-log-portion") }.listRowBackground(Palette.surface)
                Section { Text("Database values describe a typical food or product label. Confirm the exact food, preparation and portion. Custom recipes calculate from your ingredient amounts.").font(.footnote).foregroundStyle(Palette.secondary) }.listRowBackground(Palette.surface)
            }.darkForm().navigationTitle("Food Details").navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }; ToolbarItemGroup(placement: .keyboard) { Spacer(); Button("Done") { hideNutritionKeyboard() }.accessibilityIdentifier("nutrition-keyboard-done") } }
                .onAppear { logDate = date; meal = initialMeal; if food.isRecipe, let first = food.portions.first { unit = portions.firstIndex(where: { $0.name == first.name }) ?? 0 } }
        }
    }
}
struct FoodEntryEditor: View {
    @EnvironmentObject private var nutrition: NutritionStore
    @Environment(\.dismiss) private var dismiss
    let entry: FoodLogEntry
    @State private var amount = ""
    @State private var meal: FoodMeal = .lunch
    @State private var date = Date()
    @State private var confirmDelete = false
    @State private var servingCount = ""
    @State private var useServingCount = false
    private var factor: Double { useServingCount ? (nutritionNumber(servingCount) ?? 0) / (entry.nutritionBasis?.servings ?? 1) : (nutritionNumber(amount) ?? 0) / entry.grams }
    var body: some View {
        NavigationStack {
            Form {
                Section { Text(entry.name).font(.headline); if useServingCount { nutritionField("Source servings",text: $servingCount); Text("Published serving counts determine nutrition. Gram weights remain estimates when the source has no weight.").font(.caption).foregroundStyle(Palette.secondary); if entry.nutritionBasis?.referenceGrams != nil { Button("Use measured grams instead") { useServingCount = false }.buttonStyle(.borderless) } } else { nutritionField("Grams",text: $amount) }; Picker("Meal",selection: $meal) { ForEach(FoodMeal.allCases) { Text($0.rawValue).tag($0) } }; DatePicker("Date",selection: $date,displayedComponents: .date) }.listRowBackground(Palette.surface)
                Section("Updated Nutrition") { macroRows(entry.macros.scaled(factor)); Text(entry.source).font(.caption).foregroundStyle(Palette.secondary); if let basis = entry.nutritionBasis { if let source = basis.sourceURL,let url = URL(string: source) { Link(basis.sourceTitle ?? "View nutrition source",destination: url) }; if let serving = basis.referenceServing { Text("Reference serving: " + serving).font(.caption) }; if let servings = basis.servings { Text("Source servings: \((servings * factor).short)").font(.caption) }; if let portion = basis.portionBasis { Text(portion).font(.caption) }; ForEach(basis.modifications ?? [],id: \.self) { Text($0).font(.caption) }; ForEach(basis.warnings ?? [],id: \.self) { Text($0).font(.caption).foregroundStyle(Palette.secondary) }; if basis.adjusted { Text("Nutrients were adjusted for this entry.").font(.caption) }; if basis.fiberMissing == true { Text("Fiber was not provided by the source.").font(.caption) } } }.listRowBackground(Palette.surface)
                Section { PrimaryButton(label: "Save Changes") { var value = entry; value.grams = useServingCount ? entry.grams * factor : (nutritionNumber(amount) ?? 0); value.macros = entry.macros.scaled(factor); if useServingCount,let servings = entry.nutritionBasis?.servings { value.nutritionBasis?.servings = servings * factor; if let count = entry.nutritionBasis?.quantityCount { value.nutritionBasis?.quantityCount = count * factor }; value.nutritionBasis?.portionBasis = "Your serving count × source nutrition" } else if factor != 1 { value.nutritionBasis?.servings = nil; value.nutritionBasis?.quantityCount = nil; value.nutritionBasis?.portionBasis = "Your weight × source nutrition" }; value.meal = meal; value.day = NutritionDay.key(date); if nutrition.update(value) { dismiss() } }.disabled(factor <= 0 || !factor.isFinite || (useServingCount && (nutritionNumber(servingCount) ?? 101) > 100)) }.listRowBackground(Palette.surface)
                Section { Button("Delete Entry",role: .destructive) { confirmDelete = true } }.listRowBackground(Palette.surface)
            }.darkForm().navigationTitle("Edit Food").navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }; ToolbarItemGroup(placement: .keyboard) { Spacer(); Button("Done") { hideNutritionKeyboard() }.accessibilityIdentifier("nutrition-keyboard-done") } }
                .onAppear { useServingCount = entry.nutritionBasis?.servings != nil; servingCount = (entry.nutritionBasis?.servings ?? 1).foodInput; amount = entry.grams.foodInput; meal = entry.meal; let f = DateFormatter(); f.dateFormat = "yyyy-MM-dd"; f.locale = Locale(identifier: "en_US_POSIX"); date = f.date(from: entry.day) ?? Date() }
                .confirmationDialog("Delete this food entry?",isPresented: $confirmDelete,titleVisibility: .visible) { Button("Delete Entry",role: .destructive) { if nutrition.remove(entry.id) { dismiss() } } }
        }
    }
}
struct NutritionGoalsView: View {
    @EnvironmentObject private var nutrition: NutritionStore
    @Environment(\.dismiss) private var dismiss
    @State private var intent = "Maintain"
    @State private var calories = ""
    @State private var protein = ""
    @State private var carbs = ""
    @State private var fat = ""
    @State private var fiber = ""
    private var macros: FoodMacros? { parseNutritionMacros(calories,protein,carbs,fat,fiber) }
    var body: some View {
        NavigationStack {
            Form {
                Section("Your Goal") { Picker("Focus",selection: $intent) { ForEach(["Lose","Maintain","Gain","Custom"],id: \.self) { Text($0).tag($0) } }; Text("Set your own daily targets. Your selected focus is recorded without automatically changing your calories.").font(.footnote).foregroundStyle(Palette.secondary) }.listRowBackground(Palette.surface)
                Section("Daily Targets") { nutritionField("Calories (kcal)",text: $calories); nutritionField("Protein (g)",text: $protein); nutritionField("Carbs (g)",text: $carbs); nutritionField("Fat (g)",text: $fat); nutritionField("Fiber (g)",text: $fiber) }.listRowBackground(Palette.surface)
                if let macros { Section { Text("Calories from protein, carbs and fat: \(macros.macroCalories.short) kcal. Label energy may differ because of fiber, alcohol and rounding.").font(.footnote).foregroundStyle(Palette.secondary) }.listRowBackground(Palette.surface) }
                Section { PrimaryButton(label: "Save Goals") { if let macros, nutrition.goals(NutritionGoals(intent: intent,macros: macros)) { Haptics.tick(); dismiss() } }.disabled(macros == nil || macros?.calories == 0) }.listRowBackground(Palette.surface)
                Section { Text("This build supports manual targets. Adaptive expenditure and weekly coaching will be added separately once enough reliable nutrition and body-weight history is available.").font(.footnote).foregroundStyle(Palette.secondary) }.listRowBackground(Palette.surface)
            }.darkForm().navigationTitle("Nutrition Goals").navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }; ToolbarItemGroup(placement: .keyboard) { Spacer(); Button("Done") { hideNutritionKeyboard() }.accessibilityIdentifier("nutrition-keyboard-done") } }
                .onAppear { if let goals = nutrition.state.goals { intent = goals.intent; calories = goals.macros.calories.foodInput; protein = goals.macros.protein.foodInput; carbs = goals.macros.carbs.foodInput; fat = goals.macros.fat.foodInput; fiber = goals.macros.fiber.foodInput } }
        }
    }
}
struct CustomFoodEditor: View {
    @EnvironmentObject private var nutrition: NutritionStore
    @Environment(\.dismiss) private var dismiss
    var existing: FoodItem? = nil
    var quickDate: Date? = nil
    var scanned: FoodLabelDraft? = nil
    @State private var name = ""
    @State private var grams = "100"
    @State private var calories = ""
    @State private var protein = ""
    @State private var carbs = ""
    @State private var fat = ""
    @State private var fiber = "0"
    @State private var meal: FoodMeal = .lunch
    private var macros: FoodMacros? { parseNutritionMacros(calories,protein,carbs,fat,fiber) }
    private var valid: Bool { !name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && (nutritionNumber(grams) ?? 0) > 0 && macros != nil }
    var body: some View {
        NavigationStack {
            Form {
                Section("Food") { TextField("Food or meal name",text: $name); nutritionField("Reference serving (grams)",text: $grams); Text("Enter nutrition for the entire reference serving below.").font(.footnote).foregroundStyle(Palette.secondary) }.listRowBackground(Palette.surface)
                Section("Nutrition per reference serving") { nutritionField("Calories (kcal)",text: $calories); nutritionField("Protein (g)",text: $protein); nutritionField("Carbs (g)",text: $carbs); nutritionField("Fat (g)",text: $fat); nutritionField("Fiber (g)",text: $fiber) }.listRowBackground(Palette.surface)
                if let scanned { Section("Scanned Label · Review Required") { Text("Confirm the serving weight and every value. A label may list more than one column.").font(.footnote); Text(scanned.text).font(.caption).textSelection(.enabled) }.listRowBackground(Palette.surface) }
                if quickDate != nil { Section { Picker("Meal",selection: $meal) { ForEach(FoodMeal.allCases) { Text($0.rawValue).tag($0) } } }.listRowBackground(Palette.surface) }
                Section { PrimaryButton(label: quickDate == nil ? "Save Food" : "Log Food") { save() }.disabled(!valid).accessibilityIdentifier("nutrition-submit-food") }.listRowBackground(Palette.surface)
            }.darkForm().navigationTitle(quickDate == nil ? "Custom Food" : "Quick Add").navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }; ToolbarItemGroup(placement: .keyboard) { Spacer(); Button("Done") { hideNutritionKeyboard() }.accessibilityIdentifier("nutrition-keyboard-done") } }
                .onAppear {
                    if let existing { name = existing.name; grams = existing.referenceGrams.foodInput; calories = existing.macros.calories.foodInput; protein = existing.macros.protein.foodInput; carbs = existing.macros.carbs.foodInput; fat = existing.macros.fat.foodInput; fiber = existing.macros.fiber.foodInput }
                    if let scanned { calories = scanned.calories.map(\.foodInput) ?? ""; protein = scanned.protein.map(\.foodInput) ?? ""; carbs = scanned.carbs.map(\.foodInput) ?? ""; fat = scanned.fat.map(\.foodInput) ?? ""; fiber = scanned.fiber.map(\.foodInput) ?? "0"; grams = scanned.grams.map(\.foodInput) ?? "" }
                }
        }
    }
    private func save() {
        guard let macros, let weight = nutritionNumber(grams), valid else { return }
        let food = FoodItem(id: existing?.id ?? "custom-" + UUID().uuidString,name: name.trimmingCharacters(in: .whitespacesAndNewlines),category: "Custom food",source: scanned == nil ? "Custom" : "Label · reviewed",referenceGrams: weight,macros: macros,portions: [FoodPortion(name: "1 serving",grams: weight)])
        Haptics.tick()
        if let quickDate { if nutrition.log(food,grams: weight,date: quickDate,meal: meal) { dismiss() } }
        else if nutrition.saveFood(food) { dismiss() }
    }
}
struct RecipeEditor: View {
    @EnvironmentObject private var nutrition: NutritionStore
    @Environment(\.dismiss) private var dismiss
    var existing: FoodItem? = nil
    @State private var name = ""
    @State private var servings = "1"
    @State private var cookedWeight = ""
    @State private var ingredients: [MealIngredient] = []
    @State private var adding = false
    private var total: FoodMacros { ingredients.reduce(FoodMacros()) { $0 + $1.macros } }
    private var weight: Double { nutritionNumber(cookedWeight) ?? ingredients.reduce(0) { $0 + $1.grams } }
    private var count: Double { nutritionNumber(servings) ?? 0 }
    var body: some View {
        NavigationStack {
            Form {
                Section("Recipe") { TextField("Meal or recipe name",text: $name); nutritionField("Number of servings",text: $servings); nutritionField("Cooked weight (g, optional)",text: $cookedWeight); Text("A cooked weight accounts for water lost or gained. It changes nutrition per gram, while the whole recipe keeps the same nutrients.").font(.footnote).foregroundStyle(Palette.secondary) }.listRowBackground(Palette.surface)
                Section("Ingredients") {
                    ForEach(ingredients) { item in VStack(alignment: .leading,spacing: 4) { Text(item.name); Text("\(item.grams.short) g · \(item.macros.calories.short) kcal").font(.caption).foregroundStyle(Palette.secondary) } }.onDelete { ingredients.remove(atOffsets: $0) }
                    Button { adding = true } label: { Label("Add Ingredient",systemImage: "plus.circle") }
                }.listRowBackground(Palette.surface)
                if !ingredients.isEmpty { Section("Per Serving") { macroRows(total.scaled(1 / max(count,0.000001))); LabeledContent("Serving weight",value: "\((weight / max(count,0.000001)).short) g") }.listRowBackground(Palette.surface); Section("Whole Recipe") { macroRows(total) }.listRowBackground(Palette.surface) }
                Section { PrimaryButton(label: "Save Recipe") { save() }.disabled(name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || ingredients.isEmpty || count <= 0 || weight <= 0) }.listRowBackground(Palette.surface)
            }.darkForm().navigationTitle(existing == nil ? "New Recipe" : "Edit Recipe").navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }; ToolbarItemGroup(placement: .keyboard) { Spacer(); Button("Done") { hideNutritionKeyboard() }.accessibilityIdentifier("nutrition-keyboard-done") } }
                .sheet(isPresented: $adding) { NutritionFoodSearch(onIngredient: { food, grams in ingredients.append(MealIngredient(foodID: food.id,name: food.name,grams: grams,macros: food.nutrition(grams: grams))) }) }
                .onAppear { if let existing { name = existing.name; ingredients = existing.ingredients ?? []; cookedWeight = existing.referenceGrams.foodInput; let portion = existing.portions.first?.grams ?? existing.referenceGrams; servings = (existing.referenceGrams / portion).foodInput } }
        }
    }
    private func save() {
        guard weight > 0,count > 0,count <= 10000,!ingredients.isEmpty else { return }
        let food = FoodItem(id: existing?.id ?? "recipe-" + UUID().uuidString,name: name.trimmingCharacters(in: .whitespacesAndNewlines),category: "Recipe",source: "Your recipe",referenceGrams: weight,macros: total,portions: [FoodPortion(name: "1 serving",grams: weight / count)],ingredients: ingredients)
        if nutrition.saveFood(food) { Haptics.tick(); dismiss() }
    }
}
func nutritionNumber(_ text: String) -> Double? { guard let n = Double(text.trimmingCharacters(in: .whitespacesAndNewlines).replacingOccurrences(of: ",",with: ".")),n.isFinite,n >= 0,n <= 100000 else { return nil }; return n }
func parseNutritionMacros(_ calories: String,_ protein: String,_ carbs: String,_ fat: String,_ fiber: String) -> FoodMacros? { guard let e = nutritionNumber(calories),let p = nutritionNumber(protein),let c = nutritionNumber(carbs),let f = nutritionNumber(fat),let b = nutritionNumber(fiber) else { return nil }; return FoodMacros(calories: e,protein: p,carbs: c,fat: f,fiber: b) }
func hideNutritionKeyboard() { UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder),to: nil,from: nil,for: nil) }
func nutritionField(_ label: String,text: Binding<String>) -> some View { HStack { Text(label); Spacer(); TextField(label.contains("optional") ? "Optional" : "Required",text: text).keyboardType(.decimalPad).multilineTextAlignment(.trailing).frame(maxWidth: 135).accessibilityLabel(label).accessibilityIdentifier("nutrition-" + label) } }
func macroRows(_ value: FoodMacros) -> some View { Group { LabeledContent("Calories",value: "\(value.calories.short) kcal"); LabeledContent("Protein",value: "\(value.protein.short) g"); LabeledContent("Carbohydrate",value: "\(value.carbs.short) g"); LabeledContent("Fat",value: "\(value.fat.short) g"); LabeledContent("Fiber",value: "\(value.fiber.short) g") } }
