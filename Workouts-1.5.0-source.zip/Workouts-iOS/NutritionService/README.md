# Local AI update · Workouts 1.5.0 / Revision 8

Double-click **UPDATE-LOCAL.cmd** after extracting the entire ZIP. Choose the existing working `start-local.ps1` if asked. The updater preserves your token, Tailscale URL and startup task, then restarts the service in the background. Install the paired Workouts 1.5.0 IPA over your current app. `/health` should show `localRevision: 8`, `workflow: 4`, `describe: true` and `multiPhoto: true`.

## New meal evidence workflow

Photo mode accepts a meal and a supporting photo; Describe accepts text alone or text with photos. Up to two JPEGs are sent together for one meal. Use a second angle, label, menu, packaging or scale as context, not as an additional meal. Photos are resized on the iPhone (1280 px single / 1024 px with a supporting photo). Structured vision stays one request with a 55-second deadline and no paid API key in local mode. Two images can take longer than one; remove the supporting photo and retry if your laptop exceeds the deadline. Closing or cancelling a scan aborts local inference. No photos, raw model outputs or meal notes are saved in server logs.

The plate shows totals, review flags, photos and source evidence. Add missing foods from the library, delete duplicates, scale the plate to the fraction eaten, edit individual amounts or use known calories to scale a selected profile. Known calories do not prove the estimated macros or gram weight. Major nutrient-density and calorie/macro conflicts require explicit review before logging. Save a reviewed plate as a reusable recipe; its ingredient snapshots can be expanded without logging the parent twice. Edited totals cannot be silently exploded back into unedited ingredients.

Protocol 2 and older app requests remain supported. New apps check workflow compatibility before sending a draft, retaining photos and notes when offline or when the service needs updating. No model change or new token is required.

# Food photo and restaurant service · Workouts 1.5.0

Extract the entire update ZIP, then double-click **UPDATE-LOCAL.cmd**. If asked, choose `start-local.ps1` in your EXISTING working food-AI folder. The updater preserves `local-service-token.txt`, checks the process listening on port 8080 before stopping it, backs up replaced files, copies the bundled PDF reader and restarts your existing launcher with a hidden window. Existing startup tasks and Tailscale Serve keep using the same installation. Node.js 22.13 or newer is required; the updater checks this before stopping anything. `/health` should show `localRevision: 8` and `mealResolution: true`.

Install the **Workouts 1.5.0 IPA** together with this update. It requests the new compact meal workflow, separates the place/dish/count/changes, and automatically resolves compatible restaurant or generic-library nutrition in review. Published servings use source counts; measured weights take priority when a gram reference exists. Generic profiles scale to estimated/measured grams and are explicitly labelled estimates. Missing recipes, unverified modifications and ambiguous matches do not become invented restaurant nutrition. No new model, token or connection setting is needed. Older app versions still work with the service but retain their old matching flow.

## Provider value handling

Revision 7 aligns the provider schema with weight, macro and serving-count bounds. A zero unknown count becomes null; absent optional meal metadata becomes explicitly unknown. Numeric strings preserve their supplied values, and verbose advisory text is bounded without changing nutrients. Missing, negative, nonfinite or out-of-range weights and nutrients still fail validation. Errors identify the rejected field path without exposing the photo, meal notes or model response. This update works with the existing Workouts 1.5.0 IPA; no reinstall or new token is needed.

## Restaurant lookup

The app sends nonempty meal notes or a direct HTTPS menu link to authenticated `/restaurant`. The service recognizes explicit “from”/“at” places, some business cues and known restaurant names. Ordinary weight/ingredient notes skip external search. Bare-name recognition is not universal; “food from restaurant, location” remains the clearest input. Food exclusions are separated from place names. A small URL registry currently routes Dave's Hot Chicken to its official US nutrition page; it contains no embedded macro values. Explicit overseas locations use search instead. Other restaurants use Bing RSS search for nutrition information, with no search API key. Only the place query goes to search; photos, service tokens and AI keys do not.

Nutrition links take priority over menu links. Up to ten public documents can be examined within an 18-second deadline, including two linked levels, explicitly linked CDN documents and WordPress Divi download links parsed as JSON literals. Page JavaScript is never executed. Every request and redirect validates public HTTPS and pins a checked DNS address. Private/local destinations are rejected. Text pages are limited to 1 MB; PDFs to 5 MB and 12 pages.

Supported nutrition: Schema.org MenuItem/Product records, explicit HTML tables, and text PDFs with horizontal named columns for item, serving, calories, protein, carbs and total fat. PDF extraction runs in a disposable worker with a memory limit and 6.5-second deadline. Image-only PDFs, complex/rotated tables, incomplete nutrients, empty servings, recipes and search snippets cannot supply restaurant macro profiles. Fat Calories is not a grams-of-fat column. Major nutrient/energy inconsistencies fail closed. Missing fiber is disclosed. Unsupported sources retain the photo/database fallback.

Confirm restaurant, country, dish and reference serving before selecting a profile. A published serving remains unmodified until reviewed. “No bread” does not prove a listed profile excludes accompanying bread, sauce or other additions, and never removes the breading from fried chicken. The service does not subtract guessed bread values. Roulette has no exact row in the currently inspected Dave’s nutrition chart, so chicken components are suggestions rather than an exact roulette profile. Confirm the actual food eaten; a shared box is not one personal portion.

Source gram weights scale to your measured or photo-estimated weight. Sources stating only a serving count require confirmed counts, without inventing grams. Matched identity, source link, reference nutrients and edits remain in diary snapshots; base database records stay unchanged. Photo weight, hidden oils and recipe modifications remain estimates.

## Vision and background operation

Protocol 2 is unchanged. Local mode uses `FOOD_PROVIDER=ollama`, loopback `OLLAMA_URL`, and `OLLAMA_MODEL=qwen3-vl:8b-instruct`, with five foods, 1800 output tokens for legacy clients; 2200 for the new meal workflow, `think:false`, one concurrent scan and a 55-second vision deadline. `MAX_DAILY_SCANS=0` removes the local daily cap. The laptop, Ollama and adapter must remain awake and connected. Gemini mode retains the existing optional provider configuration; provider quotas and model availability still apply.

Lookup caches up to 200 requests in memory, positive evidence for 24 hours and other responses for one minute. No photos, notes or pages are written to disk. Diagnostics contain statuses/timings/token counts, not credentials or model prompts. The Windows token file and iPhone Keychain remain outside nutrition backups.

## Development and verification

The portable ZIP includes unmodified PDF.js 6.4.299 legacy text-reader files and its Apache 2.0 license; it needs no npm install or native canvas. Repository checkouts instead run `npm ci --omit=optional --ignore-scripts` in this folder to install the pinned dependency from `package-lock.json`. For a cloud deployment, use that as the build command. `node --test *.test.mjs` checks the real decoder with an offline synthetic PDF as well as auth, bounds, providers, discovery, modifiers, columns and fallback behavior. Native checks cover automatic matches, generic preparation fallback, measured weights, counts, changes, snapshots and older backups. PDF coordinates/macros were separately verified against Dave's official current PDF. Windows updater process/restart behavior requires Windows and was not run on the Linux development host.

- Official source: https://store.daveshotchicken.com/nutrition-information/
- PDF reader: https://github.com/mozilla/pdf.js
- Nutrition schema: https://schema.org/NutritionInformation
- Vision API: https://docs.ollama.com/api/chat
