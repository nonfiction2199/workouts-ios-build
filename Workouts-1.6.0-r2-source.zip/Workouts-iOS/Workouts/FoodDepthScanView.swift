import SwiftUI
import ARKit
import AVFoundation
import CoreImage
import Vision
import simd

struct FoodDepthCapture {
    var image: UIImage
    var frame: MetricDepthFrame
    var timestamp: TimeInterval
    var samples: [DepthCameraSample] = []
}

// A fresh, synchronized RGB/depth frame; existing JPEGs are never presented as
// LiDAR captures. Raw depth remains in memory and is not sent to the AI service.
final class FoodDepthCameraModel: NSObject, ObservableObject, ARSessionDelegate {
    static var supported: Bool { ARWorldTrackingConfiguration.supportsFrameSemantics(.sceneDepth) }
    @Published var preview: UIImage?
    @Published var ready = false
    @Published var message = "Allow camera access to take a food photo."
    private let session = ARSession()
    private let context = CIContext()
    private var latest: FoodDepthCapture?
    private var lastPreview = 0.0
    private var active = false
    private var samples: [DepthCameraSample] = []
    func start() async {
        guard Self.supported else { message = "This device has no supported rear LiDAR scanner. Use a photo, measured grams or serving counts."; return }
        let allowed = await AVCaptureDevice.requestAccess(for:.video)
        guard !Task.isCancelled else { return }
        await MainActor.run {
            guard allowed else { self.message = "Camera access is disabled. Enable it in iPhone Settings to scan."; return }
            self.active = true; self.session.delegate = self; self.session.delegateQueue = .main
            let config = ARWorldTrackingConfiguration(); config.frameSemantics = [.sceneDepth]
            self.session.run(config,options:[.resetTracking,.removeExistingAnchors])
            self.message = "Hold the phone steady above your meal."
        }
    }
    func stop() { active = false; session.pause(); latest = nil; samples=[]; ready = false }
    func capture() -> FoodDepthCapture? {
        guard ready,let value=latest,ProcessInfo.processInfo.systemUptime-value.timestamp < 0.6 else { message = "Hold still and try again."; return nil }
        return value
    }
    func session(_ session: ARSession,didUpdate frame: ARFrame) {
        guard active,frame.timestamp-lastPreview >= 0.2 else { return }; lastPreview = frame.timestamp
        let ci=CIImage(cvPixelBuffer:frame.capturedImage).oriented(.right)
        guard let cg=context.createCGImage(ci,from:ci.extent) else { return }
        let image=UIImage(cgImage:cg); preview=image
        guard case .normal = frame.camera.trackingState else { latest=nil; samples=[]; ready=true; message="Hold the phone steady above your meal."; return }
        guard let depth=frame.sceneDepth,let confidence=depth.confidenceMap else { ready = false; message = "Waiting for a complete depth frame…"; return }
        let buffer=depth.depthMap,w=CVPixelBufferGetWidth(buffer),h=CVPixelBufferGetHeight(buffer)
        guard w <= 1024,h <= 1024,CVPixelBufferGetPixelFormatType(buffer) == kCVPixelFormatType_DepthFloat32,CVPixelBufferGetPixelFormatType(confidence)==kCVPixelFormatType_OneComponent8,CVPixelBufferGetWidth(confidence)==w,CVPixelBufferGetHeight(confidence)==h else { return }
        CVPixelBufferLockBaseAddress(buffer,.readOnly); CVPixelBufferLockBaseAddress(confidence,.readOnly)
        defer { CVPixelBufferUnlockBaseAddress(buffer,.readOnly); CVPixelBufferUnlockBaseAddress(confidence,.readOnly) }
        guard let d=CVPixelBufferGetBaseAddress(buffer),let c=CVPixelBufferGetBaseAddress(confidence) else { return }
        var values:[Float]=[],quality:[UInt8]=[]; values.reserveCapacity(w*h); quality.reserveCapacity(w*h)
        for y in 0..<h {
            let row=d.advanced(by:y*CVPixelBufferGetBytesPerRow(buffer)).assumingMemoryBound(to:Float.self)
            let q=c.advanced(by:y*CVPixelBufferGetBytesPerRow(confidence)).assumingMemoryBound(to:UInt8.self)
            for x in 0..<w { values.append(row[x]); quality.append(q[x]) }
        }
        let k=frame.camera.intrinsics,sx=Double(w)/Double(frame.camera.imageResolution.width),sy=Double(h)/Double(frame.camera.imageResolution.height)
        let metric=MetricDepthFrame(width:w,height:h,depths:values,confidence:quality,fx:Double(k[0][0])*sx,fy:Double(k[1][1])*sy,cx:Double(k[2][0])*sx,cy:Double(k[2][1])*sy)
        guard metric.valid else { return }
        samples.append(DepthCameraSample(frame:metric,pose:frame.camera.transform,timestamp:frame.timestamp)); samples=Array(samples.suffix(5))
        latest=FoodDepthCapture(image:image,frame:metric,timestamp:ProcessInfo.processInfo.systemUptime,samples:samples)
        preview=image; ready=true; message="Keep the whole meal in view."
    }
    func session(_ session: ARSession,didFailWithError error: Error) { ready=false; latest=nil; message="Camera tracking failed. Close this scan and retry." }
    func sessionWasInterrupted(_ session: ARSession) { ready=false; latest=nil; message="Capture interrupted. Close this scan and retry." }
}


struct DepthCameraSample {
    var frame: MetricDepthFrame
    var pose: simd_float4x4
    var timestamp: TimeInterval
}
enum FoodDepthPipeline {
    static func fuse(_ capture:FoodDepthCapture) -> MetricDepthFrame? {
        guard let anchor=capture.samples.last,capture.samples.count>=3 else { return nil }
        let f=anchor.frame,inverse=simd_inverse(anchor.pose)
        var bins=[[Float]](repeating:[],count:f.depths.count)
        for sample in capture.samples {
            guard anchor.timestamp-sample.timestamp<=1,simd_distance(sample.pose.columns.3,anchor.pose.columns.3)<0.025 else { continue }
            let transform=inverse*sample.pose,s=sample.frame
            // Z-buffer each reprojected frame: one depth per sample per pixel.
            var depths=[Float](repeating:.infinity,count:f.depths.count)
            for y in 0..<s.height { for x in 0..<s.width {
                guard let p=s.point(x,y) else { continue }
                let point=transform*SIMD4<Float>(Float(p.x),Float(-p.y),Float(-p.z),1)
                let z = -Double(point.z)
                guard z>0 else { continue }
                let u=Int((Double(point.x)*f.fx/z+f.cx).rounded()),v=Int((-Double(point.y)*f.fy/z+f.cy).rounded())
                if u>=0,v>=0,u<f.width,v<f.height { let i=v*f.width+u;depths[i]=min(depths[i],Float(z)) }
            } }
            for i in depths.indices where depths[i].isFinite { bins[i].append(depths[i]) }
        }
        var output=f
        for i in bins.indices {
            let values=bins[i].sorted()
            guard values.count>=3 else { output.confidence[i]=0;continue }
            let median=values[values.count/2],deviation=values.map { abs($0-median) }.sorted()
            guard deviation[deviation.count/2]<=0.003 else { output.confidence[i]=0;continue }
            output.depths[i]=median;output.confidence[i]=2
        }
        return output
    }
    static func regions(_ capture:FoodDepthCapture) -> [FoodDepthRegion] {
        guard let frame=fuse(capture),let image=capture.image.cgImage else { return [] }
        let request=VNGenerateForegroundInstanceMaskRequest()
        let handler=VNImageRequestHandler(cgImage:image,orientation:.up)
        do {
            try handler.perform([request])
            guard let observation=request.results?.first,!observation.allInstances.isEmpty else { return [] }
            let mask=try observation.generateScaledMaskForImage(forInstances:observation.allInstances,from:handler)
            guard CVPixelBufferGetPixelFormatType(mask)==kCVPixelFormatType_OneComponent32Float else { return [] }
            CVPixelBufferLockBaseAddress(mask,.readOnly);defer { CVPixelBufferUnlockBaseAddress(mask,.readOnly) }
            guard let base=CVPixelBufferGetBaseAddress(mask) else { return [] }
            let w=CVPixelBufferGetWidth(mask),h=CVPixelBufferGetHeight(mask),stride=CVPixelBufferGetBytesPerRow(mask)
            var foreground=[UInt8](repeating:0,count:frame.depths.count)
            for y in 0..<frame.height { for x in 0..<frame.width {
                // Inverse of clockwise RGB rotation; center-of-pixel mapping.
                let px=min(w-1,max(0,Int((1-(Double(y)+0.5)/Double(frame.height))*Double(w))))
                let py=min(h-1,max(0,Int((Double(x)+0.5)/Double(frame.width)*Double(h))))
                let value=base.advanced(by:py*stride).assumingMemoryBound(to:Float.self)[px]
                foreground[y*frame.width+x]=value>=0.9 ? 1:0
            } }
            return (try? FoodDepthGeometry.automatic(frame:frame,foreground:foreground)) ?? []
        } catch { return [] }
    }
}
struct FoodDepthCameraView: View {
    let captured:(UIImage,FoodDepthCapture?)->Void
    @Environment(\.dismiss) private var dismiss
    @Environment(\.scenePhase) private var scenePhase
    @StateObject private var camera=FoodDepthCameraModel()
    var body:some View {
        NavigationStack {
            ZStack(alignment:.bottom) {
                Palette.background.ignoresSafeArea()
                if let preview=camera.preview { Image(uiImage:preview).resizable().scaledToFit().ignoresSafeArea(edges:.bottom) }
                VStack(spacing:16) {
                    Text(camera.message).font(.subheadline).foregroundStyle(.primary).padding(10).background(Palette.surface.opacity(0.92),in:Capsule())
                    Button {
                        guard let image=camera.preview else { return }
                        let depth=camera.capture();camera.stop();captured(image,depth);dismiss()
                    } label: { Circle().fill(Palette.action).frame(width:72,height:72).overlay(Circle().stroke(.primary,lineWidth:3).padding(5)) }.accessibilityLabel("Take Photo").disabled(camera.preview == nil)
                }.padding(.bottom,28)
            }.navigationTitle("Food Photo").navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement:.cancellationAction) { Button("Cancel") { dismiss() } } }
                .task { await camera.start() }.onDisappear { camera.stop() }
                .onChange(of:scenePhase) { _,phase in if phase != .active { camera.stop() } }
        }
    }
}
