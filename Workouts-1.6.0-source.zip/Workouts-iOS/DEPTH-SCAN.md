# Workouts 1.6.0: guided 3D portion estimation

Open AI Food Logging → 3D Portion Scan. On a supported rear-LiDAR iPhone, capture the meal from directly above a flat plate in good light. Keep the entire portion visible, with empty flat plate areas around it, approximately 25–60 cm away.

Analyze Meal uses the existing free local food service. In Review Meal, tap one food, confirm its nutrition profile, and choose Outline this food in depth photo. Tap the boundary in order, finish the outline, and mark four empty flat plate points around it. Use the plate's flat food-support surface, not its raised rim or the table beneath it.

The app estimates volume in mL. Select a volume/weight portion from the matched food when available, or enter a known weight/volume reference for that same food and preparation. Confirm the reference and use the estimated grams, then Save Correction and approve the meal. Volume is never assumed equal to weight. USDA cup/spoon suggestions use US customary units; other databases' ambiguous cup units are omitted.

You can also start a fresh scan from a food's correction screen. A gallery JPEG cannot be converted into a LiDAR capture after the fact. Early Pro models without rear LiDAR and other unsupported devices keep normal photo, grams and serving logging.

## What this update does

* Synchronized RGB, metric sceneDepth and high-confidence map from ARKit, with camera intrinsics scaled to the depth resolution.
* Clockwise portrait RGB display and explicit inverse mapping of tap coordinates into sensor depth coordinates.
* Guided per-food boundary and four plate patches, a fitted 3D plane, and integration of projected surface triangles above that plane.
* Rejection of low-confidence data, insufficient coverage, non-flat/degenerate plate references, crossed outlines, negative height, oblique views and portions below 12 mm mean resolved height.
* Selected food-specific density and proportional nutrition scaling. Food identity and the original photo estimate remain attached.
* Optional diary/backup provenance: original scan volume, reference density, estimated grams and quality diagnostics. Fraction/manual weight changes mark the scan as reference evidence, rather than a new scan.
* Raw depth remains on the iPhone in this draft; it is not uploaded or stored in the diary. The regular photo uses the same existing AI service on explicit Analyze Meal.

## Accuracy and limits

Experimental. A successful geometry/unit test or simulator flow does not validate real iPhone sensor accuracy. The quality percentage reports accepted depth cells, not confidence in calorie accuracy. Single-view reconstruction assumes a height field supported by a flat plane; it cannot resolve hidden undersides, internal gaps, a bowl's bottom, stacked foods, ingredients or absorbed oil. Thin foods need measured grams or a supported serving count. Density derived from a household portion is a packing/preparation assumption. Guided segmentation is user-assisted; this release does not claim an automatic food segmentation model or multi-view reconstruction.

Benchmark before claiming improved accuracy: photograph and scan at least 20 separately weighed food portions over several days, including rice, pasta, meats and irregular shapes, at two distances. Record food match, reference density, plain-photo estimated grams, scan-estimated grams, scale weight and rejected scans. Compare paired absolute percentage errors and report median, mean, worst errors and rejection rate. Do not cherry-pick successful scans or change density after seeing the scale result.

Technical sources:
* Apple ARDepthData: https://developer.apple.com/documentation/arkit/ardepthdata
* Apple sceneDepth semantics: https://developer.apple.com/documentation/arkit/arconfiguration/framesemantics-swift.struct/scenedepth
* Herzig et al., 2020: https://pmc.ncbi.nlm.nih.gov/articles/PMC7142738/ — independent system; its results are not this app's measured performance.
* US household measurement conversion: https://www.nist.gov/pml/owm/metric-household

No new provider key, subscription, laptop package or model installation is required. Existing Workouts 1.5.0 local food service (workflow 4) is compatible.
