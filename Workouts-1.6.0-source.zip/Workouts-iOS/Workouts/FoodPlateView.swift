import SwiftUI

struct FoodAIReview: View {
    let response: FoodAIResponse
    let date: Date
    var photos: [UIImage] = []
    var depthCapture: FoodDepthCapture? = nil
    var revise: (() -> Void)? = nil
    let completed: () -> Void
    @EnvironmentObject private var nutrition: NutritionStore
    @Environment(\.dismiss) private var dismiss
    @State private var items: [FoodAIItem] = []
    @State private var meal: FoodMeal = .lunch
    @State private var selected: FoodAIItem?
    @State private var library = false
    @State private var initialized = false
    @State private var acknowledged = false
    @State private var saveMeal = false
    @State private var mealName = ""
    @State private var status: String?
    private var total: FoodMacros { items.reduce(FoodMacros()) { $0 + $1.macros } }
    private var unusual: Bool { items.contains { !FoodPlate.qualityWarnings($0).isEmpty } }
    private var signature: [String] { items.map { "\($0.id)|\($0.grams)|\($0.macros.calories)|\($0.macros.protein)|\($0.macros.carbs)|\($0.macros.fat)|\($0.macros.fiber)" } }
    var body: some View {
        NavigationStack {
            List {
                totals
                if !photos.isEmpty {
                    Section("Meal reference") {
                        ScrollView(.horizontal) { HStack { ForEach(Array(photos.enumerated()),id: \.offset) { _,photo in Image(uiImage: photo).resizable().scaledToFit().frame(height: 150).clipShape(RoundedRectangle(cornerRadius: 10)) } } }
                    }.listRowBackground(Palette.surface)
                }
                sources
                Section("Foods & portions · Tap to correct") {
                    ForEach(items) { item in
                        VStack(alignment: .leading,spacing: 8) {
                            Button { selected = item } label: { FoodAIReviewRow(item: item) }.buttonStyle(.plain).accessibilityIdentifier("nutrition-review-" + item.name)
                            if FoodPlate.expanded(item) != nil { Button("Expand recipe ingredients") { if let children = FoodPlate.expanded(item),let index = items.firstIndex(where: { $0.id == item.id }) { items.replaceSubrange(index...index,with: children) } }.buttonStyle(.borderless) }
                        }
                    }.onDelete { items.remove(atOffsets: $0) }
                    Button { library = true } label: { Label("Add missing food",systemImage: "plus.circle") }.accessibilityIdentifier("nutrition-plate-add")
                    Text("Swipe left to remove a food. Mixed dishes already include their ingredients; only add extra oil or sauce if it is missing from the selected profile.").font(.caption).foregroundStyle(Palette.secondary)
                }.listRowBackground(Palette.surface)
                Section("Amount eaten") {
                    Text("Scale the current plate when you ate only part of it. Each food remains separately editable.").font(.caption).foregroundStyle(Palette.secondary)
                    HStack {
                        Button("Half the plate") { scale(0.5) }.accessibilityIdentifier("nutrition-half-plate")
                        Spacer()
                        Button("Double") { scale(2) }.accessibilityIdentifier("nutrition-double-plate")
                    }.buttonStyle(.borderless)
                    if let revise { Button("Discard draft & revise description") { revise() }.buttonStyle(.borderless) }
                }.listRowBackground(Palette.surface)
                Section {
                    Picker("Meal",selection: $meal) { ForEach(FoodMeal.allCases) { Text($0.rawValue).tag($0) } }
                    if unusual { Toggle("I checked the unusual nutrition values",isOn: $acknowledged).accessibilityIdentifier("nutrition-confirm-unusual") }
                    PrimaryButton(label: "Approve & Log \(items.count) Foods") { log() }.disabled(items.isEmpty || !items.allSatisfy(\.valid) || (unusual && !acknowledged))
                    Button { saveMeal = true } label: { Label("Save as reusable meal",systemImage: "bookmark") }.disabled(items.isEmpty || !items.allSatisfy(\.valid) || (unusual && !acknowledged)).accessibilityIdentifier("nutrition-save-plate")
                }.listRowBackground(Palette.surface)
            }.darkForm().navigationTitle("Review Meal").navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } } }
                .interactiveDismissDisabled()
                .onAppear { if !initialized { items = response.items; initialized = true } }
                .onChange(of: signature) { _,_ in acknowledged = false }
                .sheet(item: $selected) { item in FoodAICorrection(item: item,depthCapture:depthCapture,restaurant: response.restaurant) { updated in if let index = items.firstIndex(where: { $0.id == updated.id }) { items[index] = updated } } }
                .sheet(isPresented: $library) { NutritionFoodSearch(onMatch: { items.append(FoodPlate.added($0)) }) }
                .alert("Save Meal",isPresented: $saveMeal) {
                    TextField("Meal name",text: $mealName)
                    Button("Save") { guard let food = FoodPlate.recipe(items,name: mealName) else { status = "Enter a meal name under 100 characters."; return }; if nutrition.saveFood(food) { status = "Saved to your recipes. Review portions when you reuse it." } }
                    Button("Cancel",role: .cancel) {}
                } message: { Text("Saves the current portions and nutrients as a recipe. Estimates stay estimates; this does not log the meal.") }
        }
    }
    private var totals: some View {
        Section("Your plate") {
            Text("\(total.calories.short) kcal total").font(.title2.bold()).accessibilityIdentifier("nutrition-plate-total")
            Text("P \(total.protein.short) · C \(total.carbs.short) · F \(total.fat.short) · Fiber \(total.fiber.short)").font(.subheadline)
            Text("\(items.filter(\.needsPortionReview).count) amounts need review · \(items.filter(\.needsIdentityReview).count) nutrition matches need review").font(.caption).foregroundStyle(Palette.action)
            Text("Review every item and portion before logging.").font(.headline)
            if !response.notes.isEmpty { Text(response.notes).font(.footnote).foregroundStyle(Palette.secondary) }
            ForEach(response.questions,id: \.self) { Text($0).font(.footnote) }
            if let status { Text(status).font(.caption).foregroundStyle(Palette.action) }
        }.listRowBackground(Palette.surface)
    }
    @ViewBuilder private var sources: some View {
        if let restaurant = response.restaurant,restaurant.status != "not_requested" {
            Section("Restaurant sources") {
                Text(restaurant.query.isEmpty ? "Restaurant lookup" : restaurant.query).font(.headline)
                Text(restaurant.notes).font(.caption).foregroundStyle(Palette.secondary)
                ForEach(restaurant.sources) { source in if let url = URL(string: source.url) { Link(source.title,destination: url).font(.subheadline) } }
                if !restaurant.candidates.isEmpty { Text("Supported matches were applied below. Review the source, portion and recipe changes before logging.").font(.caption) }
            }.listRowBackground(Palette.surface)
        }
    }
    private func scale(_ factor: Double) {
        let scaled = items.compactMap { FoodPlate.scaled($0,by: factor,reason: "Your fraction of the current plate; estimated amounts scaled") }
        guard !items.isEmpty,scaled.count == items.count else { status = "That plate size exceeds the supported portion range."; return }
        items = scaled; status = "Plate scaled. Check foods eaten in different proportions individually."
    }
    private func log() {
        let entries = items.map { item -> FoodLogEntry in
            var basis = item.nutritionBasis ?? FoodNutritionBasis(resolution: "ai")
            let warnings = (basis.warnings ?? []) + FoodPlate.qualityWarnings(item)
            basis.warnings = Array(Array(Set(warnings)).sorted().prefix(8))
            return FoodLogEntry(day: NutritionDay.key(date),meal: meal,foodID: item.matchedFood?.id ?? basis.sourceFoodID ?? "ai-" + UUID().uuidString,name: item.name,grams: item.grams,macros: item.macros,source: item.nutritionLabel + " · reviewed",estimated: true,nutritionBasis: basis)
        }
        if !entries.isEmpty,items.compactMap(\.matchedFood).allSatisfy({ nutrition.remember($0) }),nutrition.log(entries) { completed() }
    }
}
