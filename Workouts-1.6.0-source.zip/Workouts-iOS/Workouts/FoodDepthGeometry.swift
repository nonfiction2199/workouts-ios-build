import Foundation

// Metric camera coordinates: x right, y down, z forward. ARKit depth is z,
// not radial distance. Never substitute relative monocular depth here.
struct DepthPoint: Equatable {
    var x: Double
    var y: Double
    var z: Double
    static func -(l: Self,r: Self) -> Self { Self(x:l.x-r.x,y:l.y-r.y,z:l.z-r.z) }
    static func +(l: Self,r: Self) -> Self { Self(x:l.x+r.x,y:l.y+r.y,z:l.z+r.z) }
    func scaled(_ k: Double) -> Self { Self(x:x*k,y:y*k,z:z*k) }
    var length: Double { sqrt(x*x+y*y+z*z) }
    func cross(_ p: Self) -> Self { Self(x:y*p.z-z*p.y,y:z*p.x-x*p.z,z:x*p.y-y*p.x) }
}
struct DepthPixel: Equatable {
    var u: Double
    var v: Double
    var valid: Bool { u.isFinite && v.isFinite && u >= 0 && u <= 1 && v >= 0 && v <= 1 }
}
struct MetricDepthFrame {
    var width: Int
    var height: Int
    var depths: [Float]
    var confidence: [UInt8]
    var fx: Double
    var fy: Double
    var cx: Double
    var cy: Double
    var valid: Bool {
        width >= 16 && height >= 16 && width <= 1024 && height <= 1024 && depths.count == width*height && confidence.count == depths.count &&
        [fx,fy,cx,cy].allSatisfy(\.isFinite) && fx > 0 && fy > 0 && cx >= 0 && cx < Double(width) && cy >= 0 && cy < Double(height)
    }
    func point(_ x: Int,_ y: Int) -> DepthPoint? {
        guard x >= 0,y >= 0,x < width,y < height else { return nil }
        let i = y*width+x,z = Double(depths[i])
        guard confidence[i] == 2,z.isFinite,z >= 0.20,z <= 1.2 else { return nil }
        return DepthPoint(x:(Double(x)-cx)*z/fx,y:(Double(y)-cy)*z/fy,z:z)
    }
    // Display uses the complete RGB image rotated 90 degrees clockwise, aspect
    // fit (never aspect fill). This inverse maps its normalized taps to sensor pixels.
    static func sensorPixel(portrait p: DepthPixel) -> DepthPixel { DepthPixel(u:p.v,v:1-p.u) }
}
struct DepthVolume {
    var milliliters: Double
    var coverage: Double
    var planeErrorMM: Double
    var meanHeightMM: Double
    var footprintCM2: Double
    var acceptedCells: Int
}
enum FoodDepthGeometry {
    static func fail(_ message: String) -> FoodScanError { .message(message) }
    // Plane z=a*x+b*y+c, fitted to high-confidence empty plate patches.
    static func plane(_ points: [DepthPoint]) throws -> (a:Double,b:Double,c:Double,error:Double) {
        guard points.count >= 12 else { throw fail("Select four clear, flat empty areas of the plate.") }
        let n = Double(points.count)
        let mx = points.reduce(0) { $0+$1.x }/n,my = points.reduce(0) { $0+$1.y }/n,mz = points.reduce(0) { $0+$1.z }/n
        var xx=0.0,yy=0.0,xy=0.0,xz=0.0,yz=0.0
        for p in points { let x=p.x-mx,y=p.y-my,z=p.z-mz; xx+=x*x; yy+=y*y; xy+=x*y; xz+=x*z; yz+=y*z }
        let det=xx*yy-xy*xy
        guard xx > 0.0001,yy > 0.0001,det > 0.08*xx*yy else { throw fail("Spread the four plate points around the food; avoid a straight line.") }
        let a=(xz*yy-yz*xy)/det,b=(yz*xx-xz*xy)/det,c=mz-a*mx-b*my,norm=sqrt(1+a*a+b*b)
        guard norm <= 1.3 else { throw fail("Hold the phone closer to directly above the plate.") }
        let rms=sqrt(points.reduce(0) { $0+pow(($1.z-a*$1.x-b*$1.y-c)/norm,2) }/n)
        guard rms <= 0.003 else { throw fail("The plate points do not form a flat surface. Avoid raised rims, bowls and food.") }
        return (a,b,c,rms)
    }
    static func contains(_ p: DepthPixel,_ polygon: [DepthPixel]) -> Bool {
        var inside=false,j=polygon.count-1
        for i in polygon.indices {
            let a=polygon[i],b=polygon[j]
            if (a.v > p.v) != (b.v > p.v),p.u < (b.u-a.u)*(p.v-a.v)/(b.v-a.v)+a.u { inside.toggle() }
            j=i
        }
        return inside
    }
    static func simple(_ polygon: [DepthPixel]) -> Bool {
        guard polygon.count >= 3,polygon.count <= 64,polygon.allSatisfy(\.valid) else { return false }
        func orient(_ a:DepthPixel,_ b:DepthPixel,_ c:DepthPixel) -> Double { (b.u-a.u)*(c.v-a.v)-(b.v-a.v)*(c.u-a.u) }
        func intersects(_ a:DepthPixel,_ b:DepthPixel,_ c:DepthPixel,_ d:DepthPixel) -> Bool {
            let x=orient(a,b,c),y=orient(a,b,d),z=orient(c,d,a),w=orient(c,d,b)
            if x*y < 0 && z*w < 0 { return true }
            func on(_ a:DepthPixel,_ b:DepthPixel,_ p:DepthPixel,_ cross:Double) -> Bool {
                abs(cross) < 1e-10 && p.u >= min(a.u,b.u) && p.u <= max(a.u,b.u) && p.v >= min(a.v,b.v) && p.v <= max(a.v,b.v)
            }
            return on(a,b,c,x) || on(a,b,d,y) || on(c,d,a,z) || on(c,d,b,w)
        }
        for i in polygon.indices {
            let ni=(i+1)%polygon.count
            guard abs(polygon[i].u-polygon[ni].u)+abs(polygon[i].v-polygon[ni].v) > 0.0001 else { return false }
            for j in polygon.indices where j > i {
                let nj=(j+1)%polygon.count
                if ni == j || nj == i { continue }
                if intersects(polygon[i],polygon[ni],polygon[j],polygon[nj]) { return false }
            }
        }
        return true
    }
    static func estimate(frame: MetricDepthFrame,outline: [DepthPixel],plate: [DepthPixel]) throws -> DepthVolume {
        guard frame.valid else { throw fail("The depth capture is incomplete. Retake the scan.") }
        guard simple(outline) else { throw fail("Outline one food with an uncrossed boundary.") }
        guard plate.count == 4,plate.allSatisfy(\.valid),plate.allSatisfy({ !contains($0,outline) }) else { throw fail("Select four empty plate areas outside the food outline.") }
        var points:[DepthPoint]=[]
        for tap in plate {
            let x=Int((tap.u*Double(frame.width-1)).rounded()),y=Int((tap.v*Double(frame.height-1)).rounded())
            var patch:[DepthPoint]=[]
            for dy in -2...2 { for dx in -2...2 { if let p=frame.point(x+dx,y+dy) { patch.append(p) } } }
            guard patch.count >= 18 else { throw fail("A plate point has unreliable depth. Choose another flat area.") }
            points.append(contentsOf:patch)
        }
        let base=try plane(points),norm=sqrt(1+base.a*base.a+base.b*base.b)
        let normal=DepthPoint(x:base.a/norm,y:base.b/norm,z:-1/norm)
        var volume=0.0,area=0.0,total=0,accepted=0,negative=0
        for y in 0..<(frame.height-1) { for x in 0..<(frame.width-1) {
            let p=DepthPixel(u:(Double(x)+0.5)/Double(frame.width-1),v:(Double(y)+0.5)/Double(frame.height-1))
            guard contains(p,outline) else { continue }; total+=1
            let samples=[frame.point(x,y),frame.point(x+1,y),frame.point(x,y+1),frame.point(x+1,y+1)]
            guard samples.allSatisfy({ $0 != nil }) else { continue }
            let top=samples.map { $0! },heights=top.map { (base.a*$0.x+base.b*$0.y+base.c-$0.z)/norm }
            if heights.contains(where: { $0 < -0.004 }) { negative+=1; continue }
            guard heights.allSatisfy({ $0 <= 0.15 }),((heights.max() ?? 0)-(heights.min() ?? 0)) <= 0.025 else { continue }
            let h=heights.map { max(0,$0) },foot=zip(top,h).map { $0.0-normal.scaled($0.1) }
            let a=(foot[1]-foot[0]).cross(foot[2]-foot[0]).length*0.5,b=(foot[2]-foot[3]).cross(foot[1]-foot[3]).length*0.5
            guard a+b <= 0.0001 else { continue }
            volume+=a*(h[0]+h[1]+h[2])/3+b*(h[3]+h[2]+h[1])/3; area+=a+b; accepted+=1
        } }
        guard total >= 100,accepted >= 100 else { throw fail("This food occupies too few reliable depth pixels. Move closer and retake.") }
        guard Double(negative)/Double(total) <= 0.03 else { throw fail("Food appears below the selected plate surface. Choose flat plate points, not the rim.") }
        let coverage=Double(accepted)/Double(total)
        guard coverage >= 0.95 else { throw fail("Too much depth is missing or inconsistent. Retake in good light, closer and directly above.") }
        let height=volume/area
        guard height >= max(0.012,base.error*4) else { throw fail("This portion is too thin to resolve reliably. Use grams or a serving count.") }
        guard volume >= 0.000005,volume <= 0.005,area > 0.0005,area <= 0.2 else { throw fail("The estimated size is outside the supported range. Check the outline and plate points.") }
        // Deliberately do not fill holes or multiply by 1/coverage. Missing regions
        // can be systematically different. Report the observed surface estimate.
        return DepthVolume(milliliters:volume*1_000_000,coverage:coverage,planeErrorMM:base.error*1000,meanHeightMM:height*1000,footprintCM2:area*10_000,acceptedCells:accepted)
    }
}

struct FoodDensityReference: Identifiable {
    var title: String
    var milliliters: Double
    var grams: Double
    var source: String
    var id: String { title }
    var density: Double { grams/milliliters }
    var valid: Bool { milliliters.isFinite && milliliters > 0 && grams.isFinite && grams > 0 && density >= 0.05 && density <= 2.5 }
    // Strict volume portions only. A slice, tender, bowl or generic serving is not
    // a volume reference. Cups remain a bulk-density assumption, chosen by the user.
    static func suggestions(_ food: FoodItem?) -> [Self] {
        guard let food else { return [] }
        return food.portions.compactMap { portion in
            let name=portion.name.lowercased().trimmingCharacters(in:.whitespacesAndNewlines)
            let pattern="^([0-9]+(?:\\.[0-9]+)?)\\s*(ml|milliliters?|millilitres?|cups?|tablespoons?|tbsp|teaspoons?|tsp)(?:$|[, (])"
            guard let r=try? NSRegularExpression(pattern:pattern),let m=r.firstMatch(in:name,range:NSRange(name.startIndex...,in:name)),let amount=Range(m.range(at:1),in:name).flatMap({ Double(name[$0]) }),let unit=Range(m.range(at:2),in:name).map({ String(name[$0]) }) else { return nil }
            // Only USDA cup/spoon portions have a known US customary convention.
            // Other databases may use metric cups (250 mL) or labeling cups (240 mL).
            let multiplier:Double
            if unit.hasPrefix("ml") || unit.hasPrefix("millil") { multiplier=1 }
            else if food.id.hasPrefix("usda-") {
                multiplier=unit.hasPrefix("cup") ? 236.5882365 : (["tbsp","tablespoon","tablespoons"].contains(unit) ? 14.7867648 : 4.9289216)
            } else { return nil }
            let result=Self(title:portion.name,milliliters:amount*multiplier,grams:portion.grams,source:food.source+" · "+portion.name)
            return result.valid ? result : nil
        }
    }
}
