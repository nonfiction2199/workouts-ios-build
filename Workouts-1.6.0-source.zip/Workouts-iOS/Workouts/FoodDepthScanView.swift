import SwiftUI
import ARKit
import AVFoundation
import CoreImage

struct FoodDepthCapture {
    var image: UIImage
    var frame: MetricDepthFrame
    var timestamp: TimeInterval
}

// A fresh, synchronized RGB/depth frame; existing JPEGs are never presented as
// LiDAR captures. Raw depth remains in memory and is not sent to the AI service.
final class FoodDepthCameraModel: NSObject, ObservableObject, ARSessionDelegate {
    static var supported: Bool { ARWorldTrackingConfiguration.supportsFrameSemantics(.sceneDepth) }
    @Published var preview: UIImage?
    @Published var ready = false
    @Published var message = "Allow camera access, then hold still above a flat plate."
    private let session = ARSession()
    private let context = CIContext()
    private var latest: FoodDepthCapture?
    private var lastPreview = 0.0
    private var active = false
    func start() async {
        guard Self.supported else { message = "This device has no supported rear LiDAR scanner. Use a photo, measured grams or serving counts."; return }
        let allowed = await AVCaptureDevice.requestAccess(for:.video)
        guard !Task.isCancelled else { return }
        await MainActor.run {
            guard allowed else { self.message = "Camera access is disabled. Enable it in iPhone Settings to scan."; return }
            self.active = true; self.session.delegate = self; self.session.delegateQueue = .main
            let config = ARWorldTrackingConfiguration(); config.frameSemantics = [.sceneDepth]
            self.session.run(config,options:[.resetTracking,.removeExistingAnchors])
            self.message = "Move gently to initialize, then hold still 25–60 cm above the plate."
        }
    }
    func stop() { active = false; session.pause(); latest = nil; ready = false }
    func capture() -> FoodDepthCapture? {
        guard ready,let value=latest,ProcessInfo.processInfo.systemUptime-value.timestamp < 0.6 else { message = "Depth is not ready. Hold still and try again."; return nil }
        return value
    }
    func session(_ session: ARSession,didUpdate frame: ARFrame) {
        guard active,frame.timestamp-lastPreview >= 0.2 else { return }; lastPreview = frame.timestamp
        guard case .normal = frame.camera.trackingState else { ready = false; message = "Move gently to initialize tracking, then hold still."; return }
        guard let depth=frame.sceneDepth,let confidence=depth.confidenceMap else { ready = false; message = "Waiting for a complete depth frame…"; return }
        let buffer=depth.depthMap,w=CVPixelBufferGetWidth(buffer),h=CVPixelBufferGetHeight(buffer)
        guard w <= 1024,h <= 1024,CVPixelBufferGetPixelFormatType(buffer) == kCVPixelFormatType_DepthFloat32,CVPixelBufferGetPixelFormatType(confidence)==kCVPixelFormatType_OneComponent8,CVPixelBufferGetWidth(confidence)==w,CVPixelBufferGetHeight(confidence)==h else { return }
        CVPixelBufferLockBaseAddress(buffer,.readOnly); CVPixelBufferLockBaseAddress(confidence,.readOnly)
        defer { CVPixelBufferUnlockBaseAddress(buffer,.readOnly); CVPixelBufferUnlockBaseAddress(confidence,.readOnly) }
        guard let d=CVPixelBufferGetBaseAddress(buffer),let c=CVPixelBufferGetBaseAddress(confidence) else { return }
        var values:[Float]=[],quality:[UInt8]=[]; values.reserveCapacity(w*h); quality.reserveCapacity(w*h)
        for y in 0..<h {
            let row=d.advanced(by:y*CVPixelBufferGetBytesPerRow(buffer)).assumingMemoryBound(to:Float.self)
            let q=c.advanced(by:y*CVPixelBufferGetBytesPerRow(confidence)).assumingMemoryBound(to:UInt8.self)
            for x in 0..<w { values.append(row[x]); quality.append(q[x]) }
        }
        let k=frame.camera.intrinsics,sx=Double(w)/Double(frame.camera.imageResolution.width),sy=Double(h)/Double(frame.camera.imageResolution.height)
        let metric=MetricDepthFrame(width:w,height:h,depths:values,confidence:quality,fx:Double(k[0][0])*sx,fy:Double(k[1][1])*sy,cx:Double(k[2][0])*sx,cy:Double(k[2][1])*sy)
        let ci=CIImage(cvPixelBuffer:frame.capturedImage).oriented(.right)
        guard metric.valid,let cg=context.createCGImage(ci,from:ci.extent) else { return }
        let image=UIImage(cgImage:cg)
        latest=FoodDepthCapture(image:image,frame:metric,timestamp:ProcessInfo.processInfo.systemUptime)
        preview=image; ready=true; message="Depth ready. Keep the complete portion and empty flat plate visible."
    }
    func session(_ session: ARSession,didFailWithError error: Error) { ready=false; latest=nil; message="Camera tracking failed. Close this scan and retry." }
    func sessionWasInterrupted(_ session: ARSession) { ready=false; latest=nil; message="Capture interrupted. Close this scan and retry." }
}

struct FoodDepthScanView: View {
    var food: FoodItem? = nil
    var foodName: String = "one food"
    var initial: FoodDepthCapture? = nil
    var captureOnly = false
    var captured: ((FoodDepthCapture) -> Void)? = nil
    var applied: ((FoodDepthEvidence) -> Void)? = nil
    @Environment(\.dismiss) private var dismiss
    @Environment(\.scenePhase) private var scenePhase
    @StateObject private var camera=FoodDepthCameraModel()
    @State private var snapshot: FoodDepthCapture?
    @State private var outline:[DepthPixel]=[]
    @State private var plate:[DepthPixel]=[]
    @State private var step=0
    @State private var volume:DepthVolume?
    @State private var referenceVolume=""
    @State private var referenceGrams=""
    @State private var densitySource="Your weight / volume reference"
    @State private var confirmed=false
    @State private var message:String?
    private var reference:FoodDensityReference? {
        guard let ml=nutritionNumber(referenceVolume),let g=nutritionNumber(referenceGrams) else { return nil }
        let result=FoodDensityReference(title:"Reference",milliliters:ml,grams:g,source:densitySource)
        return result.valid ? result : nil
    }
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment:.leading,spacing:16) {
                    Text("3D Portion Scan · Experimental").font(.title3.bold())
                    Text(snapshot == nil ? "Use a flat plate in good light. Hold the phone directly above the food, 25–60 cm away. Bowls, stacked foods and thin slices need grams or serving counts." : step == 0 ? "Tap around the visible boundary of \(foodName), in order. Include only this food; keep the entire portion in frame." : step == 1 ? "Tap four empty, flat parts of the plate around the food. Avoid the raised rim, table, sauce and other foods." : "Review the volume and select a density reference for this exact food and preparation.").font(.subheadline).foregroundStyle(Palette.secondary)
                    if let snapshot {
                        annotated(snapshot)
                        if step < 2 {
                            HStack { Button("Undo point") { if step == 0 { if !outline.isEmpty { outline.removeLast() } } else { if !plate.isEmpty { plate.removeLast() } }; message=nil }; Spacer(); Text(step == 0 ? "\(outline.count) boundary points" : "\(plate.count) / 4 plate points").font(.caption) }
                            if step == 0 { PrimaryButton(label:"Finish food outline") { step=1; message=nil }.disabled(outline.count < 3).accessibilityIdentifier("nutrition-depth-outline-done") }
                            else { PrimaryButton(label:"Estimate volume") { calculate(snapshot) }.disabled(plate.count != 4).accessibilityIdentifier("nutrition-depth-estimate") }
                            Button("Reset outline & plate points") { reset() }
                        }
                        if let volume {
                            VStack(alignment:.leading,spacing:8) {
                                Text("≈ \(volume.milliliters.short) mL").font(.title2.bold()).accessibilityIdentifier("nutrition-depth-volume")
                                Text("\(Int(volume.coverage*100))% accepted depth · plate fit \(volume.planeErrorMM.short) mm · mean height \(volume.meanHeightMM.short) mm").font(.caption)
                                Text("These are scan quality checks, not an accuracy percentage. Single-view volume assumes food rests on the selected plane and has no hidden cavities.").font(.caption).foregroundStyle(Palette.secondary)
                            }.padding(16).card()
                            Text("Convert volume to grams").font(.headline)
                            Text("Choose a weight / volume reference for this same food. Density changes with preparation and packing. We never assume 1 mL = 1 g.").font(.caption).foregroundStyle(Palette.secondary)
                            ForEach(FoodDensityReference.suggestions(food)) { ref in
                                Button("Use \(ref.title) · \(ref.grams.short) g / \(ref.milliliters.short) mL") { referenceVolume=ref.milliliters.foodInput; referenceGrams=ref.grams.foodInput; densitySource=String(ref.source.prefix(200)); confirmed=false }.buttonStyle(.borderless)
                            }
                            nutritionField("Reference volume (mL)",text:$referenceVolume)
                            nutritionField("Reference weight (g)",text:$referenceGrams)
                            Text(densitySource).font(.caption).foregroundStyle(Palette.secondary)
                            if let reference { Text("≈ \((volume.milliliters*reference.density).short) g estimated · density \(reference.density.short) g/mL").font(.headline).accessibilityIdentifier("nutrition-depth-weight") }
                            Toggle("I checked the food, flat plate and density reference",isOn:$confirmed).accessibilityIdentifier("nutrition-depth-confirm")
                            Text("The scan estimates weight, not ingredients or absorbed oil. Confirm the nutrition match separately. Use a scale whenever you need a measured weight.").font(.caption).foregroundStyle(Palette.secondary)
                            PrimaryButton(label:"Use estimated grams") { apply(volume) }.disabled(!confirmed || reference == nil || (volume.milliliters*(reference?.density ?? 0)) > 10000).accessibilityIdentifier("nutrition-depth-apply")
                            Button("Edit outline & plate points") { reset() }
                        }
                    } else {
                        if let preview=camera.preview { Image(uiImage:preview).resizable().scaledToFit().frame(maxHeight:420).clipShape(RoundedRectangle(cornerRadius:12)) }
                        Text(camera.message).font(.footnote).foregroundStyle(Palette.secondary)
                        PrimaryButton(label:"Capture depth & photo") {
                            guard let value=camera.capture() else { return }
                            camera.stop()
                            if captureOnly { captured?(value); dismiss() } else { snapshot=value }
                        }.disabled(!camera.ready).accessibilityIdentifier("nutrition-depth-capture")
                    }
                    if let message { Text(message).font(.footnote).foregroundStyle(Palette.action).accessibilityIdentifier("nutrition-depth-error") }
                    Text("Depth is processed on your iPhone. Raw depth is discarded when this meal draft closes. Only the normal photo is sent to your configured AI service when you tap Analyze Meal.").font(.caption).foregroundStyle(Palette.secondary)
                }.padding(16)
            }.background(Palette.background).navigationTitle("3D Portion Scan").navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement:.cancellationAction) { Button("Cancel") { dismiss() } }; ToolbarItemGroup(placement:.keyboard) { Spacer(); Button("Done") { hideNutritionKeyboard() } } }
                .task { if let initial { snapshot=initial } else { await camera.start() } }
                .onDisappear { camera.stop() }
                .onChange(of:scenePhase) { _,phase in if phase != .active { camera.stop() } }
                .onChange(of:referenceVolume) { _,_ in confirmed=false }
                .onChange(of:referenceGrams) { _,_ in confirmed=false }
        }
    }
    private func annotated(_ capture:FoodDepthCapture) -> some View {
        GeometryReader { geo in
            ZStack {
                Image(uiImage:capture.image).resizable()
                Path { path in
                    guard let first=outline.first else { return }; path.move(to:CGPoint(x:CGFloat(first.u)*geo.size.width,y:CGFloat(first.v)*geo.size.height))
                    for p in outline.dropFirst() { path.addLine(to:CGPoint(x:CGFloat(p.u)*geo.size.width,y:CGFloat(p.v)*geo.size.height)) }
                    if step > 0 { path.closeSubpath() }
                }.stroke(Palette.action,lineWidth:3)
                ForEach(Array(outline.enumerated()),id:\.offset) { _,p in Circle().fill(Palette.action).frame(width:9,height:9).position(x:CGFloat(p.u)*geo.size.width,y:CGFloat(p.v)*geo.size.height) }
                ForEach(Array(plate.enumerated()),id:\.offset) { index,p in Text("\(index+1)").font(.caption.bold()).foregroundStyle(Palette.background).frame(width:24,height:24).background(Palette.action,in:Circle()).position(x:CGFloat(p.u)*geo.size.width,y:CGFloat(p.v)*geo.size.height) }
            }.contentShape(Rectangle()).gesture(SpatialTapGesture().onEnded { value in
                let p=DepthPixel(u:Double(value.location.x/geo.size.width),v:Double(value.location.y/geo.size.height))
                guard p.valid else { return }
                if step == 0,outline.count < 64 { outline.append(p) }
                else if step == 1,plate.count < 4 { plate.append(p) }
                message=nil
            }).accessibilityIdentifier("nutrition-depth-canvas")
        }.aspectRatio(capture.image.size.width/capture.image.size.height,contentMode:.fit)
    }
    private func reset() { step=0; outline=[]; plate=[]; volume=nil; confirmed=false; message=nil }
    private func calculate(_ capture:FoodDepthCapture) {
        do { volume=try FoodDepthGeometry.estimate(frame:capture.frame,outline:outline.map { MetricDepthFrame.sensorPixel(portrait:$0) },plate:plate.map { MetricDepthFrame.sensorPixel(portrait:$0) }); step=2; message=nil }
        catch { message=error.localizedDescription }
    }
    private func apply(_ volume:DepthVolume) {
        guard confirmed,let reference else { return }
        let evidence=FoodDepthEvidence(volumeML:volume.milliliters,densityGramsPerML:reference.density,densitySource:String(reference.source.prefix(200)),referenceVolumeML:reference.milliliters,referenceWeightGrams:reference.grams,scanGrams:volume.milliliters*reference.density,coverage:volume.coverage,planeErrorMM:volume.planeErrorMM,meanHeightMM:volume.meanHeightMM,foodID:food?.id,applied:true)
        guard evidence.valid else { message="This conversion is outside the supported range."; return }
        applied?(evidence); dismiss()
    }
}
