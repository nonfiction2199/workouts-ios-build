import XCTest
final class FoodDepthFlowTests: XCTestCase {
    func testDepthUnavailablePreservesDescription() throws {
        let app=XCUIApplication();app.launchEnvironment["WORKOUTS_PREVIEW_SCREEN"]="food-photo";app.launchEnvironment["WORKOUTS_NUTRITION_TEST"]=UUID().uuidString;app.launch()
        let start=app.buttons["nutrition-depth-start"]
        XCTAssertTrue(start.waitForExistence(timeout:20));start.tap()
        XCTAssertTrue(app.staticTexts["This device has no supported rear LiDAR scanner. Use a photo, measured grams or serving counts."].waitForExistence(timeout:10))
        XCTAssertFalse(app.buttons["nutrition-depth-capture"].isEnabled)
        app.buttons["Cancel"].tap()
        XCTAssertTrue(app.buttons["nutrition-depth-start"].waitForExistence(timeout:10))
    }
    func testMetricVolumeConversionAndDiaryPersist() throws {
        let app=XCUIApplication();app.launchEnvironment["WORKOUTS_PREVIEW_SCREEN"]="food-depth";app.launchEnvironment["WORKOUTS_NUTRITION_TEST"]=UUID().uuidString;app.launchEnvironment["WORKOUTS_PREVIEW_THEME"]="blueprint";app.launch()
        let food=app.buttons["nutrition-review-Cooked rice"]
        XCTAssertTrue(food.waitForExistence(timeout:20));food.tap()
        let scan=app.buttons["nutrition-depth-food"]
        for _ in 0..<4 { if scan.isHittable { break };app.swipeUp() };XCTAssertTrue(scan.waitForExistence(timeout:10));scan.tap()
        let canvas=app.otherElements["nutrition-depth-canvas"].firstMatch
        XCTAssertTrue(canvas.waitForExistence(timeout:10))
        for p in [(0.34,0.34),(0.66,0.34),(0.66,0.66),(0.34,0.66)] { canvas.coordinate(withNormalizedOffset:CGVector(dx:p.0,dy:p.1)).tap() }
        app.buttons["nutrition-depth-outline-done"].tap()
        for p in [(0.15,0.15),(0.85,0.15),(0.85,0.85),(0.15,0.85)] { canvas.coordinate(withNormalizedOffset:CGVector(dx:p.0,dy:p.1)).tap() }
        let estimate=app.buttons["nutrition-depth-estimate"]
        for _ in 0..<3 { if estimate.isHittable { break };app.swipeUp() };XCTAssertTrue(estimate.isEnabled);estimate.tap()
        let volume=app.staticTexts["nutrition-depth-volume"]
        XCTAssertTrue(volume.waitForExistence(timeout:10));XCTAssertTrue(volume.label.contains("324"),volume.label)
        func enter(_ name:String,_ value:String) {
            let field=app.textFields["nutrition-"+name]
            for _ in 0..<5 { if field.isHittable { break };app.swipeUp() }
            XCTAssertTrue(field.exists);field.tap();field.typeText(value)
            app.toolbars.buttons["Done"].firstMatch.tap()
        }
        enter("Reference volume (mL)","400");enter("Reference weight (g)","200")
        let confirm=app.switches["nutrition-depth-confirm"]
        for _ in 0..<3 { if confirm.isHittable { break };app.swipeUp() };confirm.tap()
        let apply=app.buttons["nutrition-depth-apply"]
        for _ in 0..<3 { if apply.isHittable { break };app.swipeUp() };XCTAssertTrue(apply.isEnabled);apply.tap()
        let grams=app.textFields["nutrition-Grams"]
        for _ in 0..<6 { if grams.isHittable { break };app.swipeDown() }
        XCTAssertTrue(grams.waitForExistence(timeout:10));XCTAssertEqual(Double(grams.value as? String ?? "") ?? 0,162,accuracy:0.1)
        let save=app.buttons["nutrition-save-match"]
        for _ in 0..<12 { if save.isHittable { break };app.swipeUp() };XCTAssertTrue(save.isEnabled);save.tap()
        let approve=app.buttons["Approve & Log 1 Foods"]
        for _ in 0..<6 { if approve.isHittable { break };app.swipeUp() };XCTAssertTrue(approve.isEnabled);approve.tap()
        app.terminate();app.launchEnvironment["WORKOUTS_PREVIEW_SCREEN"]="nutrition";app.launch()
        let entry=app.buttons.containing(.staticText,identifier:"Cooked rice").firstMatch
        for _ in 0..<5 { if entry.isHittable { break };app.swipeUp() };XCTAssertTrue(entry.waitForExistence(timeout:10));entry.tap()
        let reference=app.staticTexts.matching(NSPredicate(format:"label BEGINSWITH %@","3D scan reference:")).firstMatch
        for _ in 0..<8 { if reference.exists && reference.isHittable { break };app.swipeUp() }
        XCTAssertTrue(reference.exists);XCTAssertTrue(reference.label.contains("324"));XCTAssertTrue(reference.label.contains("162"))
    }
}
