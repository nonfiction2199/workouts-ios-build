import Foundation
@main struct FoodDepthTests {
    static func main() throws {
        var checks=0
        func check(_ value:Bool,_ reason:String) { checks+=1; if !value { fatalError(reason) } }
        func reject(_ frame:MetricDepthFrame,_ outline:[DepthPixel],_ plate:[DepthPixel]) -> Bool { do { _=try FoodDepthGeometry.estimate(frame:frame,outline:outline,plate:plate); return false } catch { return true } }
        let n=80
        var frame=MetricDepthFrame(width:n,height:n,depths:Array(repeating:0.4,count:n*n),confidence:Array(repeating:2,count:n*n),fx:100,fy:100,cx:40,cy:40)
        for y in 25...54 { for x in 25...54 { frame.depths[y*n+x]=0.36 } }
        let outline=[DepthPixel(u:26.0/79,v:26.0/79),DepthPixel(u:53.0/79,v:26.0/79),DepthPixel(u:53.0/79,v:53.0/79),DepthPixel(u:26.0/79,v:53.0/79)]
        let plate=[DepthPixel(u:0.15,v:0.15),DepthPixel(u:0.85,v:0.15),DepthPixel(u:0.85,v:0.85),DepthPixel(u:0.15,v:0.85)]
        let result=try FoodDepthGeometry.estimate(frame:frame,outline:outline,plate:plate)
        // Independent analytic prism: 27 pixels × 0.36/100 m, squared × 0.04 m.
        let exact=pow(27*0.36/100,2)*0.04*1_000_000
        check(abs(result.milliliters-exact)<0.002,"known metric rectangular prism volume")
        check(result.coverage==1 && abs(result.meanHeightMM-40)<0.001,"complete reliable scan quality")
        check(abs(result.footprintCM2-pow(27*0.36/100,2)*10_000)<0.002,"physical footprint area")
        let portrait=DepthPixel(u:0.2,v:0.7),sensor=MetricDepthFrame.sensorPixel(portrait:portrait)
        check(abs(sensor.u-0.7)<1e-10 && abs(sensor.v-0.8)<1e-10,"clockwise RGB rotation maps to original depth")
        check(MetricDepthFrame.sensorPixel(portrait:DepthPixel(u:0,v:0)) == DepthPixel(u:0,v:1),"corner mapping")
        var bad=frame;bad.confidence=Array(repeating:1,count:n*n)
        check(reject(bad,outline,plate),"medium confidence cannot silently produce volume")
        bad=frame; for y in 30...45 { for x in 30...45 { bad.confidence[y*n+x]=0 } }
        check(reject(bad,outline,plate),"missing depth rejects instead of inventing a fill")
        bad=frame;bad.depths[20] = .nan
        check(bad.point(20,0) == nil,"nonfinite sensor values filtered")
        bad=frame;bad.fx=0
        check(reject(bad,outline,plate),"invalid camera calibration rejected")
        bad=frame;bad.depths.removeLast()
        check(reject(bad,outline,plate),"truncated depth rejected before indexing")
        check(reject(frame,[outline[0],outline[2],outline[1],outline[3]],plate),"crossed boundaries rejected")
        check(reject(frame,outline,[plate[0],plate[0],plate[0],plate[0]]),"degenerate plate plane rejected")
        check(reject(frame,outline,[outline[0],plate[1],plate[2],plate[3]]),"plate reference inside food rejected")
        bad=frame;for y in 25...54 { for x in 25...54 { bad.depths[y*n+x]=0.395 } }
        check(reject(bad,outline,plate),"thin foods cannot pretend to be resolved")
        bad=frame;for y in 25...54 { for x in 25...54 { bad.depths[y*n+x]=0.42 } }
        check(reject(bad,outline,plate),"incorrect raised base plane rejected")
        let tilted=(0..<30).map { i in let x=Double(i%6)*0.025,y=Double(i/6)*0.025; return DepthPoint(x:x,y:y,z:0.3*x+0.15*y+0.4) }
        let fitted=try FoodDepthGeometry.plane(tilted)
        check(abs(fitted.a-0.3)<1e-9 && abs(fitted.b-0.15)<1e-9 && fitted.error<1e-9,"tilted plate fit recovers analytic plane")
        var rice=FoodItem(id:"usda-1",name:"Cooked rice",category:"Grains",source:"USDA",referenceGrams:100,macros:FoodMacros(calories:130),portions:[FoodPortion(name:"1 cup",grams:158),FoodPortion(name:"1 bowl",grams:200),FoodPortion(name:"100 ml",grams:66.8)])
        let refs=FoodDensityReference.suggestions(rice)
        check(refs.count==2 && abs(refs[0].milliliters-236.5882365)<0.0001,"only explicit supported volume portions produce density options")
        rice.id="brand-1"
        check(FoodDensityReference.suggestions(rice).count==1,"unknown cup conventions cannot supply density")
        check(!FoodDensityReference(title:"Bad",milliliters:0,grams:1,source:"Test").valid,"invalid density reference rejected")
        var evidence=FoodDepthEvidence(volumeML:300,densityGramsPerML:0.6,densitySource:"User weighed 240 g in 400 mL",referenceVolumeML:400,referenceWeightGrams:240,scanGrams:180,coverage:1,planeErrorMM:0.5,meanHeightMM:30,foodID:rice.id,applied:true)
        check(evidence.valid,"valid density conversion provenance")
        evidence.scanGrams=300
        check(!evidence.valid,"mL cannot be silently relabeled grams")
        evidence.scanGrams=180
        let basis=FoodNutritionBasis(resolution:"library",depth:evidence)
        let entry=FoodLogEntry(day:"2026-10-05",meal:.lunch,foodID:rice.id,name:rice.name,grams:180,macros:rice.nutrition(grams:180),source:"Depth estimate",estimated:true,nutritionBasis:basis)
        let state=NutritionState(customFoods:[],entries:[entry])
        let restored=try JSONDecoder().decode(NutritionState.self,from:JSONEncoder().encode(state))
        check(restored.valid && restored.entries[0].nutritionBasis?.depth?.volumeML==300,"depth reference persists through diary/backup round trip")
        let old=Data("{\"adjusted\":false,\"resolution\":\"library\"}".utf8)
        let oldBasis=try JSONDecoder().decode(FoodNutritionBasis.self,from:old)
        check(oldBasis.depth==nil,"old diary remains compatible")
        let item=FoodAIItem(name:rice.name,grams:180,macros:rice.nutrition(grams:180),uncertainty:"Estimate",matchedFood:rice,nutritionBasis:basis)
        let half=FoodPlate.scaled(item,by:0.5,reason:"Half")!
        check(half.grams==90 && half.nutritionBasis?.depth?.scanGrams==180 && half.nutritionBasis?.depth?.applied==false,"fraction changes mark retained scan as reference rather than new measurement")
        print("Food depth: \(checks) checks passed")
    }
}
