import SwiftUI
import UserNotifications

final class AppDelegate: NSObject, UIApplicationDelegate, UNUserNotificationCenterDelegate {
    func application(_ application: UIApplication, didFinishLaunchingWithOptions options: [UIApplication.LaunchOptionsKey: Any]? = nil) -> Bool {
        #if DEBUG
        if let theme = ProcessInfo.processInfo.environment["WORKOUTS_PREVIEW_THEME"], AppTheme(rawValue: theme) != nil {
            UserDefaults.standard.set(theme, forKey: "appearance")
        }
        #endif
        UNUserNotificationCenter.current().delegate = self
        Haptics.prepare()
        let navigation = UINavigationBarAppearance()
        navigation.configureWithOpaqueBackground()
        navigation.backgroundColor = UIColor(Palette.surface)
        navigation.shadowColor = .clear
        UINavigationBar.appearance().standardAppearance = navigation
        UINavigationBar.appearance().scrollEdgeAppearance = navigation
        UITableView.appearance().backgroundColor = UIColor(Palette.background)
        UICollectionView.appearance().backgroundColor = UIColor(Palette.background)
        return true
    }
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completion: @escaping (UNNotificationPresentationOptions) -> Void) {
        completion([.banner, .sound])
    }
}
@main
struct WorkoutsApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) var delegate
    @StateObject private var store = TrainingStore()
    @StateObject private var nutrition = NutritionStore()
    @AppStorage("appearance") private var appearance = "dark"
    var body: some Scene {
        WindowGroup {
            RootView().environmentObject(store).environmentObject(nutrition)
                .onReceive(NotificationCenter.default.publisher(for: UIApplication.didBecomeActiveNotification)) { _ in Haptics.prepare() }
                .preferredColorScheme(AppTheme(rawValue: appearance)?.colorScheme)
                .tint(Palette.action)
        }
    }
}
enum Palette {
    private static func dynamic(_ key: KeyPath<ThemeColors, UInt32>) -> Color {
        Color(uiColor: UIColor { traits in AppTheme.current.resolved(for: traits.userInterfaceStyle).colors[keyPath: key].uiColor })
    }
    static var background: Color { dynamic(\.background) }
    static var surface: Color { dynamic(\.surface) }
    static var control: Color { dynamic(\.control) }
    static var secondary: Color { dynamic(\.secondary) }
    static var separator: Color { dynamic(\.separator) }
    static var blue: Color { dynamic(\.blue) }
    static var ringBlue: Color { dynamic(\.ringBlue) }
    static var coral: Color { dynamic(\.coral) }
    static var teal: Color { dynamic(\.teal) }
    static var action: Color { dynamic(\.action) }
    static var actionText: Color { dynamic(\.actionText) }
    static var bodySilhouette: Color { dynamic(\.bodySilhouette) }
    static var bodyNeutral: Color { dynamic(\.bodyNeutral) }
}
extension View {
    func card() -> some View { self.background(Palette.surface, in: RoundedRectangle(cornerRadius: 14, style: .continuous)) }
    func darkForm() -> some View { self.scrollContentBackground(.hidden).background(Palette.background) }
}
struct ScreenTitle: View {
    let text: String
    var body: some View { Text(text.uppercased()).font(.custom("WorkoutsDisplay-Regular", size: 25, relativeTo: .title2)).lineLimit(1).minimumScaleFactor(0.75).tracking(-0.5).accessibilityAddTraits(.isHeader) }
}
struct CircleAction: View {
    let symbol: String; let label: String; var diameter: CGFloat = 40; var action: () -> Void
    var body: some View {
        Button(action: action) { ReferenceSymbol(name: symbol).font(.system(size: 20, weight: .medium)).frame(width: diameter, height: diameter).background(Palette.control, in: Circle()) }.buttonStyle(.plain).accessibilityLabel(label)
    }
}
struct PrimaryButton: View {
    let label: String; var action: () -> Void
    var body: some View { Button(action: action) { Text(label).font(.system(size: 18)).frame(maxWidth: .infinity).padding(.vertical, 17).foregroundStyle(Palette.actionText).background(Palette.action, in: RoundedRectangle(cornerRadius: 7)) }.buttonStyle(.plain) }
}
struct SectionHeading: View {
    let title: String
    var body: some View { Text(title).font(.system(size: 20, weight: .semibold)).frame(maxWidth: .infinity, alignment: .leading).accessibilityAddTraits(.isHeader) }
}
struct SettingsRow: View {
    let title: String; let symbol: String; var subtitle: String? = nil; var action: () -> Void
    var body: some View {
        Button(action: action) {
            HStack(spacing: 18) {
                ReferenceSymbol(name: symbol).font(.system(size: 22, weight: .semibold)).frame(width: 28)
                VStack(alignment: .leading, spacing: 4) { Text(title).font(.body); if let subtitle { Text(subtitle).font(.caption).foregroundStyle(.secondary) } }
                Spacer(); Image(systemName: "chevron.right").font(.subheadline.weight(.semibold)).foregroundStyle(.tertiary)
            }.padding(.horizontal, 22).padding(.vertical, 20).frame(minHeight: 65).contentShape(Rectangle())
        }.buttonStyle(.plain)
    }
}
enum AppSheet: String, Identifiable {
    case shortcuts, newProgram, newWorkout, dashboardSettings, shortcutSettings, history, catalog, preferences, progression, programEditor, nutrition, foodSearch, foodPhoto, foodRecipe, foodGoals
    var id: String { rawValue }
}
struct RootView: View {
    @EnvironmentObject var store: TrainingStore
    @AppStorage("appearance") private var appearance = "dark"
    @State private var sheet: AppSheet?
    var body: some View {
        ZStack {
            (store.tab == 3 ? Palette.background : Palette.surface).ignoresSafeArea()
            if store.startupBlocked {
                ContentUnavailableView("Saved data needs attention", systemImage: "externaldrive.badge.exclamationmark", description: Text("Your data has not been overwritten. Install a newer build or restore from your exported backup after resolving the error."))
            } else if store.state != nil {
                Group {
                    switch store.tab {
                    case 0: DashboardView(open: { sheet = $0 })
                    case 1: WorkoutView(open: { sheet = $0 })
                    case 2: LevelsView()
                    default: MoreView(open: { sheet = $0 })
                    }
                }.id(store.tab == 3 ? "more" : appearance).safeAreaInset(edge: .bottom, spacing: 0) { bottomBar }
            } else { Text("Unable to open Workouts") }
        }
        .onAppear {
            #if DEBUG
            // Only the simulator screenshot job sets this. Release builds omit it.
            if ProcessInfo.processInfo.environment["WORKOUTS_PREVIEW_SCREEN"] != nil, store.state?.program.isEmpty == true {
                store.send("generate", ["settings": ["days": 4]])
            }
            switch ProcessInfo.processInfo.environment["WORKOUTS_PREVIEW_SCREEN"] {
            case "workout": store.tab = 1
            case "overview", "exercise", "exercise-details", "exercise-history", "exercise-options":
                if store.state?.program.isEmpty == true { store.send("generate", ["settings": ["days": 4]]) }
                store.tab = 1
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { store.openWorkout(0, haptic: false) }
            case "exercise-picker":
                store.tab = 1
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) { store.startEmpty(haptic: false) }
            case "levels": store.tab = 2
            case "more", "theme-picker": store.tab = 3
            case "shortcuts": sheet = .shortcuts
            case "nutrition", "nutrition-goals", "food-search", "food-library", "food-photo", "food-match", "food-restaurant", "food-depth", "food-portions", "food-recipe": sheet = .nutrition
            default: break
            }
            #endif
        }
        .sheet(item: $sheet) { item in
            Group {
                switch item {
                case .shortcuts: ShortcutsView(open: { next in sheet = nil; DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) { sheet = next } })
                case .newProgram: ProgramBuilderView()
                case .newWorkout: ProgramEditorView(createNew: true)
                case .dashboardSettings: DisplaySettingsView(shortcuts: false)
                case .shortcutSettings: DisplaySettingsView(shortcuts: true)
                case .history: HistoryView()
                case .catalog: ExerciseLibraryView()
                case .preferences: PreferencesView()
                case .progression: ProgressionView()
                case .programEditor: ProgramEditorView()
                case .nutrition: NutritionView()
                case .foodSearch: NutritionView(initial: .search)
                case .foodPhoto: NutritionView(initial: .photo)
                case .foodRecipe: NutritionView(initial: .recipe)
                case .foodGoals: NutritionView(initial: .goals)
                }
            }.presentationDragIndicator(.visible).presentationCornerRadius(22).presentationBackground(Palette.surface)
        }
        .fullScreenCover(item: $store.overview, onDismiss: {
            if let day = store.pendingOverviewStart {
                store.pendingOverviewStart = nil
                store.start(day, haptic: false)
            }
        }) { route in WorkoutOverviewView(dayIndex: route.id) }
        .fullScreenCover(isPresented: $store.showLogger) { LoggerView() }
        .alert("Workouts", isPresented: Binding(get: { store.error != nil }, set: { if !$0 { store.error = nil } })) { Button("OK", role: .cancel) { store.error = nil } } message: { Text(store.error ?? "") }
    }
    private var bottomBar: some View {
        HStack(spacing: 0) {
            tab("Dashboard", symbol: store.tab == 0 ? "square.grid.2x2.fill" : "square.grid.2x2", index: 0)
            tab("Workout", symbol: "dumbbell.fill", index: 1)
            Button { sheet = .shortcuts } label: { Image(systemName: "plus").font(.system(size: 28)).foregroundStyle(Palette.actionText).frame(width: 42,height: 42).background(Palette.action, in: Circle()).frame(maxWidth: .infinity) }.buttonStyle(.plain).accessibilityLabel("Open shortcuts")
            Button { store.tab = 2 } label: {
                VStack(spacing: 4) { RocketIcon(filled: store.tab == 2, color: store.tab == 2 ? .primary : .secondary).frame(width: 25, height: 28); Text("Levels").font(.system(size: 11)) }.foregroundStyle(store.tab == 2 ? Color.primary : Color.secondary).frame(maxWidth: .infinity).frame(minHeight: 48)
            }.buttonStyle(.plain).accessibilityAddTraits(store.tab == 2 ? [.isSelected] : [])
            tab("More", symbol: store.tab == 3 ? "ellipsis.circle.fill" : "ellipsis.circle", index: 3)
        }.padding(.top, 8).padding(.bottom, 4).background(Palette.surface).overlay(alignment: .top) { Divider() }
    }
    private func tab(_ title: String, symbol: String, index: Int) -> some View {
        Button { store.tab = index } label: {
            VStack(spacing: 4) { Group { if index == 0 { DashboardIcon(filled: store.tab == 0) } else { Image(systemName: symbol).font(.system(size: 23)).rotationEffect(.degrees(index == 1 ? -45 : 0)) } }.frame(height: 26); Text(title).font(.system(size: 11)) }.foregroundStyle(store.tab == index ? Color.primary : Color.secondary).frame(maxWidth: .infinity).frame(minHeight: 48)
        }.buttonStyle(.plain).accessibilityAddTraits(store.tab == index ? [.isSelected] : [])
    }
}
