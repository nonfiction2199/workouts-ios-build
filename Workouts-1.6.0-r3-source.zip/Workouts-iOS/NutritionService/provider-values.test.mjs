import test from 'node:test';
import assert from 'node:assert/strict';
import {createService,mealSchema,normalizeProviderResult,validMealResult,invalidFoodFields} from './server.mjs';
const item={name:'Fried chicken tenders',grams:450,macros:{calories:1274,protein:85,carbs:76,fat:70,fiber:5},uncertainty:'Estimated portion'};
test('schema excludes zero grams and zero counts accepted by the previous schema',()=>{
 assert.equal(mealSchema.properties.items.items.properties.grams.exclusiveMinimum,0);
 assert.equal(mealSchema.properties.items.items.properties.quantity.properties.count.exclusiveMinimum,0);
});
test('missing optional meal metadata and zero unknown count preserve real nutrition',()=>{
 const raw={items:[{...item,quantity:{count:0,unit:null,basis:null,weightBasis:null},exclude:[''],add:null}],notes:null,questions:null};
 const normalized=normalizeProviderResult(raw,{mealMode:true,compact:true});
 assert.ok(validMealResult(normalized));assert.deepEqual(normalized.items[0].macros,item.macros);
 assert.deepEqual(normalized.items[0].quantity,{count:null,unit:'',basis:'photo',weightBasis:'photo'});
 assert.deepEqual(normalized.items[0].exclude,[]);assert.equal(normalized.restaurantName,'');
 assert.equal(raw.items[0].quantity.count,0,'normalization must not mutate input');
});
test('numeric strings and excessive advisory text do not reject complete portion nutrition',()=>{
 const raw={items:[{...item,grams:'450',macros:Object.fromEntries(Object.entries(item.macros).map(([k,v])=>[k,String(v)])),uncertainty:'Estimate '.repeat(30)}],notes:'Estimate '.repeat(50),questions:['Review portion?','Review oil?','Extra question']};
 const normalized=normalizeProviderResult(raw,{mealMode:true,compact:true});
 assert.ok(validMealResult(normalized));assert.deepEqual(normalized.items[0].macros,item.macros);
 assert.equal(normalized.items[0].grams,450);assert.equal(normalized.questions.length,2);
});
test('normalization never substitutes missing or invalid weights and nutrients',()=>{
 for(const [path,change] of [
  ['items[0].grams',{grams:-1}],['items[0].grams',{grams:'450 g'}],
  ['items[0].macros.protein',{macros:{...item.macros,protein:null}}],
  ['items[0].macros.fiber',{macros:{...item.macros,fiber:undefined}}],
  ['items[0]',null]
 ]){
  const raw={items:[change===null?null:{...item,...change}]};
  const normalized=normalizeProviderResult(raw,{mealMode:true,compact:true});
  assert.equal(Boolean(validMealResult(normalized)),false);assert.ok(invalidFoodFields(normalized,{mealMode:true,compact:true}).includes(path));
 }
});
test('real workflow-3 HTTP response accepts optional metadata repairs and retains explicit changes',async()=>{
 const token='test-token-with-at-least-24-characters';
 const raw={items:[{...item,quantity:{count:0,unit:'',basis:'user',weightBasis:'user'},exclude:['bread']}],notes:null,questions:null};
 const server=createService({token,provider:'ollama',fetchImpl:async()=>({ok:true,json:async()=>({message:{content:JSON.stringify(raw)}})})});
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 try{
  const base='http://127.0.0.1:'+server.address().port;
  assert.equal((await (await fetch(base+'/health')).json()).localRevision,9);
  const response=await fetch(base+'/analyze',{method:'POST',headers:{Authorization:'Bearer '+token,'Content-Type':'application/json'},body:JSON.stringify({workflow:3,image:Buffer.from([255,216,255,217]).toString('base64'),mimeType:'image/jpeg',context:'fried chicken, no bread'})});
  assert.equal(response.status,200);const value=await response.json();assert.ok(validMealResult(value));
  assert.deepEqual(value.items[0].macros,item.macros);assert.deepEqual(value.items[0].exclude,['bread']);assert.equal(value.items[0].quantity.count,null);assert.equal(value.items[0].quantity.weightBasis,'photo');
 }finally{await new Promise(r=>server.close(r));}
});
