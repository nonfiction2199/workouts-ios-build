import XCTest
final class NutritionFlowTests: XCTestCase {
    func testQuickLogPersistsAndGoalsSave() throws {
        let app = XCUIApplication()
        app.launchEnvironment["WORKOUTS_PREVIEW_SCREEN"] = "nutrition"
        app.launchEnvironment["WORKOUTS_NUTRITION_TEST"] = UUID().uuidString
        app.launchEnvironment["WORKOUTS_PREVIEW_THEME"] = "blueprint"
        app.launch()
        XCTAssertTrue(app.buttons["Quick Add"].waitForExistence(timeout: 20))
        app.buttons["Quick Add"].tap()
        let name = app.textFields["Food or meal name"]
        XCTAssertTrue(name.waitForExistence(timeout: 5)); name.tap(); name.typeText("UI test meal")
        func enter(_ label: String,_ text: String) {
            let field = app.textFields["nutrition-" + label]
            XCTAssertTrue(field.waitForExistence(timeout: 5))
            for _ in 0..<3 { if field.isHittable { break }; app.swipeUp() }
            field.tap()
            if let value = field.value as? String,value != "Required",!value.isEmpty {
                field.doubleTap()
                field.typeText(String(repeating: XCUIKeyboardKey.delete.rawValue,count: value.count))
            }
            field.typeText(text)
            XCTAssertEqual(field.value as? String,text,"Input must be replaced correctly: " + label)
        }
        enter("Reference serving (grams)","200")
        enter("Calories (kcal)","400")
        enter("Protein (g)","30")
        enter("Carbs (g)","40")
        enter("Fat (g)","12")
        if app.keyboards.count>0 { app.buttons["nutrition-keyboard-done"].firstMatch.tap() }
        let log = app.buttons["nutrition-submit-food"]
        if !log.isHittable { app.swipeUp() }
        XCTAssertTrue(log.isEnabled); log.tap()
        let entry = app.buttons.containing(.staticText,identifier: "UI test meal").firstMatch
        if !entry.isHittable { app.swipeUp() }
        XCTAssertTrue(entry.waitForExistence(timeout: 5))
        app.terminate(); app.launch()
        XCTAssertTrue(app.buttons["Quick Add"].waitForExistence(timeout: 15))
        if !entry.isHittable { app.swipeUp() }
        XCTAssertTrue(entry.waitForExistence(timeout: 5))
        // Goal fields must retain full numeric values, not locale-formatted commas.
        app.swipeDown(); app.swipeDown()
        app.buttons["nutrition-goals-button"].tap()
        XCTAssertTrue(app.textFields["nutrition-Calories (kcal)"].waitForExistence(timeout: 5))
        enter("Calories (kcal)","2400")
        enter("Protein (g)","160")
        enter("Carbs (g)","280")
        enter("Fat (g)","70")
        enter("Fiber (g)","30")
        if app.keyboards.count>0 { app.buttons["nutrition-keyboard-done"].firstMatch.tap() }
        let save = app.buttons["Save Goals"]
        if !save.isHittable { app.swipeUp() }
        XCTAssertTrue(save.isEnabled); save.tap()
        XCTAssertTrue(app.buttons["Quick Add"].waitForExistence(timeout: 5))
    }
    func testCatalogueSearchLogsPortion() throws {
        let app = XCUIApplication()
        app.launchEnvironment["WORKOUTS_PREVIEW_SCREEN"] = "nutrition"
        app.launchEnvironment["WORKOUTS_NUTRITION_TEST"] = UUID().uuidString
        app.launchEnvironment["WORKOUTS_PREVIEW_THEME"] = "blueprint"
        app.launch()
        XCTAssertTrue(app.buttons["Log Food"].waitForExistence(timeout: 20))
        app.buttons["Log Food"].tap()
        let query = app.textFields["nutrition-food-query"]
        XCTAssertTrue(query.waitForExistence(timeout: 10))
        query.tap(); query.typeText("Abiyuch\n")
        let food = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "nutrition-result-")).containing(.staticText,identifier: "Abiyuch, raw").firstMatch
        XCTAssertTrue(food.waitForExistence(timeout: 15)); food.tap()
        XCTAssertTrue(app.staticTexts["Food Details"].waitForExistence(timeout: 5))
        let log = app.buttons["nutrition-log-portion"]
        for _ in 0..<3 { if log.isHittable { break }; app.swipeUp() }
        XCTAssertTrue(log.isEnabled); log.tap()
        XCTAssertTrue(query.waitForExistence(timeout: 5))
        app.terminate(); app.launch()
        XCTAssertTrue(app.buttons["Quick Add"].waitForExistence(timeout: 15))
        let entry = app.buttons.containing(.staticText,identifier: "Abiyuch, raw").firstMatch
        for _ in 0..<3 { if entry.isHittable { break }; app.swipeUp() }
        XCTAssertTrue(entry.waitForExistence(timeout: 5))
    }

    private func replace(_ app: XCUIApplication,_ label: String,_ text: String) {
        let field = app.textFields["nutrition-" + label]
        for _ in 0..<6 { if field.exists && field.isHittable { break }; app.swipeUp() }
        XCTAssertTrue(field.waitForExistence(timeout: 5))
        field.tap()
        if let value = field.value as? String,!value.isEmpty { field.doubleTap(); field.typeText(String(repeating: XCUIKeyboardKey.delete.rawValue,count: value.count)) }
        field.typeText(text); XCTAssertEqual(field.value as? String,text)
        if app.keyboards.count > 0 { app.buttons["nutrition-keyboard-done"].firstMatch.tap() }
    }
    private func tapVisible(_ app: XCUIApplication,_ button: XCUIElement) {
        for _ in 0..<8 { if button.exists && button.isHittable && button.frame.maxY < app.frame.maxY - 90 { break }; if !button.exists { _ = button.waitForExistence(timeout: 1) }; app.swipeUp() }
        XCTAssertTrue(button.waitForExistence(timeout: 5))
        XCTAssertTrue(button.isHittable); button.tap()
    }
    func testAutomaticSourcesCountsAndModifiedFallbackAcrossThemes() throws {
        for theme in ["system","light","dark","fieldNotes","blueprint","terracotta","cinder","studio"] {
            let app = XCUIApplication()
            app.launchEnvironment["WORKOUTS_PREVIEW_SCREEN"] = "food-portions"
            app.launchEnvironment["WORKOUTS_NUTRITION_TEST"] = UUID().uuidString
            app.launchEnvironment["WORKOUTS_PREVIEW_THEME"] = theme
            app.launch()
            XCTAssertTrue(app.staticTexts["Review Meal"].waitForExistence(timeout: 25))
            for _ in 0..<6 { if app.staticTexts["500 g · 1,400 kcal"].exists { break }; app.swipeUp() }
            XCTAssertTrue(app.staticTexts["500 g · 1,400 kcal"].exists,"published per-piece count automatically applied: " + theme)
            for _ in 0..<5 { if app.staticTexts["450 g · 1,273.5 kcal"].exists { break }; app.swipeUp() }
            XCTAssertTrue(app.staticTexts["450 g · 1,273.5 kcal"].exists,"modified meal uses generic density, not 2200 AI calories: " + theme)
            XCTAssertTrue(app.staticTexts["No bread"].exists)
            tapVisible(app,app.buttons["nutrition-log-meal"])
            app.terminate(); app.launchEnvironment["WORKOUTS_PREVIEW_SCREEN"] = "nutrition"; app.launch()
            XCTAssertTrue(app.buttons["Quick Add"].waitForExistence(timeout: 20))
            for _ in 0..<6 { if app.buttons.containing(.staticText,identifier: "Fried chicken tenders").firstMatch.exists { break }; app.swipeUp() }
            XCTAssertEqual(app.buttons.containing(.staticText,identifier: "Fried chicken tenders").count,2,"both reviewed foods persist: " + theme)
            app.terminate()
        }
    }
    func testRestaurantPortionAndAdjustedMatchPersist() throws {
        let app = XCUIApplication()
        app.launchEnvironment["WORKOUTS_PREVIEW_SCREEN"] = "food-restaurant"
        app.launchEnvironment["WORKOUTS_NUTRITION_TEST"] = UUID().uuidString
        app.launchEnvironment["WORKOUTS_PREVIEW_THEME"] = "terracotta"
        app.launch()
        tapVisible(app,app.buttons["nutrition-review-Margherita pizza"])
        tapVisible(app,app.buttons["nutrition-menu-test-pizza"])
        // Form virtualizes rows; reveal the selected profile below menu choices.
        let selected = app.staticTexts["Selected: Margherita pizza"]
        for _ in 0..<6 { if selected.exists { break }; app.swipeUp() }
        XCTAssertTrue(selected.waitForExistence(timeout: 5))
        // Source is 1000 kcal per 400 g. Photo estimates 200 g, then measured 100 g.
        app.swipeDown(); app.swipeDown(); app.swipeDown()
        replace(app,"Grams","100")
        tapVisible(app,app.buttons["nutrition-adjust-match"])
        let calories = app.textFields["nutrition-Calories"]
        XCTAssertTrue(calories.waitForExistence(timeout: 5)); XCTAssertEqual(calories.value as? String,"250.0")
        replace(app,"Calories","300")
        tapVisible(app,app.buttons["nutrition-save-match"])
        XCTAssertTrue(app.staticTexts["100 g · 300 kcal"].waitForExistence(timeout: 10))
        tapVisible(app,app.buttons["nutrition-log-meal"])
        app.terminate(); app.launchEnvironment["WORKOUTS_PREVIEW_SCREEN"] = "nutrition"; app.launch()
        XCTAssertTrue(app.buttons["Quick Add"].waitForExistence(timeout: 20))
        let entry = app.buttons.containing(.staticText,identifier: "Margherita pizza").firstMatch
        tapVisible(app,entry)
        XCTAssertTrue(app.descendants(matching: .any).matching(NSPredicate(format: "label CONTAINS %@", "300 kcal")).firstMatch.waitForExistence(timeout: 5))
        XCTAssertTrue(app.staticTexts["Nutrients were adjusted for this entry."].exists)
        XCTAssertTrue(app.links["Example Pizzeria · Brooklyn"].exists || app.buttons["Example Pizzeria · Brooklyn"].exists)
    }
    func testRestaurantServingWithoutWeightUsesServingCount() throws {
        let app = XCUIApplication()
        app.launchEnvironment["WORKOUTS_PREVIEW_SCREEN"] = "food-restaurant"
        app.launchEnvironment["WORKOUTS_NUTRITION_TEST"] = UUID().uuidString
        app.launchEnvironment["WORKOUTS_PREVIEW_THEME"] = "studio"
        app.launch()
        tapVisible(app,app.buttons["nutrition-review-Margherita pizza"])
        tapVisible(app,app.buttons["nutrition-menu-test-slice"])
        app.swipeDown(); app.swipeDown(); app.swipeDown()
        replace(app,"Source servings","2")
        tapVisible(app,app.buttons["nutrition-save-match"])
        XCTAssertTrue(app.staticTexts["200 g · 600 kcal"].waitForExistence(timeout: 10))
        tapVisible(app,app.buttons["nutrition-log-meal"])
        app.terminate(); app.launchEnvironment["WORKOUTS_PREVIEW_SCREEN"] = "nutrition"; app.launch()
        XCTAssertTrue(app.buttons["Quick Add"].waitForExistence(timeout: 20))
        tapVisible(app,app.buttons.containing(.staticText,identifier: "Margherita pizza slice").firstMatch)
        XCTAssertTrue(app.staticTexts["Source servings: 2"].waitForExistence(timeout: 5))
        XCTAssertTrue(app.descendants(matching: .any).matching(NSPredicate(format: "label CONTAINS %@", "600 kcal")).firstMatch.exists)
    }

    func testPhotoDatabaseMatchReplacesAIMacros() throws {
        let app = XCUIApplication()
        app.launchEnvironment["WORKOUTS_PREVIEW_SCREEN"] = "food-match"
        app.launchEnvironment["WORKOUTS_NUTRITION_TEST"] = UUID().uuidString
        app.launchEnvironment["WORKOUTS_PREVIEW_THEME"] = "cinder"
        app.launch()
        let review = app.buttons["nutrition-review-Abiyuch, raw"]
        XCTAssertTrue(review.waitForExistence(timeout: 25)); tapVisible(app,review)
        XCTAssertTrue(app.staticTexts["Review Food"].waitForExistence(timeout: 10),"The full review row must open the correction editor")
        let search = app.buttons["nutrition-match-library"]
        tapVisible(app,search)
        let food = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "nutrition-result-")).containing(.staticText,identifier: "Abiyuch, raw").firstMatch
        XCTAssertTrue(food.waitForExistence(timeout: 15)); food.tap()
        XCTAssertTrue(app.staticTexts["Selected: Abiyuch, raw"].waitForExistence(timeout: 5))
        let save = app.buttons["nutrition-save-match"]
        for _ in 0..<4 { if save.isHittable { break }; app.swipeUp() }
        XCTAssertTrue(save.isEnabled); save.tap()
        // The fixture's intentionally wrong 999 kcal must be replaced by USDA's 69 kcal.
        XCTAssertTrue(app.staticTexts["100 g · 69 kcal"].waitForExistence(timeout: 10))
        let approve = app.buttons["nutrition-log-meal"]
        for _ in 0..<3 { if approve.isHittable { break }; app.swipeUp() }
        XCTAssertTrue(approve.isEnabled); approve.tap()
        app.terminate(); app.launchEnvironment["WORKOUTS_PREVIEW_SCREEN"] = "nutrition"; app.launch()
        XCTAssertTrue(app.buttons["Quick Add"].waitForExistence(timeout: 15))
        let entry = app.buttons.containing(.staticText,identifier: "Abiyuch, raw").firstMatch
        for _ in 0..<3 { if entry.isHittable { break }; app.swipeUp() }
        XCTAssertTrue(entry.waitForExistence(timeout: 5))
    }

    func testFocusedSearchAndPrefixBrowsing() throws {
        let app = XCUIApplication()
        app.launchEnvironment["WORKOUTS_PREVIEW_SCREEN"] = "nutrition"
        app.launchEnvironment["WORKOUTS_NUTRITION_TEST"] = UUID().uuidString
        app.launch()
        XCTAssertTrue(app.buttons["Log Food"].waitForExistence(timeout: 20)); app.buttons["Log Food"].tap()
        let query = app.textFields["nutrition-food-query"]
        XCTAssertTrue(query.waitForExistence(timeout: 10)); query.tap(); query.typeText("naan\n")
        let naan = app.buttons["nutrition-result-usda-2707613"]
        XCTAssertTrue(naan.waitForExistence(timeout: 15))
        XCTAssertFalse(app.buttons["nutrition-result-usda-171845"].exists)
        app.buttons["nutrition-expand-results"].tap()
        XCTAssertTrue(app.buttons["nutrition-result-usda-171845"].waitForExistence(timeout: 15))
        app.buttons["Clear food search"].tap(); query.tap(); query.typeText("B\n")
        let burger = app.buttons["nutrition-result-usda-2706932"]
        let banana = app.buttons["nutrition-result-usda-2709224"]
        XCTAssertTrue(burger.waitForExistence(timeout: 15)); XCTAssertTrue(banana.exists)
        XCTAssertLessThan(burger.frame.minY,banana.frame.minY)
        XCTAssertTrue(app.staticTexts["Common foods first"].exists,"new query resets expanded matching")
    }

    func testOfflineBarcodeSearchLogsBrandedFood() throws {
        let app = XCUIApplication()
        app.launchEnvironment["WORKOUTS_PREVIEW_SCREEN"] = "nutrition"
        app.launchEnvironment["WORKOUTS_NUTRITION_TEST"] = UUID().uuidString
        app.launchEnvironment["WORKOUTS_PREVIEW_THEME"] = "terracotta"
        app.launch()
        XCTAssertTrue(app.buttons["Log Food"].waitForExistence(timeout: 20)); app.buttons["Log Food"].tap()
        let query = app.textFields["nutrition-food-query"]
        XCTAssertTrue(query.waitForExistence(timeout: 10)); query.tap(); query.typeText("016000275287\n")
        let cereal = app.buttons.containing(.staticText,identifier: "Cheerios Cereal").firstMatch
        XCTAssertTrue(cereal.waitForExistence(timeout: 15)); cereal.tap()
        XCTAssertTrue(app.staticTexts["Food Details"].waitForExistence(timeout: 10))
        let log = app.buttons["nutrition-log-portion"]
        for _ in 0..<5 {
            if log.isHittable && log.frame.maxY < app.frame.maxY - 90 { break }
            app.swipeUp()
        }
        XCTAssertTrue(log.isHittable && log.frame.maxY < app.frame.maxY - 90, "Scroll the entire Log button above the home indicator")
        XCTAssertTrue(log.isEnabled); log.tap()
        let logged = XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == false"),object: log)
        XCTAssertEqual(XCTWaiter.wait(for: [logged],timeout: 10),.completed,"Logging must save and dismiss the portion sheet")
        app.buttons["nutrition-library-done"].tap()
        XCTAssertTrue(app.buttons["Quick Add"].waitForExistence(timeout: 10))
        let beforeRestart = app.buttons.containing(.staticText,identifier: "Cheerios Cereal").firstMatch
        for _ in 0..<4 { if beforeRestart.isHittable { break }; app.swipeUp() }
        XCTAssertTrue(beforeRestart.waitForExistence(timeout: 5), "The branded food must be in the diary before restart")
        app.terminate(); app.launch()
        XCTAssertTrue(app.buttons["Quick Add"].waitForExistence(timeout: 15))
        let entry = app.buttons.containing(.staticText,identifier: "Cheerios Cereal").firstMatch
        for _ in 0..<4 { if entry.isHittable { break }; app.swipeUp() }
        XCTAssertTrue(entry.waitForExistence(timeout: 5))
    }

    func testDescribeAcceptsTextWithoutPhoto() throws {
        let app = XCUIApplication()
        app.launchEnvironment["WORKOUTS_PREVIEW_SCREEN"] = "food-photo"
        app.launchEnvironment["WORKOUTS_NUTRITION_TEST"] = UUID().uuidString
        app.launchEnvironment["WORKOUTS_PREVIEW_THEME"] = "studio"
        app.launch()
        XCTAssertTrue(app.staticTexts["AI Food Logging"].waitForExistence(timeout: 20))
        app.buttons["Add details"].tap()
        app.switches["nutrition-ai-mode"].tap()
        let details = app.textViews["nutrition-meal-details"].exists ? app.textViews["nutrition-meal-details"] : app.textFields["nutrition-meal-details"]
        XCTAssertTrue(details.waitForExistence(timeout: 5)); details.tap(); details.typeText("250g cooked rice and two eggs")
        app.swipeUp()
        let find = app.buttons["nutrition-analyze-meal"]
        XCTAssertTrue(find.waitForExistence(timeout: 5)); XCTAssertTrue(find.isEnabled,"text-only Describe must not require a photo")
        // Transport/schema and inference bounds are covered by real HTTP service tests.
    }
    func testPlateFractionsAndSavedMealSurviveRestart() throws {
        let app = XCUIApplication()
        app.launchEnvironment["WORKOUTS_PREVIEW_SCREEN"] = "food-portions"
        app.launchEnvironment["WORKOUTS_NUTRITION_TEST"] = UUID().uuidString
        app.launchEnvironment["WORKOUTS_PREVIEW_THEME"] = "blueprint"
        app.launch()
        XCTAssertTrue(app.staticTexts["2,673.5 kcal total"].waitForExistence(timeout: 25))
        tapVisible(app,app.buttons["More options"])
        tapVisible(app,app.buttons["nutrition-half-plate"])
        for _ in 0..<8 { if app.staticTexts["250 g · 700 kcal"].exists { break }; app.swipeDown() }
        XCTAssertTrue(app.staticTexts["250 g · 700 kcal"].exists,"published piece count and calories scale together")
        tapVisible(app,app.buttons["nutrition-save-plate"])
        let alert = app.alerts["Save Meal"]
        XCTAssertTrue(alert.waitForExistence(timeout: 5)); alert.textFields.firstMatch.tap(); alert.textFields.firstMatch.typeText("My tested plate")
        alert.buttons["Save"].tap()
        // Log the half plate, then find the saved recipe after restart.
        tapVisible(app,app.buttons["nutrition-log-meal"])
        app.terminate(); app.launchEnvironment["WORKOUTS_PREVIEW_SCREEN"] = "nutrition"; app.launch()
        XCTAssertTrue(app.buttons["Log Food"].waitForExistence(timeout: 20)); app.buttons["Log Food"].tap()
        let query = app.textFields["nutrition-food-query"]
        XCTAssertTrue(query.waitForExistence(timeout: 10)); query.tap(); query.typeText("My tested plate\n")
        XCTAssertTrue(app.buttons.containing(.staticText,identifier: "My tested plate").firstMatch.waitForExistence(timeout: 15))
    }
    func testAddMissingFoodToScanPlate() throws {
        let app = XCUIApplication()
        app.launchEnvironment["WORKOUTS_PREVIEW_SCREEN"] = "food-portions"
        app.launchEnvironment["WORKOUTS_NUTRITION_TEST"] = UUID().uuidString
        app.launchEnvironment["WORKOUTS_PREVIEW_THEME"] = "fieldNotes"
        app.launch()
        tapVisible(app,app.buttons["More options"])
        tapVisible(app,app.buttons["nutrition-plate-add"])
        let query = app.textFields["nutrition-food-query"]
        XCTAssertTrue(query.waitForExistence(timeout: 10)); query.tap(); query.typeText("Abiyuch\n")
        let result = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "nutrition-result-")).containing(.staticText,identifier: "Abiyuch, raw").firstMatch
        XCTAssertTrue(result.waitForExistence(timeout: 15)); result.tap()
        XCTAssertTrue(app.staticTexts["Review Meal"].waitForExistence(timeout: 10))
        tapVisible(app,app.buttons["nutrition-review-Abiyuch, raw"])
        tapVisible(app,app.buttons["nutrition-save-match"])
        tapVisible(app,app.buttons["nutrition-log-meal"])
        app.terminate(); app.launchEnvironment["WORKOUTS_PREVIEW_SCREEN"] = "nutrition"; app.launch()
        XCTAssertTrue(app.buttons["Quick Add"].waitForExistence(timeout: 20))
        for _ in 0..<7 { if app.buttons.containing(.staticText,identifier: "Abiyuch, raw").firstMatch.exists { break }; app.swipeUp() }
        XCTAssertTrue(app.buttons.containing(.staticText,identifier: "Abiyuch, raw").firstMatch.exists)
    }
    func testKnownCaloriesScaleChosenProfile() throws {
        let app = XCUIApplication()
        app.launchEnvironment["WORKOUTS_PREVIEW_SCREEN"] = "food-restaurant"
        app.launchEnvironment["WORKOUTS_NUTRITION_TEST"] = UUID().uuidString
        app.launchEnvironment["WORKOUTS_PREVIEW_THEME"] = "terracotta"
        app.launch()
        tapVisible(app,app.buttons["nutrition-review-Margherita pizza"])
        tapVisible(app,app.buttons["nutrition-menu-test-pizza"])
        app.swipeDown(); app.swipeDown(); app.swipeDown()
        replace(app,"Known calories (kcal)","400")
        tapVisible(app,app.buttons["nutrition-known-calories"])
        tapVisible(app,app.buttons["nutrition-save-match"])
        XCTAssertTrue(app.staticTexts["160 g · 400 kcal"].waitForExistence(timeout: 10))
    }

}
