import test from 'node:test';
import assert from 'node:assert/strict';
import { createService,validResult,validLocalResult } from './server.mjs';
const result={items:[{name:'Chicken biryani',grams:300,macros:{calories:500,protein:30,carbs:60,fat:15,fiber:3},uncertainty:'Portion and added oil need confirmation'}],notes:'Estimate; review before logging',questions:['How much did it weigh?']};
test('numeric and structure validation rejects impossible values',()=>{assert.ok(validResult(result));assert.equal(Boolean(validResult({...result,items:[{...result.items[0],grams:-1}]})),false);assert.equal(Boolean(validResult({...result,items:[{...result.items[0],macros:{...result.items[0].macros,calories:Infinity}}]})),false);assert.equal(Boolean(validResult({...result,items:'food'})),false);});
test('photo service protocol authenticates and returns editable validated items',async()=>{
 let calls=0;const token='test-token-with-at-least-24-characters';
 const server=createService({token,apiKey:'fake-key',fetchImpl:async(url,request)=>{calls++;const body=JSON.parse(request.body);assert.equal(body.store,false);assert.ok(body.response_format.schema);assert.equal(body.input[1].mime_type,'image/jpeg');return {ok:true,json:async()=>({steps:[{type:'thought'},{type:'model_output',content:[{type:'text',text:JSON.stringify(result)}]}]})};}});
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
 try{const url='http://127.0.0.1:'+server.address().port+'/analyze';assert.equal((await fetch(url,{method:'POST'})).status,401);
 const request={method:'POST',headers:{Authorization:'Bearer '+token,'Content-Type':'application/json'},body:JSON.stringify({image:Buffer.from([255,216,255,217]).toString('base64'),mimeType:'image/jpeg',context:'300 g meal'})};
 const reply=await fetch(url,request);assert.equal(reply.status,200);assert.deepEqual(await reply.json(),result);assert.equal(calls,1);assert.equal((await fetch(url,request)).status,429);
 }finally{await new Promise(resolve=>server.close(resolve));}
});
test('local limits still reject oversized results after provider schema simplification',()=>{
 assert.equal(Boolean(validResult({...result,items:Array(31).fill(result.items[0])})),false);
 assert.equal(Boolean(validResult({...result,questions:Array(9).fill('Question')})),false);
});
test('transient provider failure retries a fallback and returns a validated result',async()=>{
 let calls=0;const token='test-token-with-at-least-24-characters';
 const server=createService({token,apiKey:'fake-key',model:'primary-model',fallbackModel:'fallback-model',fetchImpl:async(url,request)=>{
   const body=JSON.parse(request.body);calls++;
   assert.equal(body.model,calls===1?'primary-model':'fallback-model');
   if(calls===1)return {ok:false,status:503};
   return {ok:true,json:async()=>({steps:[{type:'model_output',content:[{type:'text',text:JSON.stringify(result)}]}]})};
 }});
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
 try {
   const base='http://127.0.0.1:'+server.address().port;
   assert.deepEqual(await (await fetch(base+'/health')).json(),{status:'ok',protocol:2,model:'primary-model',restaurantLookup:true});
   const reply=await fetch(base+'/analyze',{method:'POST',headers:{Authorization:'Bearer '+token,'Content-Type':'application/json'},body:JSON.stringify({image:Buffer.from([255,216,255,217]).toString('base64'),mimeType:'image/jpeg'})});
   assert.equal(reply.status,200);assert.deepEqual(await reply.json(),result);assert.equal(calls,2);
 } finally {await new Promise(resolve=>server.close(resolve));}
});
test('invalid provider requests are reported without retry or raw provider data',async()=>{
 let calls=0;const token='test-token-with-at-least-24-characters';
 const server=createService({token,apiKey:'fake-key',fetchImpl:async()=>{calls++;return {ok:false,status:400};}});
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
 try {
   const reply=await fetch('http://127.0.0.1:'+server.address().port+'/analyze',{method:'POST',headers:{Authorization:'Bearer '+token,'Content-Type':'application/json'},body:JSON.stringify({image:Buffer.from([255,216,255,217]).toString('base64'),mimeType:'image/jpeg'})});
   assert.equal(reply.status,502);assert.deepEqual(await reply.json(),{error:'The AI provider rejected the request.',providerStatus:400});assert.equal(calls,1);
 } finally {await new Promise(resolve=>server.close(resolve));}
});
test('Ollama mode uses local image/schema protocol without a Gemini key',async()=>{
 let calls=0;const token='test-token-with-at-least-24-characters';
 const server=createService({token,provider:'ollama',model:'qwen3-vl:8b',maxDaily:Infinity,fetchImpl:async(url,request)=>{
   calls++;assert.equal(url,'http://127.0.0.1:11434/api/chat');assert.equal(request.headers['x-goog-api-key'],undefined);assert.equal(request.headers.Authorization,undefined);
   const body=JSON.parse(request.body);assert.equal(body.model,'qwen3-vl:8b-instruct');assert.equal(body.stream,false);assert.equal(body.think,false);assert.ok(body.format.properties.items);assert.equal(body.messages[0].images.length,1);assert.equal(body.options.num_ctx,8192);assert.equal(body.options.num_predict,1800);assert.equal(body.format.properties.items.maxItems,5);assert.equal(body.format.properties.notes.maxLength,240);
   return {ok:true,json:async()=>({message:{content:JSON.stringify(result)}})};
 }});
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
 try {
   const reply=await fetch('http://127.0.0.1:'+server.address().port+'/analyze',{method:'POST',headers:{Authorization:'Bearer '+token,'Content-Type':'application/json'},body:JSON.stringify({image:Buffer.from([255,216,255,217]).toString('base64'),mimeType:'image/jpeg'})});
   assert.equal(reply.status,200);assert.deepEqual(await reply.json(),result);assert.equal(calls,1);
 } finally {await new Promise(resolve=>server.close(resolve));}
});
test('Ollama mode rejects remote destinations and invalid scan limits',()=>{
 assert.throws(()=>createService({token:'test-token-with-at-least-24-characters',provider:'ollama',ollamaURL:'https://example.com'}),/loopback/);
 assert.throws(()=>createService({token:'test-token-with-at-least-24-characters',provider:'ollama',maxDaily:NaN}),/scan limit/);
});
test('invalid local model values cannot reach the diary response',async()=>{
 const token='test-token-with-at-least-24-characters';
 const invalid={...result,items:[{...result.items[0],grams:-1}]};
 const server=createService({token,provider:'ollama',fetchImpl:async()=>({ok:true,json:async()=>({message:{content:JSON.stringify(invalid)}})})});
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
 try {
   const reply=await fetch('http://127.0.0.1:'+server.address().port+'/analyze',{method:'POST',headers:{Authorization:'Bearer '+token,'Content-Type':'application/json'},body:JSON.stringify({image:Buffer.from([255,216,255,217]).toString('base64'),mimeType:'image/jpeg'})});
   assert.equal(reply.status,502);assert.deepEqual(await reply.json(),{error:'Provider returned invalid food values'});
 } finally {await new Promise(resolve=>server.close(resolve));}
});
test('local response bounds reject verbose output while preserving general validation',()=>{
 assert.ok(validLocalResult(result));
 for(const value of [
  {...result,items:Array(6).fill(result.items[0])},
  {...result,notes:'x'.repeat(241)},
  {...result,questions:Array(3).fill('Question')},
  {...result,items:[{...result.items[0],name:'x'.repeat(81)}]}
 ]){assert.ok(validResult(value));assert.equal(Boolean(validLocalResult(value)),false);}
});
test('local truncation and timeout return actionable errors',async()=>{
 const token='test-token-with-at-least-24-characters';
 for(const failure of ['length','timeout']){
  const server=createService({token,provider:'ollama',fetchImpl:async()=>{
   if(failure==='timeout'){const error=new Error('deadline');error.name='TimeoutError';throw error;}
   return {ok:true,json:async()=>({done:true,done_reason:'length',message:{content:JSON.stringify(result)}})};
  }});
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  try{
   const base='http://127.0.0.1:'+server.address().port;
   assert.equal((await (await fetch(base+'/health')).json()).localRevision,6);
   const reply=await fetch(base+'/analyze',{method:'POST',headers:{Authorization:'Bearer '+token,'Content-Type':'application/json'},body:JSON.stringify({image:Buffer.from([255,216,255,217]).toString('base64'),mimeType:'image/jpeg'})});
   assert.equal(reply.status,502);
   assert.deepEqual(await reply.json(),{error:failure==='length'?'Local AI response was too long. Try a simpler photo or log individual foods.':'Local AI exceeded the 55-second scan deadline.'});
  }finally{await new Promise(resolve=>server.close(resolve));}
 }
});

test('workflow 3 grounds restaurant, modifications, measured weights and counts in user evidence',async()=>{
 const {groundMealResult,validMealResult}=await import('./server.mjs');
 const meal={...structuredClone(result),restaurantName:'Example Kitchen',restaurantLocation:'Brooklyn NY'};
 Object.assign(meal.items[0],{requestedName:'Chicken biryani',quantity:{count:2,unit:'servings',basis:'user',weightBasis:'user'},exclude:['bread','oil'],add:['cheese']});
 assert.ok(validMealResult(meal));
 const grounded=groundMealResult(meal,'2 servings of chicken biryani, 300 g, from Example Kitchen Brooklyn NY, no bread');
 assert.equal(grounded.restaurantName,'Example Kitchen');assert.equal(grounded.restaurantLocation,'Brooklyn NY');
 assert.deepEqual(grounded.items[0].exclude,['bread']);assert.deepEqual(grounded.items[0].add,[]);
 assert.equal(grounded.items[0].quantity.basis,'user');assert.equal(grounded.items[0].quantity.weightBasis,'user');
 const invented=groundMealResult(structuredClone(grounded),'rice with bread');
 assert.equal(invented.restaurantName,'');assert.deepEqual(invented.items[0].exclude,[]);
 assert.equal(invented.items[0].quantity.basis,'photo');assert.equal(invented.items[0].quantity.weightBasis,'photo');
 assert.equal(validMealResult({...grounded,items:[{...grounded.items[0],quantity:{count:0,unit:'serving',basis:'user',weightBasis:'photo'}}]}),false);
});
test('workflow 3 handles ounces, explicit changes and spelled counts without inventing ingredients',async()=>{
 const {groundMealResult}=await import('./server.mjs');
 const meal={...structuredClone(result),restaurantName:'',restaurantLocation:''};
 Object.assign(meal.items[0],{grams:6*28.349523125,requestedName:'Chicken',quantity:{count:2,unit:'tenders',basis:'user',weightBasis:'user'},exclude:['bread','mayonnaise'],add:['cheese']});
 const grounded=groundMealResult(meal,'two tenders, 6 oz, without the bread, no mayo, extra cheese');
 assert.equal(grounded.items[0].quantity.weightBasis,'user');assert.equal(grounded.items[0].quantity.basis,'user');
 assert.deepEqual(grounded.items[0].exclude,['bread','mayonnaise']);assert.deepEqual(grounded.items[0].add,['cheese']);
 const prefix=structuredClone(meal);prefix.items[0].quantity.count=10;
 assert.equal(groundMealResult(prefix,'110 tenders').items[0].quantity.basis,'photo','a numeric suffix is not a supplied count');
});
test('workflow 3 remains one compact local vision call and sends no source lookup with the photo',async()=>{
 const token='test-token-with-at-least-24-characters';let calls=0;
 const meal={...structuredClone(result),restaurantName:'Example Kitchen',restaurantLocation:'Brooklyn'};
 Object.assign(meal.items[0],{requestedName:'Chicken biryani',quantity:{count:null,unit:'',basis:'photo',weightBasis:'user'},exclude:[],add:[]});
 const server=createService({token,provider:'ollama',fetchImpl:async(url,request)=>{
  calls++;const payload=JSON.parse(request.body);assert.equal(payload.think,false);assert.equal(payload.format.properties.restaurantName.maxLength,120);
  assert.ok(payload.format.properties.items.items.required.includes('quantity'));return {ok:true,json:async()=>({message:{content:JSON.stringify(meal)}})};
 }});
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 try {
  const reply=await fetch('http://127.0.0.1:'+server.address().port+'/analyze',{method:'POST',headers:{Authorization:'Bearer '+token,'Content-Type':'application/json'},body:JSON.stringify({workflow:3,image:Buffer.from([255,216,255,217]).toString('base64'),mimeType:'image/jpeg',context:'300 g chicken biryani from Example Kitchen Brooklyn'})});
  assert.equal(reply.status,200);assert.deepEqual(await reply.json(),meal);assert.equal(calls,1);
 }finally {await new Promise(r=>server.close(r));}
});

test('a supplied single-food weight overrides the image estimate rather than being ignored',async()=>{
 const {groundMealResult}=await import('./server.mjs');const meal={...structuredClone(result),restaurantName:'',restaurantLocation:''};
 Object.assign(meal.items[0],{grams:450,requestedName:'Biryani',quantity:{count:null,unit:'',basis:'photo',weightBasis:'photo'},exclude:[],add:[]});
 const grounded=groundMealResult(meal,'300 g chicken biryani');assert.equal(grounded.items[0].grams,300);assert.equal(grounded.items[0].quantity.weightBasis,'user');
});
test('numbers belonging to a different food cannot become a claimed user serving count',async()=>{
 const {groundMealResult}=await import('./server.mjs');const meal={...structuredClone(result),restaurantName:'',restaurantLocation:''};
 Object.assign(meal.items[0],{requestedName:'Pizza',quantity:{count:2,unit:'pizzas',basis:'user',weightBasis:'photo'},exclude:[],add:[]});
 const grounded=groundMealResult(meal,'1 pizza and 2 tenders');assert.equal(grounded.items[0].quantity.count,null);assert.equal(grounded.items[0].quantity.basis,'photo');
});
