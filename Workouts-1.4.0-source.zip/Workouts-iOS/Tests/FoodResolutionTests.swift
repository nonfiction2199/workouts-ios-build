import Foundation
@main struct FoodResolutionTests {
    static func main() throws {
        var checks = 0
        func check(_ condition: Bool,_ message: String) { checks += 1; if !condition { fatalError(message) } }
        func lookup(_ candidates: [FoodWebCandidate]) -> RestaurantLookupResponse { RestaurantLookupResponse(query: "Example Kitchen Brooklyn",status: candidates.isEmpty ? "not_found" : "nutrition_found",notes: "Review location and portion",sources: [],candidates: candidates) }
        let pizza = FoodWebCandidate(id: "pizza",name: "Margherita pizza",description: "Tomato and mozzarella",sourceURL: "https://example.com/nutrition",sourceTitle: "Example Kitchen",servingSize: "1 pizza (400 g)",referenceGrams: 400,macros: FoodMacros(calories: 1000,protein: 40,carbs: 120,fat: 40,fiber: 4),fiberMissing: false)
        var photo = FoodAIItem(name: "Margherita pizza",grams: 200,macros: FoodMacros(calories: 999),uncertainty: "Estimated portion")
        var resolved = FoodNutritionResolver.resolve(photo,restaurant: lookup([pizza]),foods: [])
        check(resolved.macros.calories == 500 && resolved.nutritionBasis?.resolution == "restaurant","unique restaurant recipe automatically replaces guessed macros")
        check(resolved.photoMacros?.calories == 999 && resolved.photoGrams == 200,"independent AI estimate remains recoverable")
        photo.quantity = FoodAIQuantity(count: 0.5,unit: "pizza",basis: "user",weightBasis: "photo")
        photo.grams = 111
        resolved = FoodNutritionResolver.resolve(photo,restaurant: lookup([pizza]),foods: [])
        check(resolved.macros.calories == 500 && resolved.grams == 200 && resolved.nutritionBasis?.servings == 0.5,"half a published pizza uses count rather than invented photo grams")
        photo.quantity?.weightBasis = "user"; photo.grams = 100
        resolved = FoodNutritionResolver.resolve(photo,restaurant: lookup([pizza]),foods: [])
        check(resolved.macros.calories == 250 && resolved.nutritionBasis?.servings == nil,"measured weight takes precedence over count")
        var tender = pizza; tender.id = "tender"; tender.name = "Fried chicken tender"; tender.servingSize = "1 tender"; tender.referenceGrams = nil; tender.macros = FoodMacros(calories: 140,protein: 12,carbs: 6,fat: 8)
        var chicken = FoodAIItem(name: "Fried chicken tenders",grams: 450,macros: FoodMacros(calories: 2200,protein: 120,carbs: 30,fat: 180),uncertainty: "Weight estimate",requestedName: "Fried chicken tender",quantity: FoodAIQuantity(count: 10,unit: "tenders",basis: "user",weightBasis: "photo"))
        resolved = FoodNutritionResolver.resolve(chicken,restaurant: lookup([tender]),foods: [])
        check(resolved.macros.calories == 1400 && resolved.grams == 450 && resolved.nutritionBasis?.servings == 10,"ten known per-piece servings work without a published gram weight")
        check(resolved.nutritionBasis?.warnings?.contains(where: { $0.contains("gram weight") }) == true,"unknown source weight remains clearly estimated")
        chicken.quantity?.unit = "cups"
        resolved = FoodNutritionResolver.resolve(chicken,restaurant: lookup([tender]),foods: [])
        check(resolved.nutritionBasis?.resolution == "ai","incompatible units cannot invent a source serving")
        chicken.quantity?.unit = "tenders"; chicken.requestedName = "Surprise platter"; chicken.exclude = ["bread"]
        let pages = try FileManager.default.contentsOfDirectory(at: URL(fileURLWithPath: "Workouts/Resources"),includingPropertiesForKeys: nil).filter { $0.lastPathComponent.hasPrefix("food-catalog-") && Int($0.deletingPathExtension().lastPathComponent.replacingOccurrences(of: "food-catalog-",with: "")) != nil }
        let foods = try pages.flatMap { try JSONDecoder().decode([FoodItem].self,from: Data(contentsOf: $0)) }
        resolved = FoodNutritionResolver.resolve(chicken,restaurant: lookup([tender]),foods: foods)
        check(resolved.matchedFood?.id == "usda-2706100" && resolved.nutritionBasis?.resolution == "library","unpublished marketed meal uses appropriate generic restaurant preparation")
        check(abs(resolved.macros.calories - 1273.5) < 0.01 && resolved.grams == 450,"generic nutrient density scales to estimated grams, not a restaurant weight invented from count")
        check(resolved.nutritionBasis?.warnings?.contains(where: { $0.contains("restaurant") }) == true && resolved.nutritionBasis?.modifications == ["No bread"],"modified meal provenance survives fallback")
        check(resolved.photoMacros?.calories == 2200 && resolved.nutritionBasis?.referenceMacros?.calories == 283,"generic profile and original estimate are separate snapshots")
        chicken.quantity?.weightBasis = "user"; chicken.grams = 300
        let weighed = FoodNutritionResolver.resolve(chicken,restaurant: lookup([]),foods: foods)
        check(weighed.macros.calories == 849 && weighed.nutritionBasis?.portionBasis?.contains("Your weight") == true,"measured modified generic meal uses library density")
        var hot = tender; hot.id = "spicy"
        chicken.exclude = []; chicken.requestedName = "Fried chicken tender"
        resolved = FoodNutritionResolver.resolve(chicken,restaurant: lookup([tender,hot]),foods: [])
        check(resolved.nutritionBasis?.resolution == "ai","duplicate/ambiguous restaurant profiles never select a heat or size")
        photo.exclude = ["cheese"]
        resolved = FoodNutritionResolver.resolve(photo,restaurant: lookup([pizza]),foods: [])
        check(resolved.nutritionBasis?.resolution == "ai" && resolved.macros.calories == 999,"no-cheese request cannot silently use an unchanged restaurant pizza recipe")
        var changedPizza = pizza; changedPizza.name = "Margherita pizza without cheese"; changedPizza.description = "Without cheese"
        photo.name = changedPizza.name; photo.requestedName = changedPizza.name
        resolved = FoodNutritionResolver.resolve(photo,restaurant: lookup([changedPizza]),foods: [])
        check(resolved.nutritionBasis?.resolution == "restaurant","explicit modified source recipe is usable")
        photo.exclude = []; photo.add = ["chicken"]
        resolved = FoodNutritionResolver.resolve(photo,restaurant: lookup([changedPizza]),foods: [])
        check(resolved.nutritionBasis?.resolution == "ai","unpublished additions cannot borrow the original source macros")
        let rice = FoodItem(id: "rice",name: "Rice, cooked",category: "Grains",source: "Test profile",referenceGrams: 100,macros: FoodMacros(calories: 130),portions: [])
        let grain = FoodAIItem(name: "Cooked rice",grams: 200,macros: FoodMacros(calories: 999),uncertainty: "Portion estimate")
        check(FoodNutritionResolver.resolve(grain,restaurant: nil,foods: [rice]).macros.calories == 260,"non-restaurant meals also get automatic compatible library nutrition")
        let biryani = FoodItem(id: "biryani",name: "Chicken biryani",category: "Mixed dishes",source: "Test profile",referenceGrams: 100,macros: FoodMacros(calories: 180),portions: [])
        let cultural = FoodAIItem(name: "Chicken biryani",grams: 350,macros: FoodMacros(calories: 999),uncertainty: "Recipe estimate")
        check(FoodNutritionResolver.resolve(cultural,restaurant: lookup([]),foods: [biryani]).macros.calories == 630,"fallback works for named cultural dishes")
        var branded = rice; branded.brand = "Other Restaurant"
        check(FoodNutritionResolver.resolve(grain,restaurant: nil,foods: [branded]).matchedFood == nil,"generic fallback cannot substitute an unrelated brand")
        let rawMeat = FoodItem(id: "raw",name: "Chicken, raw",category: "Meat",source: "Test",referenceGrams: 100,macros: FoodMacros(calories: 120),portions: [])
        let plain = FoodAIItem(name: "Chicken",grams: 200,macros: FoodMacros(calories: 999),uncertainty: "Preparation unknown")
        check(FoodNutritionResolver.resolve(plain,restaurant: nil,foods: [rawMeat]).matchedFood == nil,"unspecified cooked meal cannot select raw meat")
        check(FoodNutritionResolver.countServing("0.5 slice (40g)",unit: "slices") == 0.5 && FoodNutritionResolver.countServing("1/2 slice",unit: "slice") == 0.5,"decimal and fraction source servings preserve their quantities")
        check(FoodNutritionResolver.countServing("2 tenders (100g)",unit: "strips") == 2 && FoodNutritionResolver.countServing("100g",unit: "tenders") == nil,"count aliases work; a gram label is not a piece count")
        let banana = FoodAIItem(name: "Raw bananas",grams: 120,macros: FoodMacros(calories: 999),uncertainty: "Portion estimate")
        let fruit = FoodNutritionResolver.resolve(banana,restaurant: nil,foods: foods)
        check(fruit.matchedFood?.id == "usda-2709224","singular/plural generic identity uses a current common-food profile")
        let broth = FoodItem(id: "broth",name: "Chicken broth",category: "Soup",source: "Test",referenceGrams: 100,macros: FoodMacros(calories: 6),portions: [])
        check(FoodNutritionResolver.resolve(plain,restaurant: nil,foods: [broth,rawMeat]).matchedFood == nil,"a meat meal cannot use broth or raw-meat density")
        let mixture = FoodItem(id: "mixture",name: "Rice, cooked, with beef",category: "Mixed dishes",source: "Test",referenceGrams: 100,macros: FoodMacros(calories: 210),portions: [])
        check(FoodNutritionResolver.resolve(grain,restaurant: nil,foods: [rice,mixture]).matchedFood?.id == rice.id,"generic preparation prefers the specified food rather than an added-protein mixture")
        let snapshot = FoodLogEntry(day: "2026-10-04",meal: .lunch,foodID: weighed.matchedFood!.id,name: weighed.name,grams: weighed.grams,macros: weighed.macros,source: weighed.nutritionLabel,estimated: true,nutritionBasis: weighed.nutritionBasis)
        let restored = try JSONDecoder().decode(FoodLogEntry.self,from: JSONEncoder().encode(snapshot))
        check(restored.valid && restored.macros == snapshot.macros && restored.nutritionBasis?.modifications == ["No bread"],"portion evidence and modifications survive diary/backup coding")
        print("\(checks) universal food-resolution checks passed")
    }
}
