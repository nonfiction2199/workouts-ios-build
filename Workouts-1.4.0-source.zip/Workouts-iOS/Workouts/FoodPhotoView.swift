import SwiftUI
import PhotosUI
import Vision
import Security

struct FoodLabelDraft: Identifiable {
    var id = UUID()
    var text: String
    var calories: Double?
    var protein: Double?
    var carbs: Double?
    var fat: Double?
    var fiber: Double?
    var grams: Double?
    init(text: String) {
        self.text = text
        func value(_ pattern: String) -> Double? {
            guard let r = try? NSRegularExpression(pattern: pattern,options: [.caseInsensitive,.anchorsMatchLines]),let match = r.firstMatch(in: text,range: NSRange(text.startIndex...,in: text)),let range = Range(match.range(at: 1),in: text) else { return nil }
            return nutritionNumber(String(text[range]))
        }
        calories = value("^\\s*Calories\\s*[:：]?\\s*(\\d+(?:[.,]\\d+)?)\\s*$")
        protein = value("^\\s*Protein\\s*[:：]?\\s*(\\d+(?:[.,]\\d+)?)\\s*g")
        carbs = value("^\\s*(?:Total Carbohydrate|Carbohydrate|Carbohydrates)\\s*[:：]?\\s*(\\d+(?:[.,]\\d+)?)\\s*g")
        fat = value("^\\s*(?:Total Fat|Fat)\\s*[:：]?\\s*(\\d+(?:[.,]\\d+)?)\\s*g")
        fiber = value("^\\s*(?:Dietary Fiber|Fiber|Fibre)\\s*[:：]?\\s*(\\d+(?:[.,]\\d+)?)\\s*g")
        grams = value("Serving size[^\\n]*?\\b(\\d+(?:[.,]\\d+)?)\\s*g\\b")
    }
}
enum FoodServiceToken {
    private static let service = "app.sudais.workouts.food-service"
    static func read() -> String {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword,kSecAttrService as String: service,kSecAttrAccount as String: "token",kSecReturnData as String: true,kSecMatchLimit as String: kSecMatchLimitOne]
        var result: CFTypeRef?; guard SecItemCopyMatching(query as CFDictionary,&result) == errSecSuccess,let data = result as? Data else { return "" }; return String(data: data,encoding: .utf8) ?? ""
    }
    static func save(_ token: String) -> Bool {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword,kSecAttrService as String: service,kSecAttrAccount as String: "token"]
        if token.isEmpty { let status = SecItemDelete(query as CFDictionary); return status == errSecSuccess || status == errSecItemNotFound }
        let data = Data(token.utf8)
        let status = SecItemUpdate(query as CFDictionary,[kSecValueData as String: data] as CFDictionary)
        if status == errSecSuccess { return true }
        guard status == errSecItemNotFound else { return false }
        var add = query; add[kSecValueData as String] = data; add[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        return SecItemAdd(add as CFDictionary,nil) == errSecSuccess
    }
}
struct FoodPhotoView: View {
    var date: Date
    @EnvironmentObject private var nutrition: NutritionStore
    @Environment(\.dismiss) private var dismiss
    @AppStorage("foodServiceURL") private var serviceURL = ""
    @State private var item: PhotosPickerItem?
    @State private var image: UIImage?
    @State private var context = ""
    @State private var menuURL = ""
    @State private var phase = "Analyzing…"
    @State private var camera = false
    @State private var settings = false
    @State private var busy = false
    @State private var message: String?
    @State private var response: FoodAIResponse?
    @State private var barcodeFood: FoodItem?
    @State private var label: FoodLabelDraft?
    @State private var work: Task<Void,Never>?
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading,spacing: 20) {
                    VStack(alignment: .leading,spacing: 10) { Image(systemName: "camera.viewfinder").font(.system(size: 32)); Text("Capture. Review. Log.").font(.title2.bold()); Text("Photograph a meal for an estimate, or scan a nutrition label on this iPhone.").font(.subheadline).foregroundStyle(Palette.secondary) }.padding(20).frame(maxWidth: .infinity,alignment: .leading).card()
                    if let image { Image(uiImage: image).resizable().scaledToFit().frame(maxHeight: 300).clipShape(RoundedRectangle(cornerRadius: 16)) }
                    HStack(spacing: 12) {
                        Button { camera = true } label: { Label("Camera",systemImage: "camera").frame(maxWidth: .infinity,minHeight: 48).background(Palette.control,in: RoundedRectangle(cornerRadius: 10)) }.buttonStyle(.plain).disabled(!UIImagePickerController.isSourceTypeAvailable(.camera) || busy)
                        PhotosPicker(selection: $item,matching: .images) { Label("Upload",systemImage: "photo").frame(maxWidth: .infinity,minHeight: 48).background(Palette.control,in: RoundedRectangle(cornerRadius: 10)) }.disabled(busy)
                    }
                    VStack(alignment: .leading,spacing: 9) { Text("Meal details").font(.headline); TextField("Food, portion, restaurant and location…",text: $context,axis: .vertical).lineLimit(3...6).padding(14).background(Palette.control,in: RoundedRectangle(cornerRadius: 10)); Text("Include the restaurant name, location and any changes, such as no bread. A measured weight improves portion accuracy.").font(.caption).foregroundStyle(Palette.secondary) }
                    VStack(alignment: .leading,spacing: 8) { TextField("Restaurant / menu HTTPS link (optional)",text: $menuURL).textInputAutocapitalization(.never).autocorrectionDisabled().keyboardType(.URL).padding(14).background(Palette.control,in: RoundedRectangle(cornerRadius: 10)); Text("Restaurant lookup sends the place and dish description to web search, then checks source pages. It does not send your photo to those websites. Confirm the location and serving size in review.").font(.caption).foregroundStyle(Palette.secondary) }
                    if busy { HStack { ProgressView(); Text(phase); Spacer(); Button("Cancel") { work?.cancel(); busy = false } } }
                    PrimaryButton(label: "Analyze Meal") { analyzeMeal() }.disabled(image == nil || busy || serviceURL.isEmpty)
                    Button { scanLabel() } label: { Label("Read Nutrition Label · Offline",systemImage: "text.viewfinder").frame(maxWidth: .infinity,minHeight: 48).background(Palette.control,in: RoundedRectangle(cornerRadius: 10)) }.buttonStyle(.plain).disabled(image == nil || busy)
                    Button { scanBarcode() } label: { Label("Read Product Barcode",systemImage: "barcode.viewfinder").frame(maxWidth: .infinity,minHeight: 48).background(Palette.control,in: RoundedRectangle(cornerRadius: 10)) }.buttonStyle(.plain).disabled(image == nil || busy)
                    Text("Barcode scanning checks the offline library first. If missing, only the barcode is sent to Open Food Facts.").font(.caption).foregroundStyle(Palette.secondary)
                    if serviceURL.isEmpty { Text("Meal recognition is not connected yet. Label scanning works offline; set up the photo service to enable AI estimates.").font(.footnote).foregroundStyle(Palette.secondary) }
                    Button { settings = true } label: { Label(serviceURL.isEmpty ? "Set Up Photo Recognition" : "Photo Recognition Settings",systemImage: "gearshape").frame(minHeight: 44) }
                    if let message { Text(message).font(.footnote).foregroundStyle(Palette.secondary) }
                    Text("Photos stay on this device unless you tap Analyze Meal. That sends the image and your notes to your configured service. Nothing is added to your diary until you approve it.").font(.footnote).foregroundStyle(Palette.secondary)
                }.padding(16)
            }.background(Palette.background).navigationTitle("Photo Logging").navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Done") { dismiss() } } }
                .sheet(isPresented: $camera) { FoodCamera { image = $0 } }
                .sheet(isPresented: $settings) { FoodServiceSettings() }
                .sheet(isPresented: Binding(get: { response != nil },set: { if !$0 { response = nil } })) { if let response { FoodAIReview(response: response,date: date) { self.response = nil; dismiss() } } }
                .sheet(item: $label) { CustomFoodEditor(scanned: $0) }
                .sheet(item: $barcodeFood) { FoodPortionView(food: $0,date: date) }
                .onChange(of: item) { _, selection in
                    Task { do { guard let data = try await selection?.loadTransferable(type: Data.self),let value = UIImage(data: data) else { message = "That photo could not be opened."; return }; image = value; message = nil } catch { message = "That photo could not be opened." } }
                }
                .task {
                    #if DEBUG
                    if ProcessInfo.processInfo.environment["WORKOUTS_PREVIEW_SCREEN"] == "food-match",response == nil {
                        try? await Task.sleep(for: .milliseconds(800))
                        guard !Task.isCancelled else { return }
                        response = FoodAIResponse(items: [FoodAIItem(name: "Abiyuch, raw",grams: 100,macros: FoodMacros(calories: 999,protein: 1,carbs: 1,fat: 1,fiber: 0),uncertainty: "Confirm food identity and weight")],notes: "Simulator fixture: review food and measured weight.",questions: [])
                    }
                    if ProcessInfo.processInfo.environment["WORKOUTS_PREVIEW_SCREEN"] == "food-restaurant",response == nil {
                        try? await Task.sleep(for: .milliseconds(800))
                        guard !Task.isCancelled else { return }
                        let candidate = FoodWebCandidate(id: "test-pizza",name: "Margherita pizza",description: "Tomato, mozzarella and basil",sourceURL: "https://example.com/menu",sourceTitle: "Example Pizzeria · Brooklyn",servingSize: "1 pizza (400 g)",referenceGrams: 400,macros: FoodMacros(calories: 1000,protein: 40,carbs: 120,fat: 40,fiber: 4),fiberMissing: false)
                        var fixture = FoodAIResponse(items: [FoodAIItem(name: "Margherita pizza",grams: 200,macros: FoodMacros(calories: 999,protein: 1,carbs: 1,fat: 1,fiber: 0),uncertainty: "Confirm estimated weight")],notes: "Simulator fixture; source nutrition must be confirmed.",questions: [])
                        fixture.restaurant = RestaurantLookupResponse(query: "Example Pizzeria Brooklyn",status: "nutrition_found",notes: "Confirm restaurant, dish and reference serving.",sources: [FoodWebSource(title: candidate.sourceTitle,url: candidate.sourceURL)],candidates: [candidate,FoodWebCandidate(id: "test-slice",name: "Margherita pizza slice",description: "Tomato and mozzarella",sourceURL: "https://example.com/menu",sourceTitle: "Example Pizzeria · Brooklyn",servingSize: "1 slice",referenceGrams: nil,macros: FoodMacros(calories: 300,protein: 12,carbs: 36,fat: 12,fiber: 1),fiberMissing: false)])
                        fixture.items = fixture.items.map { FoodNutritionResolver.resolve($0,restaurant: fixture.restaurant,foods: nutrition.allFoods) }
                        response = fixture
                    }
                    if ProcessInfo.processInfo.environment["WORKOUTS_PREVIEW_SCREEN"] == "food-portions",response == nil {
                        try? await Task.sleep(for: .milliseconds(800))
                        guard !Task.isCancelled else { return }
                        let candidate = FoodWebCandidate(id: "test-count",name: "Fried chicken tender",description: "Breaded chicken only",sourceURL: "https://example.com/nutrition",sourceTitle: "Example Kitchen",servingSize: "1 tender (50 g)",referenceGrams: 50,macros: FoodMacros(calories: 140,protein: 12,carbs: 6,fat: 8,fiber: 0),fiberMissing: true)
                        let source = RestaurantLookupResponse(query: "Example Kitchen Brooklyn",status: "nutrition_found",notes: "Simulator fixture: review restaurant and portions.",sources: [FoodWebSource(title: candidate.sourceTitle,url: candidate.sourceURL)],candidates: [candidate])
                        let counted = FoodAIItem(name: "Fried chicken tenders",grams: 999,macros: FoodMacros(calories: 9999),uncertainty: "Confirm count",requestedName: "Fried chicken tender",quantity: FoodAIQuantity(count: 10,unit: "tenders",basis: "user",weightBasis: "photo"))
                        let modified = FoodAIItem(name: "Fried chicken tenders",grams: 450,macros: FoodMacros(calories: 2200),uncertainty: "Photo weight estimate",requestedName: "Surprise platter",quantity: FoodAIQuantity(count: 10,unit: "tenders",basis: "user",weightBasis: "photo"),exclude: ["bread"])
                        let generic = FoodItem(id: "fixture-tenders",name: "Chicken tenders or strips, breaded, from restaurant",category: "Poultry",source: "Simulator test profile",referenceGrams: 100,macros: FoodMacros(calories: 283,protein: 18.8,carbs: 16.9,fat: 15.6,fiber: 1.2),portions: [])
                        response = FoodAIResponse(items: [FoodNutritionResolver.resolve(counted,restaurant: source,foods: [generic]),FoodNutritionResolver.resolve(modified,restaurant: source,foods: [generic])],notes: "Simulator fixture: first published count, then modified generic estimate.",questions: [],restaurant: source)
                    }
                    #endif
                }
                .onDisappear { work?.cancel() }
        }
    }
    private func jpeg() -> Data? {
        guard let image else { return nil }; let scale = min(1,1600 / max(image.size.width,image.size.height)); let size = CGSize(width: image.size.width * scale,height: image.size.height * scale)
        let format = UIGraphicsImageRendererFormat(); format.scale = 1; let renderer = UIGraphicsImageRenderer(size: size,format: format)
        return renderer.image { _ in image.draw(in: CGRect(origin: .zero,size: size)) }.jpegData(compressionQuality: 0.8)
    }
    private func analyzeMeal() {
        guard let data = jpeg(), let url = URL(string: serviceURL),url.scheme == "https",url.host != nil else { message = "Choose a photo and configure a valid HTTPS service."; return }
        guard context.count <= 2000 else { message = "Keep meal notes under 2,000 characters."; return }
        let source = menuURL.trimmingCharacters(in: .whitespacesAndNewlines)
        guard source.isEmpty || FoodNutritionBasis.validURL(source) else { message = "Enter a valid HTTPS restaurant or menu link."; return }
        busy = true; phase = "Analyzing…"; message = nil
        work = Task { @MainActor in
            defer { busy = false }
            do {
                phase = "Analyzing photo…"
                var request = URLRequest(url: url); request.httpMethod = "POST"; request.timeoutInterval = 65; request.setValue("application/json",forHTTPHeaderField: "Content-Type"); request.setValue("Bearer " + FoodServiceToken.read(),forHTTPHeaderField: "Authorization")
                request.httpBody = try JSONSerialization.data(withJSONObject: ["image": data.base64EncodedString(),"mimeType": "image/jpeg","context": context,"workflow": 3])
                let (body,reply) = try await URLSession.shared.data(for: request); try Task.checkCancellation()
                guard let http = reply as? HTTPURLResponse else { throw FoodScanError.message("Photo service returned an invalid response.") }
                guard http.statusCode == 200 else {
                    let failure = body.count <= 10000 ? (try? JSONSerialization.jsonObject(with: body) as? [String:Any]) : nil
                    let detail = (failure?["error"] as? String).map { String($0.prefix(300)) }
                    throw FoodScanError.message(detail ?? "Photo analysis could not complete (HTTP \(http.statusCode)). Check your service settings.")
                }
                guard body.count <= 200000 else { throw FoodScanError.message("The service returned an invalid response.") }
                var value = try JSONDecoder().decode(FoodAIResponse.self,from: body)
                guard value.restaurantName != nil else { throw FoodScanError.message("Update your laptop food service to Workouts 1.4.0, then try again. This build needs the new meal and portion workflow.") }
                guard value.valid else { throw FoodScanError.message("The service returned invalid food values.") }
                guard !value.items.isEmpty else { message = "No foods could be identified. Try a clearer photo or log manually."; return }
                var lookup: RestaurantLookupResponse?
                if !(value.restaurantName ?? "").isEmpty || !source.isEmpty {
                    phase = "Checking restaurant nutrition…"
                    lookup = await lookupRestaurant(endpoint: url,sourceURL: source,meal: value)
                    try Task.checkCancellation()
                }
                phase = "Matching foods and portions…"
                let foods = nutrition.allFoods, estimates = value.items, sourceLookup = lookup
                value.items = await Task.detached { estimates.map { FoodNutritionResolver.resolve($0,restaurant: sourceLookup,foods: foods) } }.value
                try Task.checkCancellation(); value.restaurant = lookup; response = value
            } catch is CancellationError { } catch { if !Task.isCancelled { message = error.localizedDescription } }
        }
    }
    private func lookupRestaurant(endpoint: URL,sourceURL: String,meal: FoodAIResponse) async -> RestaurantLookupResponse {
        let fallback = RestaurantLookupResponse(query: "",status: "unavailable",notes: "Restaurant lookup could not complete. You can keep the estimate and choose a database match. The laptop service must be updated to enable web lookup.",sources: [],candidates: [])
        do {
            // A separate request keeps web lookup outside the vision model deadline.
            let url = endpoint.deletingLastPathComponent().appendingPathComponent("restaurant")
            var request = URLRequest(url: url); request.httpMethod = "POST"; request.timeoutInterval = 22
            request.setValue("application/json",forHTTPHeaderField: "Content-Type"); request.setValue("Bearer " + FoodServiceToken.read(),forHTTPHeaderField: "Authorization")
            let dishes = meal.items.prefix(5).map { ($0.requestedName?.isEmpty == false ? $0.requestedName! : $0.name) + " " + $0.name }
            let components = Array(Set(meal.items.flatMap { ($0.exclude ?? []) + ($0.add ?? []) })).prefix(12)
            request.httpBody = try JSONSerialization.data(withJSONObject: ["context": context,"sourceURL": sourceURL,"restaurantName": meal.restaurantName ?? "","restaurantLocation": meal.restaurantLocation ?? "","dishes": dishes,"components": Array(components)])
            let (body,reply) = try await URLSession.shared.data(for: request)
            guard (reply as? HTTPURLResponse)?.statusCode == 200,body.count <= 100000,let result = try? JSONDecoder().decode(RestaurantLookupResponse.self,from: body),result.valid else { return fallback }
            return result
        } catch { return fallback }
    }
    private func scanBarcode() {
        guard let data = jpeg() else { return }; busy = true; message = nil
        work = Task { @MainActor in
            defer { busy = false }
            do {
                let code = try await Task.detached { () throws -> String? in
                    let request = VNDetectBarcodesRequest(); request.symbologies = [.ean8,.ean13,.upce]
                    try VNImageRequestHandler(data: data).perform([request])
                    return request.results?.compactMap(\.payloadStringValue).first
                }.value
                try Task.checkCancellation()
                guard let code else { message = "No product barcode was found. Photograph the barcode clearly or type its number in the Food Library."; return }
                let normalized = String(code.drop(while: { $0 == "0" }))
                var found = (nutrition.state.cachedFoods ?? []).filter { String(($0.barcode ?? "").drop(while: { $0 == "0" })) == normalized }
                if found.isEmpty { found = await FoodDatabase.shared.barcode(code) }
                if found.isEmpty { found = try await InternationalFoodService.shared.search(code) }
                try Task.checkCancellation()
                guard let food = found.first else { message = "This barcode has no complete nutrient profile in the available databases. Scan the nutrition label or create a custom food."; return }
                barcodeFood = food
            } catch is CancellationError { } catch { if !Task.isCancelled { message = error.localizedDescription } }
        }
    }
    private func scanLabel() {
        guard let data = jpeg() else { return }; busy = true; message = nil
        work = Task { @MainActor in
            defer { busy = false }
            do {
                let text = try await Task.detached { () throws -> String in
                    let request = VNRecognizeTextRequest(); request.recognitionLevel = .accurate; request.usesLanguageCorrection = false
                    try VNImageRequestHandler(data: data).perform([request]); return (request.results ?? []).compactMap { $0.topCandidates(1).first?.string }.joined(separator: "\n")
                }.value
                try Task.checkCancellation()
                guard !text.isEmpty else { message = "No readable text was found. Try a clearer label photo."; return }; label = FoodLabelDraft(text: text)
            } catch is CancellationError { } catch { if !Task.isCancelled { message = "The label could not be read. Try another photo." } }
        }
    }
}
struct FoodServiceSettings: View {
    @Environment(\.dismiss) private var dismiss
    @AppStorage("foodServiceURL") private var serviceURL = ""
    @State private var endpoint = ""
    @State private var token = ""
    @State private var error: String?
    var body: some View {
        NavigationStack {
            Form {
                Section { Text("Connect your local laptop service or a hosted photo service. Local Ollama runs without a cloud provider key.").font(.footnote).foregroundStyle(Palette.secondary) }.listRowBackground(Palette.surface)
                Section("Connection") { TextField("HTTPS analysis endpoint",text: $endpoint).textInputAutocapitalization(.never).autocorrectionDisabled().keyboardType(.URL); SecureField("Service access token",text: $token).textInputAutocapitalization(.never).autocorrectionDisabled(); Text("Use the service access token here. The AI provider key belongs on the server.").font(.caption).foregroundStyle(Palette.secondary) }.listRowBackground(Palette.surface)
                Section { PrimaryButton(label: "Save Connection") {
                    let value = endpoint.trimmingCharacters(in: .whitespacesAndNewlines)
                    guard let url = URL(string: value),url.scheme == "https",url.host != nil,url.user == nil,url.password == nil,!token.isEmpty else { error = "Enter an HTTPS endpoint and service token."; return }
                    guard FoodServiceToken.save(token) else { error = "The access token could not be saved securely."; return }; serviceURL = value; dismiss()
                }; Button("Disconnect",role: .destructive) { guard FoodServiceToken.save("") else { error = "The access token could not be removed."; return }; serviceURL = ""; dismiss() } }.listRowBackground(Palette.surface)
                Section("Accuracy") { Text("Meal identification and portions are estimates. Confirm food names, weights, oils and sauces before logging. The app does not claim exact nutrients from appearance alone.").font(.footnote).foregroundStyle(Palette.secondary) }.listRowBackground(Palette.surface)
            }.darkForm().navigationTitle("Photo Recognition").navigationBarTitleDisplayMode(.inline).toolbar { ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } } }
                .onAppear { endpoint = serviceURL; token = FoodServiceToken.read() }
                .alert("Connection",isPresented: Binding(get: { error != nil },set: { if !$0 { error = nil } })) { Button("OK",role: .cancel) { error = nil } } message: { Text(error ?? "") }
        }
    }
}
struct FoodAIReview: View {
    let response: FoodAIResponse
    let date: Date
    let completed: () -> Void
    @EnvironmentObject private var nutrition: NutritionStore
    @Environment(\.dismiss) private var dismiss
    @State private var items: [FoodAIItem] = []
    @State private var meal: FoodMeal = .lunch
    @State private var selected: FoodAIItem?
    var body: some View {
        NavigationStack {
            List {
                Section { Text("Review every item and portion before logging.").font(.headline); Text(response.notes).font(.footnote).foregroundStyle(Palette.secondary); ForEach(response.questions,id: \.self) { Text($0).font(.footnote) } }.listRowBackground(Palette.surface)
                if let restaurant = response.restaurant,restaurant.status != "not_requested" { Section("Restaurant sources") { Text(restaurant.query.isEmpty ? "Restaurant lookup" : restaurant.query).font(.headline); Text(restaurant.notes).font(.caption).foregroundStyle(Palette.secondary); ForEach(restaurant.sources) { source in if let url = URL(string: source.url) { Link(source.title,destination: url).font(.subheadline) } }; if !restaurant.candidates.isEmpty { Text("Supported matches were applied below. Review the source, portion and recipe changes before logging.").font(.caption) } }.listRowBackground(Palette.surface) }
                Section("Foods & portions · Tap to correct") { ForEach(items) { item in Button { selected = item } label: { FoodAIReviewRow(item: item) }.buttonStyle(.plain).accessibilityIdentifier("nutrition-review-" + item.name) }.onDelete { items.remove(atOffsets: $0) } }.listRowBackground(Palette.surface)
                Section { Picker("Meal",selection: $meal) { ForEach(FoodMeal.allCases) { Text($0.rawValue).tag($0) } }; PrimaryButton(label: "Approve & Log \(items.count) Foods") { let entries = items.map { FoodLogEntry(day: NutritionDay.key(date),meal: meal,foodID: $0.matchedFood?.id ?? $0.nutritionBasis?.sourceFoodID ?? ("ai-" + UUID().uuidString),name: $0.name,grams: $0.grams,macros: $0.macros,source: $0.nutritionLabel + " · reviewed",estimated: true,nutritionBasis: $0.nutritionBasis) }; if !entries.isEmpty,items.compactMap(\.matchedFood).allSatisfy({ nutrition.remember($0) }),nutrition.log(entries) { completed() } }.disabled(items.isEmpty || !items.allSatisfy(\.valid)) }.listRowBackground(Palette.surface)
            }.darkForm().navigationTitle("Review Meal").navigationBarTitleDisplayMode(.inline).toolbar { ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } } }.interactiveDismissDisabled().onAppear { items = response.items }
                .sheet(item: $selected) { item in FoodAICorrection(item: item,restaurant: response.restaurant) { updated in if let index = items.firstIndex(where: { $0.id == updated.id }) { items[index] = updated } } }
        }
    }
}
struct FoodAIReviewRow: View {
    let item: FoodAIItem
    var body: some View {
        VStack(alignment: .leading,spacing: 6) {
            Text(item.name).font(.headline)
            Text("\(item.grams.short) g · \(item.macros.calories.short) kcal").font(.subheadline)
            Text("P \(item.macros.protein.short) · C \(item.macros.carbs.short) · F \(item.macros.fat.short)").font(.caption)
            Text(item.nutritionLabel).font(.caption).foregroundStyle(Palette.action)
            if let basis = item.nutritionBasis {
                if let count = basis.quantityCount,let unit = basis.quantityUnit,!unit.isEmpty { Text("\(count.short) \(unit)").font(.caption) }
                if let portion = basis.portionBasis { Text(portion).font(.caption).foregroundStyle(Palette.secondary) }
                ForEach(basis.modifications ?? [],id: \.self) { Text($0).font(.caption) }
                ForEach(basis.warnings ?? [],id: \.self) { Text($0).font(.caption).foregroundStyle(Palette.secondary) }
            }
            Text(item.uncertainty).font(.caption).foregroundStyle(Palette.secondary)
        }.padding(.vertical,5).frame(maxWidth: .infinity,alignment: .leading).contentShape(Rectangle())
    }
}
struct FoodAICorrection: View {
    let item: FoodAIItem
    var restaurant: RestaurantLookupResponse? = nil
    let save: (FoodAIItem) -> Void
    @EnvironmentObject private var nutrition: NutritionStore
    @Environment(\.dismiss) private var dismiss
    @State private var name = ""
    @State private var grams = ""
    @State private var calories = ""
    @State private var protein = ""
    @State private var carbs = ""
    @State private var fat = ""
    @State private var fiber = ""
    @State private var matchedFood: FoodItem?
    @State private var basis: FoodNutritionBasis?
    @State private var manual = true
    @State private var servings = "1"
    @State private var lastGrams: Double = 0
    @State private var lastServings: Double = 1
    @State private var suggestions: [FoodItem] = []
    @State private var library = false
    private var currentGrams: Double { nutritionNumber(grams) ?? 0 }
    private var currentServings: Double { nutritionNumber(servings) ?? 0 }
    private var servingMode: Bool { basis?.referenceMacros != nil && basis?.servings != nil }
    private var sourceMacros: FoodMacros? {
        if servingMode { return basis?.referenceMacros?.scaled(currentServings) }
        return matchedFood?.nutrition(grams: currentGrams) ?? basis?.referenceGrams.flatMap { grams in basis?.referenceMacros?.scaled(currentGrams / grams) }
    }
    private var currentMacros: FoodMacros? { manual ? parseNutritionMacros(calories,protein,carbs,fat,fiber) : sourceMacros }
    private var canSave: Bool { !name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && currentGrams > 0 && currentGrams <= 10000 && (currentMacros?.valid ?? false) && (currentMacros?.calories ?? 20001) <= 20000 && (!servingMode || (currentServings > 0 && currentServings <= 100)) }
    var body: some View {
        NavigationStack {
            Form {
                if let basis { Section("Match & recipe") { Text(basis.resolution == "restaurant" ? "Published restaurant nutrition" : basis.resolution == "library" ? "Food-library estimate" : "AI nutrient estimate").font(.subheadline); ForEach(basis.modifications ?? [],id: \.self) { Text($0).font(.caption) }; ForEach(basis.warnings ?? [],id: \.self) { Text($0).font(.caption).foregroundStyle(Palette.secondary) } }.listRowBackground(Palette.surface) }
                Section("Confirm the portion") {
                    TextField("Name",text: $name)
                    nutritionField("Grams",text: $grams)
                    if servingMode {
                        nutritionField("Source servings",text: $servings)
                        if let count = basis?.referenceCount,let unit = basis?.quantityUnit { Text("1 source serving = \(count.short) \(unit)").font(.caption).foregroundStyle(Palette.secondary) }
                        if basis?.referenceGrams != nil { Button("Use my measured grams instead") { basis?.servings = nil; basis?.quantityCount = nil; basis?.portionBasis = "Your weight × source nutrition" }.buttonStyle(.borderless) }
                        Text("Nutrition uses published servings, independent of the photo weight. Confirm the serving count you ate.").font(.caption).foregroundStyle(Palette.secondary)
                    } else {
                        Text("Nutrition scales to this weight. The photo's grams are an estimate; use a measured weight when available.").font(.caption).foregroundStyle(Palette.secondary)
                    }
                }.listRowBackground(Palette.surface)
                if let restaurant,!restaurant.candidates.isEmpty {
                    Section("Confirm restaurant & menu item") {
                        Text("Check the source restaurant and location before choosing. A similarly named restaurant may have different nutrition.").font(.caption).foregroundStyle(Palette.secondary)
                        ForEach(restaurant.candidates) { candidate in
                            VStack(alignment: .leading,spacing: 7) {
                                Text(candidate.name).font(.subheadline.weight(.semibold))
                                if !candidate.description.isEmpty { Text(candidate.description).font(.caption).foregroundStyle(Palette.secondary) }
                                if let url = URL(string: candidate.sourceURL) { Link(candidate.sourceTitle,destination: url).font(.caption).buttonStyle(.borderless) }
                                if let macros = candidate.macros {
                                    Text("\(macros.calories.short) kcal · \(candidate.servingSize)").font(.caption)
                                    Button("Use this menu nutrition") { select(candidate,query: restaurant.query) }.buttonStyle(.borderless).accessibilityIdentifier("nutrition-menu-" + candidate.id)
                                } else { Text("Menu information only · no complete nutrition with a serving size").font(.caption).foregroundStyle(Palette.secondary) }
                            }.padding(.vertical,4).accessibilityElement(children: .contain)
                        }
                    }.listRowBackground(Palette.surface)
                }
                Section("Choose database nutrition") {
                    Button { library = true } label: { Label("Search Food Library",systemImage: "magnifyingglass") }.accessibilityIdentifier("nutrition-match-library")
                    if let matchedFood {
                        Text("Selected: " + matchedFood.name).font(.subheadline.weight(.semibold))
                        Text(matchedFood.source + ((matchedFood.brand ?? "").isEmpty ? "" : " · " + (matchedFood.brand ?? ""))).font(.caption).foregroundStyle(Palette.secondary)
                        Text("The match stays attached when you adjust its nutrients.").font(.caption).foregroundStyle(Palette.secondary)
                    } else if !servingMode {
                        Text("Suggested matches need confirmation. Check preparation and ingredients.").font(.caption).foregroundStyle(Palette.secondary)
                        ForEach(suggestions) { food in
                            Button { select(food) } label: { VStack(alignment: .leading,spacing: 4) { Text(food.name); Text("\(food.macros.calories.short) kcal / \(food.referenceGrams.short) g · \(food.source)").font(.caption).foregroundStyle(Palette.secondary) } }.buttonStyle(.plain)
                        }
                    }
                }.listRowBackground(Palette.surface)
                if matchedFood != nil || servingMode || basis?.referenceMacros != nil {
                    Section("Nutrition source") {
                        if let basis,let sourceURL = basis.sourceURL,let url = URL(string: sourceURL) { Link(basis.sourceTitle ?? "View source",destination: url); Text("Reference: " + (basis.referenceServing ?? "")).font(.caption) }
                        if !manual,let macros = sourceMacros { macroRows(macros) }
                        Button(manual ? "Reset to source nutrition" : "Adjust macros, keep match") { if let macros = sourceMacros { setValues(macros) }; manual.toggle() }.accessibilityIdentifier("nutrition-adjust-match")
                        Button("Use photo AI macros, keep match") { setValues((item.photoMacros ?? item.macros).scaled(currentGrams / (item.photoGrams ?? item.grams))); manual = true }.accessibilityIdentifier("nutrition-use-photo-macros")
                        Text("Changes are estimates and apply only to this diary entry. They do not change the database food.").font(.caption).foregroundStyle(Palette.secondary)
                        if matchedFood?.fiberMissing == true || basis?.fiberMissing == true { Text("Fiber was not provided by the source.").font(.caption).foregroundStyle(Palette.secondary) }
                    }.listRowBackground(Palette.surface)
                }
                if manual {
                    Section("Editable nutrition for this entire portion") {
                        nutritionField("Calories",text: $calories); nutritionField("Protein (g)",text: $protein); nutritionField("Carbs (g)",text: $carbs); nutritionField("Fat (g)",text: $fat); nutritionField("Fiber (g)",text: $fiber)
                        Text(servingMode ? "Enter totals for the serving count above. Further serving-count changes scale these values; estimated grams do not." : "Enter totals for the portion above. Further weight changes scale these values proportionally.").font(.caption).foregroundStyle(Palette.secondary)
                    }.listRowBackground(Palette.surface)
                }
                Section { PrimaryButton(label: "Save Correction") {
                    guard canSave,let macros = currentMacros else { return }
                    var next = item; next.name = name.trimmingCharacters(in: .whitespacesAndNewlines); next.grams = currentGrams; next.macros = macros; next.matchedFood = matchedFood
                    if basis == nil { basis = FoodNutritionBasis() }
                    basis?.adjusted = manual
                    if servingMode { basis?.servings = currentServings; if let reference = basis?.referenceCount { basis?.quantityCount = currentServings * reference }; basis?.portionBasis = "Your serving count × source nutrition" }
                    else if currentGrams != item.grams { basis?.quantityCount = nil; basis?.portionBasis = "Your weight × source nutrition" }
                    next.nutritionBasis = basis; next.photoMacros = item.photoMacros ?? item.macros; next.photoGrams = item.photoGrams ?? item.grams
                    guard next.valid else { return }; save(next); dismiss()
                }.disabled(!canSave).accessibilityIdentifier("nutrition-save-match") }.listRowBackground(Palette.surface)
            }.darkForm().navigationTitle("Review Food").navigationBarTitleDisplayMode(.inline).interactiveDismissDisabled()
                .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }; ToolbarItemGroup(placement: .keyboard) { Spacer(); Button("Done") { hideNutritionKeyboard() }.accessibilityIdentifier("nutrition-keyboard-done") } }
                .onAppear { name = item.name; grams = item.grams.foodInput; lastGrams = item.grams; matchedFood = item.matchedFood; basis = item.nutritionBasis; servings = (basis?.servings ?? 1).foodInput; lastServings = basis?.servings ?? 1; manual = (matchedFood == nil && !servingMode) || basis?.adjusted == true; setValues(item.macros) }
                .onChange(of: grams) { _,_ in
                    let amount = currentGrams
                    guard amount > 0,amount <= 10000 else { return }
                    if manual,!servingMode,lastGrams > 0,let macros = parseNutritionMacros(calories,protein,carbs,fat,fiber) { setValues(macros.scaled(amount / lastGrams)) }
                    lastGrams = amount
                }
                .onChange(of: servings) { _,_ in
                    let count = currentServings
                    guard servingMode,count > 0,count <= 100 else { return }
                    if manual,lastServings > 0,let macros = parseNutritionMacros(calories,protein,carbs,fat,fiber) { setValues(macros.scaled(count / lastServings)) }
                    if let reference = basis?.referenceGrams { grams = (reference * count).foodInput }
                    lastServings = count
                }
                .task(id: nutrition.loadingCatalogue) {
                    guard !nutrition.loadingCatalogue else { return }
                    let foods = nutrition.allFoods, query = item.name
                    let matches = await Task.detached { FoodMatching.candidates(query,in: foods,limit: 5) }.value
                    guard !Task.isCancelled else { return }; suggestions = matches
                }
                .sheet(isPresented: $library) { NutritionFoodSearch(initialQuery: item.name,onMatch: { select($0) }) }
        }
    }
    private func select(_ food: FoodItem) {
        matchedFood = food; name = food.name; manual = false
        basis = FoodNutritionBasis(restaurantQuery: restaurant?.query,sourceFoodID: food.id,referenceGrams: food.referenceGrams,referenceMacros: food.macros,fiberMissing: food.fiberMissing,resolution: "library",portionBasis: "Reviewed weight × food-library nutrition",warnings: item.nutritionBasis?.warnings,modifications: item.nutritionBasis?.modifications)
    }
    private func select(_ candidate: FoodWebCandidate,query: String) {
        guard let macros = candidate.macros else { return }
        matchedFood = candidate.food; name = candidate.name; manual = false; servings = "1"; lastServings = 1
        basis = candidate.basis(query: query,servings: candidate.referenceGrams == nil ? 1 : nil)
        basis?.sourceFoodID = "restaurant-" + candidate.id
        basis?.resolution = "restaurant"; basis?.portionBasis = candidate.referenceGrams == nil ? "Your source serving count" : "Reviewed weight × published nutrition"; basis?.modifications = item.nutritionBasis?.modifications
        if !(item.exclude ?? []).isEmpty || !(item.add ?? []).isEmpty { basis?.warnings = ["Manually selected source: confirm that its recipe includes your changes."] }
        setValues(candidate.referenceGrams.map { macros.scaled(currentGrams / $0) } ?? macros)
    }
    private func setValues(_ m: FoodMacros) { calories = m.calories.foodInput; protein = m.protein.foodInput; carbs = m.carbs.foodInput; fat = m.fat.foodInput; fiber = m.fiber.foodInput }
}
struct FoodCamera: UIViewControllerRepresentable {
    let captured: (UIImage) -> Void
    @Environment(\.dismiss) private var dismiss
    func makeCoordinator() -> Coordinator { Coordinator(self) }
    func makeUIViewController(context: Context) -> UIImagePickerController { let picker = UIImagePickerController(); picker.sourceType = .camera; picker.delegate = context.coordinator; return picker }
    func updateUIViewController(_ controller: UIImagePickerController,context: Context) {}
    final class Coordinator: NSObject, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
        let parent: FoodCamera
        init(_ parent: FoodCamera) { self.parent = parent }
        func imagePickerController(_ picker: UIImagePickerController,didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) { if let image = info[.originalImage] as? UIImage { parent.captured(image) }; parent.dismiss() }
        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) { parent.dismiss() }
    }
}
