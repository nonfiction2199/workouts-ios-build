import Foundation
import Combine

@MainActor
final class NutritionStore: ObservableObject {
    @Published private(set) var state = NutritionState()
    @Published private(set) var catalogue: [FoodItem] = []
    @Published private(set) var loadingCatalogue = true
    @Published private(set) var brandedCount = 0
    @Published private(set) var blocked = false
    @Published var error: String?
    private let directory: URL
    private var file: URL { directory.appendingPathComponent("nutrition-v1.json") }
    init(directory: URL? = nil,loadCatalogue: Bool = true) {
        let defaultDirectory = FileManager.default.urls(for: .applicationSupportDirectory,in: .userDomainMask)[0].appendingPathComponent("Nutrition",isDirectory: true)
        #if DEBUG
        let testDirectory = ProcessInfo.processInfo.environment["WORKOUTS_NUTRITION_TEST"].map { FileManager.default.temporaryDirectory.appendingPathComponent("NutritionUITest-" + $0) }
        self.directory = directory ?? testDirectory ?? defaultDirectory
        #else
        self.directory = directory ?? defaultDirectory
        #endif
        if FileManager.default.fileExists(atPath: file.path) {
            do { let value = try JSONDecoder().decode(NutritionState.self,from: Data(contentsOf: file)); guard value.valid else { throw NutritionFailure.invalid }; state = value }
            catch { blocked = true; self.error = "Saved nutrition data could not be read. The original file has been kept unchanged." }
        }
        if loadCatalogue {
            let urls = (Bundle.main.urls(forResourcesWithExtension: "json",subdirectory: nil) ?? []).filter { $0.lastPathComponent.hasPrefix("food-catalog-") && $0.lastPathComponent != "food-catalog-provenance.json" }
            Task {
                let foods = await Task.detached(priority: .userInitiated) { () -> [FoodItem] in
                    var values: [FoodItem] = []
                    for url in urls { if let data = try? Data(contentsOf: url), let page = try? JSONDecoder().decode([FoodItem].self,from: data) { values.append(contentsOf: page.filter(\.valid)) } }
                    return values.sorted { $0.name.localizedStandardCompare($1.name) == .orderedAscending }
                }.value
                self.catalogue = foods; self.brandedCount = await FoodDatabase.shared.count(); self.loadingCatalogue = false
                if foods.isEmpty { self.error = "The food catalogue is unavailable. Custom foods and quick logging still work." }
            }
        } else { loadingCatalogue = false }
    }
    #if DEBUG
    func seedPreview() {
        guard state.entries.isEmpty else { return }
        let breakfast = FoodItem(id: "preview-oats",name: "Overnight oats with yogurt",category: "Recipe",source: "Your recipe",referenceGrams: 280,macros: FoodMacros(calories: 430,protein: 29,carbs: 56,fat: 11,fiber: 7),portions: [FoodPortion(name: "1 serving",grams: 280)])
        let lunch = FoodItem(id: "preview-biryani",name: "Chicken biryani",category: "Custom meal",source: "Custom",referenceGrams: 350,macros: FoodMacros(calories: 610,protein: 36,carbs: 74,fat: 19,fiber: 4),portions: [FoodPortion(name: "1 bowl",grams: 350)])
        var preview = NutritionState(); preview.goals = NutritionGoals(); preview.customFoods = [breakfast,lunch]
        preview.entries = [FoodLogEntry(day: NutritionDay.key(Date()),meal: .breakfast,foodID: breakfast.id,name: breakfast.name,grams: 280,macros: breakfast.macros,source: breakfast.source),FoodLogEntry(day: NutritionDay.key(Date()),meal: .lunch,foodID: lunch.id,name: lunch.name,grams: 350,macros: lunch.macros,source: lunch.source)]
        state = preview // Simulator review only; not persisted to the user's nutrition file.
    }
    #endif
    var allFoods: [FoodItem] { let ids = Set(catalogue.map(\.id)); return state.customFoods + (state.cachedFoods ?? []).filter { !ids.contains($0.id) } + catalogue }
    var databaseCount: Int { catalogue.count + brandedCount }
    @discardableResult func remember(_ food: FoodItem) -> Bool {
        guard !catalogue.contains(where: { $0.id == food.id }), !state.customFoods.contains(where: { $0.id == food.id }) else { return true }
        var next = state; var cache = next.cachedFoods ?? []; cache.removeAll { $0.id == food.id }; cache.insert(food,at: 0)
        next.cachedFoods = Array(cache.prefix(5000)); return commit(next)
    }
    func entries(on date: Date) -> [FoodLogEntry] { state.entries.filter { $0.day == NutritionDay.key(date) }.sorted { $0.loggedAt < $1.loggedAt } }
    func total(on date: Date) -> FoodMacros { entries(on: date).reduce(FoodMacros()) { $0 + $1.macros } }
    func food(_ id: String) -> FoodItem? { state.customFoods.first { $0.id == id } ?? (state.cachedFoods ?? []).first { $0.id == id } ?? catalogue.first { $0.id == id } }
    @discardableResult func commit(_ next: NutritionState) -> Bool {
        guard !blocked else { error = "Your saved nutrition file needs recovery before changes can be saved."; return false }
        guard next.valid else { error = "Enter valid names, portions, calories and macros."; return false }
        do {
            try FileManager.default.createDirectory(at: directory,withIntermediateDirectories: true)
            let data = try JSONEncoder().encode(next)
            if FileManager.default.fileExists(atPath: file.path) { try Data(contentsOf: file).write(to: directory.appendingPathComponent("nutrition-v1.previous.json"),options: [.atomic,.completeFileProtectionUnlessOpen]) }
            try data.write(to: file,options: [.atomic,.completeFileProtectionUnlessOpen]); state = next; return true
        } catch { self.error = "Could not save nutrition: \(error.localizedDescription)"; return false }
    }
    @discardableResult func log(_ food: FoodItem,grams: Double,date: Date,meal: FoodMeal) -> Bool {
        guard remember(food) else { return false }
        return log([FoodLogEntry(day: NutritionDay.key(date),meal: meal,foodID: food.id,name: food.name,grams: grams,macros: food.nutrition(grams: grams),source: food.source)])
    }
    @discardableResult func log(_ entries: [FoodLogEntry]) -> Bool { var next = state; next.entries += entries; return commit(next) }
    @discardableResult func update(_ entry: FoodLogEntry) -> Bool { var next = state; guard let i = next.entries.firstIndex(where: { $0.id == entry.id }) else { return false }; next.entries[i] = entry; return commit(next) }
    @discardableResult func remove(_ id: String) -> Bool { var next = state; next.entries.removeAll { $0.id == id }; return commit(next) }
    @discardableResult func saveFood(_ food: FoodItem) -> Bool { var next = state; next.customFoods.removeAll { $0.id == food.id }; next.customFoods.insert(food,at: 0); return commit(next) }
    @discardableResult func removeFood(_ id: String) -> Bool { var next = state; next.customFoods.removeAll { $0.id == id }; next.favorites.removeAll { $0 == id }; return commit(next) }
    func favorite(_ id: String) { var next = state; if next.favorites.contains(id) { next.favorites.removeAll { $0 == id } } else { next.favorites.append(id) }; _ = commit(next) }
    @discardableResult func goals(_ goals: NutritionGoals) -> Bool { var next = state; next.goals = goals; return commit(next) }
    func export() throws -> URL {
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("Workouts-Nutrition-\(NutritionDay.key(Date())).json")
        try JSONEncoder().encode(state).write(to: url,options: .atomic); return url
    }
    func importBackup(_ url: URL) {
        let access = url.startAccessingSecurityScopedResource(); defer { if access { url.stopAccessingSecurityScopedResource() } }
        do {
            let data = try Data(contentsOf: url); guard data.count <= 40_000_000 else { throw NutritionFailure.invalid }
            let imported = try JSONDecoder().decode(NutritionState.self,from: data); guard imported.valid else { throw NutritionFailure.invalid }
            var next = state
            let ids = Set(next.entries.map(\.id)); next.entries += imported.entries.filter { !ids.contains($0.id) }
            let foods = Set(next.customFoods.map(\.id)); next.customFoods += imported.customFoods.filter { !foods.contains($0.id) }
            var cached = next.cachedFoods ?? []; let cachedIDs = Set(cached.map(\.id)); cached += (imported.cachedFoods ?? []).filter { !cachedIDs.contains($0.id) }; next.cachedFoods = Array(cached.prefix(5000));
            next.favorites = Array(Set(next.favorites + imported.favorites)); if next.goals == nil { next.goals = imported.goals }; _ = commit(next)
        } catch { self.error = "That file is not a valid nutrition backup. Nothing was imported." }
    }
}
enum NutritionFailure: LocalizedError {
    case invalid
    var errorDescription: String? { "Invalid nutrition data." }
}
