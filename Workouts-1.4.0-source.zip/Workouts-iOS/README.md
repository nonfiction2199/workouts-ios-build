# Workouts for iPhone

Native SwiftUI app for iOS 17+, with an offline JavaScriptCore workout engine.
This is an independent personal app, not MacroFactor and not affiliated with it.

**Status:** Source project and cloud build workflows prepared. The JavaScript
engine and bridge tests pass. An Xcode compile, simulator UI check, and signed
installation still need to run. This ZIP is source code, not an installable IPA.

## Included

- Native dashboard, workout/program screens, exercise library and logger.
- Existing independent progression engine, 945 exercises, working-set tracking,
  load/rep/RIR guidance, manual overrides, periodization and deloads.
- Centered front/back muscle map with volume contributions and muscle details.
- Offline workout storage, atomic writes and a previous-file checkpoint.
- JSON import from the existing web app, merge by session ID, workout export.
- Haptics on workout/shortcut actions and setting changes; no tab/dashboard haptics.
- Native rest countdown and optional local notification when the rest ends.
- Device-only bodyweight/measurement records and Front/Side/Back progress photos.
- Dark/light/system appearance. Existing dumbbell icon, no added splash animation.
- Signulous-oriented unsigned device IPA build, stable bundle ID and versions.

## What is not included

No automatic cloud sync with the web app. Export its JSON first, then use
More → Import Workout Backup. No HealthKit, Apple Watch, remote push service,
Live Activities or automatic OTA updates. This first native version uses pounds.
The interface follows the supplied references but has not yet been verified
pixel-for-pixel in an iPhone simulator. Exercise programming, search, analytics
and some editing options differ from the web version and the original app.

Weight/measurement records and progress photos currently stay only on the
phone; workout JSON backups do not contain them. Keep original photos in Photos.
Do not delete the app to update it.

## Build from Windows using Codemagic

1. Put the **contents** of this folder in a new private GitHub repository.
   `project.yml`, `codemagic.yaml`, `VERSION` and `package.json` belong at its root.
   Include `.github` if using GitHub Actions. Never upload `node_modules` or build output.
2. Connect that repository to Codemagic. Select the workflow defined in
   `codemagic.yaml`: **Workouts — unsigned IPA for Signulous**.
3. Run the workflow. It installs dependencies, runs 31 tests, bundles the
   engine, generates the Xcode project and builds a device ARM64 app.
4. Download the `build/Workouts-1.0.0-<build>.ipa` artifact after a successful run.
   A `.sha256` checksum and the build log are also generated.

No Apple developer certificate or provisioning profile goes into this build.
Signulous handles the signing after compilation. This workflow does not use
`xcodebuild -exportArchive`, which would require signing configuration.
Use included free build minutes and avoid enabling paid overages if you want
this route to stay free. Account terms and available allowances may change.

## Alternative: GitHub Actions

The included `.github/workflows/ios-ipa.yml` runs on a hosted macOS runner.
In your repository: Actions → Build iPhone IPA → Run workflow. Download the
**Workouts-Signulous** artifact, unzip it, then upload the enclosed IPA to Signulous.
The workflow can also be triggered by pushing a version tag such as `v1.0.1`.
Private repository runner usage counts toward your account's included allowance.

## Sign and install

1. Open Signulous on your registered iPhone and choose its custom IPA upload.
2. Select the compiled `.ipa`, not this project ZIP or the GitHub artifact ZIP.
3. Keep the app name **Workouts** and bundle identifier **app.sudais.workouts**.
4. Sign and install using your existing Signulous account.
5. Open Workouts. Import your web backup, or create a program.
6. To get rest alerts, enable More → Preferences → Notify when rest finishes.

The build is unsigned by design. Installation cannot work until Signulous signs
it for your device. Signing availability and certificate changes are managed by
Signulous, not by this app.

## New updates

- Edit the app source and raise `VERSION`, e.g. `1.0.1`.
- Keep `PRODUCT_BUNDLE_IDENTIFIER` unchanged at **app.sudais.workouts**.
- Run the same build workflow and get the new IPA.
- Export a workout backup before updating.
- Use the same Signulous signing/customization settings, without Duplicate App.
- Install over the old app; **do not uninstall first**.

The default build number is UTC days since 2020-01-01, hour and minute, so it
increases across both CI providers. `WORKOUTS_BUILD_NUMBER` may override it in
`1234.12.34` format. App data stays in Application Support and is not bundled
into the IPA. Compatible in-place updates preserve the local app container;
certificate or identifier changes can disrupt that, so retain your backups.

## Development

```sh
npm ci
npm test
npm run build:engine
```

On a Mac with Xcode and XcodeGen:

```sh
brew install xcodegen
bash Scripts/build-ipa.sh
```

To inspect in Simulator, run `xcodegen generate`, open `Workouts.xcodeproj`,
select an iPhone simulator and run. The shared scheme is Workouts.
The engine is bundled in Resources/engine.js; no downloaded executable code,
remote web UI, backend account or internet connection is needed to log workouts.

## Validation still required on Mac/iPhone

- Compile the SwiftUI target and resolve any compiler/SDK issues.
- Launch on a current iPhone simulator; inspect narrow and large screens.
- Create/import program, log an edited set, minimize/reopen, finish, confirm levels.
- Relaunch, export/import and verify data survives an in-place second-version install.
- Confirm only the intended actions vibrate on a real iPhone.
- Enable alerts, complete a set, background/lock, confirm one rest notification.
- Select/save all three photo positions and confirm persistence after relaunch.

See `Engine/README.md` for the independent progression model. The exercise data
is derived from the existing app's public-domain catalogue plus its additions;
font and catalogue notices are in `Workouts/Resources`.
