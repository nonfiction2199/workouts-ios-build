#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
DEVICE="$(xcrun simctl list devices available -j | python3 -c 'import json,sys; d=json.load(sys.stdin); phones=[x for v in d["devices"].values() for x in v if "iPhone" in x["name"]]; print(next((x["udid"] for x in phones if "Pro Max" in x["name"]),phones[0]["udid"]))')"
xcodebuild test -project Workouts.xcodeproj -scheme Workouts -configuration Debug \
  -destination "platform=iOS Simulator,id=$DEVICE" -derivedDataPath build/UITests \
  -only-testing:WorkoutsUITests/NutritionFlowTests -only-testing:WorkoutsUITests/ExerciseFlowTests CODE_SIGNING_ALLOWED=NO \
  > build/nutrition-ui.log 2>&1
xcrun simctl shutdown "$DEVICE" || true
