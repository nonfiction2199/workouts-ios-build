#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p build
python3 Scripts/check-food-catalog.py
npm ci --prefix NutritionService --omit=optional --ignore-scripts
node --test NutritionService/*.test.mjs
swiftc -parse-as-library Workouts/NutritionModels.swift Workouts/FoodNutritionResolver.swift Workouts/NutritionStore.swift Workouts/FoodDatabase.swift Workouts/InternationalFoodService.swift Tests/NutritionTests.swift -lsqlite3 -o build/nutrition-tests
swiftc -parse-as-library Workouts/NutritionModels.swift Workouts/FoodNutritionResolver.swift Workouts/NutritionStore.swift Workouts/FoodDatabase.swift Workouts/InternationalFoodService.swift Tests/FoodResolutionTests.swift -lsqlite3 -o build/food-resolution-tests
build/food-resolution-tests
build/nutrition-tests

swiftc -parse-as-library Workouts/Models.swift Workouts/ExerciseSearchRanking.swift Tests/ExerciseSearchTests.swift -o build/exercise-search-tests
build/exercise-search-tests
